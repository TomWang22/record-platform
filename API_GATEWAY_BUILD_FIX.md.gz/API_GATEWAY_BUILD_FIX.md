# API Gateway Build Fix

## Issue
Docker build failed when run from `services/api-gateway` directory:
```
ERROR: failed to build: failed to solve: failed to compute cache key: 
failed to calculate checksum of ref ... "/proto": not found
```

## Root Cause
The Dockerfile expects files from the repository root:
- `package.json`, `pnpm-workspace.yaml`, `pnpm-lock.yaml`, `tsconfig.base.json`
- `services/common/`
- `proto/`

But the build command used `services/api-gateway` as the build context:
```bash
docker build -t api-gateway:dev services/api-gateway  # ❌ Wrong context
```

## Solution
Build from the repository root with the Dockerfile path:
```bash
docker build -t api-gateway:dev -f services/api-gateway/Dockerfile .  # ✅ Correct
```

## Changes Included
1. **Increased gRPC Register timeout**: 10s → 20s
   - Location: `services/api-gateway/src/server.ts` line 683
   - Reason: Register calls take ~11.6s (password hashing, DB writes, JWT generation)
   - Fix: Prevents "gRPC call Register timed out after 10000ms" errors

## Deployment
```bash
# Rebuild image
docker build -t api-gateway:dev -f services/api-gateway/Dockerfile .

# Restart deployment
kubectl rollout restart deployment/api-gateway -n record-platform

# Check status
kubectl rollout status deployment/api-gateway -n record-platform
```

## Testing
After deployment, test the Register endpoint:
```bash
./scripts/test-microservices-http2-http3.sh
```

Expected result: Register calls should no longer timeout.

