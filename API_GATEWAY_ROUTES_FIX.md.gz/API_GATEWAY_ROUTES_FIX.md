# API Gateway Routes Fix

## Issues Found
1. **Social Service Routes Missing**:
   - `/forum/posts/:postId/attachments` (POST, GET)
   - `/forum/comments/:commentId/attachments` (POST)
   - `/messages/:messageId/attachments` (POST)
   - `/messages/groups/:groupId/leave` (DELETE)

2. **Shopping Service Routes Missing**:
   - `/cart/checkout` (POST)
   - `/orders` (GET)
   - `/orders/:orderId` (GET)
   - `/history/purchases` (GET)
   - `/resell/purchases` (GET)
   - `/resell/purchases/:purchaseId` (POST)
   - `/history/search` (POST)

3. **Route Path Mismatch**:
   - Test script calls `/api/cart`, `/api/orders`, etc.
   - API gateway had `/shopping/cart`, `/shopping/orders`, etc.
   - Added route aliases to support both paths

## Fixes Applied

### Social Service Routes
Added HTTP proxy routes for:
- Forum post attachments (POST, GET)
- Forum comment attachments (POST)
- Message attachments (POST)
- Leave group chat (DELETE)

All routes proxy to `http://social-service:4006` with proper path rewriting.

### Shopping Service Routes
Added HTTP proxy routes for:
- Cart checkout (`/shopping/cart/checkout` → `/cart/checkout`)
- Orders (`/shopping/orders` → `/orders`)
- Order details (`/shopping/orders/:orderId` → `/orders/:orderId`)
- Purchase history (`/shopping/history/purchases` → `/history/purchases`)
- Resell purchases (`/shopping/resell/purchases` → `/resell/purchases`)
- Resell purchase (`/shopping/resell/purchases/:purchaseId` → `/resell/:purchaseId`)
- Search history (`/shopping/history/search` → `/history/searches`)

### Route Aliases
Added route aliases for test script compatibility:
- `/cart` → proxies to shopping-service `/cart`
- `/orders` → proxies to shopping-service `/orders`
- `/history` → proxies to shopping-service `/history`
- `/resell` → proxies to shopping-service `/resell`

This allows the test script to use `/api/cart` (which becomes `/cart` after `/api` prefix removal) and still reach the shopping service.

## Testing
After deployment, run:
```bash
./scripts/test-microservices-http2-http3.sh
```

Expected results:
- ✅ Social service attachment routes should work (Tests 9h, 9i, 9j)
- ✅ Leave group chat should work (Test 9k)
- ✅ Shopping cart checkout should work (Test 13c)
- ✅ Shopping orders should work (Tests 13d, 13e)
- ✅ Purchase history should work (Test 13f)
- ✅ Resell functionality should work (Tests 13g, 13h)
- ✅ Search history should work (Test 13i)

