# Auction Monitor - Data Pipeline Architecture & Implementation Plan

## Executive Summary

This document outlines the comprehensive data pipeline architecture for the Auction Monitor service, designed to ingest, validate, normalize, and analyze auction data from multiple platforms (eBay, Discogs, Buyee, YahooJP, CarousellHK, RecordCity, etc.) while ensuring data quality before feeding into Analytics Service and Python AI Service.

## Core Problem Statement

**Challenge**: Collect high-quality auction data from diverse sources (APIs + scraping) with varying data formats, rate limits, and reliability, then consolidate into a unified data model for analyticswhat  and AI processing.

**Requirements**:
1. **Multi-Platform Support**: eBay (API), Discogs (API), Buyee (scraping), YahooJP (scraping), CarousellHK (scraping), RecordCity (scraping)
2. **Data Quality**: Validation, normalization, deduplication, confidence scoring
3. **Scalability**: Handle thousands of listings per day, rate limiting, error recovery
4. **Monitoring**: Track data quality metrics, ingestion success rates, platform health
5. **ETL Pipeline**: Extract → Transform → Load with proper staging and validation

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Data Sources (External Platforms)                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │   eBay API   │  │ Discogs API  │  │  Buyee Web   │  │ YahooJP Web  │ │
│  │  (Official)  │  │  (Official)  │  │  (Scraping)  │  │  (Scraping)  │ │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘ │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │CarousellHK   │  │ RecordCity   │  │  Other       │                      │
│  │  (Scraping)  │  │  (Scraping)  │  │  Sources     │                      │
│  └──────────────┘  └──────────────┘  └──────────────┘                      │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Auction Monitor Service (Ingestion Layer)               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Platform Adapters (Extract)                       │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │                                                                       │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │  │
│  │  │  eBay        │  │  Discogs     │  │  Buyee       │              │  │
│  │  │  Adapter     │  │  Adapter     │  │  Adapter     │              │  │
│  │  │              │  │              │  │  (Puppeteer) │              │  │
│  │  │  - API Client│  │  - API Client│  │  - Scraper   │              │  │
│  │  │  - Rate Limit│  │  - Rate Limit│  │  - Rate Limit│              │  │
│  │  │  - Retry     │  │  - Retry     │  │  - Retry     │              │  │
│  │  │  - Auth      │  │  - Auth     │  │  - Headers   │              │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │  │
│  │                                                                       │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │  │
│  │  │  YahooJP     │  │ CarousellHK  │  │ RecordCity   │              │  │
│  │  │  Adapter     │  │  Adapter     │  │  Adapter     │              │  │
│  │  │  (Puppeteer) │  │  (Puppeteer) │  │  (Puppeteer) │              │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                       │                                      │
│                                       ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Data Normalizer (Transform)                      │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │                                                                       │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │  │
│  │  │  Schema      │  │  Field       │  │  Validation  │              │  │
│  │  │  Mapper      │  │  Normalizer  │  │  Engine      │              │  │
│  │  │              │  │              │  │              │              │  │
│  │  │  - Platform  │  │  - Price     │  │  - Required  │              │  │
│  │  │    → Unified │  │    Conversion│  │    Fields    │              │  │
│  │  │  - Field     │  │  - Currency  │  │  - Data Types│              │  │
│  │  │    Mapping   │  │    Normalize │  │  - Ranges    │              │  │
│  │  │  - Condition │  │  - Date      │  │  - Formats   │              │  │
│  │  │    Mapping   │  │    Parsing   │  │  - Business  │              │  │
│  │  │              │  │  - Text      │  │    Rules     │              │  │
│  │  │              │  │    Clean     │  │              │              │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                       │                                      │
│                                       ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Data Quality Engine                               │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │                                                                       │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │  │
│  │  │  Deduplication│  │  Confidence  │  │  Data        │              │  │
│  │  │  Engine      │  │  Scorer      │  │  Enrichment  │              │  │
│  │  │              │  │              │  │              │              │  │
│  │  │  - Hash      │  │  - Completeness│  │  - Catalog  │              │  │
│  │  │    Matching  │  │  - Accuracy  │  │    Number    │              │  │
│  │  │  - Fuzzy     │  │  - Source    │  │    Lookup    │              │  │
│  │  │    Matching  │  │    Reliability│  │  - Artist   │              │  │
│  │  │  - External  │  │  - Freshness │  │    Normalize │              │  │
│  │  │    ID Check  │  │  - Consistency│  │  - Format    │              │  │
│  │  │              │  │              │  │    Detection │              │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                       │                                      │
│                                       ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Staging Layer (PostgreSQL)                       │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │                                                                       │  │
│  │  auction_monitor.raw_listings (staging)                              │  │
│  │  - Raw data from all platforms                                       │  │
│  │  - Validation status, quality scores                                │  │
│  │  - Processing metadata (source, timestamp, errors)                   │  │
│  │                                                                       │  │
│  │  auction_monitor.normalized_listings (validated)                     │  │
│  │  - Unified schema, validated data                                   │  │
│  │  - Confidence scores, enrichment data                               │  │
│  │  - Ready for Analytics Service                                      │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Analytics Service (Data Science Core)                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Data Processing Pipeline                          │  │
│  ├──────────────────────────────────────────────────────────────────────┤  │
│  │                                                                       │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │  │
│  │  │  Statistical │  │  Time-Series│  │  Price       │              │  │
│  │  │  Analysis    │  │  Analysis   │  │  Percentiles │              │  │
│  │  │              │  │              │  │              │              │  │
│  │  │  - Aggregates│  │  - Trends   │  │  - p25, p50, │              │  │
│  │  │  - Correlations│  │  - Seasonal │  │    p75, p95  │              │  │
│  │  │  - Outliers  │  │  - Patterns │  │  - Confidence │              │  │
│  │  │  - Distributions│ │  - Forecasts│  │    Intervals │              │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                       │                                      │
│                                       ▼                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Clean Data Store (PostgreSQL)                    │  │
│  ├──────────────────────────────────────────────────────────────────────┤
│  │                                                                       │  │
│  │  analytics.price_snapshots (time-series)                            │  │
│  │  analytics.price_history (historical)                               │  │
│  │  analytics.market_trends (aggregated)                               │  │
│  │  analytics.confidence_metrics (data quality)                         │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Python AI Service (ML/AI Layer)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  - Consumes clean, validated data from Analytics Service                    │
│  - ML models trained on high-quality data                                  │
│  - Predictions, recommendations, content generation                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Platform-Specific Implementation Details

### 1. eBay (Official API)

**API Access:**
- **Finding API**: Search listings, completed items
- **Browse API**: Item details, images, seller info
- **Trading API**: User-specific data (requires OAuth)

**Implementation:**
```typescript
// services/auction-monitor/src/platforms/ebay/adapter.ts
class eBayAdapter {
  private apiClient: eBayFindingAPI
  private rateLimiter: RateLimiter
  
  async searchListings(criteria: SearchCriteria): Promise<RawListing[]> {
    // Rate limit: 5000 calls/day (free tier)
    // Implement exponential backoff
    // Cache results for 5-15 minutes
  }
  
  async getListingDetails(listingId: string): Promise<RawListing> {
    // Browse API for detailed info
  }
  
  async getCompletedSales(criteria: SearchCriteria): Promise<CompletedSale[]> {
    // Completed Items API for historical data
  }
}
```

**Data Quality:**
- ✅ **High**: Official API, structured data
- ✅ **Reliability**: 99.9% uptime, rate limits documented
- ✅ **Completeness**: Rich metadata (seller feedback, shipping, images)

### 2. Discogs (Official API)

**API Access:**
- **Database API**: Release information, catalog numbers
- **Marketplace API**: Current listings, price history
- **Rate Limit**: 60 requests/minute (free tier)

**Implementation:**
```typescript
class DiscogsAdapter {
  private apiClient: DiscogsAPI
  private rateLimiter: RateLimiter
  
  async searchReleases(query: string): Promise<Release[]> {
    // Database API for catalog info
  }
  
  async getPriceHistory(releaseId: number): Promise<PriceHistory[]> {
    // Marketplace API for price data
  }
  
  async getCurrentListings(releaseId: number): Promise<RawListing[]> {
    // Marketplace API for active listings
  }
}
```

**Data Quality:**
- ✅ **High**: Official API, music-focused
- ✅ **Completeness**: Catalog numbers, formats, conditions standardized
- ⚠️ **Limitation**: Price history may be incomplete (user-submitted)

### 3. Buyee (Web Scraping)

**Challenges:**
- No official API
- Requires proxy service integration
- Japanese language content
- Dynamic content (JavaScript rendering)

**Implementation:**
```typescript
class BuyeeAdapter {
  private browser: PuppeteerBrowser
  private rateLimiter: RateLimiter
  
  async searchListings(criteria: SearchCriteria): Promise<RawListing[]> {
    // Puppeteer for JavaScript rendering
    // Respect robots.txt, rate limiting
    // Handle CAPTCHAs (manual intervention or CAPTCHA service)
  }
  
  async getListingDetails(url: string): Promise<RawListing> {
    // Scrape individual listing page
    // Extract: title, price, images, seller, shipping
  }
  
  private async extractProxyFees(listing: RawListing): Promise<ProxyFees> {
    // Calculate Buyee proxy fees (10% + consolidation + shipping)
  }
}
```

**Data Quality:**
- ⚠️ **Medium**: Scraping reliability, HTML structure changes
- ⚠️ **Completeness**: May miss some fields, requires parsing
- ✅ **Enrichment**: Can calculate total cost (item + proxy + shipping)

**ToS Compliance:**
- Respect `robots.txt`
- Rate limiting (max 1 request/second)
- User-Agent identification
- Consider official partnership if available

### 4. YahooJP Auctions (Web Scraping)

**Challenges:**
- No official API
- Japanese language only
- Requires translation for international users
- Proxy service required for international buyers

**Implementation:**
```typescript
class YahooJPAdapter {
  private browser: PuppeteerBrowser
  private translator: TranslationService
  
  async searchListings(criteria: SearchCriteria): Promise<RawListing[]> {
    // Scrape YahooJP auction search
    // Translate titles/descriptions (optional, can store both)
    // Extract: title, price (JPY), images, seller rating, time remaining
  }
  
  async getListingDetails(url: string): Promise<RawListing> {
    // Scrape auction detail page
    // Extract bid history, watchers, shipping options
  }
}
```

**Data Quality:**
- ⚠️ **Medium**: Scraping reliability
- ⚠️ **Language**: Requires translation for non-Japanese users
- ✅ **Coverage**: Large marketplace, many rare items

### 5. CarousellHK (Web Scraping)

**Challenges:**
- No official API
- Hong Kong marketplace
- Mobile-first design (may need mobile user agent)
- Regional restrictions

**Implementation:**
```typescript
class CarousellHKAdapter {
  private browser: PuppeteerBrowser
  
  async searchListings(criteria: SearchCriteria): Promise<RawListing[]> {
    // Scrape CarousellHK search
    // Handle mobile/desktop views
    // Extract: title, price (HKD), images, seller location
  }
}
```

**Data Quality:**
- ⚠️ **Medium**: Scraping reliability
- ✅ **Coverage**: Good for Asian market items
- ⚠️ **Currency**: HKD, requires conversion

### 6. RecordCity (Web Scraping)

**Challenges:**
- Multiple sites: RecordCity UK, US, EU
- No official API
- Different domains/schemas per region
- May have anti-bot measures

**Implementation:**
```typescript
class RecordCityAdapter {
  private regions = ['uk', 'us', 'eu']
  private browsers: Map<string, PuppeteerBrowser>
  
  async searchListings(criteria: SearchCriteria, region: string): Promise<RawListing[]> {
    // Scrape region-specific site
    // Extract: title, price (region currency), condition, format
  }
  
  async getAllRegions(criteria: SearchCriteria): Promise<RawListing[]> {
    // Parallel scraping across all regions
    // Merge results with region metadata
  }
}
```

**Data Quality:**
- ⚠️ **Medium**: Scraping reliability, multiple sites
- ✅ **Coverage**: Good for European/US market
- ⚠️ **Consistency**: Different schemas per region

## Unified Data Model

### Core Schema (PostgreSQL)

```sql
-- Staging: Raw data from platforms
CREATE TABLE auction_monitor.raw_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform VARCHAR(50) NOT NULL,  -- 'ebay', 'discogs', 'buyee', etc.
  external_id VARCHAR(255) NOT NULL,  -- Platform-specific ID
  url TEXT NOT NULL,
  raw_data JSONB NOT NULL,  -- Original platform data
  ingestion_status VARCHAR(20) DEFAULT 'pending',  -- pending, processing, validated, failed
  validation_errors JSONB,  -- Array of validation errors
  ingested_at TIMESTAMPTZ DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  UNIQUE(platform, external_id)
);

-- Normalized: Unified schema
CREATE TABLE auction_monitor.normalized_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  raw_listing_id UUID REFERENCES auction_monitor.raw_listings(id),
  platform VARCHAR(50) NOT NULL,
  external_id VARCHAR(255) NOT NULL,
  url TEXT NOT NULL,
  
  -- Core Fields (Required)
  title TEXT NOT NULL,
  description TEXT,
  current_price DECIMAL(10,2) NOT NULL,
  currency VARCHAR(3) NOT NULL,  -- ISO 4217
  condition VARCHAR(50),  -- Normalized: 'Mint', 'Near Mint', 'Very Good', etc.
  format VARCHAR(50),  -- 'LP', '7"', 'CD', 'Cassette', etc.
  
  -- Catalog Information
  artist VARCHAR(255),
  album VARCHAR(255),
  catalog_number VARCHAR(100),
  label VARCHAR(255),
  year INTEGER,
  
  -- Seller Information
  seller_id VARCHAR(255),
  seller_name VARCHAR(255),
  seller_feedback_score INTEGER,
  seller_location VARCHAR(255),
  
  -- Listing Details
  listing_type VARCHAR(50),  -- 'auction', 'buy_it_now', 'best_offer'
  starting_price DECIMAL(10,2),
  buy_it_now_price DECIMAL(10,2),
  bid_count INTEGER DEFAULT 0,
  watcher_count INTEGER DEFAULT 0,
  time_remaining INTERVAL,
  end_date TIMESTAMPTZ,
  
  -- Shipping & Costs
  shipping_cost DECIMAL(10,2),
  shipping_location VARCHAR(255),
  estimated_total DECIMAL(10,2),  -- price + shipping + fees
  
  -- Proxy Service (for Buyee, YahooJP)
  proxy_service VARCHAR(50),  -- 'buyee', 'zenmarket', etc.
  proxy_fee DECIMAL(10,2),
  consolidation_fee DECIMAL(10,2),
  international_shipping DECIMAL(10,2),
  
  -- Images
  images JSONB,  -- Array of image URLs
  thumbnail_url TEXT,
  
  -- Restrictions
  location_restrictions JSONB,  -- Array of allowed/blocked countries
  payment_restrictions JSONB,  -- Payment methods required
  review_restrictions JSONB,  -- Min feedback, account age, etc.
  
  -- Data Quality
  confidence_score DECIMAL(3,2) DEFAULT 0.5,  -- 0.0 to 1.0
  completeness_score DECIMAL(3,2) DEFAULT 0.5,
  data_quality_flags JSONB,  -- Array of quality issues
  
  -- Enrichment
  discogs_release_id INTEGER,  -- Matched Discogs release
  catalog_match_confidence DECIMAL(3,2),
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(platform, external_id)
);

-- Indexes for performance
CREATE INDEX idx_normalized_listings_platform ON auction_monitor.normalized_listings(platform);
CREATE INDEX idx_normalized_listings_catalog ON auction_monitor.normalized_listings(catalog_number);
CREATE INDEX idx_normalized_listings_artist ON auction_monitor.normalized_listings(artist);
CREATE INDEX idx_normalized_listings_price ON auction_monitor.normalized_listings(current_price);
CREATE INDEX idx_normalized_listings_confidence ON auction_monitor.normalized_listings(confidence_score);
CREATE INDEX idx_normalized_listings_updated ON auction_monitor.normalized_listings(updated_at);

-- Price History (Time-Series)
CREATE TABLE auction_monitor.price_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  normalized_listing_id UUID REFERENCES auction_monitor.normalized_listings(id),
  snapshot_at TIMESTAMPTZ DEFAULT NOW(),
  price DECIMAL(10,2) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  bid_count INTEGER,
  watcher_count INTEGER,
  time_remaining INTERVAL,
  status VARCHAR(50),  -- 'active', 'ended', 'sold', 'unsold'
  metadata JSONB
);

CREATE INDEX idx_price_history_listing ON auction_monitor.price_history(normalized_listing_id, snapshot_at DESC);
CREATE INDEX idx_price_history_snapshot ON auction_monitor.price_history(snapshot_at DESC);

-- User Watches
CREATE TABLE auction_monitor.user_watches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  search_criteria JSONB NOT NULL,  -- Artist, title, format, condition, price range
  platforms JSONB NOT NULL,  -- Array of platforms to monitor
  notification_preferences JSONB,  -- Email, in-app, push
  status VARCHAR(20) DEFAULT 'active',  -- active, paused, expired
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  last_checked_at TIMESTAMPTZ
);

-- Watch Matches (listings that match user watches)
CREATE TABLE auction_monitor.watch_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  watch_id UUID REFERENCES auction_monitor.user_watches(id),
  normalized_listing_id UUID REFERENCES auction_monitor.normalized_listings(id),
  match_score DECIMAL(3,2),  -- How well it matches criteria
  notified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(watch_id, normalized_listing_id)
);

-- Platform Health Monitoring
CREATE TABLE auction_monitor.platform_health (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform VARCHAR(50) NOT NULL,
  check_type VARCHAR(50) NOT NULL,  -- 'api', 'scraping', 'rate_limit'
  status VARCHAR(20) NOT NULL,  -- 'healthy', 'degraded', 'down'
  response_time_ms INTEGER,
  error_message TEXT,
  checked_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(platform, check_type, checked_at)
);

-- Data Quality Metrics
CREATE TABLE auction_monitor.data_quality_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  platform VARCHAR(50) NOT NULL,
  metric_date DATE NOT NULL,
  total_listings INTEGER DEFAULT 0,
  validated_listings INTEGER DEFAULT 0,
  failed_validations INTEGER DEFAULT 0,
  avg_confidence_score DECIMAL(3,2),
  avg_completeness_score DECIMAL(3,2),
  duplicate_count INTEGER DEFAULT 0,
  enrichment_rate DECIMAL(5,2),  -- % with catalog number match
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(platform, metric_date)
);
```

## Data Pipeline Implementation

### Phase 1: Extraction Layer

**Platform Adapters Pattern:**
```typescript
// services/auction-monitor/src/platforms/base/adapter.ts
interface PlatformAdapter {
  platform: string
  search(criteria: SearchCriteria): Promise<RawListing[]>
  getDetails(externalId: string): Promise<RawListing>
  getCompletedSales(criteria: SearchCriteria): Promise<CompletedSale[]>
  healthCheck(): Promise<PlatformHealth>
}

// services/auction-monitor/src/platforms/ebay/adapter.ts
class eBayAdapter implements PlatformAdapter {
  platform = 'ebay'
  private client: eBayAPIClient
  private rateLimiter: RateLimiter
  
  async search(criteria: SearchCriteria): Promise<RawListing[]> {
    await this.rateLimiter.acquire()
    try {
      const results = await this.client.findItemsAdvanced({
        keywords: criteria.query,
        priceRange: criteria.priceRange,
        // ... other criteria
      })
      return this.mapToRawListings(results)
    } catch (error) {
      await this.handleError(error)
      throw error
    }
  }
}

// services/auction-monitor/src/platforms/buyee/adapter.ts
class BuyeeAdapter implements PlatformAdapter {
  platform = 'buyee'
  private browser: PuppeteerBrowser
  private rateLimiter: RateLimiter
  
  async search(criteria: SearchCriteria): Promise<RawListing[]> {
    await this.rateLimiter.acquire()
    const page = await this.browser.newPage()
    try {
      await page.goto(`https://buyee.jp/...`, { waitUntil: 'networkidle0' })
      const listings = await page.evaluate(() => {
        // Extract data from DOM
      })
      return this.mapToRawListings(listings)
    } finally {
      await page.close()
    }
  }
}
```

**Rate Limiting Strategy:**
```typescript
// services/auction-monitor/src/lib/rate-limiter.ts
class PlatformRateLimiter {
  private limits: Map<string, RateLimit>
  
  constructor() {
    this.limits = new Map([
      ['ebay', { requests: 5000, window: '24h', strategy: 'token-bucket' }],
      ['discogs', { requests: 60, window: '1m', strategy: 'sliding-window' }],
      ['buyee', { requests: 1, window: '1s', strategy: 'fixed-window' }],
      ['yahoojp', { requests: 1, window: '2s', strategy: 'fixed-window' }],
    ])
  }
  
  async acquire(platform: string): Promise<void> {
    const limit = this.limits.get(platform)
    // Implement rate limiting logic
    // Use Redis for distributed rate limiting
  }
}
```

### Phase 2: Transformation Layer

**Schema Normalization:**
```typescript
// services/auction-monitor/src/normalizers/base.ts
interface NormalizedListing {
  // Unified schema fields
}

class ListingNormalizer {
  normalize(raw: RawListing, platform: string): NormalizedListing {
    const mapper = this.getMapper(platform)
    return {
      title: mapper.extractTitle(raw),
      price: this.normalizePrice(raw.price, raw.currency),
      condition: this.normalizeCondition(raw.condition, platform),
      // ... map all fields
    }
  }
  
  private normalizeCondition(condition: string, platform: string): string {
    // Map platform-specific conditions to unified values
    // eBay: 'New', 'Used' → 'Mint', 'Near Mint', etc.
    // Discogs: Already standardized
    // Buyee: Japanese terms → English
  }
  
  private normalizePrice(price: number, currency: string): { amount: number, currency: string } {
    // Convert to base currency (USD) for comparison
    // Store original currency for display
  }
}
```

**Data Validation:**
```typescript
// services/auction-monitor/src/validators/listing-validator.ts
class ListingValidator {
  validate(normalized: NormalizedListing): ValidationResult {
    const errors: string[] = []
    const warnings: string[] = []
    
    // Required fields
    if (!normalized.title) errors.push('Title is required')
    if (!normalized.current_price) errors.push('Price is required')
    if (!normalized.url) errors.push('URL is required')
    
    // Data type validation
    if (normalized.current_price <= 0) errors.push('Price must be positive')
    if (normalized.bid_count < 0) errors.push('Bid count cannot be negative')
    
    // Business rules
    if (normalized.buy_it_now_price && normalized.buy_it_now_price < normalized.current_price) {
      warnings.push('Buy it now price is less than current price')
    }
    
    // Completeness scoring
    const completeness = this.calculateCompleteness(normalized)
    
    return {
      valid: errors.length === 0,
      errors,
      warnings,
      completeness,
      confidence: this.calculateConfidence(normalized, errors, warnings)
    }
  }
}
```

### Phase 3: Data Quality Engine

**Deduplication:**
```typescript
// services/auction-monitor/src/quality/deduplicator.ts
class ListingDeduplicator {
  async findDuplicates(listing: NormalizedListing): Promise<NormalizedListing[]> {
    // Strategy 1: Exact match (platform + external_id)
    const exact = await this.findByExternalId(listing.platform, listing.external_id)
    if (exact) return [exact]
    
    // Strategy 2: URL matching (normalized URLs)
    const urlMatch = await this.findByUrl(this.normalizeUrl(listing.url))
    if (urlMatch) return [urlMatch]
    
    // Strategy 3: Fuzzy matching (title + price + seller)
    const fuzzy = await this.findFuzzyMatches({
      title: listing.title,
      price: listing.current_price,
      seller: listing.seller_id,
      threshold: 0.85  // 85% similarity
    })
    
    return fuzzy
  }
  
  private async findFuzzyMatches(criteria: FuzzyMatchCriteria): Promise<NormalizedListing[]> {
    // Use PostgreSQL pg_trgm for fuzzy text matching
    // Compare titles, prices, seller info
    // Return matches above threshold
  }
}
```

**Confidence Scoring:**
```typescript
// services/auction-monitor/src/quality/confidence-scorer.ts
class ConfidenceScorer {
  calculate(listing: NormalizedListing, validation: ValidationResult): number {
    let score = 1.0
    
    // Completeness penalty
    score *= validation.completeness
    
    // Source reliability
    const sourceReliability = this.getSourceReliability(listing.platform)
    score *= sourceReliability
    
    // Data freshness
    const freshness = this.calculateFreshness(listing.updated_at)
    score *= freshness
    
    // Enrichment bonus
    if (listing.discogs_release_id) {
      score *= 1.1  // 10% bonus for catalog match
    }
    
    // Validation errors penalty
    score *= Math.max(0, 1 - (validation.errors.length * 0.1))
    
    return Math.min(1.0, Math.max(0.0, score))
  }
  
  private getSourceReliability(platform: string): number {
    const reliability = {
      'ebay': 0.95,      // Official API, high reliability
      'discogs': 0.95,   // Official API, high reliability
      'buyee': 0.75,     // Scraping, medium reliability
      'yahoojp': 0.75,   // Scraping, medium reliability
      'carousellhk': 0.70, // Scraping, lower reliability
      'recordcity': 0.70,  // Scraping, lower reliability
    }
    return reliability[platform] || 0.5
  }
}
```

**Data Enrichment:**
```typescript
// services/auction-monitor/src/enrichers/catalog-enricher.ts
class CatalogEnricher {
  async enrich(listing: NormalizedListing): Promise<EnrichedListing> {
    // Try to match with Discogs catalog
    if (listing.catalog_number) {
      const discogsMatch = await this.matchDiscogsRelease(listing.catalog_number)
      if (discogsMatch) {
        listing.discogs_release_id = discogsMatch.id
        listing.catalog_match_confidence = discogsMatch.confidence
        // Enrich with Discogs data
        listing.artist = discogsMatch.artist || listing.artist
        listing.album = discogsMatch.album || listing.album
        listing.format = discogsMatch.format || listing.format
      }
    }
    
    // Fuzzy match if no exact catalog number
    if (!listing.discogs_release_id && listing.artist && listing.album) {
      const fuzzyMatch = await this.fuzzyMatchDiscogs({
        artist: listing.artist,
        album: listing.album,
        format: listing.format
      })
      if (fuzzyMatch) {
        listing.discogs_release_id = fuzzyMatch.id
        listing.catalog_match_confidence = fuzzyMatch.confidence * 0.8  // Lower confidence for fuzzy
      }
    }
    
    return listing
  }
}
```

### Phase 4: Staging & Validation

**Staging Pipeline:**
```typescript
// services/auction-monitor/src/pipeline/staging-pipeline.ts
class StagingPipeline {
  async processRawListing(raw: RawListing): Promise<void> {
    // 1. Store in raw_listings table
    const rawId = await this.storeRaw(raw)
    
    // 2. Normalize
    const normalized = await this.normalizer.normalize(raw, raw.platform)
    
    // 3. Validate
    const validation = await this.validator.validate(normalized)
    
    // 4. Check for duplicates
    const duplicates = await this.deduplicator.findDuplicates(normalized)
    
    // 5. Enrich
    const enriched = await this.enricher.enrich(normalized)
    
    // 6. Calculate confidence
    const confidence = await this.scorer.calculate(enriched, validation)
    enriched.confidence_score = confidence
    
    // 7. Store in normalized_listings (only if validation passes)
    if (validation.valid && confidence >= 0.5) {
      await this.storeNormalized(enriched, rawId)
    } else {
      await this.markAsFailed(rawId, validation.errors)
    }
  }
}
```

## Analytics Service Integration

### Data Flow to Analytics

```typescript
// services/analytics-service/src/ingestion/auction-ingestion.ts
class AuctionDataIngestion {
  async ingestFromAuctionMonitor(): Promise<void> {
    // Poll normalized_listings for new/updated listings
    const newListings = await this.getNewListings()
    
    for (const listing of newListings) {
      // 1. Statistical Analysis
      const stats = await this.calculateStatistics(listing)
      
      // 2. Price Percentiles
      const percentiles = await this.calculatePercentiles(listing)
      
      // 3. Time-Series Storage
      await this.storePriceSnapshot({
        listing_id: listing.id,
        price: listing.current_price,
        timestamp: listing.updated_at,
        metadata: {
          bid_count: listing.bid_count,
          watcher_count: listing.watcher_count,
        }
      })
      
      // 4. Historical Comparison
      const historical = await this.compareWithHistory(listing)
      
      // 5. Store in analytics.price_snapshots
      await this.storeAnalytics({
        listing_id: listing.id,
        statistics: stats,
        percentiles,
        historical_comparison: historical,
        confidence: listing.confidence_score
      })
    }
  }
  
  private async calculatePercentiles(listing: NormalizedListing): Promise<Percentiles> {
    // Find similar items (same catalog number, condition, format)
    const similar = await this.findSimilarListings(listing)
    
    // Calculate percentiles
    return {
      p25: this.percentile(similar.prices, 0.25),
      p50: this.percentile(similar.prices, 0.50),
      p75: this.percentile(similar.prices, 0.75),
      p95: this.percentile(similar.prices, 0.95),
      count: similar.length,
      confidence: similar.length >= 10 ? 'high' : similar.length >= 5 ? 'medium' : 'low'
    }
  }
}
```

## Monitoring & Observability

### Data Quality Metrics

```typescript
// services/auction-monitor/src/monitoring/quality-metrics.ts
class DataQualityMonitor {
  async trackMetrics(platform: string): Promise<void> {
    const metrics = {
      total_ingested: await this.countIngested(platform),
      total_validated: await this.countValidated(platform),
      total_failed: await this.countFailed(platform),
      avg_confidence: await this.avgConfidence(platform),
      avg_completeness: await this.avgCompleteness(platform),
      duplicate_rate: await this.duplicateRate(platform),
      enrichment_rate: await this.enrichmentRate(platform),
    }
    
    // Store in data_quality_metrics table
    await this.storeMetrics(platform, metrics)
    
    // Alert if quality drops
    if (metrics.avg_confidence < 0.7) {
      await this.alert('Low confidence score', { platform, metrics })
    }
  }
}
```

### Platform Health Monitoring

```typescript
// services/auction-monitor/src/monitoring/platform-health.ts
class PlatformHealthMonitor {
  async checkHealth(platform: string): Promise<PlatformHealth> {
    const adapter = this.getAdapter(platform)
    
    try {
      const start = Date.now()
      await adapter.healthCheck()
      const responseTime = Date.now() - start
      
      return {
        platform,
        status: 'healthy',
        responseTime,
        checkedAt: new Date()
      }
    } catch (error) {
      return {
        platform,
        status: 'down',
        error: error.message,
        checkedAt: new Date()
      }
    }
  }
  
  async monitorAll(): Promise<void> {
    const platforms = ['ebay', 'discogs', 'buyee', 'yahoojp', 'carousellhk', 'recordcity']
    
    for (const platform of platforms) {
      const health = await this.checkHealth(platform)
      await this.storeHealth(health)
      
      // Alert if platform is down
      if (health.status === 'down') {
        await this.alert(`Platform ${platform} is down`, health)
      }
    }
  }
}
```

## Implementation Roadmap

### Phase 1: Foundation (Weeks 1-2)
1. ✅ Database schema design and migration
2. ✅ Platform adapter interface and base classes
3. ✅ eBay API adapter (official API)
4. ✅ Discogs API adapter (official API)
5. ✅ Basic normalization and validation
6. ✅ Staging pipeline (raw → normalized)

### Phase 2: Scraping Infrastructure (Weeks 3-4)
1. ✅ Puppeteer setup and browser pool management
2. ✅ Buyee adapter (scraping)
3. ✅ YahooJP adapter (scraping)
4. ✅ Rate limiting and retry logic
5. ✅ Error handling and recovery
6. ✅ CAPTCHA handling strategy

### Phase 3: Data Quality (Weeks 5-6)
1. ✅ Deduplication engine
2. ✅ Confidence scoring
3. ✅ Data enrichment (Discogs catalog matching)
4. ✅ Validation rules engine
5. ✅ Quality metrics tracking
6. ✅ Monitoring dashboards

### Phase 4: Additional Platforms (Weeks 7-8)
1. ✅ CarousellHK adapter
2. ✅ RecordCity adapter (UK, US, EU)
3. ✅ Platform-specific normalization
4. ✅ Multi-region support

### Phase 5: Analytics Integration (Weeks 9-10)
1. ✅ Analytics Service ingestion pipeline
2. ✅ Price percentile calculation
3. ✅ Historical comparison
4. ✅ Time-series storage
5. ✅ Data quality reporting

### Phase 6: Production Hardening (Weeks 11-12)
1. ✅ Error recovery and retry logic
2. ✅ Monitoring and alerting
3. ✅ Performance optimization
4. ✅ Load testing
5. ✅ Documentation

## Technology Stack

### Auction Monitor Service
- **Language**: TypeScript/Node.js
- **Database**: PostgreSQL (auction_monitor schema)
- **Scraping**: Puppeteer (headless Chrome)
- **Queue**: Kafka (for async processing)
- **Cache**: Redis (rate limiting, deduplication)
- **Monitoring**: Prometheus metrics, Grafana dashboards

### Analytics Service
- **Language**: TypeScript/Node.js (can add Python for heavy data science)
- **Database**: PostgreSQL (analytics schema, TimescaleDB for time-series)
- **Libraries**: Can use Python via subprocess or gRPC for Pandas/NumPy
- **Cache**: Redis (frequently accessed analytics)

### Python AI Service
- **Language**: Python
- **Framework**: FastAPI
- **ML**: Hugging Face Transformers, scikit-learn
- **Database**: PostgreSQL (python_ai schema)

## Key Design Decisions

### 1. Staging Layer
**Decision**: Two-stage storage (raw → normalized)
**Rationale**: 
- Allows reprocessing raw data if normalization logic changes
- Enables debugging and data quality analysis
- Preserves original platform data for reference

### 2. Confidence Scoring
**Decision**: Multi-factor confidence score (0.0-1.0)
**Rationale**:
- Helps Analytics Service prioritize high-quality data
- Enables filtering low-confidence data from AI training
- Provides transparency to users

### 3. Platform Adapter Pattern
**Decision**: Interface-based adapter pattern
**Rationale**:
- Easy to add new platforms
- Consistent error handling
- Testable in isolation
- Can swap implementations (API → scraping if API becomes available)

### 4. Rate Limiting Strategy
**Decision**: Platform-specific rate limiters with Redis
**Rationale**:
- Prevents platform blocking
- Respects ToS
- Distributed rate limiting across multiple workers

### 5. Data Quality Before AI
**Decision**: Only feed high-confidence data (≥0.7) to Python AI
**Rationale**:
- Prevents garbage-in-garbage-out
- Better model performance
- Lower training costs

## Next Steps

1. **Start with eBay + Discogs** (official APIs, high reliability)
2. **Build staging pipeline** (raw → normalized → validated)
3. **Implement data quality engine** (confidence scoring, deduplication)
4. **Add Analytics Service integration** (price percentiles, historical data)
5. **Then add scraping platforms** (Buyee, YahooJP, etc.) incrementally
6. **Monitor and iterate** (track quality metrics, improve over time)

This phased approach ensures we have a solid foundation with high-quality data before expanding to more complex scraping scenarios.

