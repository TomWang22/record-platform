# Auth Service Fixes Applied

## Issues Fixed

### 1. ✅ Multiple PrismaClient Instances
**Problem**: 3 separate PrismaClient instances (server.ts, grpc-server.ts, passkey.ts)
- Each creates its own connection pool (~10 connections)
- Total: ~30 connections, causing exhaustion

**Fix**: Created shared PrismaClient module (`lib/prisma.ts`)
- Single instance shared across all modules
- Reduces connection pool usage by 66%

### 2. ✅ No Connection Pool Configuration
**Problem**: PrismaClient created without connection_limit
- Defaults to ~10 connections per instance
- No control over pool size

**Fix**: Added connection pool configuration
- `connection_limit=20` (single shared instance = 20 total connections)
- `pool_timeout=10` (10 second timeout for getting connection from pool)

### 3. ✅ Connection String Format
**Problem**: Using short hostname `postgres-auth-external:5437`
- May cause DNS resolution issues under load

**Fix**: Updated to FQDN `postgres-auth-external.record-platform.svc.cluster.local:5437`

### 4. ✅ Slow Queries
**Problem**: Queries running for 2-3 minutes, blocking connection pool

**Fix**: Killed stuck queries (3 queries terminated)
- Need to investigate root cause (locks, missing indexes, etc.)

## Files Modified

1. **Created**: `services/auth-service/src/lib/prisma.ts`
   - Shared PrismaClient instance with connection pool configuration

2. **Updated**: `services/auth-service/src/server.ts`
   - Uses shared prisma instance

3. **Updated**: `services/auth-service/src/grpc-server.ts`
   - Uses shared prisma instance

4. **Updated**: `services/auth-service/src/routes/passkey.ts`
   - Uses shared prisma instance

5. **Updated**: `infra/k8s/base/config/app-config.yaml`
   - Fixed connection string to use FQDN

## Next Steps

1. **Rebuild auth-service**:
   ```bash
   docker build -t auth-service:dev -f services/auth-service/Dockerfile .
   ```

2. **Redeploy**:
   ```bash
   kubectl -n record-platform rollout restart deployment/auth-service
   ```

3. **Monitor**:
   ```bash
   kubectl -n record-platform logs -f -l app=auth-service
   ```

4. **Verify Connection Pool**:
   ```bash
   docker exec record-platform-postgres-auth-1 psql -U postgres -d records -c "SELECT count(*) FROM pg_stat_activity WHERE datname = 'records';"
   ```

5. **Re-run Load Tests**:
   ```bash
   bash scripts/find-bottlenecks.sh shopping
   bash scripts/run-k6-shopping.sh ramp
   ```

## Expected Improvements

- **Connection Pool**: Reduced from ~30 to 20 connections (single instance)
- **Connection Exhaustion**: Should be resolved
- **Query Performance**: Need to investigate slow queries further
- **Error Rate**: Should decrease significantly

## Additional Recommendations

1. **Add Query Timeouts**: Set statement_timeout in connection string
2. **Monitor Slow Queries**: Set up alerts for queries > 1 second
3. **Database Tuning**: Review PostgreSQL configuration for load
4. **Consider PgBouncer**: For additional connection pooling if needed

