# Auth Service Performance Investigation

## Summary

Investigating auth service Register endpoint performance issues - requests taking 30+ seconds.

## Findings

### Current Performance
- **gRPC Register**: 30-32 seconds per request
- **HTTP Register**: 30+ seconds per request
- **Direct service call**: 32.6 seconds

### Timing Breakdown (Added Logging)

Added detailed timing logs to `grpc-server.ts` Register function:
- SELECT existing user check
- bcrypt.hash operation
- INSERT user operation
- signJwt operation
- Total duration with breakdown

### Potential Causes

1. **Connection Pool Exhaustion**
   - Connection pool increased to 50 (from 20)
   - Pool timeout increased to 30s (from 10s)
   - But requests still taking 30+ seconds

2. **Database Lock Contention**
   - No waiting queries detected (0 locks)
   - 15 active connections (within limits)

3. **bcrypt.hash Performance**
   - bcrypt with cost factor 10 can take 100-200ms
   - But shouldn't take 30 seconds

4. **Network Latency**
   - Connection to `postgres-auth-external:5437`
   - May be slow if external service is overloaded

5. **Prisma Query Performance**
   - Raw SQL queries should be fast
   - But may be waiting for connection from pool

## Changes Made

1. **Added Timing Logs** (`services/auth-service/src/grpc-server.ts`):
   - Log duration of each operation (SELECT, bcrypt, INSERT, signJwt)
   - Log total duration with breakdown

2. **Removed Unnecessary Delays**:
   - Removed connection refresh delay in Authenticate (already removed from HTTP login)
   - Removed 200ms delay in gRPC Authenticate

3. **Connection Pool Configuration**:
   - Increased `connection_limit` to 50
   - Increased `pool_timeout` to 30s

4. **ConfigMap Fix**:
   - Removed `search_path=auth` from POSTGRES_URL_AUTH (was causing psql errors)
   - Applied configmap and restarted service

## Next Steps

1. **Check Timing Logs**: Wait for timing logs to appear to identify bottleneck
2. **Database Performance**: Check if external Postgres is slow
3. **Connection Pool Monitoring**: Monitor active connections during load
4. **bcrypt Optimization**: Consider reducing cost factor or using async bcrypt

## Files Modified

- `services/auth-service/src/grpc-server.ts`: Added timing logs, removed delays
- `services/auth-service/src/lib/prisma.ts`: Increased connection pool
- `infra/k8s/base/config/app-config.yaml`: Fixed POSTGRES_URL_AUTH
