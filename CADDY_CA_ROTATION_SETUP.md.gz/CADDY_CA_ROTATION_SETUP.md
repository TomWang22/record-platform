# Caddy H3 CA Rotation Setup - 100% Zero-Downtime

## Configuration

✅ **Replicas**: 2 (for zero-downtime CA rotation)
✅ **Strategy**: RollingUpdate
  - `maxSurge: 1` - Allow 1 extra pod during update
  - `maxUnavailable: 0` - Keep at least 1 pod available at all times
✅ **Pod Anti-Affinity**: Enabled (prefers different nodes)

## How It Works

### With 1 Node:
- **Normal state**: 1 pod Running, 1 pod Pending (can't bind port 443)
- **During CA rotation**:
  1. Old pod (running) continues serving traffic
  2. New pod starts (pending until old pod terminates)
  3. Old pod terminates gracefully
  4. New pod binds port 443 and becomes ready
  5. **Zero downtime!** ✅

### With Multiple Nodes:
- Both pods run on different nodes
- During rotation: Old pod stays up, new pod starts on different node
- **True zero-downtime** ✅

## Safety Checks Before Testing

Before running test scripts, verify:
1. ✅ At least 1 Caddy pod is Running (1/1 Ready)
2. ✅ Node is Ready
3. ✅ Caddy health endpoint responds (HTTP 200)
4. ✅ Deployment configured for 2 replicas
5. ✅ Strategy is RollingUpdate

## Test Scripts

### Safe to Run:
- `scripts/test-http2-http3-strict-tls.sh` - Tests HTTP/2, HTTP/3, TLS, and CA rotation
- `scripts/test-full-chain-with-rotation.sh` - Full end-to-end test with CA rotation

### What Tests Verify:
- HTTP/2 connectivity
- HTTP/3 connectivity (QUIC)
- Strict TLS (TLS 1.2/1.3 only)
- CA rotation with zero-downtime (100% success rate expected)

## Expected Results

With 2 replicas + RollingUpdate:
- **100% success rate** during CA rotation
- Zero downtime
- Old pod stays up while new pod starts

