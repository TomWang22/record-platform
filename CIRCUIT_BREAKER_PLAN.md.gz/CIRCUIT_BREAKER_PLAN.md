# Circuit Breaker and Rate Limiting Implementation Plan

**Date**: January 6, 2026  
**Author**: Tom

## Overview

This document outlines the plan for implementing circuit breakers and rate limiting for gradual degradation and preventing service overload.

## Current Status

### Existing Circuit Breaker
- ✅ **Python AI Service**: Already has circuit breaker implementation (`services/python-ai-service/app/circuit_breaker.py`)
  - Used for external API calls (eBay, Discogs)
  - States: CLOSED, OPEN, HALF_OPEN
  - Configurable failure thresholds and timeouts

### Database Retry Logic
- ✅ **Listings Service**: Has `withRetry` function for database queries
- ✅ **Shopping Service**: Just added `withRetry` function (needs rebuild/redeploy)

## Implementation Plan

### Phase 1: Circuit Breakers (Before Rate Limiting)

#### 1.1 Shopping Service Database Circuit Breaker
**Priority**: HIGH (503 errors from database timeouts)

**Implementation**:
- Add circuit breaker for database connection pool
- Open circuit after 5 connection failures within 60 seconds
- Half-open state after 30 seconds
- Close circuit after 2 successful queries in half-open state

**Files to Modify**:
- `services/shopping-service/src/lib/db.ts` - Add circuit breaker wrapper
- `services/shopping-service/src/lib/availability.ts` - Use circuit breaker for listings DB queries

**Pattern** (similar to Python AI service):
```typescript
class DatabaseCircuitBreaker {
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private failures: number[] = []; // Timestamps
  private successes: number = 0;
  
  async execute<T>(queryFn: () => Promise<T>): Promise<T | null> {
    if (this.state === 'OPEN') {
      // Check if should transition to half-open
      if (Date.now() - this.openedAt > 30000) {
        this.state = 'HALF_OPEN';
        this.successes = 0;
      } else {
        return null; // Circuit open, skip query
      }
    }
    
    try {
      const result = await queryFn();
      if (this.state === 'HALF_OPEN') {
        this.successes++;
        if (this.successes >= 2) {
          this.state = 'CLOSED';
        }
      }
      return result;
    } catch (err) {
      this.failures.push(Date.now());
      // Clean old failures (outside 60s window)
      this.failures = this.failures.filter(t => Date.now() - t < 60000);
      
      if (this.failures.length >= 5) {
        this.state = 'OPEN';
        this.openedAt = Date.now();
      }
      throw err;
    }
  }
}
```

#### 1.2 API Gateway Circuit Breaker
**Priority**: MEDIUM (prevent cascading failures)

**Implementation**:
- Circuit breaker for upstream service calls
- Open circuit after 5 failures within 60 seconds
- Return 503 Service Unavailable when circuit is open
- Half-open state for testing recovery

**Files to Modify**:
- `services/api-gateway/src/lib/circuit-breaker.ts` (new file)
- `services/api-gateway/src/server.ts` - Use circuit breaker for proxy middleware

#### 1.3 Social Service Circuit Breaker
**Priority**: MEDIUM (Kafka connection failures)

**Implementation**:
- Circuit breaker for Kafka producer/consumer
- Open circuit after Kafka connection failures
- Fallback to in-memory queue when circuit is open

**Files to Modify**:
- `services/social-service/src/lib/kafka.ts` - Add circuit breaker

### Phase 2: Rate Limiting (After Circuit Breakers)

#### 2.1 API Gateway Rate Limiting
**Priority**: HIGH (prevent overload)

**Implementation**:
- Per-IP rate limiting (100 req/min per IP)
- Per-user rate limiting (1000 req/min per authenticated user)
- Per-endpoint rate limiting (different limits for different endpoints)
- Use `express-rate-limit` middleware

**Configuration**:
```typescript
// Per-IP rate limiting
const ipLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute per IP
  message: 'Too many requests from this IP, please try again later',
});

// Per-user rate limiting (after authentication)
const userLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 1000, // 1000 requests per minute per user
  keyGenerator: (req) => req.user?.sub || req.ip,
  message: 'Too many requests, please try again later',
});
```

#### 2.2 Service-Level Rate Limiting
**Priority**: MEDIUM

**Implementation**:
- Rate limiting for expensive operations (search, analytics)
- Use Redis for distributed rate limiting
- Different limits for different user tiers

### Phase 3: Gradual Degradation

#### 3.1 Fallback Responses
**Priority**: LOW

**Implementation**:
- Return cached responses when circuit is open
- Return simplified responses when rate limited
- Graceful degradation for non-critical features

## Implementation Order

1. ✅ **Database Retry Logic** (DONE)
   - Listings service: ✅
   - Shopping service: ✅ (needs rebuild/redeploy)

2. **Circuit Breakers** (NEXT)
   - Shopping service database circuit breaker
   - API Gateway circuit breaker
   - Social service Kafka circuit breaker

3. **Rate Limiting** (AFTER CIRCUIT BREAKERS)
   - API Gateway rate limiting
   - Service-level rate limiting

4. **Gradual Degradation** (FINAL)
   - Fallback responses
   - Cached responses
   - Simplified responses

## Testing Strategy

1. **Circuit Breaker Tests**:
   - Simulate database connection failures
   - Verify circuit opens after threshold
   - Verify circuit closes after recovery

2. **Rate Limiting Tests**:
   - Send requests exceeding rate limit
   - Verify 429 Too Many Requests responses
   - Verify rate limit headers

3. **Gradual Degradation Tests**:
   - Verify fallback responses when circuit is open
   - Verify cached responses when available

## Monitoring

- Track circuit breaker state changes
- Track rate limit violations
- Track fallback response usage
- Alert on high circuit breaker open rates

## Related Files

- `services/python-ai-service/app/circuit_breaker.py` - Reference implementation
- `services/shopping-service/src/lib/db.ts` - Database retry logic
- `services/listings-service/src/lib/db.ts` - Database retry logic (reference)
- `services/api-gateway/src/server.ts` - API Gateway routing

---

**Last Updated**: January 6, 2026  
**Author**: Tom
