# Database Benchmark Test Plan

## Overview
This document outlines the plan for creating comprehensive benchmark tests for all databases in the platform, similar to `run_pgbench_sweep.sh`.

## Current Status

### ✅ Completed Benchmarks
1. **Main Records DB** (port 5433)
   - Script: `scripts/run_pgbench_sweep.sh`
   - Features: Deep mode, cold cache, fast temp tablespace, comprehensive metrics
   - Status: ✅ Production-ready

2. **Social DB** (port 5434)
   - Script: `scripts/run_social_pgbench_sweep.sh`
   - Features: Deep mode, cold cache, fast temp tablespace, comprehensive metrics
   - Status: ✅ Production-ready

### 📋 Planned Benchmarks

3. **Listings DB** (port 5435)
   - Schema: `listings` (listings, user_settings, search_history, etc.)
   - Key Operations:
     - Create listing
     - Search listings (with filters)
     - Update listing
     - Get user listings
     - Get listing by ID
   - Script: `scripts/run_listings_pgbench_sweep.sh` (TODO)

4. **Shopping DB** (port 5436)
   - Schema: `shopping` (shopping_cart, orders, purchase_history, watchlist, wishlist, etc.)
   - Key Operations:
     - Add to cart
     - Checkout (order creation)
     - Get orders
     - Get purchase history
     - Resell purchase
     - Search history
   - Script: `scripts/run_shopping_pgbench_sweep.sh` (TODO)

5. **Analytics DB** (if separate)
   - Schema: `analytics` (price_snapshots, etc.)
   - Key Operations:
     - Insert price snapshot
     - Query price trends
     - Aggregate analytics
   - Script: `scripts/run_analytics_pgbench_sweep.sh` (TODO)

6. **Auth DB** (if separate)
   - Schema: `auth` (users, sessions, etc.)
   - Key Operations:
     - User authentication
     - Session management
     - User creation
   - Script: `scripts/run_auth_pgbench_sweep.sh` (TODO)

7. **Search Service DB** (if separate)
   - Schema: `search` (index_status, etc.)
   - Key Operations:
     - Index updates
     - Search queries
   - Script: `scripts/run_search_pgbench_sweep.sh` (TODO)

8. **Other Service DBs**
   - Additional databases as needed
   - Scripts: `scripts/run_<service>_pgbench_sweep.sh` (TODO)

## Benchmark Script Template

Each benchmark script should follow this structure (based on `run_pgbench_sweep.sh`):

### Required Features
- ✅ **Deep Mode Support**: `MODE=deep` for 8-256 clients
- ✅ **Quick Mode**: Default mode with 8-64 clients
- ✅ **Cold Cache Phase**: Optional `RUN_COLD_CACHE=true`
- ✅ **Fast Temp Tablespace**: Optional `FAST_TEMP_TABLESPACE=fasttmp`
- ✅ **Extended Duration**: 3x duration for clients >= 128
- ✅ **Comprehensive Metrics**: p50, p95, p99, p999, p9999, p99999, p999999, p100
- ✅ **Cache Hit Ratio**: Track database cache efficiency
- ✅ **I/O Metrics**: Track disk I/O performance
- ✅ **CSV Export**: Results exported to CSV for analysis
- ✅ **Database Storage**: Results stored in `bench.results` table

### Script Structure
```bash
#!/usr/bin/env bash
# Benchmark target database: <service> DB
#   - Postgres host: localhost:<port>
#   - Database: records (or service-specific)
#   - Docker Compose service: postgres-<service>
#   - Schemas used: <schema> (data), bench (results)

# Connection settings
DB_HOST="localhost"
DB_PORT="<port>"
DB_USER="postgres"
DB_NAME="records"  # or service-specific
DB_PASS="postgres"

# Mode and client counts
MODE="${MODE:-quick}"
if [[ "$MODE" == "deep" ]]; then
  CLIENTS="8,16,24,32,48,64,96,128,192,256"
else
  CLIENTS="8,16,24,32,48,64"
fi

# Feature toggles
RUN_COLD_CACHE="${RUN_COLD_CACHE:-false}"
FAST_TEMP_TABLESPACE="${FAST_TEMP_TABLESPACE:-}"
GENERATE_PLOTS="${GENERATE_PLOTS:-true}"
SKIP_DISK_CHECK="${SKIP_DISK_CHECK:-false}"

# Cold cache reset function
cold_cache_reset() {
  # Same as run_pgbench_sweep.sh
}

# Variants to test (service-specific)
declare -a variants=("variant1" "variant2" "variant3" "noop")

# Main benchmark loop
for clients in "${client_array[@]}"; do
  # Warm phase
  PHASE="warm"
  for variant in "${variants[@]}"; do
    run_variant "$variant" "$sql_file" "$clients"
  done
  
  # Cold phase (optional)
  if [[ "$RUN_COLD_CACHE" == "true" ]]; then
    PHASE="cold"
    cold_cache_reset
    for variant in "${variants[@]}"; do
      run_variant "$variant" "$sql_file" "$clients"
    done
  fi
done
```

## Implementation Priority

### Phase 1: High Priority (Next)
1. **Shopping DB Benchmark** (`run_shopping_pgbench_sweep.sh`)
   - Most complex schema (7 tables)
   - Critical for e-commerce performance
   - Includes checkout, orders, purchase history

2. **Listings DB Benchmark** (`run_listings_pgbench_sweep.sh`)
   - Core marketplace functionality
   - Search-heavy workload
   - User settings and preferences

### Phase 2: Medium Priority
3. **Analytics DB Benchmark** (if separate)
4. **Auth DB Benchmark** (if separate)

### Phase 3: Lower Priority
5. **Search Service DB Benchmark** (if separate)
6. **Other Service DBs**

## k6 Load Testing (Future)

k6 tests will be added much later for:
- **End-to-end load testing**: Full user journeys
- **HTTP/2 and HTTP/3**: Protocol-specific testing
- **Multi-service scenarios**: Cross-service workflows
- **Real-world traffic patterns**: Simulate actual usage

### k6 Test Structure (Future)
```
scripts/k6/
├── scenarios/
│   ├── shopping-checkout.js
│   ├── listings-search.js
│   ├── social-forum.js
│   └── end-to-end.js
├── config/
│   └── thresholds.js
└── run-k6-tests.sh
```

## Notes

- All benchmark scripts should follow the same structure for consistency
- Results should be stored in `bench.results` table with `run_id` for filtering
- CSV exports should be timestamped and saved to `bench_logs/`
- Each script should support the same feature toggles for consistency
- Documentation should be updated as new benchmarks are added

