# Debug Logging and Route Fixes

## Changes Applied

### 1. Test 9f - Group Messages Not Returned
**Issue**: `GET /messages` was using gRPC `ListMessages` which returns empty array for group messages
**Fix**: Changed to HTTP proxy to social service HTTP endpoint which properly returns group messages
**Debug Logging**: Added comprehensive logging for path rewriting and proxy requests

### 2. Test 9i - Comment ID Placeholder
**Issue**: `POST /forum/posts/:postId/comments` was using gRPC `CreateComment` which may have issues
**Fix**: Changed to HTTP proxy to social service HTTP endpoint
**Debug Logging**: Added logging for postId, userId, and proxy path

### 3. Test 9j - Message Attachment 502
**Issue**: Message attachment route may have path rewriting issues
**Fix**: Already has correct path rewriting, added more debug logging

### 4. Test 11/12 - Listings HTTP/2 Timeout/502
**Issue**: HTTP/2 requests timing out or returning 502, but HTTP/3 works
**Fix**: Added comprehensive debug logging to trace the issue
**Note**: This may be a Caddy or keep-alive connection issue specific to HTTP/2

### 5. Test 14 - Logout 502
**Issue**: Logout route returning 502
**Fix**: Added debug logging and proper path rewriting
**Debug Logging**: Added logging for proxy requests

### 6. Shopping Service Routes (13b, 13d, 13f, 13g, 13i)
**Issue**: Shopping service routes returning 502
**Fix**: Already has debug logging, routes should work now that services are healthy
**Debug Logging**: Enhanced logging for all shopping service routes

## Debug Logging Added

All routes now include:
- Path rewriting logs showing original path, rewritten path, and final path
- Proxy request logs showing method, path, query params, userId
- Proxy response logs showing status codes
- Error logs with full error details including stack traces

## Next Steps

1. Run the test script again to see detailed debug logs
2. Check API gateway logs for each failing test:
   ```bash
   kubectl logs -n record-platform -l app=api-gateway -c app --tail=1000 | grep -E "Proxying|pathRewrite|error"
   ```
3. For HTTP/2 vs HTTP/3 issues, check Caddy logs and connection keep-alive settings

