# Docker Cleanup and Cluster Creation Fix

## Issues Fixed

1. **Stale curl containers**: The `nodeport_curl` helper was creating many curl containers that weren't being cleaned up, eating up Docker storage.

2. **Kind cluster creation failure**: On Docker Desktop for macOS, creating a cluster with port mappings in `kind-h3.yaml` was failing with a Docker inspect error.

## Solutions

### 1. Automatic Cleanup

The `restart-cluster-and-redeploy.sh` script now automatically:
- Cleans up stale curl containers before cluster creation
- Removes leftover Kind node containers
- Prunes Docker resources before building images

### 2. Cluster Creation Fix

The script now creates the cluster **without port mappings** (which causes issues on Docker Desktop for macOS) and uses `kubectl port-forward` instead, which works reliably.

**Why this works better:**
- Port mappings in `kind-h3.yaml` can conflict with Docker Desktop's networking
- `kubectl port-forward` is the recommended approach for macOS
- The test script already uses port-forwarding for high-throughput tests

## Usage

### Clean up stale containers manually:
```bash
./scripts/cleanup-stale-containers.sh
```

### Full restart (includes cleanup):
```bash
./scripts/restart-cluster-and-redeploy.sh h3
```

### Clean up Docker storage:
```bash
./scripts/docker-cleanup.sh
# Or aggressive cleanup:
AGGRESSIVE=true ./scripts/docker-cleanup.sh
```

## What Gets Cleaned

1. **Stale curl containers** - From `nodeport_curl` helper (18+ containers found)
2. **Stopped containers** - All exited containers
3. **Dangling images** - Untagged images
4. **Unused networks** - Orphaned networks
5. **Build cache** - Optional (via `AGGRESSIVE_CLEANUP=true`)

## Cluster Creation

The restart script now:
1. Cleans up stale containers first
2. Removes any leftover Kind nodes
3. Creates cluster without port mappings (avoids Docker Desktop issues)
4. Uses port-forwarding for NodePort access (works reliably on macOS)

## Docker Desktop Resource Usage

Before cleanup:
- 26 containers (many stale curl containers)
- High storage usage

After cleanup:
- ~13 containers (only active services)
- Reduced storage usage

## Notes

- The `nodeport_curl` helper creates a persistent container that should be cleaned up periodically
- Kind cluster creation works better without port mappings on Docker Desktop for macOS
- Port-forwarding is the recommended approach for local development on macOS

