# Docker Storage Expansion Guide

## Current Issue
Docker's internal storage is running out of space during builds, even though host disk has plenty of space (63GB free).

## Solution: Expand Docker Desktop Storage

### Option 1: Increase Docker Desktop Disk Image Size (Recommended)

1. Open Docker Desktop
2. Go to Settings → Resources → Advanced
3. Increase "Disk image size" (default is usually 64GB)
   - Recommended: 128GB or 256GB
4. Click "Apply & Restart"

### Option 2: Move Docker Data to External Drive

If you have an external drive with more space:

1. Stop Docker Desktop
2. Move Docker data:
   ```bash
   # Find Docker data location
   docker info | grep "Docker Root Dir"
   
   # Move to external drive (example)
   # This is complex - see Docker Desktop settings instead
   ```
3. Or use Docker Desktop Settings → Resources → Advanced → "Move disk image"

### Option 3: Use Docker's Storage Optimization

```bash
# Clean everything aggressively
docker system prune -a --volumes

# Check current usage
docker system df
```

### Option 4: Build Services One at a Time (Already Implemented)

The build script now:
- Cleans build cache before starting
- Cleans build cache after each service
- Removes old :dev images before building
- Builds services sequentially (not parallel)

## Current Docker Usage
- Images: 5.5GB (3.5GB reclaimable)
- Volumes: 48.5GB (postgres - needed for local dev)
- Build Cache: 0GB (cleaned)
- Containers: 90MB

## Recommended Action
**Increase Docker Desktop disk image size to 128GB or 256GB** in Docker Desktop Settings.

