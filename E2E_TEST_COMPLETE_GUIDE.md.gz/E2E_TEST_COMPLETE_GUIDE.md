# E2E Test Complete Guide - For Agent Continuation

**Last Updated:** $(date)
**Status:** Root cause fixed, ready for E2E test

---

## 🎯 Executive Summary

### Root Cause Identified and Fixed
**Primary Issue:** Caddy H3 was routing to a **NON-EXISTENT** service (`ingress-nginx-controller.ingress-nginx.svc.cluster.local`), causing 100% DNS timeout failures.

**Fix Applied:** Changed Caddy routing to direct API Gateway connection (`api-gateway.record-platform.svc.cluster.local:4000`).

### Current Status
- ✅ Root cause fixed (direct API Gateway routing)
- ✅ k6 memory increased (1Gi → 1.5Gi)
- ✅ Caddy ConfigMap updated
- ⏳ Waiting for Caddy H3 rollout
- ⏳ E2E test ready to run

---

## 📋 Architecture Overview

### Request Flow (After Fix)
```
k6 Pods → Caddy H3 (port 443) → API Gateway (port 4000) → Microservices
```

### E2E Test Flow (7 Stages)
1. **Auth** - Register/Login users
2. **Listings** - Create/search listings
3. **Social** - Follow/unfollow, posts
4. **Pipeline** - Analytics + Python AI (recommendations, chat)
5. **Shopping** - Cart, checkout, wishlist
6. **Records** - CRUD operations
7. **Logout** - Cleanup

### Key Services
- **Caddy H3** (`ingress-nginx` namespace) - TLS termination, HTTP/3
- **API Gateway** (`record-platform` namespace) - Central routing
- **Microservices** - Auth, Listings, Social, Shopping, Records, Analytics, Python AI

---

## 🔧 Fixes Applied

### 1. Caddy Routing Fix (PRIMARY)
**File:** `/Users/tom/record-platform/Caddyfile`
**Change:** Direct API Gateway routing instead of through non-existent ingress-nginx

**Before (BROKEN):**
```caddy
reverse_proxy http://ingress-nginx-controller.ingress-nginx.svc.cluster.local:80
```

**After (FIXED):**
```caddy
reverse_proxy http://api-gateway.record-platform.svc.cluster.local:4000
```

**Impact:** Eliminates DNS timeouts (NXDOMAIN errors)

### 2. k6 Memory Increase
**File:** `infra/k8s/base/k6/k6-shopping-e2e-jobs-multi.yaml`
**Change:** Memory limit increased from 1Gi → 1.5Gi

**Reason:** 2/4 pods were OOMKilled with 1Gi limit

### 3. API Gateway Connection Settings
**File:** `services/api-gateway/src/server.ts`
**Settings:**
- `maxConnections: 500` per pod
- `keepAliveTimeout: 65000ms`
- `headersTimeout: 66000ms`

### 4. Shopping Service DB Pool
**File:** `services/shopping-service/src/lib/db.ts`
**Settings:**
- `max: 50` connections (increased from 20)
- `connectionTimeoutMillis: 10000ms` (increased from 2000ms)

### 5. k6 Script Improvements
**File:** `scripts/load/k6-shopping-service-comprehensive.js`
**Changes:**
- Added cart validation before checkout
- Added `sleep(0.5)` after adding to cart
- Added retry logic (3 retries) for authentication
- Improved error logging

---

## 🚀 Running E2E Test

### Prerequisites
1. **Verify Caddy H3 is ready:**
   ```bash
   kubectl get pods -n ingress-nginx -l app=caddy-h3
   # Should show 2 pods, both Running and Ready
   ```

2. **Verify API Gateway is ready:**
   ```bash
   kubectl get pods -n record-platform -l app=api-gateway
   # Should show 3 pods, all Running and Ready
   ```

3. **Verify kubeconfig:**
   ```bash
   kind get kubeconfig --name h3 > ~/.kube/config
   ```

### Run E2E Test
```bash
cd /Users/tom/.cursor/worktrees/record-platform/oxy
./scripts/run-k6-e2e-enhanced.sh
```

### Monitor E2E Test
```bash
# Live monitoring (auto-stops on errors)
/tmp/live-monitor-e2e-fixed.sh

# Or continuous monitoring (background)
/tmp/monitor-e2e-continuous.sh
```

### Check Test Status
```bash
# Check pod status
kubectl get pods -n record-platform -l 'job-name in (k6-shopping-e2e-1,k6-shopping-e2e-2,k6-shopping-e2e-3,k6-shopping-e2e-4)'

# Check logs
kubectl logs -n record-platform -l job-name=k6-shopping-e2e-1 --tail=50

# Check job completion
kubectl get jobs -n record-platform -l 'job-name in (k6-shopping-e2e-1,k6-shopping-e2e-2,k6-shopping-e2e-3,k6-shopping-e2e-4)'
```

---

## 📊 Monitoring Commands

### Service Health
```bash
# All services
kubectl get pods -n record-platform

# Specific service
kubectl get pods -n record-platform -l app=api-gateway

# Service logs
kubectl logs -n record-platform -l app=api-gateway --tail=100
```

### Caddy H3 Status
```bash
# Pods
kubectl get pods -n ingress-nginx -l app=caddy-h3

# Logs (check for DNS errors)
kubectl logs -n ingress-nginx -l app=caddy-h3 --tail=50 | grep -iE "error|timeout|refused"

# ConfigMap (verify direct routing)
kubectl get configmap -n ingress-nginx caddy-h3 -o jsonpath='{.data.Caddyfile}' | grep api-gateway
```

### DNS Resolution Test
```bash
# From Caddy pod
CADDY_POD=$(kubectl get pods -n ingress-nginx -l app=caddy-h3 --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n ingress-nginx "$CADDY_POD" -- nslookup api-gateway.record-platform.svc.cluster.local

# Should return: Address: 10.96.50.141
```

### Connection Test
```bash
# From k6 pod
K6_POD=$(kubectl get pods -n record-platform -l job-name=k6-shopping-e2e-1 --field-selector=status.phase=Running -o jsonpath='{.items[0].metadata.name}')
kubectl exec -n record-platform "$K6_POD" -- wget --spider --timeout=5 https://caddy-h3.ingress-nginx.svc.cluster.local:443 2>&1
```

---

## 🔍 Troubleshooting

### DNS Timeouts
**Symptom:** `dial tcp: lookup api-gateway...: i/o timeout`

**Check:**
1. Verify Caddy ConfigMap has direct routing:
   ```bash
   kubectl get configmap -n ingress-nginx caddy-h3 -o jsonpath='{.data.Caddyfile}' | grep api-gateway
   ```

2. Verify API Gateway service exists:
   ```bash
   kubectl get svc -n record-platform api-gateway
   ```

3. Test DNS from Caddy pod:
   ```bash
   kubectl exec -n ingress-nginx <caddy-pod> -- nslookup api-gateway.record-platform.svc.cluster.local
   ```

**Fix:** If ConfigMap is wrong, update Caddyfile and restart:
```bash
kubectl create configmap caddy-h3 -n ingress-nginx --from-file=Caddyfile=/Users/tom/record-platform/Caddyfile --dry-run=client -o yaml | kubectl apply -f -
kubectl rollout restart deployment/caddy-h3 -n ingress-nginx
```

### Connection Refused
**Symptom:** `dial tcp ...: connect: connection refused`

**Check:**
1. API Gateway pods are running:
   ```bash
   kubectl get pods -n record-platform -l app=api-gateway
   ```

2. API Gateway is listening on port 4000:
   ```bash
   kubectl logs -n record-platform -l app=api-gateway | grep "gateway up"
   ```

3. Service endpoints:
   ```bash
   kubectl get endpoints -n record-platform api-gateway
   ```

**Fix:** Restart API Gateway if needed:
```bash
kubectl rollout restart deployment/api-gateway -n record-platform
```

### OOMKilled Errors
**Symptom:** k6 pods exit with code 137

**Check:**
1. Current memory limit:
   ```bash
   kubectl get pods -n record-platform -l job-name=k6-shopping-e2e-1 -o jsonpath='{.items[0].spec.containers[0].resources.limits.memory}'
   ```

**Fix:** Increase memory limit in `infra/k8s/base/k6/k6-shopping-e2e-jobs-multi.yaml`:
```yaml
limits:
  memory: "1.5Gi"  # Increase if still failing
```

### kubeconfig TLS Timeout
**Symptom:** `net/http: TLS handshake timeout`

**Fix:**
```bash
kind get kubeconfig --name h3 > ~/.kube/config
sleep 5  # Wait for config to be ready
```

**Note:** This issue occurs frequently. The monitoring script (`/tmp/monitor-e2e-final.sh`) auto-regenerates kubeconfig on timeout.

---

## 📁 Key Files

### Configuration Files
- `/Users/tom/record-platform/Caddyfile` - Caddy routing configuration
- `infra/k8s/base/k6/k6-shopping-e2e-jobs-multi.yaml` - k6 job definitions
- `services/api-gateway/src/server.ts` - API Gateway server settings
- `services/shopping-service/src/lib/db.ts` - Shopping service DB pool

### Test Scripts
- `scripts/load/k6-shopping-service-comprehensive.js` - Main k6 E2E test
- `scripts/run-k6-e2e-enhanced.sh` - E2E test runner
- `/tmp/live-monitor-e2e-fixed.sh` - Live monitoring script
- `/tmp/monitor-e2e-continuous.sh` - Continuous monitoring script

### Analysis Documents
- `/Users/tom/record-platform/ROOT_CAUSE_FINAL.md` - Root cause analysis
- `/Users/tom/record-platform/ROOT_CAUSE_FIXES_APPLIED.md` - Fix summary
- `/Users/tom/record-platform/E2E_TEST_STATUS_REPORT.md` - Test status reports

---

## 🎯 Success Criteria

### Expected Results
- **DNS Timeouts:** 0 (eliminated by direct routing)
- **Connection Errors:** < 100 total (down from 3,564)
- **5xx Errors:** < 50 total (down from high hundreds)
- **Success Rate:** > 70% (up from ~0%)
- **OOMKilled:** 0 (fixed with 1.5Gi memory)

### Test Completion
- All 4 k6 jobs complete successfully
- All 7 E2E stages execute
- No critical errors in logs

---

## 📝 Next Steps

1. **Regenerate kubeconfig** (if TLS timeout):
   ```bash
   kind get kubeconfig --name h3 > ~/.kube/config
   sleep 5
   ```

2. **Wait for Caddy H3 rollout** (if not complete):
   ```bash
   kubectl get pods -n ingress-nginx -l app=caddy-h3
   # Should show 2 pods, both Ready
   ```

3. **Verify all services are healthy**:
   ```bash
   kubectl get pods -n record-platform
   ```

4. **Check E2E test status**:
   ```bash
   kubectl get pods -n record-platform -l 'job-name in (k6-shopping-e2e-1,k6-shopping-e2e-2,k6-shopping-e2e-3,k6-shopping-e2e-4)'
   ```

5. **Monitor test execution**:
   ```bash
   /tmp/monitor-e2e-final.sh
   ```

6. **Analyze results and address any remaining issues**

---

## 🔗 Related Issues

### Past Issues (Fixed)
- ✅ API Gateway crashes (44 restarts) - Fixed with startup probes
- ✅ Checkout 400 errors - Fixed with cart validation and timing
- ✅ Connection refused errors - Fixed with direct routing
- ✅ DNS timeouts - Fixed with direct routing (root cause)
- ✅ OOMKilled errors - Fixed with 1.5Gi memory
- ✅ High service restarts - Fixed with health probes

### Current Status
- ⏳ Caddy H3 rollout in progress
- ⏳ E2E test ready to run
- ✅ All fixes applied

---

## 📞 Quick Reference

### Namespaces
- `record-platform` - All microservices and k6 jobs
- `ingress-nginx` - Caddy H3

### Key Services
- `caddy-h3` - TLS termination (ingress-nginx namespace)
- `api-gateway` - Central routing (record-platform namespace)
- `k6-shopping-e2e-{1,2,3,4}` - E2E test jobs (record-platform namespace)

### Important Ports
- `443` - Caddy H3 HTTPS
- `4000` - API Gateway HTTP
- `5000` - Caddy H3 gRPC (h2c)

---

**Note:** This document is maintained for agent handoff. Update status as work progresses.

