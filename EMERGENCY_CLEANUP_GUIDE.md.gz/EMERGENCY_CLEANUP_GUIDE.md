# Emergency Disk Cleanup Guide

## Current Situation
- **Disk Usage:** 88% (379Gi / 460Gi used)
- **Available:** 54Gi
- **Status:** ⚠️ High usage - cleanup recommended

## Quick Cleanup (Safe)

Run the quick cleanup script for fast, safe cleanup:
```bash
./scripts/quick-memory-cleanup.sh
```

This will:
- Clean Docker system (safe)
- Remove Next.js build caches
- Remove old benchmark logs (keeps last 3 days)

## Emergency Cleanup (More Aggressive)

For more aggressive cleanup:
```bash
./scripts/emergency-disk-cleanup.sh
```

This will:
- Keep only last 1 day of bench logs
- Keep only last 2 backups
- Clean Docker (images, containers, build cache)
- Clean Next.js caches
- Clean temporary files
- Check PostgreSQL container disk usage

## Aggressive Cleanup (Maximum Space)

For maximum space recovery (⚠️ may require reinstalling dependencies):
```bash
./scripts/emergency-disk-cleanup.sh --aggressive
```

This will:
- Keep only today's bench logs
- Keep only last 1 backup
- Clean Docker aggressively
- **Remove node_modules** (will need `pnpm install` to restore)
- Clean all caches

## Dry Run (Preview)

Always preview what will be deleted:
```bash
./scripts/emergency-disk-cleanup.sh --dry-run
./scripts/emergency-disk-cleanup.sh --aggressive --dry-run
```

## Large Items Found

1. **Docker Volume:** 44.11GB (in use - cannot safely remove)
2. **PostgreSQL volumes:** ~5GB total
3. **Next.js cache:** 55MB
4. **Bench logs:** Small amount

## Manual Cleanup Options

If scripts don't free enough space:

### Docker (⚠️ Dangerous)
```bash
# Remove ALL unused images
docker image prune -a -f

# Remove unused volumes (⚠️ may delete data!)
docker volume prune -f

# Full cleanup (⚠️ VERY DANGEROUS - may break services!)
docker system prune -a --volumes -f
```

### PostgreSQL Container
The PostgreSQL container is at 90% usage. Check WAL files:
```bash
docker exec record-platform-postgres-1 du -sh /var/lib/postgresql/data/pg_wal
```

### Kubernetes (if using K8s)
```bash
# Check PVC sizes
kubectl get pvc --all-namespaces

# Clean old backups
./scripts/cleanup-k8s-pvc-space.sh
```

## Monitoring

Check disk usage:
```bash
df -h .
du -sh * | sort -hr | head -20
```

## Prevention

To prevent future issues:
1. Run cleanup regularly: `./scripts/cleanup-disk-space.sh`
2. Monitor disk usage weekly
3. Set up alerts for >85% usage
4. Clean old bench logs: `./scripts/cleanup-old-bench-results.sh`

## Scripts Available

- `scripts/quick-memory-cleanup.sh` - Fast, safe cleanup
- `scripts/emergency-disk-cleanup.sh` - Comprehensive emergency cleanup
- `scripts/cleanup-disk-space.sh` - Regular maintenance cleanup
- `scripts/cleanup-old-bench-results.sh` - Clean old benchmark logs
- `scripts/prune-postgres-container.sh` - PostgreSQL-specific cleanup
