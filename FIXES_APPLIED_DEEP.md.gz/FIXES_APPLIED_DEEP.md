# Deep Layer Fixes Applied

**Generated:** $(date)

---

## ✅ Fixes Applied

### 1. Shopping Service DB Pool Increased
- **Before:** 20 connections (TOO LOW)
- **After:** 50 connections (matches other services)
- **Additional:** 
  - Increased connection timeout to 10s
  - Added statement timeout (30s)
  - Added query timeout (30s)
  - Enabled keep-alive
- **Status:** ✅ Applied (service rebuilt and restarted)

### 2. k6 Memory Limit Reduced
- **Before:** 2Gi limit (causing node memory pressure)
- **After:** 512Mi limit (reduces node pressure)
- **Request:** 128Mi (unchanged)
- **Status:** ✅ Applied (k6 jobs updated)

### 3. API Gateway Investigation
- **Issue:** Connection refused on port 4000
- **Status:** Investigating root cause
- **Next:** Check if scaling needed

---

## 🔍 Root Causes Identified

### Primary Issue: API Gateway Connection Refusal
- **Error Pattern:** `dial tcp 10.96.50.141:4000: connect: connection refused`
- **Frequency:** Constant in Caddy H3 logs
- **Impact:** 77-81% of requests failing with 502
- **Likely Causes:**
  1. API Gateway crashing/restarting (41 restarts)
  2. Port 4000 not binding
  3. Service overloaded
  4. Resource exhaustion

### Secondary Issues:
1. **DNS Timeouts:** Service discovery failing
2. **Shopping DB Pool:** Too small (now fixed)
3. **k6 Memory:** Too high limit (now fixed)

---

## 📊 Expected Impact

### Immediate:
- **Shopping Service:** Better connection handling (50 vs 20 pool)
- **Node Memory:** Reduced pressure (512Mi vs 2Gi per k6 pod)
- **Total k6 Memory:** 2Gi → 512Mi × 4 = 2Gi → 2Gi (same total, but better distributed)

### After API Gateway Fix:
- **5xx Errors:** Should drop from 77-81% to <10%
- **Success Rate:** Should improve from 7-9% to 70-80%+
- **Connection Errors:** Should be eliminated

---

## ⏳ Next Steps

1. **IMMEDIATE:** Fix API Gateway connection issues
2. **HIGH:** Scale API Gateway if needed
3. **HIGH:** Fix DNS timeout issues
4. **MEDIUM:** Re-run E2E test after API Gateway fix

