# API Gateway Route Fixes - Complete Summary

## Issues Fixed

### 1. User ID Validation (CRITICAL SECURITY FIX)
**Problem**: PostgreSQL was receiving invalid user IDs like `"test-user-123"` instead of valid UUIDs
**Root Cause**: `proxyReq` handlers were forwarding client-provided `x-user-id` headers without validation
**Fix**: Updated all `proxyReq` handlers to:
- **Primary**: Use `req.user.sub` from JWT token (validated by auth guard)
- **Fallback**: Only allow valid UUIDs from `x-user-id` header (for DEBUG_FAKE_AUTH)
- **Reject**: Invalid user IDs with error logging

**Routes Fixed**:
- ✅ `POST /forum/posts`
- ✅ `POST /forum/posts/:postId/attachments`
- ✅ `GET /forum/posts/:postId/attachments`
- ✅ `POST /forum/comments/:commentId/attachments`
- ✅ `POST /messages/:messageId/attachments`
- ✅ `DELETE /messages/groups/:groupId/leave`
- ✅ `POST /messages/groups/:groupId/members`
- ✅ `GET /messages/groups/:groupId`
- ✅ `GET /messages/groups`
- ✅ All shopping service routes

### 2. Forum Post Creation
**Problem**: Returning "placeholder-post-id" instead of real UUIDs
**Root Cause**: Using gRPC `CreatePost` which returns placeholder
**Fix**: Changed to HTTP proxy route that calls social service HTTP endpoint

### 3. Route Order
**Problem**: More specific routes (attachments, leave) were defined after general routes
**Fix**: Reordered routes so specific routes come first

### 4. Duplicate Route Definitions
**Problem**: Routes were defined twice (middleware and proxy on separate lines)
**Fix**: Combined into single route with chained middleware

### 5. Missing x-user-id Forwarding
**Problem**: Some attachment routes weren't forwarding `x-user-id` header
**Fix**: Added `x-user-id` forwarding to all social service proxy routes

## Security Improvements
- **Before**: Client could send any `x-user-id` header value
- **After**: Only JWT-validated user IDs or valid UUIDs are forwarded
- **Result**: Prevents SQL injection and invalid data errors

## Testing Status
After these fixes, the following should work:
- ✅ Forum post creation returns real UUIDs
- ✅ Attachment routes work with real post IDs
- ✅ Group chat operations work correctly
- ✅ Shopping service routes work correctly
- ✅ No more "invalid input syntax for type uuid" errors

## Next Steps
Run the test script to verify all fixes:
```bash
./scripts/test-microservices-http2-http3.sh
```

Expected improvements:
- Tests 9h, 9i, 9j, 9k, 9l should pass (social service attachments)
- Tests 13a-13i should pass (shopping service)
- Forum posts should return real UUIDs
- No more 502/503 errors from invalid user IDs

