# gRPC Timeout Investigation

## Issues Found

### 1. gRPC Register Timeout
- **Problem**: Register call takes 11.6 seconds but timeout is 10 seconds
- **Location**: `services/api-gateway/src/server.ts` line 683
- **Error**: `gRPC call Register timed out after 10000ms`
- **Fix**: Increased timeout to 20 seconds for Register calls

### 2. Linkerd Fail-Fast Mode
- **Problem**: API gateway Linkerd proxy enters fail-fast mode when reaching auth-service:50051
- **Symptoms**: 
  - "Unavailable; entering failfast timeout=3.0"
  - "service in fail-fast"
  - Then recovers: "Available; exited failfast elapsed=4.2s"
- **Root Cause**: Linkerd proxy can't establish connection quickly enough
- **Impact**: Initial connection attempts fail, but subsequent attempts succeed

### 3. API Gateway Pod Status
- **Current**: 1/2 READY (app container: false, linkerd-proxy: true)
- **Issue**: App container not ready, which may cause routing issues

### 4. Linkerd DNS Issues
- **Problem**: DNS resolution failures for `linkerd-dst-headless` and `linkerd-policy`
- **Impact**: May cause routing delays and fail-fast behavior

## Fixes Applied

### 1. Increased gRPC Timeout for Register
```typescript
// Before: Default 10s timeout
const response = await promisifyGrpcCall<any>(authGrpcClient, "Register", {
  email,
  password,
});

// After: 20s timeout for registration
const response = await promisifyGrpcCall<any>(authGrpcClient, "Register", {
  email,
  password,
}, 20000); // 20 second timeout
```

### 2. Why Register is Slow
From auth-service logs:
- `[gRPC] Register completed in 11643ms`
- Registration involves:
  - Password hashing (bcrypt - intentionally slow)
  - Database writes (user creation)
  - JWT token generation
  - Potentially email verification setup

## Recommendations

1. **Deploy the timeout fix**: Rebuild and redeploy api-gateway
2. **Monitor Register performance**: Consider optimizing if consistently >15s
3. **Fix Linkerd DNS**: Install missing linkerd-policy controller
4. **Investigate API gateway pod**: Check why app container is not ready

## Next Steps

1. Rebuild api-gateway with increased timeout
2. Test Register endpoint again
3. Monitor Linkerd proxy logs for fail-fast behavior
4. Check API gateway pod health

