# HTTP/3 Support for k6 - Implementation Plan

**Based on:** `/Users/tom/record-platform/docs/k6-http3-investigation.md`  
**Generated:** $(date)

---

## 📋 Current Status

### Investigation Complete ✅
- ✅ Research phase completed
- ✅ Technical feasibility confirmed
- ✅ Approach selected: **xk6 Extension** (recommended)
- ✅ Library selected: **quic-go** (mature, well-maintained)

### Key Findings from Investigation

1. **k6 does NOT support HTTP/3 natively**
   - Only HTTP/1.1 and HTTP/2 are supported
   - `httpVersion: "HTTP/3"` option is ignored/falls back

2. **Recommended Approach: xk6 Extension**
   - Non-invasive (no k6 fork needed)
   - Can be maintained independently
   - Easier to iterate and test
   - Can be shared as standalone extension

3. **Infrastructure Ready**
   - Caddy H3 already supports HTTP/3
   - We have HTTP/3-capable infrastructure
   - Can test against existing setup

---

## 🎯 Implementation Phases

### Phase 1: Extension Skeleton (Days 1-2)

**Goal:** Set up basic xk6 extension structure

**Tasks:**
1. Create xk6 extension repository structure
2. Set up Go module with dependencies:
   - `github.com/grafana/xk6`
   - `github.com/quic-go/quic-go`
   - `github.com/quic-go/webtransport` or `github.com/quic-go/quic-go/http3`
   - `go.k6.io/k6`
3. Implement basic module registration
4. Create minimal JavaScript API

**Deliverables:**
- Extension compiles
- Can be imported in k6 scripts
- Basic structure in place

**Success Criteria:**
- `xk6 build --with github.com/your-org/xk6-http3` succeeds
- Can import `k6/x/http3` in k6 script

---

### Phase 2: Basic HTTP/3 Client (Days 3-5)

**Goal:** Get a basic HTTP/3 GET request working

**Tasks:**
1. Integrate quic-go HTTP/3 client
2. Implement connection management (pooling)
3. Create minimal `http3.get()` function
4. Test against Caddy H3 server
5. Handle TLS/QUIC handshake

**Deliverables:**
- Can make HTTP/3 GET request
- Response status and body accessible
- Basic error handling

**Success Criteria:**
- HTTP/3 GET request completes successfully
- Response data is accessible in k6 script
- TLS validation works

---

### Phase 3: API Compatibility (Days 6-10)

**Goal:** Match k6's HTTP module API

**Tasks:**
1. Implement all HTTP methods:
   - `http3.get()`
   - `http3.post()`
   - `http3.put()`
   - `http3.patch()`
   - `http3.del()`
   - `http3.head()`
   - `http3.options()`
2. Support request options:
   - Headers
   - Timeout
   - Tags
   - Body (various formats)
3. Return response object matching k6's format
4. Implement connection pooling/reuse

**Deliverables:**
- API matches k6's `http` module
- Can drop-in replace `http` with `http3` in simple scripts
- Connection reuse works correctly

**Success Criteria:**
- API is compatible with k6's HTTP module
- Can migrate existing scripts with minimal changes
- Connection pooling works under load

---

### Phase 4: Metrics Integration (Days 11-13)

**Goal:** Ensure HTTP/3 requests are tracked in k6 metrics

**Tasks:**
1. Integrate with k6's metrics system
2. Track standard HTTP metrics:
   - Request duration
   - Request count
   - Error rates
3. Add HTTP/3-specific metrics:
   - QUIC handshake time
   - Stream establishment time
   - Connection migration events (if applicable)
4. Add protocol tagging (`protocol: http3`)

**Deliverables:**
- HTTP/3 requests appear in k6 metrics
- Protocol tag shows `http3`
- Custom metrics available

**Success Criteria:**
- Metrics appear in k6 output
- Protocol tag is correct
- Custom metrics work

---

### Phase 5: Load Testing & Validation (Days 14-16)

**Goal:** Validate extension under load

**Tasks:**
1. Run load tests against Caddy H3
2. Compare HTTP/2 vs HTTP/3 performance
3. Test connection pooling under high concurrency (50+ VUs)
4. Validate ephemeral port usage (QUIC uses UDP)
5. Test error handling and fallback scenarios
6. Memory leak testing

**Deliverables:**
- Extension handles high load
- Performance comparison data
- No connection leaks
- Error handling validated

**Success Criteria:**
- Handles 50+ VUs without issues
- Metrics are accurate
- No memory leaks
- Performance is acceptable

---

### Phase 6: Production Readiness (Days 17-21)

**Goal:** Make extension robust and production-ready

**Tasks:**
1. Comprehensive error handling
2. Edge case testing
3. Documentation:
   - README with examples
   - API documentation
   - Migration guide
4. CI/CD setup:
   - Automated builds
   - Testing pipeline
   - Release process
5. Performance optimization
6. Compatibility testing with different k6 versions

**Deliverables:**
- Stable, well-documented extension
- CI/CD pipeline
- Release process
- Performance benchmarks

**Success Criteria:**
- Extension is stable
- Well-documented
- Easy to integrate
- Performance overhead is minimal

---

## 🏗️ Technical Architecture

### Extension Structure

```
xk6-http3/
├── main.go                 # Extension entry point
├── http3/
│   ├── module.go          # Module registration
│   ├── client.go          # HTTP/3 client implementation
│   ├── connection.go      # QUIC connection management
│   └── metrics.go         # Metrics integration
├── go.mod
├── go.sum
├── README.md
└── examples/
    └── basic.js           # Example k6 script
```

### Key Components

1. **QUIC Connection Pool**
   - Manage QUIC connections per host
   - Connection reuse
   - Connection lifecycle management

2. **HTTP/3 Client**
   - Wrap `http3.RoundTripper`
   - Handle TLS/QUIC handshake
   - Request/response handling

3. **JavaScript API**
   - Match k6's `http` module API
   - Export functions to k6 scripts
   - Handle Go ↔ JavaScript data conversion

4. **Metrics Integration**
   - Integrate with k6 metrics system
   - Track HTTP/3-specific metrics
   - Protocol tagging

---

## 🔧 Implementation Details

### Dependencies

```go
require (
    github.com/grafana/xk6 v0.0.0-... // Latest xk6
    github.com/quic-go/quic-go v0.40.0 // QUIC library
    github.com/quic-go/webtransport v0.6.0 // HTTP/3 on quic-go
    go.k6.io/k6 v0.47.0 // k6 core
)
```

### Basic API Structure

```javascript
// k6 script usage
import http3 from 'k6/x/http3';

export default function() {
  const res = http3.get('https://caddy-h3.ingress-nginx.svc.cluster.local:443/api', {
    headers: { 'X-Custom': 'value' },
    timeout: '30s',
    tags: { name: 'my-request' },
  });
  
  console.log(res.status, res.body);
}
```

### Connection Pooling

```go
type QUICConnPool struct {
    mu       sync.RWMutex
    conns    map[string]*quic.Connection
    dialer   *quic.Dialer
}

func (p *QUICConnPool) GetConnection(addr string) (*quic.Connection, error) {
    // Get or create QUIC connection
    // Handle connection reuse
    // Manage connection lifecycle
}
```

---

## 📊 Testing Strategy

### Unit Tests
- Connection management
- Request/response handling
- Error handling
- Timeout scenarios

### Integration Tests
- Against Caddy H3 server
- Protocol negotiation
- TLS validation
- Connection reuse

### Load Tests
- 10, 50, 100, 500 VUs
- Compare HTTP/2 vs HTTP/3
- Connection pooling under load
- Long-running stability tests

---

## 🚀 Deployment Plan

### Build Process

```bash
# Install xk6
go install go.k6.io/xk6/cmd/xk6@latest

# Build k6 with HTTP/3 extension
xk6 build --with github.com/your-org/xk6-http3@latest

# Use in k6 scripts
./k6 run test.js
```

### Docker Image

```dockerfile
FROM golang:1.21-alpine AS builder
RUN go install go.k6.io/xk6/cmd/xk6@latest
WORKDIR /build
RUN xk6 build --with github.com/your-org/xk6-http3@latest --output /k6

FROM alpine:latest
COPY --from=builder /k6 /usr/local/bin/k6
ENTRYPOINT ["k6"]
```

### Kubernetes Integration

- Update k6 job manifests to use custom image
- Test in existing E2E test infrastructure
- Integrate with monitoring

---

## 📈 Success Metrics

### PoC Success Criteria

1. **Functionality:**
   - ✅ Can make HTTP/3 requests from k6 scripts
   - ✅ API is compatible with k6's HTTP module
   - ✅ Requests are tracked in k6 metrics

2. **Performance:**
   - ✅ Handles 50+ VUs without issues
   - ✅ Connection pooling works correctly
   - ✅ No connection leaks

3. **Reliability:**
   - ✅ Handles errors gracefully
   - ✅ Supports TLS/certificate validation
   - ✅ Compatible with Caddy HTTP/3 server

---

## ⏱️ Timeline

**Total Estimated Time: 3-4 weeks**

- Phase 1: 2 days
- Phase 2: 3 days
- Phase 3: 5 days
- Phase 4: 3 days
- Phase 5: 3 days
- Phase 6: 5 days

**Buffer:** 1 week for unexpected issues

---

## 🎯 Next Steps

1. **Review & Approve Plan** ✅ (this document)
2. **Set up Repository**
   - Create GitHub repository for xk6-http3
   - Set up basic structure
   - Initialize Go module
3. **Begin Phase 1**
   - Create extension skeleton
   - Set up dependencies
   - Test basic compilation
4. **Iterate Based on Findings**
   - Adjust plan as needed
   - Document learnings
   - Update timeline

---

## 📚 Resources

- Investigation Document: `/Users/tom/record-platform/docs/k6-http3-investigation.md`
- k6 Extensions: https://k6.io/docs/extensions/get-started/create/
- xk6 Documentation: https://github.com/grafana/xk6
- quic-go: https://github.com/quic-go/quic-go
- Caddy HTTP/3: https://caddyserver.com/docs/automatic-https#http-3

---

**Status:** Ready to Begin Implementation  
**Priority:** High (enables HTTP/3 load testing)  
**Dependencies:** None (can start immediately)

