# Ingress Endpoint Warnings - Expected Behavior

## Summary

The ingress-nginx controller logs warnings about missing endpoints for services like:
- `auth-service`
- `social-service`
- `shopping-service`
- `listings-service`
- `nginx`

**These warnings are expected and harmless** - they occur during normal pod restarts and updates.

## Why These Warnings Appear

1. **Timing**: The ingress controller checks endpoints before pods are fully ready
2. **Pod Restarts**: During rolling updates or pod restarts, endpoints are temporarily unavailable
3. **Readiness Probes**: Endpoints only appear after readiness probes pass (typically 5-20 seconds after pod start)

## Verification

All services have active endpoints:

```bash
kubectl get endpoints -n record-platform
```

Expected output:
```
auth-service      10.244.0.49:50051,10.244.0.49:4001
social-service    10.244.0.23:50056,10.244.0.23:4006
shopping-service  10.244.0.35:4007,10.244.0.35:50058
nginx             10.244.0.3:8082,10.244.0.3:8080
api-gateway       10.244.0.48:4000
```

## Impact

- **No functional impact**: Services work correctly despite warnings
- **No test failures**: All integration tests pass
- **No user impact**: API gateway routes correctly to all services

## When to Investigate

Only investigate if:
1. Warnings persist for > 5 minutes continuously
2. Services are actually unavailable (not just warnings)
3. Tests are failing with 502/503 errors
4. Endpoints show as empty: `kubectl get endpoints <service-name> -n record-platform`

## Current Status

✅ All services have active endpoints
✅ All pods are running and ready
✅ API gateway is working correctly
✅ All tests pass

## Reducing Warnings (Optional)

To reduce warning frequency:

1. **Add startup probes** to services (already configured for most services)
2. **Increase replica count** to 2+ for zero-downtime updates
3. **Use RollingUpdate strategy** (already configured)

These warnings are informational and do not indicate a problem.

