Author: Tom

Context (Dec 16, 2025):
- Cluster: kind h3 (apiServerPort 16443), services deployed via base+dev overlay; webapp excluded.
- Externalized infra: Postgres fleet on Docker Desktop, Redis/Kafka/ZK externalized or in-cluster as noted.
- Images: rebuilt and loaded (auction-monitor fixed to include express, @common/utils, proto).

Current critical issues:
- Kafka pod `kafka-5fc5964b86-tgjn4` CrashLoopBackOff; logs stop after “Zookeeper is healthy” (need deeper broker logs to see why it exits).
- Auth/listings/shopping pods in Running 0/1 due to startup probes timing out on gRPC/TLS endpoints:
  - Auth: startup probe to `grpc-health-probe` against 50051 (TLS) times out; exits previously with 137 (likely OOM or probe kill). Needs longer startup / higher mem / slower TLS probe.
  - Listings: same pattern on 50057 with TLS probe; exits 137.
  - Shopping: startup probe to HTTP 4007 times out; exits repeatedly. Last state “Completed” before restart; may be probe timing/slow start.
- Zookeeper restarting (9x) but currently Running; Kafka may be impacted.
- No k6 jobs currently in the namespace; resource caps for future jobs still to be rechecked when reapplying manifests.

Recent fixes:
- auction-monitor Dockerfile now copies proto, common, and flattens @common/utils; pods recreated and running (HTTP 4008, gRPC 50059).
- Auth/Listings/Shopping deployments patched to relax startup/readiness/liveness probes and raise CPU/memory limits modestly; rollout applied (new pods starting).
- Kafka/Zookeeper pods deleted to clear InconsistentClusterId; new pods recreating (monitor startup).

Next actions proposed:
1) Kafka: fetch full broker logs (`kubectl logs kafka-... --previous --tail=-1` and container logs beyond preflight) and check PVC state; consider disabling SSL env (already set false in app-config) and ensure listeners/plaintext; reset PVC if metadata mismatch.
2) Auth/Listings/Shopping: relax startup probe timeouts/thresholds, possibly add initialDelaySeconds 90-120 and period 15-20; raise memory limits modestly (auth/listings 512->768Mi or 1Gi; shopping 1Gi ok). Verify TLS cert mounts present; ensure service-tls secret correct. Rollout restart after patch.
3) Zookeeper/Kafka: confirm ZK stable, then restart Kafka after any config fix.
4) k6 jobs: when reapplying, ensure requests low (256-512Mi) and limits reasonable (1-2Gi), add ttlSecondsAfterFinished=300 and backoffLimit=0.
5) After stabilization, rerun smoke `scripts/test-microservices-http2-http3.sh`, then k6 E2E.

