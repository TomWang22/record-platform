# k6 Load Testing Guide

## Overview

The k6 test suite tests the entire pipeline including:
- Authentication flow
- Records CRUD operations
- Analytics pipeline (auction-monitor → analytics-service)
- Mixed workloads (reads/writes)
- Stress testing
- Soak testing (memory leaks)

## Quick Start

### Option 1: Run In-Cluster (Recommended)

```bash
# Run main all-in-one test
./scripts/run-k6-in-cluster.sh all-in-one-k6.js

# Run analytics pipeline tests
./scripts/run-k6-in-cluster.sh k6-analytics-ingestion.js

# With custom parameters
BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000 \
MODE=mixed \
RATE=100 \
DURATION=10m \
VUS=50 \
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

### Option 2: Run Locally (with port-forward)

```bash
# Start port-forward
kubectl -n record-platform port-forward svc/api-gateway 8080:4000 &
PF_PID=$!

# Run test
BASE_URL=http://localhost:8080 \
./scripts/run-k6-tests.sh

# Cleanup
kill $PF_PID
```

### Option 3: Run Analytics Pipeline Tests

```bash
# Full analytics test suite
./scripts/load/run-analytics-tests.sh

# Individual tests
k6 run scripts/load/k6-analytics-ingestion.js
k6 run scripts/load/k6-analytics-load-ramp.js
k6 run scripts/load/k6-analytics-read-heavy.js
```

## Available Test Scripts

### Main Tests
- **`all-in-one-k6.js`** - Complete pipeline test (auth, CRUD, mixed workload)
- **`k6-mixed.js`** - Mixed read/write workload
- **`k6-reads.js`** - Read-only workload

### Analytics Pipeline Tests
- **`k6-analytics-ingestion.js`** - Basic ingestion pipeline test
- **`k6-analytics-real-data.js`** - Real data from eBay/Discogs APIs
- **`k6-analytics-data-quality.js`** - Data quality validation
- **`k6-analytics-db-validation.js`** - Database validation
- **`k6-analytics-load-ramp.js`** - Load ramp (1K → 5K VU)
- **`k6-analytics-read-heavy.js`** - Read-heavy workload (1K → 3K VU)
- **`k6-analytics-soak.js`** - Soak test (30m, memory leak detection)
- **`k6-analytics-stress.js`** - Stress test (high concurrent load)

### Pipeline Tests
- **`k6-pipeline-tail-latency.js`** - Tail latency metrics

## Test Modes

### Mixed Mode (Default)
- 70% reads, 30% writes
- Tests full CRUD operations
- Good for general pipeline testing

```bash
MODE=mixed RATE=50 DURATION=5m ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

### Read-Only Mode
- 100% reads
- Tests cache and read performance
- Good for read-heavy scenarios

```bash
MODE=get RATE=100 DURATION=5m ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

### Soak Mode
- Long duration, steady load
- Tests for memory leaks
- Good for stability testing

```bash
MODE=soak RATE=40 DURATION=30m ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

### Stress Mode
- Ramping load
- Tests breaking points
- Good for capacity planning

```bash
MODE=stress RATE=50 ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

## Configuration

### Environment Variables

```bash
BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000  # In-cluster
# or
BASE_URL=http://localhost:8080  # Local with port-forward

MODE=mixed          # mixed | get | soak | stress
RATE=50             # Requests per second
DURATION=5m         # Test duration
VUS=20              # Virtual users (pre-allocated)
MAX_VUS=200         # Maximum virtual users
EMAIL=t@t.t         # Test user email
PASS=p@ssw0rd       # Test user password
```

### Analytics-Specific Variables

```bash
ANALYTICS_URL=http://analytics-service.record-platform.svc.cluster.local:4004
AUCTION_MONITOR_URL=http://auction-monitor.record-platform.svc.cluster.local:4008
START_VUS=1000      # Starting VUs for ramp tests
MAX_VUS=5000        # Maximum VUs for ramp tests
STEP_VUS=500        # VU increment per step
STEP_DURATION=2m    # Duration per step
```

## Running Tests

### 1. All-in-One Test (Main Pipeline)

```bash
# In-cluster
./scripts/run-k6-in-cluster.sh all-in-one-k6.js

# Local (requires k6 installed)
k6 run \
  --env BASE_URL=http://localhost:8080 \
  --env MODE=mixed \
  --env RATE=50 \
  --env DURATION=5m \
  scripts/load/all-in-one-k6.js
```

### 2. Analytics Pipeline Tests

```bash
# Full suite
./scripts/load/run-analytics-tests.sh

# Individual test
k6 run \
  --env ANALYTICS_URL=http://analytics-service.record-platform.svc.cluster.local:4004 \
  --env AUCTION_MONITOR_URL=http://auction-monitor.record-platform.svc.cluster.local:4008 \
  scripts/load/k6-analytics-ingestion.js
```

### 3. Pipeline Load Test

```bash
./scripts/load/run-pipeline-load-test.sh
```

## Results

### In-Cluster Results
Results are logged to the job pod. View with:
```bash
kubectl -n record-platform logs job/k6-test-<timestamp>
```

### Local Results
Results are printed to stdout and can be exported:
```bash
k6 run --out json=results.json scripts/load/all-in-one-k6.js
```

### Analytics Test Results
Results are saved to:
```
scripts/load/results/analytics-*.json
```

View results:
```bash
cat scripts/load/results/analytics-*.json | jq
```

## Prerequisites

### For In-Cluster Testing
- Kubernetes cluster access
- kubectl configured
- Services running in cluster

### For Local Testing
- k6 installed: `brew install k6` (macOS) or [k6.io/docs/getting-started/installation/](https://k6.io/docs/getting-started/installation/)
- Port-forward running (if testing against cluster)
- Services accessible

## Test Scenarios

### Scenario 1: Basic Pipeline Test
```bash
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```
Tests: Auth, records CRUD, mixed workload

### Scenario 2: Analytics Pipeline
```bash
./scripts/load/run-analytics-tests.sh
```
Tests: Ingestion, data quality, load ramp, read-heavy, soak, stress

### Scenario 3: Stress Test
```bash
MODE=stress RATE=100 DURATION=10m VUS=50 MAX_VUS=500 \
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```
Tests: Breaking points, capacity planning

### Scenario 4: Soak Test
```bash
MODE=soak RATE=40 DURATION=30m VUS=50 \
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```
Tests: Memory leaks, stability

## Troubleshooting

### Services Not Ready
```bash
# Check service health
./scripts/test-all-services.sh

# Check specific service
kubectl -n record-platform get pods -l app=api-gateway
kubectl -n record-platform logs -l app=api-gateway --tail=50
```

### Authentication Failures
```bash
# Get test token
./scripts/load/get-token.sh

# Check auth service
kubectl -n record-platform logs -l app=auth-service --tail=50
```

### Database Connection Issues
```bash
# Check database connectivity
kubectl -n record-platform exec -it <pod-name> -- \
  env | grep POSTGRES_URL

# Test connection
kubectl -n record-platform run psql-test --rm -i --restart=Never \
  --image=postgres:16 -- \
  psql "$POSTGRES_URL" -c "SELECT 1"
```

## Next Steps

1. **Run basic test**: `./scripts/run-k6-in-cluster.sh all-in-one-k6.js`
2. **Run analytics tests**: `./scripts/load/run-analytics-tests.sh`
3. **Review results**: Check logs and JSON output files
4. **Adjust parameters**: Modify RATE, DURATION, VUS based on results
5. **Run stress tests**: Find breaking points with stress mode

