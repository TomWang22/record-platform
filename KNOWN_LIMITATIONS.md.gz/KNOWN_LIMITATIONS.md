# Known Limitations

## HTTP/3 Support

### Issue
Test 7b (Add Comment to Forum Post via HTTP/3) occasionally fails with HTTP 502.

### Root Cause
- HTTP/3 uses QUIC (UDP-based protocol)
- `http-proxy-middleware` uses Node.js's `http`/`https` modules (TCP-based)
- When Caddy forwards HTTP/3 to API Gateway, connection resets can occur during protocol conversion
- Error: `ECONNRESET` - connection reset by peer

### Impact
- **Low**: Only affects HTTP/3 POST requests to `/api/forum/posts/:postId/comments`
- HTTP/2 version works perfectly
- All other HTTP/3 operations work correctly
- 201/202 tests passing (99.5% success rate)

### Workaround
- Use HTTP/2 for comment POST requests (automatic fallback)
- Retry failed HTTP/3 requests as HTTP/2
- Client applications should handle HTTP/3 failures gracefully

### Future Fix
- Wait for Node.js native HTTP/3 support (experimental in Node.js 20+)
- Or use alternative proxy library with HTTP/3 support
- Or implement direct HTTP/3 handling in API Gateway

### Status
**Accepted as known limitation** - HTTP/3 is experimental and HTTP/2 provides full functionality.

---

## PGBouncer

### Issue
PGBouncer has been removed from the stack for direct database tuning.

### Impact
- Services connect directly to PostgreSQL
- Connection pooling handled by PostgreSQL itself
- May need to tune PostgreSQL `max_connections` if needed

### Status
**Intentionally disabled** - Direct DB connections for better control.

---

## Service Mesh

### Issue
Both Linkerd and Istio are installed, which may cause conflicts.

### Recommendation
- Use **one** service mesh (recommend Linkerd for simplicity)
- Disable the other to avoid conflicts
- Both provide similar functionality (mTLS, metrics, traffic management)

### Status
**Needs decision** - Choose one service mesh for production.

