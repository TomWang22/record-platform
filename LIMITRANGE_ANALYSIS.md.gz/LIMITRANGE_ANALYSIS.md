# LimitRange Analysis

**Generated:** $(date)

---

## Purpose

This document analyzes LimitRange configurations in the `record-platform` namespace that may be affecting pod scheduling, particularly for k6 jobs.

---

## LimitRange Check

### Command Used
```bash
kubectl -n record-platform get limitrange -o yaml
```

### Results
*(Output will be populated below after running the check)*

---

## Impact on Pod Scheduling

### How LimitRange Affects Scheduling

1. **Default Requests:**
   - If LimitRange sets default requests, pods without explicit requests will use these defaults
   - Defaults may be set to match limits (requests = limits)
   - This can cause "Insufficient memory" errors even when actual usage is low

2. **Memory Requests vs Limits:**
   - **Requests:** What Kubernetes reserves for scheduling (affects scheduling)
   - **Limits:** Maximum allowed usage (doesn't affect scheduling)
   - If requests are too high, pods will be Pending even if limits are reasonable

3. **k6 Job Impact:**
   - k6 jobs need low requests (for scheduling) but high limits (for burst)
   - If LimitRange forces high requests, multiple k6 pods cannot schedule

---

## Recommended k6 Resource Configuration

### Current Configuration (After Fix)
```yaml
resources:
  requests:
    cpu: "250m"
    memory: "512Mi"
  limits:
    cpu: "1000m"
    memory: "4Gi"
```

### Why This Works
- **Low requests (250m CPU, 512Mi memory):** Allows scheduling on single-node kind
- **High limits (1000m CPU, 4Gi memory):** Allows k6 to use resources when available
- **Explicit requests:** Overrides any LimitRange defaults

---

## Additional k6 Job Settings

### TTL and Backoff
```yaml
ttlSecondsAfterFinished: 300  # Auto-delete after 5 minutes
backoffLimit: 0                # Don't retry on failure
```

### Why These Matter
- **ttlSecondsAfterFinished:** Prevents old jobs from reserving resources
- **backoffLimit: 0:** Prevents failed jobs from retrying and consuming resources

---

## Troubleshooting

### If Pods Are Still Pending

1. **Check LimitRange:**
   ```bash
   kubectl -n record-platform get limitrange -o yaml
   ```

2. **Check Node Resources:**
   ```bash
   kubectl describe node | grep -A 10 "Allocated resources"
   ```

3. **Check Pod Events:**
   ```bash
   kubectl describe pod <pod-name> | grep -A 10 "Events:"
   ```

4. **Look for "Insufficient memory" errors:**
   - This means requests are too high for available node memory
   - Solution: Lower requests in k6 job manifest

---

## Next Steps

1. Review LimitRange output (below)
2. If LimitRange exists with high defaults, either:
   - Remove/update LimitRange, OR
   - Ensure k6 jobs have explicit low requests (already done)
3. Verify k6 jobs can schedule with new resource configuration
4. Monitor node memory allocation

---

## LimitRange Output

### Check Result
```bash
kubectl -n record-platform get limitrange -o yaml
```

### Result
**No LimitRange found in `record-platform` namespace.**

This means:
- ✅ No default resource constraints are set
- ✅ Pods can use explicit resource requests/limits without LimitRange interference
- ✅ k6 jobs with low requests (250m CPU, 512Mi memory) should schedule without issues
- ✅ The "Insufficient memory" errors are likely due to actual node memory pressure, not LimitRange defaults

### Impact
Since no LimitRange exists, the k6 job resource configuration is the primary factor:
- **Requests:** 250m CPU, 512Mi memory (low for scheduling)
- **Limits:** 1000m CPU, 4Gi memory (high for burst)

This configuration should allow 4 k6 pods to schedule on a single-node kind cluster.

