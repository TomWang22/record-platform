# Listings Service Bottlenecks Analysis

## Test Results Summary

**Test Date:** 2025-12-08  
**Database:** Fixed - Now using standalone postgres-listings-1 (port 5435:5432)  
**Configuration:** Fixed - POSTGRES_URL_LISTINGS corrected to port 5435

## Critical Bottleneck Fixed ✅

### 1. Missing Database Table (RESOLVED)

**Issue:** The `listings.listings` table did not exist in the database.

**Error Logs:**
```
[listings] search error: error: relation "listings.listings" does not exist
[listings] create error: error: relation "listings.listings" does not exist
```

**Resolution:**
- ✅ Applied all listings schema migrations
- ✅ Created `listings.listings` table (199 rows exist)
- ✅ All related tables created (auction_details, bids, images, offers, watchlist, etc.)

**Impact:**
- This was causing 82.76% error rate
- All database operations were failing
- **RESOLVED** - Table now exists and service is connected

### 2. Wrong Database Connection (RESOLVED)

**Issue:** `POSTGRES_URL_LISTINGS` was pointing to port 5439 (Analytics DB) instead of 5435 (Listings DB).

**Configuration Error:**
```yaml
# BEFORE (WRONG):
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@host.docker.internal:5439/records?connect_timeout=5
# Comment said: "Listings DB: 5439:5432 (same as Analytics)" - INCORRECT

# AFTER (CORRECT):
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@host.docker.internal:5435/records?connect_timeout=5
# Comment says: "Listings DB: 5435:5432 (standalone, separate from Analytics)"
```

**Resolution:**
- ✅ Updated `app-config.yaml` to use port 5435
- ✅ Restarted listings-service
- ✅ Service now connected to correct database

**Impact:**
- Service was trying to use Analytics database
- Could not find listings schema/tables
- **RESOLVED** - Now using correct standalone listings database

## Critical Bottleneck Identified 🚨

### 1. Authentication Service - bcrypt Performance (PRIMARY BOTTLENECK)

**Issue:** bcrypt.hash is taking 56-84 seconds per registration, blocking all authenticated operations.

**Current Performance:**
- bcrypt.hash: 56-84 seconds (EXTREMELY SLOW - should be < 1 second)
- Total Register Duration: 60-84 seconds
- HTTP Register: 3-23 seconds (inconsistent)
- gRPC Register: 60-84 seconds (very slow)
- Direct service call: 2-5 seconds (acceptable)

**Root Causes:**
1. **CPU Contention**: Multiple concurrent bcrypt operations competing for CPU
2. **bcryptjs Synchronous Blocking**: Even though it's async, bcrypt is CPU-intensive and blocks the event loop
3. **High bcrypt Rounds**: Currently using rounds=10, which is secure but slow under load
4. **No Request Queuing**: All registrations happen concurrently, overwhelming the CPU

**Impact:**
- **100% Error Rate**: All requests timing out (20+ seconds)
- **0% Success Rate**: No successful operations
- **Blocking All Authenticated Operations**: Cannot create listings, bid, or use watchlist
- **Only Public Endpoints Work**: Search works, but all authenticated endpoints fail

**Evidence from Logs:**
```
[gRPC] Register: bcrypt.hash took 83875ms
[gRPC] Register: Total duration 84581ms (check: 160ms, hash: 83875ms, insert: 237ms, token: 298ms)

[gRPC] Register: bcrypt.hash took 56030ms
[gRPC] Register: Total duration 60487ms (check: 4374ms, hash: 56030ms, insert: 62ms, token: 10ms)
```

**Test Results:**
- Total Requests: 21
- Error Rate: 100% (all requests failed)
- Success Rate: 0%
- Test Duration: 62.5 seconds
- VUs: 10
- Min Latency: 5.7 seconds
- Avg Latency: 15.3 seconds
- Median Latency: 20.3 seconds
- P95 Latency: 24.2 seconds
- P99 Latency: 24.2 seconds
- Max Latency: 24.2 seconds

**Recommendations (Priority Order):**

1. **Reduce bcrypt Rounds (IMMEDIATE)**
   - Change from rounds=10 to rounds=8 (still secure, 4x faster)
   - For development: Consider rounds=6 (8x faster)
   - Location: `services/auth-service/src/server.ts:116` and `services/auth-service/src/grpc-server.ts:73`

2. **Implement Request Queuing (HIGH PRIORITY)**
   - Add a queue for registration requests to prevent CPU contention
   - Limit concurrent bcrypt operations to 2-3 at a time
   - Use a worker pool for bcrypt hashing

3. **Use Async bcrypt with Worker Threads (MEDIUM PRIORITY)**
   - Move bcrypt to worker threads to prevent event loop blocking
   - Consider using `bcrypt` (native) instead of `bcryptjs` (JS) for better performance

4. **Add Rate Limiting (MEDIUM PRIORITY)**
   - Limit registration requests per IP/user
   - Prevent abuse and reduce load

5. **Optimize Database Queries (LOW PRIORITY)**
   - The database operations are fast (62-237ms)
   - Focus on bcrypt first

## Remaining Bottlenecks (Secondary)

**Issue:** Authentication is still slow, causing failures during load tests.

**Current Performance:**
- HTTP Register: 3-23 seconds (inconsistent)
- gRPC Register: 30+ seconds (very slow)
- Direct service call: 2-5 seconds (acceptable)

**Potential Causes:**
- Connection pool exhaustion (currently 50 connections)
- Database query performance (SELECT taking 3-4 seconds)
- bcrypt hashing performance
- Network latency to external Postgres

**Impact:**
- Prevents authenticated operations (create listing, bid, watchlist)
- Only public endpoints (search) work reliably
- High latency for successful requests

**Recommendations:**
- Investigate auth service Register endpoint performance
- Check connection pool configuration
- Optimize database queries
- Consider async bcrypt hashing
- Add connection retry logic

### 2. High Latency Outliers

**Issue:** Even successful requests have high latency outliers.

**Previous Metrics (before fixes):**
- Average Latency: 2276.90ms
- Median Latency: 62.98ms (good, but outliers are extreme)
- P95: 12619.32ms (very high)
- P99: 12620.42ms (very high)
- Max: 12620.84ms

**Analysis:**
- Median (62.98ms) is reasonable, indicating most requests are fast
- P95/P99 are extremely high (12+ seconds), indicating severe outliers
- These outliers are likely authentication timeouts

**Potential Causes:**
- Authentication timeouts (20+ seconds)
- Database connection issues
- Network latency
- Service overload

**Recommendations:**
- Reduce P95/P99 latency to < 500ms
- Implement request queuing
- Add circuit breakers
- Optimize database queries

## Database Configuration

**Standalone Databases (All Separate):**
- postgres-1: 5433:5432 (main/records)
- postgres-social-1: 5434:5432
- postgres-listings-1: 5435:5432 ✅ (standalone)
- postgres-shopping-1: 5436:5432
- postgres-auth-1: 5437:5432
- postgres-auction-monitor-1: 5438:5432
- postgres-analytics-1: 5439:5432
- postgres-python-ai-1: 5440:5432

**Listings Database:**
- Container: record-platform-postgres-listings-1 (e94729a8bc09)
- Port: 5435:5432 (host:container)
- Database: records
- Schema: listings
- Tables: 10 tables (listings, auction_details, bids, images, offers, watchlist, ratings, etc.)
- Data: 199 listings exist

## Test Configuration

- **TLS:** Strict TLS enabled (k6-strict-tls:dev)
- **Protocol:** HTTP/2 and HTTP/3 (QUIC) via ALPN negotiation
- **Test Type:** Comprehensive load test
- **Service:** Listings Service

## Next Steps

1. ✅ Fix database schema (completed)
2. ✅ Fix database connection (completed)
3. 🔄 Re-run k6 tests to verify error rate improvement
4. 🔄 Investigate auth service Register performance
5. 🔄 Optimize authentication flow
6. 🔄 Monitor database performance during load
7. 🔄 Run limit test to find maximum capacity

## Files Modified

- `infra/k8s/base/config/app-config.yaml`: Fixed POSTGRES_URL_LISTINGS port
- `infra/db/05-listings-schema.sql`: Applied schema
- `infra/db/05-listings-schema-extended.sql`: Applied extended schema
- `infra/db/05-listings-timeline-duration.sql`: Applied timeline schema
- `infra/db/05-listings-ratings-timezone.sql`: Applied ratings schema
- `infra/db/08-listings-catalog-id-migration.sql`: Applied catalog ID migration

---

*Analysis based on k6 test results and service logs from 2025-12-08*
