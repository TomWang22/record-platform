# Listings Database Optimization - Complete

**Date:** 2025-12-08  
**Database:** postgres-listings-1 (port 5435)  
**Status:** ✅ Complete

## Optimizations Implemented

### 1. Watchlist Schema Fix ✅

**Issue:** ON CONFLICT errors due to missing unique constraint for (user_id, listing_id)

**Solution:**
- Created unique index: `unique_user_listing` on (user_id, listing_id) WHERE listing_id IS NOT NULL
- Existing constraint: `watchlist_user_source_query_key` on (user_id, source, query) for search query watchlists
- Both constraints now work correctly

**Result:** ON CONFLICT now works for both listing watchlists and search query watchlists

### 2. Database Indexes Optimization ✅

**Indexes Created/Verified:**
- ✅ `idx_listings_title_trgm` - Trigram index for fast text search on titles
- ✅ `idx_listings_description_trgm` - Trigram index for fast text search on descriptions
- ✅ `idx_watchlist_user_id` - Fast user watchlist lookups
- ✅ `idx_watchlist_listing_id` - Fast listing watchlist lookups
- ✅ `unique_user_listing` - Unique constraint for listing watchlists
- ✅ `watchlist_user_source_query_key` - Unique constraint for search query watchlists

**Partial Indexes (for write optimization):**
- `idx_listings_active_created` - Only indexes active listings
- `idx_listings_expires_at` - Only indexes listings with expiration dates
- `idx_listings_stock_quantity` - Only indexes listings with stock

### 3. Redis Caching with Lua Scripts ✅

**Implementation:**
- Created `services/listings-service/src/lib/redis-cache.ts`
- Atomic operations using Lua scripts
- Multiple cache types with appropriate TTLs

**Cache Types:**
- **Listing Cache:** 5 minutes TTL (individual listings)
- **Search Results Cache:** 1 minute TTL (dynamic, shorter for freshness)
- **Watchlist Cache:** 3 minutes TTL (user watchlists)

**Lua Scripts:**
- `LISTING_CACHE_UPDATE_SCRIPT` - Atomic listing cache update
- `SEARCH_CACHE_UPDATE_SCRIPT` - Atomic search cache with size limits
- `WATCHLIST_CACHE_UPDATE_SCRIPT` - Atomic watchlist cache update
- `CACHE_INVALIDATE_PATTERN_SCRIPT` - Pattern-based cache invalidation

**Features:**
- Size limits to prevent memory bloat
- Automatic TTL refresh
- Pattern-based invalidation for bulk updates
- Cache statistics for monitoring

### 4. PostgreSQL Tuning Configuration ✅

**File Created:** `infra/db/postgres-listings-tune.conf`

**Key Settings for Write-Heavy Workloads:**

**Memory:**
- `shared_buffers = 2GB` (25% of RAM)
- `effective_cache_size = 6GB` (50-75% of RAM)
- `work_mem = 8MB` (per operation)
- `maintenance_work_mem = 1GB` (for VACUUM, CREATE INDEX)

**Write Performance:**
- `wal_buffers = 16MB` (good for write-heavy)
- `checkpoint_completion_target = 0.9` (spreads checkpoints)
- `max_wal_size = 2GB` (more writes between checkpoints)
- `min_wal_size = 512MB`

**Query Planner:**
- `random_page_cost = 1.1` (SSD optimized)
- `effective_io_concurrency = 200` (SSD optimized)
- `default_statistics_target = 100`

**Autovacuum (Critical for Writes):**
- `autovacuum_max_workers = 4` (more workers)
- `autovacuum_naptime = 10s` (check frequently)
- `autovacuum_vacuum_scale_factor = 0.1` (lower threshold)
- `autovacuum_analyze_scale_factor = 0.05` (lower threshold)
- `autovacuum_vacuum_cost_delay = 2ms` (more aggressive)

**Connection Settings:**
- `max_connections = 200` (adjust based on pooler)
- `superuser_reserved_connections = 3`

**Parallel Query:**
- `max_parallel_workers_per_gather = 4`
- `max_parallel_workers = 8`
- `max_worker_processes = 8`

### 5. Trigram Optimization ✅

**Extension:** `pg_trgm` (already enabled)

**Indexes:**
- Title trigram index for fast fuzzy search
- Description trigram index for fast fuzzy search
- Search history query trigram index

**Usage:**
- Fast text search with similarity matching
- Supports ILIKE queries efficiently
- Reduces full table scans

## Performance Improvements Expected

### Write Performance
- **Before:** 1607ms for user insert, 248ms for listing insert
- **After:** Expected 50-80% reduction with:
  - Optimized autovacuum
  - Better WAL configuration
  - Connection pool tuning
  - Reduced index maintenance overhead

### Read Performance
- **Search Queries:** 50-90% faster with trigram indexes
- **Cache Hits:** < 1ms (vs 10-100ms database queries)
- **Watchlist Queries:** Faster with composite indexes

### Cache Performance
- **Listing Lookups:** < 1ms (cache hit) vs 10-50ms (database)
- **Search Results:** < 1ms (cache hit) vs 100-500ms (database)
- **Watchlist:** < 1ms (cache hit) vs 20-100ms (database)

## Integration Status

### ✅ Completed
1. Database schema fixes
2. Index optimization
3. Redis cache implementation
4. PostgreSQL tuning configuration

### 🔄 In Progress
1. Integrate Redis cache into listings routes
2. Apply PostgreSQL tuning config to postgres-listings-1
3. Test with pgbench

### 📋 To Do
1. Integrate cache into:
   - `getListingById()` - Cache individual listings
   - `searchListings()` - Cache search results
   - `getUserWatchlist()` - Cache user watchlists
2. Add cache invalidation on:
   - Listing updates
   - Listing creation
   - Watchlist changes
3. Apply PostgreSQL tuning config
4. Run pgbench tests to measure improvements
5. Monitor cache hit rates

## Files Created/Modified

- ✅ `infra/db/optimize-listings-db.sql` - Database optimization script
- ✅ `infra/db/postgres-listings-tune.conf` - PostgreSQL tuning config
- ✅ `services/listings-service/src/lib/redis-cache.ts` - Redis cache with Lua scripts
- ✅ `LISTINGS_DB_OPTIMIZATION_COMPLETE.md` - This document

## Next Steps

1. **Integrate Redis Cache:**
   - Update `getListingById()` to use cache
   - Update `searchListings()` to use cache
   - Update `getUserWatchlist()` to use cache
   - Add cache invalidation on writes

2. **Apply PostgreSQL Tuning:**
   - Mount `postgres-listings-tune.conf` in Docker
   - Restart postgres-listings-1
   - Verify settings with `SHOW` commands

3. **Run pgbench Tests:**
   - Use `scripts/run_listings_pgbench_sweep.sh`
   - Compare before/after performance
   - Measure write performance improvements

4. **Monitor Performance:**
   - Track cache hit rates
   - Monitor database query times
   - Watch for slow queries
   - Adjust cache TTLs based on usage

---

*Optimization complete - Ready for integration and testing*

