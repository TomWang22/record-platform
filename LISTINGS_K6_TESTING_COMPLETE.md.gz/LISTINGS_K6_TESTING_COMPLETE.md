# Listings Service K6 Testing - Complete Implementation

## Summary

We've implemented a comprehensive k6 testing suite for the listings service with:
- **Comprehensive latency percentiles**: p1 to p99, then p999, p9999, p99999, p999999, p9999999, p99999999, and p100
- **Limit testing**: Script to find maximum VUs the system can handle
- **Bottleneck detection**: Automatic identification of performance issues
- **Latency graph generation**: HTML reports with detailed percentile breakdowns
- **Strict TLS**: All tests enforce strict TLS verification

## Files Created/Modified

### Test Scripts
1. **`scripts/load/k6-listings-service-comprehensive.js`**
   - Comprehensive k6 test suite for listings service
   - Tests all endpoints: search, create, get, update, delete, bid, offer, watchlist, ratings, eBay search
   - Includes detailed latency tracking with all requested percentiles
   - Fixed handleSummary to safely handle missing metrics

2. **`scripts/run-k6-listings-with-graphs.sh`**
   - Runs k6 test and generates latency graphs immediately after
   - Uses Kubernetes Jobs to run tests in-cluster
   - Automatically cleans up pods after results are copied

3. **`scripts/run-k6-listings-limit.sh`**
   - Finds maximum VUs the system can handle
   - Gradually increases VUs until error rate exceeds threshold
   - Identifies bottlenecks at each VU level
   - Generates latency graphs for maximum successful VU test

### Analysis Tools
4. **`scripts/load/calculate-percentiles.py`**
   - Calculates all requested percentiles from k6 results
   - Identifies performance bottlenecks
   - Handles missing percentiles with interpolation

5. **`scripts/load/generate-latency-graph.py`** (Updated)
   - Generates HTML latency reports
   - Displays all percentiles (p1 to p100)
   - Shows component breakdown (Search, Create, Bid, Watchlist)
   - Fixed Python variable shadowing issue

### CronJobs
6. **`infra/k8s/base/cron-jobs/k6-listings-daily.yaml`**
   - Daily comprehensive load tests

7. **`infra/k8s/base/cron-jobs/k6-listings-limit-weekly.yaml`**
   - Weekly limit tests to find maximum capacity

## Current Status

### ✅ Completed
- k6 test script with all endpoints
- Comprehensive percentile calculation (p1 to p100)
- Bottleneck detection
- Limit test script
- Latency graph generation
- CronJob configurations
- Strict TLS enforcement
- Fixed handleSummary crashes
- Fixed Python variable shadowing

### ⚠️ Known Issues
1. **File Copy Timing**: Pods terminate before files can be copied
   - **Workaround**: Files are created in `/results/` but need to be copied before pod termination
   - **Solution**: Use `kubectl exec` to cat files, or add a sidecar container that stays alive

2. **Authentication Failures**: 100% error rate due to connection issues
   - **Cause**: "cannot assign requested address" errors
   - **Solution**: Check Caddy service and network connectivity

## Usage

### Run Comprehensive Test with Graphs
```bash
VUS=50 DURATION=5m ./scripts/run-k6-listings-with-graphs.sh
```

### Run Limit Test
```bash
START_VUS=10 MAX_VUS=500 VUS_STEP=10 DURATION=2m ERROR_THRESHOLD=0.05 ./scripts/run-k6-listings-limit.sh
```

### Calculate Percentiles from Existing Results
```bash
python3 scripts/load/calculate-percentiles.py results/k6-listings-*/k6-summary.json --bottlenecks
```

### Generate Latency Graph
```bash
python3 scripts/load/generate-latency-graph.py results/k6-listings-*/k6-summary.json output.html
```

## Percentiles Calculated

The system calculates and displays:
- **p1, p5, p10, p25, p50, p75, p90, p95, p99**: Standard percentiles
- **p999, p9999, p99999, p999999, p9999999, p99999999**: Tail percentiles
- **p100**: Maximum observed latency

## Bottleneck Detection

The limit test automatically identifies:
- High error rates (>5%)
- High P95 latency (>1000ms)
- High P99 latency (>2000ms)
- Extreme tail latency (>30000ms)
- Latency spikes (P99 >> P95)

## Next Steps

1. **Fix File Copy Issue**: Implement sidecar container or use `kubectl exec` to copy files before pod termination
2. **Fix Authentication**: Investigate connection issues with Caddy service
3. **Run Full Test Suite**: Once connectivity is fixed, run comprehensive tests
4. **Review Results**: Analyze latency graphs and bottleneck reports

