# NodePort 30443 Fix Summary

## Problem
After running `build-and-load.sh`, the Caddy NodePort service (port 30443) was being lost or misconfigured, causing the full-chain test to fail.

## Root Cause
1. **Missing Service Definition File**: The Caddy service was being created manually via `kubectl apply`, but there was no persistent YAML file to ensure it survives rebuilds/restarts.
2. **Build Script Integration**: The `build-and-load.sh` script didn't ensure the service was recreated after image rebuilds.
3. **Known Kind Limitation**: Kind NodePort on macOS has TLS handshake issues (connection resets), which is a known limitation.

## Solution

### 1. Created Persistent Service Definition
- **File**: `infra/k8s/caddy-h3-service.yaml`
- Defines the NodePort service with port 30443
- Ensures the service configuration persists across rebuilds

### 2. Created Service Verification Script
- **File**: `scripts/ensure-caddy-service.sh`
- Checks if the service exists and has the correct NodePort
- Automatically fixes misconfigurations

### 3. Updated Deployment Scripts
- **File**: `scripts/edeploy-caddy-h3.sh`
- Fixed paths to use correct service definition location
- Added service verification after deployment

### 4. Integrated into Build Script
- **File**: `scripts/build-and-load.sh`
- Automatically ensures Caddy service exists after builds complete

## TLS Handshake Issue on macOS/Kind

**Known Limitation**: Kind NodePort on macOS has TLS handshake issues causing "Connection reset by peer" errors. This is a known Kind limitation, not a configuration issue.

**Workaround**: The test script (`scripts/test-full-chain-with-rotation.sh`) already has a fallback mechanism:
- First tries NodePort 30443 (production setup)
- Falls back to port-forward 8443 if TLS handshake fails
- This allows testing to continue even with the Kind limitation

## Usage

### Verify Service is Configured
```bash
./scripts/ensure-caddy-service.sh
```

### Deploy/Update Caddy
```bash
./scripts/edeploy-caddy-h3.sh
```

### After Rebuilds
The `build-and-load.sh` script now automatically ensures the service is configured, so no manual intervention needed.

## Service Configuration

- **Type**: NodePort
- **NodePort**: 30443 (TCP and UDP)
- **Target Port**: 443
- **Namespace**: ingress-nginx
- **Selector**: app: caddy-h3

## Verification

Check service status:
```bash
kubectl -n ingress-nginx get svc caddy-h3
```

Expected output:
```
NAME       TYPE       CLUSTER-IP     EXTERNAL-IP   PORT(S)                       AGE
caddy-h3   NodePort   10.96.72.132   <none>        443:30443/TCP,443:30443/UDP   Xm
```

## Notes

- The service will persist across cluster restarts (as long as Kind cluster is not deleted)
- If the Kind cluster is recreated, run `./scripts/ensure-caddy-service.sh` to recreate the service
- The TLS handshake issue on macOS is a known Kind limitation and doesn't affect in-cluster connectivity
