# NodePort TLS Issue Diagnosis

## Problem

Even port-forward is getting TLS errors:
```
curl: (35) TLS connect error: error:0A000126:SSL routines::unexpected eof while reading
```

This suggests the issue is **not** with NodePort or macOS/Kind TLS forwarding, but with **Caddy itself**.

## Root Cause Analysis

1. **Certificate exists**: `record-local-tls` secret exists and is mounted correctly
2. **Port-forward fails**: Even port-forward (which bypasses NodePort) gets TLS errors
3. **One pod not ready**: Readiness probe timing out on port 443
4. **Working commit had hostNetwork**: The working commit `b6bf4a2` likely had `hostNetwork: true`

## Possible Issues

### 1. Certificate Format
- Certificate might be corrupted or in wrong format
- Check: `kubectl -n ingress-nginx exec <pod> -- cat /etc/caddy/certs/tls.crt`

### 2. Caddy Configuration
- Caddyfile might have syntax errors
- TLS configuration might be incorrect
- Check: `kubectl -n ingress-nginx exec <pod> -- cat /etc/caddy/Caddyfile`

### 3. Caddy Not Listening
- Caddy might not be binding to port 443 correctly
- Check: `kubectl -n ingress-nginx exec <pod> -- netstat -tlnp | grep 443`

### 4. Readiness Probe Issue
- Readiness probe is TCP-only (no HTTP), so it might pass even if TLS is broken
- But if TCP probe is timing out, Caddy might not be listening at all

## Next Steps

1. **Regenerate certificate** using `mkcert`:
   ```bash
   ./scripts/rotate-ca-and-fix-tls.sh
   ```

2. **Check Caddy logs** for errors:
   ```bash
   kubectl -n ingress-nginx logs -l app=caddy-h3 --tail=100
   ```

3. **Test from inside cluster**:
   ```bash
   kubectl -n ingress-nginx run curl-test --rm -i --restart=Never --image=curlimages/curl -- \
     curl -k -sS -I --http2 -H "Host: record.local" \
     "https://caddy-h3.ingress-nginx.svc.cluster.local:443/_caddy/healthz"
   ```

4. **Verify certificate is valid**:
   ```bash
   kubectl -n ingress-nginx exec <pod> -- \
     openssl x509 -in /etc/caddy/certs/tls.crt -text -noout
   ```

5. **Check if Caddy is listening**:
   ```bash
   kubectl -n ingress-nginx exec <pod> -- netstat -tlnp | grep 443
   ```

## Working Commit Reference

Commit `b6bf4a2eaae9324ad3ce3c28c85aba5f988e5370` had:
- `hostNetwork: true` (bypassed NodePort TLS issues)
- Direct curl with `--resolve` worked perfectly
- No port-forward needed

Current setup:
- `hostNetwork: false` (using NodePort)
- Port-forward still gets TLS errors
- Suggests Caddy configuration or certificate issue

## Solution

The issue is likely that:
1. Certificate needs to be regenerated, OR
2. Caddy configuration needs to be fixed, OR  
3. Caddy pods need to be fully restarted

Try regenerating the certificate first:
```bash
./scripts/rotate-ca-and-fix-tls.sh
kubectl -n ingress-nginx rollout restart deploy/caddy-h3
kubectl -n ingress-nginx rollout status deploy/caddy-h3
```

Then test again.

