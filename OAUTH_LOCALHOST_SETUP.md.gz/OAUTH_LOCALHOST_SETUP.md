# OAuth Setup with localhost or ngrok

## Problem
Google OAuth doesn't accept `.local` domains. You need either:
- `localhost` (may require HTTPS)
- A real domain (like `yourdomain.com`)
- ngrok (for development with real HTTPS)

## Solution 1: Use localhost (Simple)

### In Google Console, use:
- **Application home page**: `http://localhost:3001`
- **Application privacy policy link**: `http://localhost:4001/privacy`
- **Application terms of service link**: (leave blank)

### Authorized domains:
- Add: `localhost`

⚠️ **Note**: Some Google OAuth features may require HTTPS. If you get errors, use Solution 2.

---

## Solution 2: Use ngrok (Recommended - Real HTTPS)

ngrok gives you a real HTTPS domain that tunnels to localhost.

### Step 1: Install ngrok
```bash
# macOS
brew install ngrok

# Or download from: https://ngrok.com/download
```

### Step 2: Start ngrok tunnel
```bash
# Tunnel to your webapp (port 3001) or gateway (port 8443)
ngrok http 8443

# Or if using auth-service directly:
ngrok http 4001
```

### Step 3: Copy the HTTPS URL
You'll see something like:
```
Forwarding: https://abc123.ngrok.io -> http://localhost:8443
```

### Step 4: Use in Google Console
- **Application home page**: `https://abc123.ngrok.io`
- **Application privacy policy link**: `https://abc123.ngrok.io/privacy`
- **Application terms of service link**: (leave blank)

### Step 5: Update OAuth Callback URL
Also update your OAuth client redirect URI:
- Go to: APIs & Services → Credentials → Your OAuth client
- Add redirect URI: `https://abc123.ngrok.io/api/auth/google/callback`
- Update `GOOGLE_CALLBACK_URL` in Kubernetes secrets

### Authorized domains:
- Add: The domain from ngrok (e.g., `abc123.ngrok.io`)

---

## Solution 3: Use a Real Domain (Production)

If you have a real domain:

- **Application home page**: `https://yourdomain.com`
- **Application privacy policy link**: `https://yourdomain.com/privacy`
- **Application terms of service link**: `https://yourdomain.com/terms` (optional)

### Authorized domains:
- Add: `yourdomain.com`

---

## Quick Decision Guide

- **Just testing locally?** → Use `localhost` (Solution 1)
- **Need HTTPS for testing?** → Use ngrok (Solution 2)
- **Production deployment?** → Use real domain (Solution 3)

---

## After Setting Up

1. Fill in the URLs in Google Console
2. Add authorized domains
3. Add test user: `tomwang04312@gmail.com`
4. Click "PUBLISH APP"

✅ Done!

