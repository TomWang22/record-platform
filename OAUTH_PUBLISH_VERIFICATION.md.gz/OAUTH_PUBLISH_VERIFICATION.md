# OAuth Publish Verification Checklist

## ✅ Pre-Publish Verification

Before clicking "PUBLISH APP", verify all these settings are correct:

---

## 1️⃣ OAuth 2.0 Client (Credentials Page)

**Go to:** https://console.cloud.google.com/apis/credentials

### Authorized JavaScript origins
**Should have:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev
```

**Why:** This is where OAuth requests originate from (your frontend).

### Authorized redirect URIs
**Should have:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback
```

**Why:** This is where Google redirects after authentication.

**⚠️ Critical:** This MUST match exactly what's in your Kubernetes secrets (`GOOGLE_CALLBACK_URL`).

---

## 2️⃣ OAuth Consent Screen (Branding)

**Go to:** https://console.cloud.google.com/apis/credentials/consent

### App Information
- **App name:** ✅ Any name (e.g., "Record Platform")
- **User support email:** ✅ `tomwang04312@gmail.com` (correct!)

### App Domain
**Application home page:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev
```

**Application privacy policy link:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/privacy
```

**Application terms of service link:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/terms
```

### Authorized domains
**Should have:**
```
denominative-contradistinctively-timika.ngrok-free.dev
```

**Note:** Just the domain, no `https://` or path.

### Verification Status
- ✅ **"Verification is not required"** - Perfect! This means you can publish without verification.

---

## 3️⃣ Kubernetes Configuration

**Verify these match Google Console:**

```yaml
GOOGLE_CLIENT_ID: "969606486482-2kt1ku811jmulj9ndvhsrk1u5n8mvbjk.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET: "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"
GOOGLE_CALLBACK_URL: "https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback"
FRONTEND_URL: "https://denominative-contradistinctively-timika.ngrok-free.dev"
```

**✅ These are already configured correctly!**

---

## 4️⃣ Test User (Optional but Recommended)

**Before publishing, add yourself as a test user:**

1. Go to OAuth Consent Screen
2. Scroll to "Test users"
3. Click "+ ADD USERS"
4. Add: `tomwang04312@gmail.com`

**Why:** Allows you to test OAuth immediately, even in testing mode.

---

## 5️⃣ Final Verification Steps

### ✅ Check 1: OAuth Client Redirect URI
- [ ] Matches: `https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback`
- [ ] Matches Kubernetes `GOOGLE_CALLBACK_URL`

### ✅ Check 2: OAuth Consent Screen URLs
- [ ] Home page: `https://denominative-contradistinctively-timika.ngrok-free.dev`
- [ ] Privacy policy: `https://denominative-contradistinctively-timika.ngrok-free.dev/privacy`
- [ ] Terms of service: `https://denominative-contradistinctively-timika.ngrok-free.dev/terms`
- [ ] Authorized domain: `denominative-contradistinctively-timika.ngrok-free.dev`

### ✅ Check 3: Pages Are Accessible
Test these URLs in your browser (via ngrok):
- [ ] `https://denominative-contradistinctively-timika.ngrok-free.dev/privacy` - Should show Privacy Policy
- [ ] `https://denominative-contradistinctively-timika.ngrok-free.dev/terms` - Should show Terms of Service

### ✅ Check 4: Verification Status
- [ ] Shows: "Verification is not required" ✅

---

## 🚀 Ready to Publish?

If all checks pass:

1. **Add Test User** (optional): `tomwang04312@gmail.com`
2. **Click "PUBLISH APP"** at the top of the OAuth Consent Screen
3. **Confirm** the warning dialog
4. **Status changes** from "Testing" to "In production"

---

## ⚠️ Important Notes

### ngrok URL Changes
**If ngrok restarts, the URL will change!** You'll need to:
1. Update Google Console with new ngrok URL
2. Update Kubernetes secrets
3. Restart auth-service

**For production:** Use a real domain instead of ngrok.

### After Publishing
- ✅ Any Google user can sign in (no need to add them manually)
- ✅ No more "This app isn't verified" warnings
- ✅ Production-ready OAuth

---

## 🐛 Troubleshooting

### "redirect_uri_mismatch" Error
- **Cause:** Callback URL in Google Console doesn't match `GOOGLE_CALLBACK_URL`
- **Fix:** Make sure both are exactly: `https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback`

### "Invalid domain" Error
- **Cause:** Domain not in authorized domains list
- **Fix:** Add `denominative-contradistinctively-timika.ngrok-free.dev` to authorized domains

### Privacy Policy Not Found
- **Cause:** Privacy policy URL returns 404
- **Fix:** Test the URL in browser, make sure it's accessible via ngrok

---

## ✅ Current Status

Based on your configuration:
- ✅ OAuth Client: Configured
- ✅ Consent Screen: Configured
- ✅ Kubernetes Secrets: Configured
- ✅ Gateway Routing: Fixed
- ✅ Privacy Policy: Created
- ✅ Terms of Service: Created
- ✅ Verification: Not required

**You're ready to publish!** 🎉

