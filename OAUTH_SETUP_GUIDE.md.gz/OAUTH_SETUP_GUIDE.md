# OAuth Setup Guide

This guide covers setting up Google OAuth (and other providers) for production-tier authentication.

## Current Implementation Status

✅ **OAuth is properly implemented** with:
- Google OAuth 2.0 via `passport-google-oauth20`
- Secure session management
- JWT token generation after OAuth
- Proper callback handling
- Error handling and redirects

## Google OAuth Setup

### Step 1: Create Google OAuth Credentials

1. Go to Google Cloud Console: https://console.cloud.google.com/
2. Create a new project or select an existing one
3. Enable **Google+ API**:
   - Go to **APIs & Services** → **Library**
   - Search for "Google+ API"
   - Click **Enable**

4. Create OAuth 2.0 Credentials:
   - Go to **APIs & Services** → **Credentials**
   - Click **Create Credentials** → **OAuth client ID**
   - If prompted, configure the OAuth consent screen first:
     - User Type: **External** (for public apps) or **Internal** (for G Suite)
     - App name, support email, developer contact
     - Scopes: `profile`, `email`
     - Test users (if in testing mode)

5. Create OAuth Client:
   - Application type: **Web application**
   - Name: "Record Platform Auth"
   - Authorized JavaScript origins:
     ```
     https://record.local:8443
     http://localhost:4001
     ```
   - Authorized redirect URIs:
     ```
     https://record.local:8443/api/auth/google/callback
     http://localhost:4001/auth/google/callback
     ```
   - Click **Create**
   - Copy the **Client ID** and **Client Secret**

### Step 2: Configure in Kubernetes

#### Update app-secrets.yaml

```yaml
# Google OAuth (required for OAuth features)
GOOGLE_CLIENT_ID: "your_google_client_id.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET: "your_google_client_secret"
GOOGLE_CALLBACK_URL: "https://record.local:8443/api/auth/google/callback"
FRONTEND_URL: "https://record.local:8443"  # Where to redirect after OAuth
```

#### Important Notes:

- **GOOGLE_CALLBACK_URL**: Must match exactly what you configured in Google Console
- **FRONTEND_URL**: Where users are redirected after successful OAuth
- For production, use your actual domain instead of `record.local`

### Step 3: Apply Configuration

```bash
# Apply secrets
kubectl apply -f infra/k8s/base/config/app-secrets.yaml

# Restart auth service
kubectl rollout restart deployment/auth-service -n record-platform
```

### Step 4: Test OAuth Flow

1. **Initiate OAuth**:
   ```bash
   curl -L "https://record.local:8443/api/auth/google"
   # This will redirect to Google login
   ```

2. **After Google login**, you'll be redirected to:
   ```
   https://record.local:8443/api/auth/google/callback?code=...
   ```

3. **The service will**:
   - Exchange code for user info
   - Create or find user in database
   - Generate JWT token
   - Redirect to `FRONTEND_URL` with token

## OAuth Flow Diagram

```
User → /api/auth/google
  ↓
Google Login Page
  ↓
User Authenticates
  ↓
Google Redirects → /api/auth/google/callback?code=...
  ↓
Auth Service:
  1. Exchanges code for user info
  2. Creates/finds user in database
  3. Generates JWT token
  4. Redirects to FRONTEND_URL?token=...
```

## Current Implementation Details

### OAuth Routes (`services/auth-service/src/routes/oauth.ts`)

1. **GET /auth/google** - Initiates OAuth flow
   - Redirects to Google login
   - Uses `passport.authenticate('google')`

2. **GET /auth/google/callback** - Handles OAuth callback
   - Receives authorization code from Google
   - Exchanges code for user profile
   - Creates or finds user in database
   - Generates JWT token
   - Redirects to frontend with token

### OAuth Configuration (`services/auth-service/src/lib/oauth.ts`)

- Uses `passport-google-oauth20` strategy
- Scopes: `['profile', 'email']`
- Session management for OAuth flow
- Error handling and redirects

## Production Checklist

### Google Cloud Console:
- [ ] Project created
- [ ] Google+ API enabled
- [ ] OAuth consent screen configured
- [ ] OAuth client ID created
- [ ] Authorized redirect URIs configured correctly
- [ ] Client ID and Secret copied

### Kubernetes Configuration:
- [ ] `GOOGLE_CLIENT_ID` set in `app-secrets.yaml`
- [ ] `GOOGLE_CLIENT_SECRET` set in `app-secrets.yaml`
- [ ] `GOOGLE_CALLBACK_URL` matches Google Console config
- [ ] `FRONTEND_URL` set to production domain
- [ ] Secrets applied: `kubectl apply -f infra/k8s/base/config/app-secrets.yaml`
- [ ] Auth service restarted

### Testing:
- [ ] OAuth initiation works (`/api/auth/google`)
- [ ] Google login page appears
- [ ] Callback URL receives code
- [ ] User created/found in database
- [ ] JWT token generated
- [ ] Redirect to frontend works
- [ ] Token is valid and can be used

## Troubleshooting

### Error: "redirect_uri_mismatch"
- **Cause**: Callback URL in Google Console doesn't match `GOOGLE_CALLBACK_URL`
- **Fix**: Update Google Console redirect URI to match exactly (including protocol, port, path)

### Error: "invalid_client"
- **Cause**: Wrong `GOOGLE_CLIENT_ID` or `GOOGLE_CLIENT_SECRET`
- **Fix**: Double-check credentials in `app-secrets.yaml` and Google Console

### Error: "access_denied"
- **Cause**: User denied OAuth permission or consent screen not configured
- **Fix**: Configure OAuth consent screen in Google Cloud Console

### OAuth works but no user created
- **Cause**: Database connection issue or user already exists
- **Fix**: Check auth service logs, verify database connection

### Token not in redirect URL
- **Cause**: Frontend URL not configured or redirect logic issue
- **Fix**: Verify `FRONTEND_URL` is set correctly, check OAuth callback handler

## Adding More OAuth Providers

The current implementation supports Google OAuth. To add more providers:

1. Install provider package (e.g., `passport-github2`, `passport-facebook`)
2. Add strategy in `services/auth-service/src/lib/oauth.ts`
3. Add routes in `services/auth-service/src/routes/oauth.ts`
4. Add credentials to `app-secrets.yaml`
5. Update frontend to support new provider

## Security Best Practices

- ✅ Use HTTPS in production (required for OAuth)
- ✅ Store secrets in Kubernetes secrets (not configmaps)
- ✅ Use environment variables (not hardcoded)
- ✅ Validate redirect URLs
- ✅ Use secure session cookies
- ✅ Implement CSRF protection
- ✅ Rate limit OAuth endpoints
- ✅ Log OAuth attempts for security monitoring

## Current Status

✅ **OAuth is properly set up** - you just need to:
1. Get Google OAuth credentials
2. Add them to `app-secrets.yaml`
3. Apply and restart

The code is production-ready!

