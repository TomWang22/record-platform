# OAuth URL Verification Checklist

## ✅ Pre-Publish URL Matching

Before publishing, verify ALL these URLs match exactly:

---

## 🔗 Required URLs

**Base ngrok URL:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev
```

---

## 1️⃣ Google OAuth Client (Credentials)

**Go to:** https://console.cloud.google.com/apis/credentials  
**Click:** Your OAuth client → **EDIT**

### Authorized JavaScript origins
**Should be:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev
```

### Authorized redirect URIs
**Should be:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback
```

**⚠️ CRITICAL:** This MUST match `GOOGLE_CALLBACK_URL` in Kubernetes secrets exactly!

---

## 2️⃣ Google OAuth Consent Screen

**Go to:** https://console.cloud.google.com/apis/credentials/consent  
**Scroll to:** "App domain" section

### Application home page
**Should be:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev
```

### Application privacy policy link
**Should be:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/privacy
```

### Application terms of service link
**Should be:**
```
https://denominative-contradistinctively-timika.ngrok-free.dev/terms
```

### Authorized domains
**Should have:**
```
denominative-contradistinctively-timika.ngrok-free.dev
```
(Just the domain, no `https://` or path)

---

## 3️⃣ Kubernetes Secrets

**File:** `infra/k8s/base/config/app-secrets.yaml`

### GOOGLE_CALLBACK_URL
**Should be:**
```yaml
GOOGLE_CALLBACK_URL: "https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback"
```

**⚠️ MUST match:** OAuth Client "Authorized redirect URIs" exactly!

### FRONTEND_URL
**Should be:**
```yaml
FRONTEND_URL: "https://denominative-contradistinctively-timika.ngrok-free.dev"
```

---

## ✅ Verification Steps

### Step 1: Check Kubernetes Secrets
```bash
kubectl get secret app-secrets -n record-platform -o jsonpath='{.data.GOOGLE_CALLBACK_URL}' | base64 -d
kubectl get secret app-secrets -n record-platform -o jsonpath='{.data.FRONTEND_URL}' | base64 -d
```

### Step 2: Check Google OAuth Client
1. Go to: https://console.cloud.google.com/apis/credentials
2. Click your OAuth client
3. Click **EDIT**
4. Verify:
   - JavaScript origins: `https://denominative-contradistinctively-timika.ngrok-free.dev`
   - Redirect URIs: `https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback`

### Step 3: Check Google Consent Screen
1. Go to: https://console.cloud.google.com/apis/credentials/consent
2. Scroll to "App domain"
3. Click each field and verify:
   - Home page: `https://denominative-contradistinctively-timika.ngrok-free.dev`
   - Privacy: `https://denominative-contradistinctively-timika.ngrok-free.dev/privacy`
   - Terms: `https://denominative-contradistinctively-timika.ngrok-free.dev/terms`
   - Domain: `denominative-contradistinctively-timika.ngrok-free.dev`

### Step 4: Test Pages Are Accessible
Test these URLs in your browser:
- ✅ Privacy: https://denominative-contradistinctively-timika.ngrok-free.dev/privacy
- ✅ Terms: https://denominative-contradistinctively-timika.ngrok-free.dev/terms
- ✅ OAuth Start: https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google

---

## 🎯 Critical Match Points

### MUST Match Exactly:
1. **OAuth Client Redirect URI** = **Kubernetes GOOGLE_CALLBACK_URL**
   ```
   https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback
   ```

2. **Consent Screen Domain** = **OAuth Client JavaScript Origins Domain**
   ```
   denominative-contradistinctively-timika.ngrok-free.dev
   ```

3. **All URLs use the same base domain**
   ```
   https://denominative-contradistinctively-timika.ngrok-free.dev
   ```

---

## ✅ Ready to Publish Checklist

- [ ] OAuth Client redirect URI matches Kubernetes `GOOGLE_CALLBACK_URL`
- [ ] OAuth Client JavaScript origins matches base ngrok URL
- [ ] Consent Screen home page matches base ngrok URL
- [ ] Consent Screen privacy policy URL is accessible
- [ ] Consent Screen terms of service URL is accessible
- [ ] Consent Screen authorized domain matches ngrok domain
- [ ] Test user added: `tomwang04312@gmail.com` (if in testing mode)
- [ ] All pages are accessible via ngrok
- [ ] Verification status: "Not required" ✅

---

## 🚀 After Verification

If all URLs match:
1. Add test user (optional): `tomwang04312@gmail.com`
2. Click **"PUBLISH APP"** in OAuth Consent Screen
3. Confirm the dialog
4. Status changes to "In production"
5. Any Google user can now sign in!

---

## ⚠️ Common Mistakes

### ❌ Wrong:
- `http://` instead of `https://`
- Missing `/api/auth/google/callback` path
- Extra trailing slash: `/callback/`
- Wrong domain (e.g., `localhost` instead of ngrok URL)

### ✅ Correct:
- `https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback`
- Exact match in both Google Console and Kubernetes

---

## 📝 Quick Reference

**All URLs should use:**
```
Base: https://denominative-contradistinctively-timika.ngrok-free.dev
Domain: denominative-contradistinctively-timika.ngrok-free.dev
Callback: https://denominative-contradistinctively-timika.ngrok-free.dev/api/auth/google/callback
Privacy: https://denominative-contradistinctively-timika.ngrok-free.dev/privacy
Terms: https://denominative-contradistinctively-timika.ngrok-free.dev/terms
```

