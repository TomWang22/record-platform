# OOMKilled Fix - k6 Pod Memory Limits

**Generated:** $(date)

---

## 🔴 Root Cause

**3 out of 4 k6 pods were OOMKilled (exit code 137)**

### Evidence:
- k6-shopping-e2e-1: OOMKilled after ~5 minutes
- k6-shopping-e2e-3: OOMKilled after ~6 minutes  
- k6-shopping-e2e-4: OOMKilled after ~1.5 minutes
- k6-shopping-e2e-2: Still running (survived)

### Current Configuration:
- Memory limit: 512Mi (reduced from 2Gi)
- Node memory: 84% allocated
- Exit code: 137 (OOMKilled)

---

## ✅ Fix Applied

**Increased k6 memory limit: 512Mi → 1Gi**

### Reasoning:
- 512Mi was too low for k6 with 15 VUs
- Pods were running but getting killed during test
- 1Gi should provide enough headroom while not overwhelming node

---

## 📊 Expected Impact

- **Before:** 3/4 pods OOMKilled
- **After:** All pods should complete successfully
- **Node Memory:** Will increase slightly but should be manageable

