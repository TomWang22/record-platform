# Production LoadBalancer Setup Guide

## Overview

This guide explains how to configure a LoadBalancer service for production deployments, replacing the NodePort setup used in development. The LoadBalancer provides a stable external IP address and better production-grade networking.

## Current Setup (Development)

- **Service Type**: NodePort
- **Port**: 30443 (HTTPS TCP/UDP)
- **Access**: `https://record.local:30443`
- **Limitations**: 
  - TLS handshake issues on macOS/Kind
  - Requires port-forward workaround
  - Not suitable for production

## Production LoadBalancer Configuration

### Option 1: Cloud Provider LoadBalancer (Recommended)

For production deployments on cloud providers (AWS, GCP, Azure, DigitalOcean, etc.), use a LoadBalancer service type.

#### Create LoadBalancer Service

**File**: `infra/k8s/caddy-h3-svc-lb.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    # Cloud-specific annotations (examples)
    # AWS:
    # service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    # service.beta.kubernetes.io/aws-load-balancer-ssl-cert: "arn:aws:acm:..."
    # GCP:
    # cloud.google.com/load-balancer-type: "External"
    # cloud.google.com/backend-config: '{"default": "caddy-backend-config"}'
    # DigitalOcean:
    # service.beta.kubernetes.io/do-loadbalancer-protocol: "https"
    # service.beta.kubernetes.io/do-loadbalancer-algorithm: "round_robin"
spec:
  type: LoadBalancer
  selector:
    app: caddy-h3
  ports:
    - name: https
      port: 443
      targetPort: 443
      protocol: TCP
    - name: https-udp
      port: 443
      targetPort: 443
      protocol: UDP
  sessionAffinity: ClientIP
  sessionAffinityConfig:
    clientIP:
      timeoutSeconds: 10800  # 3 hours
  loadBalancerIP: ""  # Leave empty for auto-assignment, or specify static IP
  externalTrafficPolicy: Local  # Preserves source IP, requires pods on all nodes
```

#### Apply LoadBalancer Service

```bash
# Backup existing NodePort service
kubectl -n ingress-nginx get svc caddy-h3 -o yaml > caddy-h3-svc-nodeport-backup.yaml

# Apply LoadBalancer service
kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-svc-lb.yaml

# Wait for LoadBalancer IP assignment
kubectl -n ingress-nginx get svc caddy-h3 -w

# Get the external IP
EXTERNAL_IP=$(kubectl -n ingress-nginx get svc caddy-h3 -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
echo "LoadBalancer IP: $EXTERNAL_IP"
```

### Option 2: MetalLB (On-Premise/Bare Metal)

For on-premise or bare metal Kubernetes clusters, use MetalLB to provide LoadBalancer functionality.

#### Install MetalLB

```bash
# Apply MetalLB manifest
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.14.5/config/manifests/metallb-native.yaml

# Wait for MetalLB to be ready
kubectl wait --namespace metallb-system \
  --for=condition=ready pod \
  --selector=app=metallb \
  --timeout=90s
```

#### Configure IP Address Pool

**File**: `infra/k8s/metallb-ip-pool.yaml`

```yaml
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  name: caddy-pool
  namespace: metallb-system
spec:
  addresses:
    - 192.168.1.100-192.168.1.110  # Replace with your IP range
    # Or use CIDR notation:
    # - 192.168.1.0/24
---
apiVersion: metallb.io/v1beta1
kind: L2Advertisement
metadata:
  name: caddy-l2
  namespace: metallb-system
spec:
  ipAddressPools:
    - caddy-pool
```

#### Apply MetalLB Configuration

```bash
kubectl apply -f infra/k8s/metallb-ip-pool.yaml
```

#### Create LoadBalancer Service

Use the same LoadBalancer service configuration as Option 1, but without cloud-specific annotations:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
spec:
  type: LoadBalancer
  selector:
    app: caddy-h3
  ports:
    - name: https
      port: 443
      targetPort: 443
      protocol: TCP
    - name: https-udp
      port: 443
      targetPort: 443
      protocol: UDP
  loadBalancerIP: "192.168.1.100"  # Optional: specify IP from MetalLB pool
```

### Option 3: Ingress Controller with LoadBalancer

Instead of exposing Caddy directly, use an ingress controller (like ingress-nginx) with LoadBalancer.

#### Configure Ingress Controller Service

**File**: `infra/k8s/ingress-nginx-lb.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: ingress-nginx-controller
  namespace: ingress-nginx
  annotations:
    # Cloud-specific annotations
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
spec:
  type: LoadBalancer
  selector:
    app.kubernetes.io/component: controller
    app.kubernetes.io/name: ingress-nginx
  ports:
    - name: http
      port: 80
      targetPort: http
      protocol: TCP
    - name: https
      port: 443
      targetPort: https
      protocol: TCP
  externalTrafficPolicy: Local
```

## DNS Configuration

After obtaining the LoadBalancer IP, configure DNS:

### Option A: Static IP with DNS Record

```bash
# Get LoadBalancer IP
EXTERNAL_IP=$(kubectl -n ingress-nginx get svc caddy-h3 -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

# Create DNS A record
# record.local -> $EXTERNAL_IP
```

### Option B: Dynamic DNS (Cloud Provider)

Most cloud providers offer DNS integration:

- **AWS**: Route 53 with ExternalDNS
- **GCP**: Cloud DNS with ExternalDNS
- **Azure**: Azure DNS with ExternalDNS
- **DigitalOcean**: DNS API with ExternalDNS

**Example ExternalDNS Configuration**:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: external-dns
  namespace: kube-system
spec:
  template:
    spec:
      containers:
      - name: external-dns
        args:
        - --source=service
        - --domain-filter=record.local
        - --provider=cloudflare  # or aws-route53, google-clouddns, etc.
        env:
        - name: CF_API_TOKEN
          valueFrom:
            secretKeyRef:
              name: cloudflare-token
              key: token
```

## TLS Certificate Management

### Option 1: Let's Encrypt (Automatic)

Configure Caddy to automatically obtain certificates:

**Update Caddyfile**:

```caddyfile
{
  email your-email@example.com
  admin localhost:2019
}

record.local {
  tls {
    dns cloudflare {env.CLOUDFLARE_API_TOKEN}
  }
  
  # ... rest of configuration
}
```

### Option 2: Cloud Provider Certificate Manager

- **AWS**: ACM (Application Load Balancer)
- **GCP**: Google-managed SSL certificates
- **Azure**: Azure Key Vault certificates

**Example AWS ACM**:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-ssl-cert: "arn:aws:acm:us-east-1:123456789012:certificate/12345678-1234-1234-1234-123456789012"
    service.beta.kubernetes.io/aws-load-balancer-ssl-ports: "443"
    service.beta.kubernetes.io/aws-load-balancer-backend-protocol: "tcp"
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
spec:
  type: LoadBalancer
  # ... rest of configuration
```

## Health Checks and Monitoring

### LoadBalancer Health Checks

Configure health checks for the LoadBalancer:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    # AWS NLB health check
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-path: "/_caddy/healthz"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-protocol: "HTTPS"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-port: "443"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-interval: "10"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-timeout: "5"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-healthy-threshold: "2"
    service.beta.kubernetes.io/aws-load-balancer-healthcheck-unhealthy-threshold: "3"
spec:
  # ... rest of configuration
```

## Migration from NodePort to LoadBalancer

### Step-by-Step Migration

1. **Backup Current Configuration**:
   ```bash
   kubectl -n ingress-nginx get svc caddy-h3 -o yaml > caddy-h3-svc-nodeport-backup.yaml
   ```

2. **Create LoadBalancer Service**:
   ```bash
   kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-svc-lb.yaml
   ```

3. **Wait for IP Assignment**:
   ```bash
   kubectl -n ingress-nginx get svc caddy-h3 -w
   # Wait for EXTERNAL-IP to be assigned
   ```

4. **Update DNS**:
   ```bash
   EXTERNAL_IP=$(kubectl -n ingress-nginx get svc caddy-h3 -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
   # Update DNS record: record.local -> $EXTERNAL_IP
   ```

5. **Verify Connectivity**:
   ```bash
   curl -k -H "Host: record.local" "https://$EXTERNAL_IP/_caddy/healthz"
   ```

6. **Update Test Scripts**:
   Update `scripts/test-full-chain-with-rotation.sh` to use LoadBalancer IP instead of NodePort.

7. **Remove NodePort Service** (Optional):
   ```bash
   kubectl -n ingress-nginx delete svc caddy-h3
   kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-svc-lb.yaml
   ```

## Cloud Provider Specific Notes

### AWS (EKS)

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    service.beta.kubernetes.io/aws-load-balancer-ssl-cert: "arn:aws:acm:..."
    service.beta.kubernetes.io/aws-load-balancer-ssl-ports: "443"
    service.beta.kubernetes.io/aws-load-balancer-backend-protocol: "tcp"
    service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
spec:
  type: LoadBalancer
  # ... rest of configuration
```

### GCP (GKE)

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    cloud.google.com/load-balancer-type: "External"
    cloud.google.com/backend-config: '{"default": "caddy-backend-config"}'
spec:
  type: LoadBalancer
  # ... rest of configuration
```

### Azure (AKS)

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-resource-group: "my-resource-group"
    service.beta.kubernetes.io/azure-load-balancer-internal: "false"
spec:
  type: LoadBalancer
  # ... rest of configuration
```

### DigitalOcean

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
  annotations:
    service.beta.kubernetes.io/do-loadbalancer-protocol: "https"
    service.beta.kubernetes.io/do-loadbalancer-algorithm: "round_robin"
    service.beta.kubernetes.io/do-loadbalancer-healthcheck-protocol: "https"
    service.beta.kubernetes.io/do-loadbalancer-healthcheck-path: "/_caddy/healthz"
spec:
  type: LoadBalancer
  # ... rest of configuration
```

## Testing LoadBalancer Setup

### Health Check

```bash
# Get LoadBalancer IP
EXTERNAL_IP=$(kubectl -n ingress-nginx get svc caddy-h3 -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

# Test health endpoint
curl -k -H "Host: record.local" "https://$EXTERNAL_IP/_caddy/healthz"
```

### Full Chain Test

```bash
# Update test script to use LoadBalancer IP
export HOST=record.local
export PORT=443  # LoadBalancer uses standard ports
./scripts/test-full-chain-with-rotation.sh
```

### DNS Resolution Test

```bash
# Test DNS resolution
dig record.local
nslookup record.local

# Test with DNS name
curl -k -H "Host: record.local" "https://record.local/_caddy/healthz"
```

## Troubleshooting

### LoadBalancer IP Not Assigned

1. **Check Service Status**:
   ```bash
   kubectl -n ingress-nginx describe svc caddy-h3
   ```

2. **Check Events**:
   ```bash
   kubectl -n ingress-nginx get events --sort-by='.lastTimestamp'
   ```

3. **Check Cloud Provider Quotas**:
   - AWS: Check EC2 service quotas for LoadBalancers
   - GCP: Check Compute Engine quotas
   - Azure: Check subscription limits

### Connection Timeouts

1. **Check Security Groups/Firewall Rules**:
   - Ensure port 443 (TCP/UDP) is open
   - Check source IP restrictions

2. **Check Pod Health**:
   ```bash
   kubectl -n ingress-nginx get pods -l app=caddy-h3
   kubectl -n ingress-nginx logs -l app=caddy-h3
   ```

3. **Check Service Endpoints**:
   ```bash
   kubectl -n ingress-nginx get endpoints caddy-h3
   ```

### TLS Certificate Issues

1. **Check Certificate Status**:
   ```bash
   kubectl -n ingress-nginx get secret record-local-tls
   ```

2. **Test Certificate**:
   ```bash
   openssl s_client -connect $EXTERNAL_IP:443 -servername record.local
   ```

## Best Practices

1. **Use Static IP**: Reserve a static IP for the LoadBalancer to avoid DNS updates
2. **Enable Health Checks**: Configure proper health checks for high availability
3. **Use SSL Termination**: Consider terminating SSL at the LoadBalancer for better performance
4. **Monitor Costs**: LoadBalancers can be expensive; monitor usage and costs
5. **Enable Logging**: Enable access logs for security and debugging
6. **Use WAF**: Consider Web Application Firewall for production
7. **Enable DDoS Protection**: Use cloud provider DDoS protection services

## Cost Considerations

- **AWS NLB**: ~$0.0225/hour + data transfer
- **GCP Load Balancer**: ~$0.025/hour + data transfer
- **Azure Load Balancer**: ~$0.025/hour + data transfer
- **DigitalOcean Load Balancer**: ~$12/month + data transfer

## References

- [Kubernetes Service Types](https://kubernetes.io/docs/concepts/services-networking/service/#loadbalancer)
- [MetalLB Documentation](https://metallb.universe.tf/)
- [AWS Load Balancer Controller](https://kubernetes-sigs.github.io/aws-load-balancer-controller/)
- [GCP Ingress Controller](https://cloud.google.com/kubernetes-engine/docs/how-to/load-balance-ingress)
- [Azure Load Balancer](https://docs.microsoft.com/en-us/azure/aks/load-balancer-standard)

