# Reference Files for Redis/Lua Cache Management & Kafka Integration

This document contains **complete file contents** for Redis setup with sophisticated Lua scripts for cache management and Kafka integration for real-time event streaming. This is specifically designed for distributed computing scenarios (like a compute broker "puddle" where donors contribute compute power and users consume it).

---

## Table of Contents

1. [Redis Setup & Configuration](#1-redis-setup--configuration)
2. [Lua Scripts for Cache Management](#2-lua-scripts-for-cache-management)
3. [Redis Client Implementation](#3-redis-client-implementation)
4. [Kafka Setup & Configuration](#4-kafka-setup--configuration)
5. [Kafka Producer/Consumer Patterns](#5-kafka-producerconsumer-patterns)
6. [Distributed Computing Patterns](#6-distributed-computing-patterns)
7. [Real-Time Notification System](#7-real-time-notification-system)

---

## 1. Redis Setup & Configuration

### Redis Configuration (Custom Port - NOT 6379)

**File**: `infra/k8s/base/redis/config/redis.conf`

```conf
########################################
# Pure cache: LFU, no persistence
########################################
# disable RDB snapshots
save ""
appendonly no
stop-writes-on-bgsave-error no

########################################
# Memory + eviction (LFU)
########################################
maxmemory 2gb
maxmemory-policy allkeys-lfu
lfu-log-factor 10
lfu-decay-time 60

########################################
# Net + throughput
########################################
protected-mode no
bind 0.0.0.0
port 6380  # Custom port (NOT 6379)
tcp-keepalive 30
tcp-backlog 65535
timeout 0
maxclients 10000

# I/O threading (must be set at startup)
io-threads 4
io-threads-do-reads yes

# Optional visibility + scheduler
latency-monitor-threshold 50
dynamic-hz yes

########################################
# Advanced settings for compute pool management
########################################
# Enable Lua script caching
lua-time-limit 5000

# Connection pooling
tcp-backlog 65535

# Memory optimization
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
list-max-ziplist-size -2
list-compress-depth 0
set-max-intset-entries 512
zset-max-ziplist-entries 128
zset-max-ziplist-value 64
```

**Key Features**:
- **Custom Port**: 6380 (not 6379) to avoid conflicts
- **LFU Eviction**: `allkeys-lfu` for intelligent cache eviction
- **I/O Threading**: 4 threads for better throughput
- **No Persistence**: Pure cache (no RDB/AOF) for performance
- **Memory Limit**: 2GB (adjust based on needs)

---

### Redis Kubernetes Deployment

**File**: `infra/k8s/base/redis/deploy.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: record-platform
  labels: { app: redis }
spec:
  replicas: 1
  selector: { matchLabels: { app: redis } }
  template:
    metadata:
      labels: { app: redis }
    spec:
      dnsPolicy: ClusterFirst
      terminationGracePeriodSeconds: 10
      containers:
        - name: redis
          image: redis:7-alpine
          env:
            - name: REDIS_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: redis-auth
                  key: REDIS_PASSWORD
          args:
            - sh
            - -lc
            - |
              ulimit -n 65536
              exec redis-server /usr/local/etc/redis/redis.conf \
                --requirepass "$REDIS_PASSWORD" \
                --port 6380
          ports:
            - { name: redis, containerPort: 6380 }
          readinessProbe:
            exec:
              command: ["sh","-lc","redis-cli -a \"$REDIS_PASSWORD\" -p 6380 ping | grep PONG"]
            initialDelaySeconds: 3
            periodSeconds: 3
            timeoutSeconds: 2
          livenessProbe:
            exec:
              command: ["sh","-lc","redis-cli -a \"$REDIS_PASSWORD\" -p 6380 ping | grep PONG"]
            initialDelaySeconds: 5
            periodSeconds: 5
            timeoutSeconds: 3
          resources:
            requests: { cpu: "500m", memory: "512Mi" }
            limits:   { cpu: "2",    memory: "2Gi" }
          volumeMounts:
            - name: redis-config
              mountPath: /usr/local/etc/redis
      volumes:
        - name: redis-config
          configMap:
            name: redis-config
```

**Key Features**:
- **Custom Port**: 6380 exposed
- **Password Protection**: Uses Kubernetes secret
- **Health Checks**: Readiness and liveness probes
- **Resource Limits**: CPU and memory constraints

---

### Redis Service Definition

**File**: `infra/k8s/base/redis/service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: record-platform
  labels: { app: redis }
spec:
  selector: { app: redis }
  ports:
    - name: redis
      port: 6380
      targetPort: 6380
      protocol: TCP
  type: ClusterIP
```

---

### Docker Compose Redis (Alternative Setup)

**File**: `docker-compose.yml` (Redis section)

```yaml
services:
  redis:
    image: redis:7-alpine
    command: 
      - redis-server
      - --port
      - "6380"
      - --requirepass
      - "${REDIS_PASSWORD:-redis-password}"
      - --maxmemory
      - "2gb"
      - --maxmemory-policy
      - "allkeys-lfu"
      - --save
      - ""
      - --appendonly
      - "no"
    ports: ["6380:6380"]
    restart: unless-stopped
    healthcheck:
      test: ["CMD","redis-cli","-p","6380","-a","${REDIS_PASSWORD:-redis-password}","ping"]
      interval: 5s
      timeout: 3s
      retries: 20
      start_period: 5s
    environment:
      - REDIS_PASSWORD=${REDIS_PASSWORD:-redis-password}
```

**Key Pattern**: Services connect via `host.docker.internal:6380` from Kubernetes

---

## 2. Lua Scripts for Cache Management

### Singleflight Cache Script (Prevents Cache Stampedes)

**File**: `services/common/src/lib/singleflight_cache.lua`

```lua
-- singleflight_cache.lua
-- Prevents cache stampedes by ensuring only one request recomputes a value
-- KEYS[1]=dataKey, KEYS[2]=lockKey
-- ARGV[1]=ttlSec, ARGV[2]=nowMs, ARGV[3]=staleMs
-- Returns: {state, value} where state ∈ {"hit","miss-locked","miss-wait"}

local dk = KEYS[1]
local lk = KEYS[2]
local ttl = tonumber(ARGV[1])
local now = tonumber(ARGV[2])
local stale = tonumber(ARGV[3])

-- Check if cached value exists
local v = redis.call("GET", dk)
if v then
  local mt = redis.call("PTTL", dk)
  if mt > 0 then
    -- Cache hit - return value immediately
    return {"hit", v}
  end
end

-- Cache miss - try to acquire lock for recompute
local ok = redis.call("SET", lk, "1", "NX", "PX", 10000)
if ok then
  -- Lock acquired - caller should recompute
  return {"miss-locked", ""}
else
  -- Lock already held - caller should wait and retry
  return {"miss-wait", ""}
end
```

**Purpose**: Prevents cache stampedes when multiple requests try to compute the same value simultaneously. Only one request computes, others wait.

**Usage Pattern**:
1. First request: Gets lock, computes value, stores in cache
2. Concurrent requests: Wait briefly, then retry GET
3. Result: Only one expensive computation, others get cached value

---

### Advanced Singleflight with Stale-While-Revalidate

**File**: `services/common/src/lib/advanced_singleflight.lua`

```lua
-- advanced_singleflight.lua
-- Enhanced singleflight with stale-while-revalidate pattern
-- KEYS[1]=dataKey, KEYS[2]=lockKey, KEYS[3]=staleKey
-- ARGV[1]=ttlSec, ARGV[2]=staleTtlSec, ARGV[3]=nowMs
-- Returns: {state, value, isStale} where state ∈ {"hit","stale","miss-locked","miss-wait"}

local dk = KEYS[1]
local lk = KEYS[2]
local sk = KEYS[3]
local ttl = tonumber(ARGV[1])
local staleTtl = tonumber(ARGV[2])
local now = tonumber(ARGV[3])

-- Check for fresh value
local v = redis.call("GET", dk)
if v then
  local mt = redis.call("PTTL", dk)
  if mt > 0 then
    return {"hit", v, "0"}
  end
end

-- Check for stale value (expired but still available)
local stale = redis.call("GET", sk)
if stale then
  -- Try to acquire lock for background refresh
  local ok = redis.call("SET", lk, "1", "NX", "PX", 10000)
  if ok then
    -- Return stale value immediately, refresh in background
    return {"stale", stale, "1"}
  else
    -- Lock held - return stale value and wait
    return {"stale", stale, "1"}
  end
end

-- No value at all - try to acquire lock
local ok = redis.call("SET", lk, "1", "NX", "PX", 10000)
if ok then
  return {"miss-locked", "", "0"}
else
  return {"miss-wait", "", "0"}
end
```

**Purpose**: Returns stale cached values immediately while refreshing in background. Improves user experience during cache refresh.

---

### Compute Pool Management Lua Script

**File**: `services/compute-broker/src/lib/compute_pool.lua`

```lua
-- compute_pool.lua
-- Manages compute resource allocation/deallocation atomically
-- KEYS[1]=pool:available, KEYS[2]=pool:allocated, KEYS[3]=pool:donors
-- ARGV[1]=command, ARGV[2]=resource_id, ARGV[3]=user_id, ARGV[4]=compute_units
-- ARGV[5]=donor_id (for donate command)

local command = ARGV[1]
local resource_id = ARGV[2]
local user_id = ARGV[3]
local compute_units = tonumber(ARGV[4] or 0)
local donor_id = ARGV[5]

local available_key = KEYS[1]
local allocated_key = KEYS[2]
local donors_key = KEYS[3]

-- Donate compute power (add to available pool)
if command == 'donate' then
  -- Add to available pool
  local current = tonumber(redis.call('GET', available_key) or 0)
  local new_total = current + compute_units
  redis.call('SET', available_key, new_total)
  
  -- Track donor contribution
  if donor_id then
    local donor_key = donors_key .. ':' .. donor_id
    local donor_total = tonumber(redis.call('GET', donor_key) or 0)
    redis.call('SET', donor_key, donor_total + compute_units)
    redis.call('EXPIRE', donor_key, 86400) -- 24h TTL
  end
  
  return {ok = 1, available = new_total, donated = compute_units}
end

-- Allocate compute power (move from available to allocated)
if command == 'allocate' then
  local available = tonumber(redis.call('GET', available_key) or 0)
  
  if available < compute_units then
    return {ok = 0, error = 'insufficient_compute', available = available, requested = compute_units}
  end
  
  -- Atomic decrement available, increment allocated
  local new_available = available - compute_units
  redis.call('SET', available_key, new_available)
  
  local allocated = tonumber(redis.call('GET', allocated_key) or 0)
  local new_allocated = allocated + compute_units
  redis.call('SET', allocated_key, new_allocated)
  
  -- Track user allocation
  local user_key = allocated_key .. ':' .. user_id
  local user_allocated = tonumber(redis.call('GET', user_key) or 0)
  redis.call('SET', user_key, user_allocated + compute_units)
  redis.call('EXPIRE', user_key, 3600) -- 1h TTL
  
  return {ok = 1, available = new_available, allocated = new_allocated, allocated_to_user = compute_units}
end

-- Deallocate compute power (move from allocated back to available)
if command == 'deallocate' then
  local allocated = tonumber(redis.call('GET', allocated_key) or 0)
  local user_key = allocated_key .. ':' .. user_id
  local user_allocated = tonumber(redis.call('GET', user_key) or 0)
  
  if user_allocated < compute_units then
    return {ok = 0, error = 'insufficient_allocation', user_allocated = user_allocated, requested = compute_units}
  end
  
  -- Atomic decrement allocated, increment available
  local new_allocated = allocated - compute_units
  redis.call('SET', allocated_key, new_allocated)
  
  local new_user_allocated = user_allocated - compute_units
  redis.call('SET', user_key, new_user_allocated)
  
  local available = tonumber(redis.call('GET', available_key) or 0)
  local new_available = available + compute_units
  redis.call('SET', available_key, new_available)
  
  return {ok = 1, available = new_available, allocated = new_allocated, deallocated = compute_units}
end

-- Get pool status
if command == 'status' then
  local available = tonumber(redis.call('GET', available_key) or 0)
  local allocated = tonumber(redis.call('GET', allocated_key) or 0)
  local total = available + allocated
  
  return {ok = 1, available = available, allocated = allocated, total = total, utilization = allocated / (total > 0 and total or 1)}
end

-- Get donor stats
if command == 'donor_stats' then
  if not donor_id then
    return {ok = 0, error = 'donor_id_required'}
  end
  
  local donor_key = donors_key .. ':' .. donor_id
  local donated = tonumber(redis.call('GET', donor_key) or 0)
  local available = tonumber(redis.call('GET', available_key) or 0)
  local total_pool = available + tonumber(redis.call('GET', allocated_key) or 0)
  
  return {ok = 1, donor_id = donor_id, donated = donated, pool_total = total_pool, contribution_pct = total_pool > 0 and (donated / total_pool) or 0}
end

-- Unknown command
return {ok = 0, error = 'unknown_command', command = command}
```

**Purpose**: Atomic compute pool management for distributed computing broker:
- **Donate**: Add compute power to available pool
- **Allocate**: Move compute from available to allocated (user consumption)
- **Deallocate**: Return compute from allocated back to available
- **Status**: Get pool utilization metrics
- **Donor Stats**: Track individual donor contributions

---

### LFU/LRU Cache Script (Advanced Eviction)

**File**: `services/common/src/lib/lfu_lru_cache.lua`

```lua
-- LFU/LRU Cache Implementation with Redis Lua Scripts
-- Provides atomic operations for cache management

-- KEYS[1] = sorted set key (for LRU) or pattern (for LFU)
-- ARGV[1] = command
-- ARGV[2] = user_id
-- ARGV[3] = cache_key
-- ARGV[4] = cache_type ('lfu' or 'lru')
-- ARGV[5] = ttl (seconds)
-- ARGV[6] = max_items (for eviction)

local command = ARGV[1]
local user_id = ARGV[2]
local cache_key = ARGV[3]
local cache_type = ARGV[4] or 'lfu'
local ttl = tonumber(ARGV[5]) or 86400
local max_items = tonumber(ARGV[6]) or 100

-- LFU (Least Frequently Used) - increment access count
if command == 'increment_lfu' then
  local access_key = 'cache:lfu:' .. user_id .. ':' .. cache_key
  local count = redis.call('INCR', access_key)
  if count == 1 then
    redis.call('EXPIRE', access_key, ttl)
  end
  return count
end

-- Get LFU access count
if command == 'get_lfu_count' then
  local access_key = 'cache:lfu:' .. user_id .. ':' .. cache_key
  return tonumber(redis.call('GET', access_key) or 0)
end

-- LRU (Least Recently Used) - update last access time
if command == 'update_lru' then
  local sorted_set_key = 'cache:lru:' .. user_id
  local now = redis.call('TIME')[1]
  redis.call('ZADD', sorted_set_key, now, cache_key)
  redis.call('EXPIRE', sorted_set_key, ttl)
  return now
end

-- Get LRU last access time
if command == 'get_lru_time' then
  local sorted_set_key = 'cache:lru:' .. user_id
  local score = redis.call('ZSCORE', sorted_set_key, cache_key)
  return tonumber(score or 0)
end

-- Evict LFU items (remove least frequently used)
if command == 'evict_lfu' then
  local pattern = cache_key -- pattern is passed as cache_key arg
  local keys = redis.call('KEYS', pattern)
  if #keys <= max_items then
    return 0
  end
  
  -- Get counts for all keys
  local items = {}
  for i, key in ipairs(keys) do
    local count = tonumber(redis.call('GET', key) or 0)
    table.insert(items, {key = key, count = count})
  end
  
  -- Sort by count (ascending)
  table.sort(items, function(a, b) return a.count < b.count end)
  
  -- Remove lowest count items
  local removed = 0
  for i = 1, #items - max_items do
    redis.call('DEL', items[i].key)
    removed = removed + 1
  end
  
  return removed
end

-- Evict LRU items (remove least recently used)
if command == 'evict_lru' then
  local sorted_set_key = KEYS[1] -- sorted set key
  local count = redis.call('ZCARD', sorted_set_key)
  if count <= max_items then
    return 0
  end
  
  -- Remove oldest items (lowest scores)
  local removed = redis.call('ZREMRANGEBYRANK', sorted_set_key, 0, count - max_items - 1)
  return removed
end

-- Unknown command
return {err = 'Unknown command: ' .. command}
```

**Purpose**: Advanced cache eviction strategies:
- **LFU**: Tracks access frequency, evicts least frequently used
- **LRU**: Tracks access time, evicts least recently used
- **Atomic Operations**: All eviction logic in Lua for consistency

---

## 3. Redis Client Implementation

### Redis Client Factory (Custom Port)

**File**: `services/common/src/redis.ts`

```typescript
import Redis from 'ioredis'

let client: Redis | null = null

/** Singleton Redis client. Why: avoid multiple TCP connections per worker. */
export function getRedis(): Redis {
  if (!client) {
    // Support both REDIS_URL (with password) and REDIS_PASSWORD env var
    // Use custom port 6380 (NOT 6379)
    let url = process.env.REDIS_URL || 'redis://redis:6380/0'
    const password = process.env.REDIS_PASSWORD

    if (password && !url.includes('@') && !url.includes('://:')) {
      // Insert password after redis://
      url = url.replace('redis://', `redis://:${password}@`)
    }
    client = new Redis(url, { 
      lazyConnect: true,  // Don't connect immediately - allows graceful degradation
      maxRetriesPerRequest: 2,
      password: password, // Also set password directly (ioredis supports both)
      retryStrategy: (times) => {
        // Exponential backoff, max 2s
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
      enableOfflineQueue: false,  // Don't queue commands when disconnected
    })
    // Handle errors gracefully - don't crash the app
    client.on('error', (err) => {
      console.warn('[redis] Connection error (non-fatal):', err.message);
    });
  }
  return client
}

/** Simple cache get/set with TTL seconds. */
export async function cache<T = unknown>(key: string, loader: () => Promise<T>, ttlSec = 60): Promise<T> {
  const r = getRedis()
  const hit = await r.get(key)
  if (hit) return JSON.parse(hit) as T
  const data = await loader()
  await r.set(key, JSON.stringify(data), 'EX', ttlSec)
  return data
}
```

**Key Features**:
- **Custom Port**: 6380 (not 6379)
- **Graceful Degradation**: Continues without Redis if connection fails
- **Singleton Pattern**: One connection per process
- **Password Support**: From URL or environment variable

---

### Advanced Cache Manager with Singleflight

**File**: `services/common/src/lib/cache.ts`

```typescript
// src/lib/cache.ts
import Redis from 'ioredis'
import { readFileSync } from 'fs'
import { join } from 'path'
import crypto from 'crypto'

const DBG = process.env.DEBUG_CACHE === '1'
const MAX_BYTES = Number(process.env.CACHE_MAX_BYTES ?? 524_288)
const SF_STALE_MS = Number(process.env.CACHE_SINGLEFLIGHT_STALE_MS ?? 2000)
const SF_SLEEP_MS = Number(process.env.CACHE_SINGLEFLIGHT_SLEEP_MS ?? 75)

// ---------- singleflight script ----------
const SINGLEFLIGHT_SCRIPT = readFileSync(
  join(__dirname, 'singleflight_cache.lua'),
  'utf8'
)
let singleflightSha: string | undefined

async function ensureSingleflightScript(r: Redis): Promise<string> {
  if (singleflightSha) return singleflightSha
  const sha = (await (r as any).script('LOAD', SINGLEFLIGHT_SCRIPT)) as string
  singleflightSha = sha
  return sha
}

// ---------- helpers ----------
const sha1 = (s: string) => crypto.createHash('sha1').update(s).digest('hex')

function jitter(ms: number) {
  const low = ms * 0.9
  const high = ms * 1.1
  return Math.round(low + Math.random() * (high - low))
}

/** Normalize query-ish strings: NFKD, strip combining marks, lowercase, trim, coalesce spaces. */
export function normalizeQ(input: string): string {
  return String(input || '')
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .trim()
    .replace(/\s+/g, ' ')
}

// ---------- Redis factory ----------
export function makeRedis(): Redis | null {
  const url = process.env.REDIS_URL || ''
  const password = process.env.REDIS_PASSWORD || undefined
  const useTLS = !!process.env.REDIS_TLS

  const common = {
    password,
    enableAutoPipelining: true,
    enableOfflineQueue: false,
    lazyConnect: true,
    maxRetriesPerRequest: 1,
    connectTimeout: 2000,
    keepAlive: 10_000,
    autoResubscribe: false,
  } as const

  // Use custom port 6380 if not in URL
  const defaultHost = process.env.REDIS_HOST || 'redis'
  const defaultPort = Number(process.env.REDIS_PORT || 6380)

  const client = url
    ? new Redis(url, { ...common, tls: useTLS ? {} : undefined })
    : new Redis({
        host: defaultHost,
        port: defaultPort,
        ...common,
      })

  client.on('error', (e) => console.error('[redis]', e.message))
  client.connect().catch(() => {}) // best-effort
  return client
}

/** BigInt-safe JSON stringify: bigint -> number (if safe) else string. */
function stringifySafe(value: unknown): string {
  return JSON.stringify(value, (_k, v) => {
    if (typeof v !== 'bigint') return v
    const abs = v < 0n ? -v : v
    return abs <= 9007199254740991n ? Number(v) : v.toString()
  })
}

// ---------- cached() with singleflight + ioredis-typed commands ----------
export async function cached<T>(
  r: Redis | null,
  key: string,
  ttlMs: number,
  compute: () => Promise<T>
): Promise<T> {
  if (!r || ttlMs <= 0) return compute()

  const lockKey = `sf:lock:${key}`
  const ttlSec = Math.ceil(ttlMs / 1000)
  let state: string | null = null
  let payload: string | null = null

  try {
    const sha = await ensureSingleflightScript(r)
    const res = (await r.evalsha(
      sha,
      2,
      key,
      lockKey,
      String(ttlSec),
      String(Date.now()),
      String(SF_STALE_MS)
    )) as unknown as [string, string]
    state = res?.[0] ?? null
    payload = res?.[1] ?? null
  } catch (err: any) {
    if (err?.message?.includes('NOSCRIPT')) {
      singleflightSha = undefined
    } else {
      console.error('[cache singleflight]', err)
    }
  }

  if (state === 'hit' && payload) {
    if (DBG) console.log('[cache] HIT', key)
    return JSON.parse(payload) as T
  }

  try {
    const hit = await r.get(key)
    if (hit != null) {
      if (DBG) console.log('[cache] HIT', key)
      return JSON.parse(hit) as T
    }
  } catch (e: any) {
    console.error('[redis get]', e?.message ?? e)
  }

  const hadLock = state === 'miss-locked'
  let haveLock = hadLock

  if (!hadLock && state === 'miss-wait') {
    const got = (await r.setnx(lockKey, '1')) === 1
    if (got) {
      await r.pexpire(lockKey, 10_000)
      haveLock = true
    } else {
      if (DBG) console.log('[cache] miss-wait', key)
      await new Promise((resolve) => setTimeout(resolve, SF_SLEEP_MS))
      const again = await r.get(key)
      if (again) return JSON.parse(again) as T
    }
  }

  const val = await compute()

  try {
    const json = stringifySafe(val)
    const bytes = Buffer.byteLength(json)
    if (bytes <= MAX_BYTES) {
      const ttl = Math.max(1_000, jitter(ttlMs))
      if (haveLock) {
        await r.multi().psetex(key, ttl, json).del(lockKey).exec()
      } else {
        await r.psetex(key, ttl, json)
      }
      if (DBG) console.log('[cache] SET', key, 'ttlMs', ttl, 'bytes', bytes)
    } else if (DBG) {
      console.log('[cache] SKIP(set too big)', key, 'bytes', bytes)
    }
  } catch (e: any) {
    console.error('[redis set]', e?.message ?? e)
  }

  return val
}

// ---------- key builders ----------
export function ckey(parts: Array<string | number | boolean | null | undefined>) {
  return parts.map((p) => (p == null ? '' : String(p))).join(':')
}
```

**Key Features**:
- **Singleflight Pattern**: Prevents cache stampedes
- **Jittered TTL**: Prevents thundering herd
- **Size Limits**: Skips caching oversized values
- **Graceful Degradation**: Works without Redis

---

## 4. Kafka Setup & Configuration

### Kafka Docker Compose Configuration

**File**: `docker-compose.yml` (Kafka section)

```yaml
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.5.0
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
      ZOOKEEPER_4LW_COMMANDS_WHITELIST: "ruok,stat,srvr,mntr"
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL","exec 3<>/dev/tcp/127.0.0.1/2181; echo srvr >&3; timeout 2 cat <&3 | grep -qi 'Mode:'"]
      interval: 5s
      timeout: 3s
      retries: 25
      start_period: 20s

  kafka:
    image: confluentinc/cp-kafka:7.5.0
    depends_on:
      zookeeper: { condition: service_healthy }
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,PLAINTEXT_HOST://0.0.0.0:29092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092,PLAINTEXT_HOST://host.docker.internal:29092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      # Performance tuning
      KAFKA_NUM_PARTITIONS: 3
      KAFKA_DEFAULT_REPLICATION_FACTOR: 1
      KAFKA_LOG_RETENTION_HOURS: 168  # 7 days
      KAFKA_LOG_SEGMENT_BYTES: 1073741824  # 1GB
      KAFKA_LOG_RETENTION_CHECK_INTERVAL_MS: 300000
    ports: ["29092:29092"]
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL","kafka-broker-api-versions --bootstrap-server localhost:9092 >/dev/null 2>&1"]
      interval: 10s
      timeout: 5s
      retries: 30
      start_period: 40s
```

**Key Features**:
- **Dual Listeners**: Internal (9092) and external (29092) for Docker/Kubernetes
- **Health Checks**: Zookeeper and Kafka readiness
- **Performance Tuning**: Partition count, retention, segment size

---

### Kafka Kubernetes Deployment

**File**: `infra/k8s/base/kafka/deploy.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: kafka
  namespace: record-platform
  labels: { app: kafka }
spec:
  replicas: 1
  selector: { matchLabels: { app: kafka } }
  template:
    metadata:
      labels: { app: kafka }
    spec:
      initContainers:
        - name: wait-for-zookeeper
          image: busybox:1.36
          command:
            - sh
            - -c
            - |
              echo "Waiting for Zookeeper to be ready..."
              until nc -z zookeeper 2181; do
                echo "Zookeeper not ready yet, waiting..."
                sleep 2
              done
              echo "Zookeeper port is open, waiting a bit more for full readiness..."
              sleep 5
              echo "Zookeeper is ready!"
      containers:
        - name: kafka
          image: confluentinc/cp-kafka:7.5.0
          imagePullPolicy: IfNotPresent
          ports:
            - name: kafka
              containerPort: 9092
            - name: kafka-host
              containerPort: 29092
          env:
            - name: KAFKA_BROKER_ID
              value: "1"
            - name: KAFKA_ZOOKEEPER_CONNECT
              value: "zookeeper:2181"
            - name: KAFKA_LISTENERS
              value: "PLAINTEXT://0.0.0.0:9092,PLAINTEXT_HOST://0.0.0.0:29092"
            - name: KAFKA_ADVERTISED_LISTENERS
              value: "PLAINTEXT://kafka:9092,PLAINTEXT_HOST://host.docker.internal:29092"
            - name: KAFKA_LISTENER_SECURITY_PROTOCOL_MAP
              value: "PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT"
            - name: KAFKA_INTER_BROKER_LISTENER_NAME
              value: "PLAINTEXT"
            - name: KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR
              value: "1"
            - name: KAFKA_NUM_PARTITIONS
              value: "3"
            - name: KAFKA_LOG_RETENTION_HOURS
              value: "168"
          volumeMounts:
            - name: kafka-data
              mountPath: /var/lib/kafka/data
          readinessProbe:
            exec:
              command:
                - sh
                - -c
                - "kafka-broker-api-versions --bootstrap-server localhost:9092 >/dev/null 2>&1"
            initialDelaySeconds: 30
            periodSeconds: 10
            timeoutSeconds: 5
          livenessProbe:
            exec:
              command:
                - sh
                - -c
                - "kafka-broker-api-versions --bootstrap-server localhost:9092 >/dev/null 2>&1"
            initialDelaySeconds: 60
            periodSeconds: 10
            timeoutSeconds: 5
          resources:
            requests: { cpu: "500m", memory: "1Gi" }
            limits:   { cpu: "2",    memory: "2Gi" }
      volumes:
        - name: kafka-data
          emptyDir: {}  # Use PVC in production
```

---

### Kafka Service Definition

**File**: `infra/k8s/base/kafka/service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: kafka
  namespace: record-platform
  labels: { app: kafka }
spec:
  selector: { app: kafka }
  ports:
    - name: kafka
      port: 9092
      targetPort: 9092
      protocol: TCP
    - name: kafka-host
      port: 29092
      targetPort: 29092
      protocol: TCP
  type: ClusterIP
```

---

## 5. Kafka Producer/Consumer Patterns

### Kafka Client Factory

**File**: `services/common/src/kafka.ts`

```typescript
import { Kafka } from 'kafkajs'

export const kafka = new Kafka({
  clientId: process.env.KAFKA_CLIENT_ID || 'record-platform',
  brokers: [process.env.KAFKA_BROKER || 'kafka:9092'],
  retry: {
    initialRetryTime: 100,
    retries: 8,
    multiplier: 2,
    maxRetryTime: 30000,
  },
  requestTimeout: 30000,
  connectionTimeout: 3000,
})
```

---

### Kafka Producer with Error Handling

**File**: `services/compute-broker/src/lib/kafka-producer.ts`

```typescript
import { kafka } from '@common/utils/kafka'

// Kafka producer for real-time events (optional - fails gracefully if Kafka is unavailable)
let kafkaProducer: any = null
let kafkaConnectionFailed = false

async function getKafkaProducer() {
  if (kafkaConnectionFailed) {
    return null
  }

  if (!kafkaProducer) {
    try {
      kafkaProducer = kafka.producer({
        maxInFlightRequests: 1,
        idempotent: true, // Enable idempotent producer
        transactionTimeout: 30000,
      })
      
      await Promise.race([
        kafkaProducer.connect(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Kafka connection timeout')), 5000)
        ),
      ])
      
      console.log('[compute-broker] Kafka producer connected')
    } catch (err) {
      console.warn('[compute-broker] Kafka producer connection failed (non-fatal):', (err as Error)?.message || err)
      kafkaConnectionFailed = true
      kafkaProducer = null
      return null
    }
  }
  return kafkaProducer
}

// Publish compute pool events
export async function publishComputeEvent(
  eventType: 'donate' | 'allocate' | 'deallocate' | 'pool_status',
  data: {
    donor_id?: string
    user_id?: string
    compute_units: number
    resource_id?: string
    pool_status?: {
      available: number
      allocated: number
      total: number
    }
  }
) {
  try {
    const producer = await getKafkaProducer()
    if (!producer) return

    const topic = 'compute-pool-events'
    const key = data.donor_id || data.user_id || 'system'

    await producer.send({
      topic,
      messages: [
        {
          key,
          value: JSON.stringify({
            event_type: eventType,
            timestamp: new Date().toISOString(),
            ...data,
          }),
          headers: {
            'event-type': eventType,
            'source': 'compute-broker',
          },
        },
      ],
    })
  } catch (err) {
    console.warn('[compute-broker] Kafka publish failed (non-fatal):', err)
  }
}

// Publish donor payment updates
export async function publishDonorPayment(
  donorId: string,
  payment: {
    amount: number
    currency: string
    compute_units_donated: number
    period_start: string
    period_end: string
  }
) {
  try {
    const producer = await getKafkaProducer()
    if (!producer) return

    await producer.send({
      topic: 'donor-payments',
      messages: [
        {
          key: donorId,
          value: JSON.stringify({
            donor_id: donorId,
            timestamp: new Date().toISOString(),
            ...payment,
          }),
          headers: {
            'event-type': 'payment',
            'source': 'compute-broker',
          },
        },
      ],
    })
  } catch (err) {
    console.warn('[compute-broker] Kafka publish failed (non-fatal):', err)
  }
}

// Cleanup on shutdown
export async function disconnectKafka() {
  if (kafkaProducer) {
    try {
      await kafkaProducer.disconnect()
      console.log('[compute-broker] Kafka producer disconnected')
    } catch (err) {
      console.warn('[compute-broker] Kafka disconnect error (non-fatal):', err)
    }
    kafkaProducer = null
  }
}
```

**Key Features**:
- **Idempotent Producer**: Prevents duplicate messages
- **Graceful Degradation**: Continues without Kafka
- **Timeout Protection**: Prevents hanging on connection
- **Structured Events**: Type-safe event publishing

---

### Kafka Consumer for Real-Time Updates

**File**: `services/compute-broker/src/lib/kafka-consumer.ts`

```typescript
import { kafka } from '@common/utils/kafka'

// Consumer group for compute pool updates
const consumer = kafka.consumer({
  groupId: 'compute-broker-consumers',
  sessionTimeout: 30000,
  heartbeatInterval: 3000,
  maxBytesPerPartition: 1048576, // 1MB
  minBytes: 1,
  maxBytes: 10485760, // 10MB
  maxWaitTimeInMs: 5000,
})

// Consumer for donor payment notifications
const paymentConsumer = kafka.consumer({
  groupId: 'donor-payment-consumers',
  sessionTimeout: 30000,
  heartbeatInterval: 3000,
})

// Start consuming compute pool events
export async function startComputePoolConsumer(
  onEvent: (event: {
    eventType: string
    data: any
    timestamp: string
  }) => Promise<void>
) {
  try {
    await consumer.connect()
    await consumer.subscribe({ topic: 'compute-pool-events', fromBeginning: false })

    await consumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        try {
          const value = message.value?.toString()
          if (!value) return

          const event = JSON.parse(value)
          await onEvent({
            eventType: event.event_type,
            data: event,
            timestamp: event.timestamp,
          })
        } catch (err) {
          console.error('[compute-broker] Error processing message:', err)
        }
      },
    })

    console.log('[compute-broker] Compute pool consumer started')
  } catch (err) {
    console.error('[compute-broker] Consumer start failed:', err)
    throw err
  }
}

// Start consuming donor payment events
export async function startPaymentConsumer(
  onPayment: (payment: {
    donorId: string
    amount: number
    currency: string
    computeUnits: number
    periodStart: string
    periodEnd: string
  }) => Promise<void>
) {
  try {
    await paymentConsumer.connect()
    await paymentConsumer.subscribe({ topic: 'donor-payments', fromBeginning: false })

    await paymentConsumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        try {
          const value = message.value?.toString()
          if (!value) return

          const payment = JSON.parse(value)
          await onPayment({
            donorId: payment.donor_id,
            amount: payment.amount,
            currency: payment.currency,
            computeUnits: payment.compute_units_donated,
            periodStart: payment.period_start,
            periodEnd: payment.period_end,
          })
        } catch (err) {
          console.error('[compute-broker] Error processing payment:', err)
        }
      },
    })

    console.log('[compute-broker] Payment consumer started')
  } catch (err) {
    console.error('[compute-broker] Payment consumer start failed:', err)
    throw err
  }
}

// Cleanup
export async function stopConsumers() {
  try {
    await consumer.disconnect()
    await paymentConsumer.disconnect()
    console.log('[compute-broker] Consumers disconnected')
  } catch (err) {
    console.warn('[compute-broker] Consumer disconnect error:', err)
  }
}
```

**Key Features**:
- **Consumer Groups**: Separate groups for different event types
- **Error Handling**: Continues processing even if one message fails
- **Type Safety**: Structured event handling
- **Graceful Shutdown**: Clean disconnection

---

## 6. Distributed Computing Patterns

### Compute Pool Manager (TypeScript)

**File**: `services/compute-broker/src/lib/compute-pool.ts`

```typescript
import Redis from 'ioredis'
import * as fs from 'fs'
import * as path from 'path'
import { publishComputeEvent, publishDonorPayment } from './kafka-producer'

// Load Lua script
function loadLuaScript(): string {
  const scriptPath = path.join(__dirname, 'compute_pool.lua')
  return fs.readFileSync(scriptPath, 'utf-8')
}

export class ComputePoolManager {
  private redis: Redis | null
  private script: string = ''

  constructor(redis: Redis | null) {
    this.redis = redis
    if (redis) {
      this.script = loadLuaScript()
    }
  }

  // Donate compute power to the pool
  async donate(
    donorId: string,
    computeUnits: number,
    metadata?: {
      donor_name?: string
      compute_type?: string
      region?: string
    }
  ): Promise<{
    ok: boolean
    available: number
    donated: number
    error?: string
  }> {
    if (!this.redis) {
      throw new Error('Redis not available')
    }

    try {
      const result = await this.redis.eval(
        this.script,
        3,
        'pool:available',
        'pool:allocated',
        'pool:donors',
        'donate',
        '', // resource_id (not used for donate)
        '', // user_id (not used for donate)
        computeUnits.toString(),
        donorId
      ) as any

      if (result.ok === 1) {
        // Publish to Kafka for real-time updates
        await publishComputeEvent('donate', {
          donor_id: donorId,
          compute_units: computeUnits,
          pool_status: {
            available: result.available,
            allocated: 0, // Will be fetched separately if needed
            total: result.available,
          },
        })

        // Calculate and publish payment (simplified - adjust based on your payment logic)
        const paymentAmount = computeUnits * 0.01 // Example: $0.01 per compute unit
        await publishDonorPayment(donorId, {
          amount: paymentAmount,
          currency: 'USD',
          compute_units_donated: computeUnits,
          period_start: new Date().toISOString(),
          period_end: new Date(Date.now() + 86400000).toISOString(), // 24h from now
        })
      }

      return result
    } catch (err) {
      console.error('[compute-pool] Donate error:', err)
      throw err
    }
  }

  // Allocate compute power from pool to user
  async allocate(
    userId: string,
    computeUnits: number,
    resourceId?: string
  ): Promise<{
    ok: boolean
    available: number
    allocated: number
    allocated_to_user: number
    error?: string
  }> {
    if (!this.redis) {
      throw new Error('Redis not available')
    }

    try {
      const result = await this.redis.eval(
        this.script,
        3,
        'pool:available',
        'pool:allocated',
        'pool:donors',
        'allocate',
        resourceId || '',
        userId,
        computeUnits.toString()
      ) as any

      if (result.ok === 1) {
        // Publish to Kafka
        await publishComputeEvent('allocate', {
          user_id: userId,
          compute_units: computeUnits,
          resource_id: resourceId,
          pool_status: {
            available: result.available,
            allocated: result.allocated,
            total: result.available + result.allocated,
          },
        })
      }

      return result
    } catch (err) {
      console.error('[compute-pool] Allocate error:', err)
      throw err
    }
  }

  // Deallocate compute power (user finished)
  async deallocate(
    userId: string,
    computeUnits: number
  ): Promise<{
    ok: boolean
    available: number
    allocated: number
    deallocated: number
    error?: string
  }> {
    if (!this.redis) {
      throw new Error('Redis not available')
    }

    try {
      const result = await this.redis.eval(
        this.script,
        3,
        'pool:available',
        'pool:allocated',
        'pool:donors',
        'deallocate',
        '',
        userId,
        computeUnits.toString()
      ) as any

      if (result.ok === 1) {
        // Publish to Kafka
        await publishComputeEvent('deallocate', {
          user_id: userId,
          compute_units: computeUnits,
          pool_status: {
            available: result.available,
            allocated: result.allocated,
            total: result.available + result.allocated,
          },
        })
      }

      return result
    } catch (err) {
      console.error('[compute-pool] Deallocate error:', err)
      throw err
    }
  }

  // Get pool status
  async getStatus(): Promise<{
    available: number
    allocated: number
    total: number
    utilization: number
  }> {
    if (!this.redis) {
      throw new Error('Redis not available')
    }

    try {
      const result = await this.redis.eval(
        this.script,
        3,
        'pool:available',
        'pool:allocated',
        'pool:donors',
        'status'
      ) as any

      return {
        available: result.available,
        allocated: result.allocated,
        total: result.total,
        utilization: result.utilization,
      }
    } catch (err) {
      console.error('[compute-pool] Status error:', err)
      throw err
    }
  }

  // Get donor statistics
  async getDonorStats(donorId: string): Promise<{
    donor_id: string
    donated: number
    pool_total: number
    contribution_pct: number
  }> {
    if (!this.redis) {
      throw new Error('Redis not available')
    }

    try {
      const result = await this.redis.eval(
        this.script,
        3,
        'pool:available',
        'pool:allocated',
        'pool:donors',
        'donor_stats',
        '',
        '',
        '',
        donorId
      ) as any

      return result
    } catch (err) {
      console.error('[compute-pool] Donor stats error:', err)
      throw err
    }
  }
}
```

**Key Features**:
- **Atomic Operations**: All pool operations use Lua scripts
- **Kafka Integration**: Publishes events for real-time updates
- **Payment Calculation**: Tracks and publishes donor payments
- **Error Handling**: Graceful error handling with detailed messages

---

## 7. Real-Time Notification System

### WebSocket/Kafka Bridge for Donor Updates

**File**: `services/compute-broker/src/lib/notifications.ts`

```typescript
import { startPaymentConsumer } from './kafka-consumer'
import { WebSocket } from 'ws'

// Map of donor_id -> WebSocket connections
const donorConnections = new Map<string, Set<WebSocket>>()

// Register WebSocket connection for donor
export function registerDonorConnection(donorId: string, ws: WebSocket) {
  if (!donorConnections.has(donorId)) {
    donorConnections.set(donorId, new Set())
  }
  donorConnections.get(donorId)!.add(ws)

  ws.on('close', () => {
    const connections = donorConnections.get(donorId)
    if (connections) {
      connections.delete(ws)
      if (connections.size === 0) {
        donorConnections.delete(donorId)
      }
    }
  })
}

// Start Kafka consumer to push updates to WebSocket connections
export async function startNotificationConsumer() {
  await startPaymentConsumer(async (payment) => {
    const connections = donorConnections.get(payment.donorId)
    if (connections) {
      const message = JSON.stringify({
        type: 'payment_update',
        data: {
          amount: payment.amount,
          currency: payment.currency,
          compute_units: payment.computeUnits,
          period_start: payment.periodStart,
          period_end: payment.periodEnd,
        },
      })

      // Send to all connected WebSockets for this donor
      connections.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message)
        }
      })
    }
  })
}
```

**Key Features**:
- **WebSocket Integration**: Real-time push to donors
- **Kafka Consumer**: Listens for payment events
- **Connection Management**: Tracks and cleans up connections
- **Multi-Connection Support**: One donor can have multiple connections

---

## Quick Reference Checklist

### Redis Setup
- [ ] Configure Redis on custom port (6380, not 6379)
- [ ] Set up password protection
- [ ] Configure LFU eviction policy
- [ ] Load Lua scripts for cache management
- [ ] Test singleflight pattern

### Kafka Setup
- [ ] Deploy Zookeeper
- [ ] Deploy Kafka with dual listeners
- [ ] Create topics for events
- [ ] Set up producer with idempotency
- [ ] Set up consumer groups

### Compute Pool Implementation
- [ ] Implement Lua script for atomic operations
- [ ] Create ComputePoolManager class
- [ ] Integrate Kafka producer for events
- [ ] Set up WebSocket notifications
- [ ] Implement payment calculation logic

---

## Key Patterns Summary

### Redis Connection (Custom Port)
```typescript
const redis = new Redis({
  host: 'redis',
  port: 6380, // NOT 6379
  password: process.env.REDIS_PASSWORD,
  lazyConnect: true,
})
```

### Singleflight Cache Pattern
```typescript
const result = await cached(redis, 'key', 60000, async () => {
  // Expensive computation
  return computeValue()
})
```

### Kafka Producer Pattern
```typescript
await producer.send({
  topic: 'events',
  messages: [{
    key: userId,
    value: JSON.stringify(event),
  }],
})
```

### Kafka Consumer Pattern
```typescript
await consumer.run({
  eachMessage: async ({ message }) => {
    const event = JSON.parse(message.value.toString())
    await handleEvent(event)
  },
})
```

### Compute Pool Operations
```typescript
// Donate
await poolManager.donate(donorId, computeUnits)

// Allocate
await poolManager.allocate(userId, computeUnits)

// Deallocate
await poolManager.deallocate(userId, computeUnits)
```

---

## Notes

1. **Custom Port**: Always use 6380 (or another custom port) to avoid conflicts with existing Redis instances on 6379

2. **Lua Scripts**: All cache operations should be atomic via Lua scripts to prevent race conditions

3. **Kafka Topics**: Create topics with appropriate partition counts (3+ for parallelism)

4. **Idempotent Producer**: Always enable idempotency for critical events (payments, allocations)

5. **Graceful Degradation**: Services should continue working even if Redis/Kafka is temporarily unavailable

6. **Connection Pooling**: Use singleton Redis clients to avoid connection exhaustion

7. **Error Handling**: All Redis/Kafka operations should have timeout and retry logic

