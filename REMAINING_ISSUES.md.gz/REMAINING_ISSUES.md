# Remaining Test Issues

## Issues Fixed
1. ✅ Test 9j - Message attachment now works
2. ✅ Test 14 - Logout now works
3. ✅ Test 13b, 13f, 13i - Shopping service routes now work

## Remaining Issues

### Test 9f - Group Messages Not Returned
**Status**: Routes are correctly defined as HTTP proxy, but logs show gRPC is still being called
**Issue**: `GET /messages` is defined as HTTP proxy but gRPC `ListMessages` is still being invoked
**Possible Causes**:
- Route order issue - another route matching first
- API gateway not rebuilt with latest changes
- Route not matching correctly

**Debug Steps**:
1. Check API gateway logs for "Proxying GET /messages" vs "ListMessages"
2. Verify route order in server.ts
3. Check if there's a catch-all route matching first

### Test 9i - Comment ID Placeholder
**Status**: Routes are correctly defined as HTTP proxy, but logs show gRPC is still being called
**Issue**: `POST /forum/posts/:postId/comments` is defined as HTTP proxy but gRPC `CreateComment` is still being invoked
**Possible Causes**:
- Route order issue
- API gateway not rebuilt
- Route not matching correctly

**Debug Steps**:
1. Check API gateway logs for "Proxying POST /forum/posts/*/comments" vs "CreateComment"
2. Verify route order
3. Check if there's a more general route matching first

### Test 13c - Checkout 404
**Status**: Path rewriting issue
**Issue**: "Cannot POST /cart/checkout" - shopping service not receiving the request correctly
**Fix Applied**: Updated pathRewrite to keep `/cart/checkout` as-is (shopping service expects this path)

### Test 13d - Get Orders 404
**Status**: Path rewriting issue
**Issue**: Orders route returning 404
**Fix Applied**: Path rewriting should add `/orders` prefix correctly

### Test 13g - Get Resellable Purchases 404
**Status**: Path rewriting issue
**Issue**: Resell route returning 404
**Fix Applied**: Path rewriting should add `/resell` prefix correctly

### Test 10b, 11b - HTTP/3 Listings Issues
**Status**: HTTP/3 specific issues
**Issue**: Listings service works on HTTP/2 but fails on HTTP/3 with 502
**Possible Causes**:
- Caddy HTTP/3 configuration issue
- Keep-alive connection issues with HTTP/3
- Service mesh (Linkerd) HTTP/3 incompatibility

**Note**: HTTP/2 works fine, so this is likely a Caddy/HTTP/3 specific issue, not a service issue.

## Next Steps
1. Rebuild and restart API gateway to ensure latest changes are applied
2. Check logs to verify HTTP proxy routes are being hit
3. If gRPC is still being called, investigate route order
4. For HTTP/3 issues, check Caddy configuration

