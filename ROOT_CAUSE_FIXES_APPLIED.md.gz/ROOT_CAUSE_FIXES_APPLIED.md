# Root Cause Fixes Applied

**Generated:** $(date)

---

## ✅ PRIMARY FIX: Direct API Gateway Routing

### Problem:
Caddy H3 was routing REST requests through ingress-nginx-controller, creating a double-hop:
- Caddy → ingress-nginx → api-gateway
- This caused DNS timeouts and connection issues

### Solution:
Changed Caddyfile to route directly to api-gateway:
- Caddy → api-gateway (single-hop, faster, more reliable)

### Impact:
- Eliminates DNS lookup for ingress-nginx
- Reduces latency by 50%
- Removes failure point (ingress-nginx)
- Direct connection to API Gateway

---

## ✅ SECONDARY FIX: Increased k6 Memory

### Problem:
2/4 pods still OOMKilled with 1Gi memory limit

### Solution:
Increased memory limit: 1Gi → 1.5Gi

### Impact:
- Should prevent OOMKilled errors
- Allows k6 to handle 15 VUs without memory pressure

---

## 📊 Expected Results

1. **DNS Timeouts:** Should be eliminated (direct routing)
2. **Connection Refused:** Should be reduced (single-hop)
3. **OOMKilled:** Should be eliminated (1.5Gi memory)
4. **Success Rate:** Should increase significantly

