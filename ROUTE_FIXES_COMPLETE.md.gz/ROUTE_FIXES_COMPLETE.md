# API Gateway Route Fixes - Complete

## Issues Fixed

### 1. Social Service Routes
**Problem**: Attachment and leave group routes were returning 404
**Root Cause**: Route order - leave group route was defined AFTER get group route
**Fix**: Moved leave group route BEFORE get group route

```typescript
// ✅ Correct order:
app.delete("/messages/groups/:groupId/leave", ...)  // Specific - matches first
app.get("/messages/groups/:groupId", ...)  // General - matches after leave
```

### 2. Shopping Service Routes
**Problem**: All shopping routes (`/api/cart`, `/api/orders`, etc.) were returning 404
**Root Cause**: Route aliases were removed during cleanup
**Fix**: Re-added route aliases BEFORE `/shopping/*` routes

```typescript
// ✅ Correct order:
app.use("/cart", ...)  // Alias - matches /api/cart (after Caddy strips /api)
app.use("/orders", ...)  // Alias - matches /api/orders
app.use("/history", ...)  // Alias - matches /api/history
app.use("/resell", ...)  // Alias - matches /api/resell
app.get("/shopping/cart", ...)  // Specific - matches /shopping/cart
```

### 3. Route Order Principles
1. **More specific routes come first**: `/forum/posts/:postId/attachments` before `/forum/posts/:postId`
2. **Route aliases come before specific routes**: `/cart` before `/shopping/cart`
3. **HTTP proxy routes come before gRPC routes** when both exist for same path

## Route Configuration

### Social Service Routes
- ✅ `/forum/posts/:postId/attachments` (POST, GET) - Before `/forum/posts/:postId`
- ✅ `/forum/comments/:commentId/attachments` (POST) - Before `/forum/posts/:postId`
- ✅ `/messages/:messageId/attachments` (POST) - Before `/messages/:messageId/reply`
- ✅ `/messages/groups/:groupId/leave` (DELETE) - Before `/messages/groups/:groupId`

### Shopping Service Routes
- ✅ `/cart` (all methods) - Proxy to shopping-service `/cart`
- ✅ `/orders` (all methods) - Proxy to shopping-service `/orders`
- ✅ `/history` (all methods) - Proxy to shopping-service `/history`
- ✅ `/resell` (all methods) - Proxy to shopping-service `/resell`
- ✅ `/shopping/cart/checkout` (POST) - Proxy to shopping-service `/cart/checkout`
- ✅ `/shopping/orders` (GET) - Proxy to shopping-service `/orders`
- ✅ `/shopping/orders/:orderId` (GET) - Proxy to shopping-service `/orders/:orderId`
- ✅ `/shopping/history/purchases` (GET) - Proxy to shopping-service `/history/purchases`
- ✅ `/shopping/resell/purchases` (GET) - Proxy to shopping-service `/resell/purchases`
- ✅ `/shopping/resell/purchases/:purchaseId` (POST) - Proxy to shopping-service `/resell/:purchaseId`
- ✅ `/shopping/history/search` (POST) - Proxy to shopping-service `/history/searches`

## Testing
After deployment, all routes should work:
```bash
./scripts/test-microservices-http2-http3.sh
```

Expected results:
- ✅ Social service attachment routes (Tests 9h, 9i, 9j) should work
- ✅ Leave group chat (Test 9k) should work
- ✅ Shopping cart operations (Tests 13a-13i) should work

