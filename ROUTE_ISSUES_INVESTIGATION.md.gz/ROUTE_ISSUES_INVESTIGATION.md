# Route Issues Investigation - Social & Shopping Services

## Current Status

### Issues Found:
1. **Forum Post Creation Still Returns "placeholder-post-id"**
   - API gateway HTTP proxy route is configured correctly
   - Social service HTTP route (`POST /forum/posts`) correctly inserts into database
   - Issue: API gateway image wasn't deployed (image ID mismatch)
   - **Fix**: Rebuilt and restarted API gateway deployment

2. **Social Service Attachment Routes (9h, 9i, 9j) - 404 Errors**
   - Routes are defined in API gateway: `/forum/posts/:postId/attachments`, `/forum/comments/:commentId/attachments`, `/messages/:messageId/attachments`
   - Routes exist in social service
   - Issue: Routes are being hit but returning 404
   - **Likely cause**: Routes need real post/comment/message IDs (not "placeholder-post-id")

3. **Leave Group Chat Route (9k) - 404 Error**
   - Route defined: `DELETE /messages/groups/:groupId/leave`
   - Route exists in social service
   - Issue: Route is being hit but returning 404
   - **Likely cause**: Route order or path matching issue

4. **Get Post Attachments (9l) - 401 Error**
   - Route defined: `GET /forum/posts/:postId/attachments`
   - Issue: Authentication failing
   - **Likely cause**: Missing Authorization header or x-user-id header

5. **Shopping Service Routes (13a-13i) - All 404 Errors**
   - Routes defined: `/cart`, `/orders`, `/history`, `/resell`
   - Routes exist in shopping service
   - Shopping service uses `requireUser` middleware expecting `Authorization: Bearer <token>`
   - Issue: Routes are being hit but returning 404
   - **Fix Applied**: Added x-user-id header forwarding in proxyReq handlers

## Root Causes

### 1. API Gateway Image Not Deployed
- The HTTP proxy route for forum post creation was added, but the image wasn't rebuilt/deployed
- **Fix**: Rebuilt image and restarted deployment

### 2. Authentication Header Mismatch
- **Social Service**: Expects `x-user-id` header (set by `injectIdentityHeadersIfAny`)
- **Shopping Service**: Expects `Authorization: Bearer <token>` header
- Both headers are now being forwarded in proxyReq handlers

### 3. Placeholder Post IDs
- Tests are using "placeholder-post-id" which doesn't exist in database
- Once forum post creation returns real UUIDs, attachment routes should work

## Fixes Applied

1. ✅ Fixed duplicate route definitions (combined middleware chains)
2. ✅ Changed forum post creation from gRPC to HTTP proxy
3. ✅ Added x-user-id header forwarding to shopping service routes
4. ✅ Rebuilt and deployed API gateway image

## Next Steps

1. **Test forum post creation** - Should now return real UUIDs
2. **Test attachment routes** - Should work with real post IDs
3. **Test shopping routes** - Should work with proper authentication headers
4. **Monitor logs** - Check for any remaining 404/401 errors

## Route Configuration Summary

### Social Service Routes (HTTP Proxy)
- `POST /forum/posts` → `http://social-service:4006/forum/posts`
- `POST /forum/posts/:postId/attachments` → `http://social-service:4006/forum/posts/:postId/attachments`
- `GET /forum/posts/:postId/attachments` → `http://social-service:4006/forum/posts/:postId/attachments`
- `POST /forum/comments/:commentId/attachments` → `http://social-service:4006/forum/comments/:commentId/attachments`
- `POST /messages/:messageId/attachments` → `http://social-service:4006/messages/:messageId/attachments`
- `DELETE /messages/groups/:groupId/leave` → `http://social-service:4006/messages/groups/:groupId/leave`

### Shopping Service Routes (HTTP Proxy)
- `POST /cart/checkout` → `http://shopping-service:4007/cart/checkout`
- `POST /cart` → `http://shopping-service:4007/cart`
- `GET /cart` → `http://shopping-service:4007/cart`
- `GET /orders` → `http://shopping-service:4007/orders`
- `GET /history/purchases` → `http://shopping-service:4007/history/purchases`
- `GET /resell/purchases` → `http://shopping-service:4007/resell/purchases`
- `POST /history/searches` → `http://shopping-service:4007/history/searches`

All routes use `injectIdentityHeadersIfAny` middleware to set `x-user-id` header, and `proxyReq` handlers forward both `Authorization` and `x-user-id` headers.

