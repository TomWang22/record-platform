# API Gateway Route Order Fix

## Problem
Routes were failing with 404 errors because:
1. **Route order matters in Express** - more specific routes must come before general ones
2. **Routes were duplicated** - same routes defined multiple times
3. **Route aliases were in wrong order** - `/cart` alias was after `/shopping/cart` routes

## Fixes Applied

### 1. Forum Attachment Routes
**Before**: `/forum/posts/:postId` was defined before `/forum/posts/:postId/attachments`
**After**: Moved attachment routes BEFORE `/forum/posts/:postId` so they match first

```typescript
// ✅ Correct order:
app.post("/forum/posts/:postId/attachments", ...)  // Specific - matches first
app.get("/forum/posts/:postId/attachments", ...)   // Specific - matches first
app.post("/forum/comments/:commentId/attachments", ...)  // Specific - matches first
app.get("/forum/posts/:postId", ...)  // General - matches after attachments
```

### 2. Message Attachment Routes
**Before**: `/messages/:messageId/reply` was defined before `/messages/:messageId/attachments`
**After**: Moved attachment routes BEFORE reply route

```typescript
// ✅ Correct order:
app.post("/messages/:messageId/attachments", ...)  // Specific - matches first
app.post("/messages/:messageId/reply", ...)  // General - matches after attachments
```

### 3. Leave Group Route
**Before**: `/messages/groups/:groupId` was defined before `/messages/groups/:groupId/leave`
**After**: Moved leave route BEFORE group details route

```typescript
// ✅ Correct order:
app.delete("/messages/groups/:groupId/leave", ...)  // Specific - matches first
app.get("/messages/groups/:groupId", ...)  // General - matches after leave
```

### 4. Shopping Service Route Aliases
**Before**: Route aliases (`/cart`, `/orders`, etc.) were defined AFTER `/shopping/cart` routes
**After**: Moved aliases BEFORE `/shopping/cart` routes so they match first

```typescript
// ✅ Correct order:
app.use("/cart", ...)  // Alias - matches first for /api/cart
app.use("/orders", ...)  // Alias - matches first for /api/orders
app.use("/history", ...)  // Alias - matches first for /api/history
app.use("/resell", ...)  // Alias - matches first for /api/resell
app.get("/shopping/cart", ...)  // Specific - matches /shopping/cart
app.post("/shopping/cart", ...)  // Specific - matches /shopping/cart
```

### 5. Removed Duplicate Routes
Removed duplicate definitions of:
- Forum attachment routes (were defined twice)
- Message attachment routes (were defined twice)
- Leave group route (was defined twice)
- Shopping route aliases (were defined twice)

## Route Matching Rules in Express
1. Routes are matched in the order they're defined
2. First matching route wins
3. More specific routes (with more path segments) should come first
4. `app.use()` matches all methods and all paths starting with the prefix
5. `app.get()`, `app.post()`, etc. match specific methods

## Testing
After deployment, test:
```bash
./scripts/test-microservices-http2-http3.sh
```

Expected results:
- ✅ Social service attachment routes (Tests 9h, 9i, 9j) should work
- ✅ Leave group chat (Test 9k) should work
- ✅ Shopping cart operations (Tests 13a-13i) should work

