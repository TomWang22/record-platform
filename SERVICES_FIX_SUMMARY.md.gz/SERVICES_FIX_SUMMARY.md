# Services Fix Summary

## Issues Fixed

### 1. ✅ Auction Monitor Health Check
**File**: `services/auction-monitor/src/server.ts`

**Problem**: Health check returned 503 if either database connection failed, causing CrashLoopBackOff.

**Solution**: Made health check resilient - checks both databases separately and returns 200 if at least one is working. Only returns 503 if both databases fail.

**Changes**:
- Checks `listingsPool` and `auctionPool` separately
- Returns detailed status for each database
- Allows degraded mode (service can run if one DB is down)
- Better error logging

### 2. ✅ Social Service Health Check
**File**: `services/social-service/src/server.ts`

**Problem**: Health check returned 503 if database connection failed, causing pod restarts.

**Solution**: Made health check more resilient - database is critical (503 if down), but Redis is non-critical (doesn't fail health check if down).

**Changes**:
- Checks database and Redis separately
- Database failure causes 503 (critical)
- Redis failure doesn't fail health check (non-critical)
- Better error logging

### 3. ✅ Probe Timeout Updates
**Files**: 
- `infra/k8s/base/auction-monitor/deploy.yaml`
- `infra/k8s/base/social-service/deploy.yaml`

**Changes**:
- **Auction Monitor**: Increased `startupProbe.initialDelaySeconds` from 15s to 30s, `timeoutSeconds` from 3s to 5s, `failureThreshold` from 20 to 30
- **Social Service**: Increased `readinessProbe.initialDelaySeconds` from 10s to 20s, `failureThreshold` from 3 to 5

### 4. ✅ Webapp Kubernetes Deployment
**Files Created**:
- `infra/k8s/base/webapp/deploy.yaml`
- `infra/k8s/base/webapp/service.yaml`
- `infra/k8s/base/webapp/kustomization.yaml`

**Configuration**:
- Port: 3001 (matches webapp package.json)
- Environment: `NEXT_PUBLIC_GATEWAY_URL` set to `http://api-gateway.record-platform.svc.cluster.local:4000`
- Health checks: Readiness and liveness probes on port 3001
- Added to base kustomization.yaml

### 5. ✅ Test Script Created
**File**: `scripts/test-all-services.sh`

**Features**:
- Checks all pod statuses
- Verifies service endpoints
- Tests health check endpoints for all services
- Tests webapp accessibility (port 3001)
- Tests nginx service (port 8080)
- Checks for CrashLoopBackOff pods
- Verifies database configuration
- Tests Kafka connectivity

## Port Configuration Summary

### Webapp
- **Container Port**: 3001 (Next.js default)
- **Service Port**: 3001
- **Access**: `http://webapp.record-platform.svc.cluster.local:3001`

### Nginx
- **Service Port**: 8080 (for webapp proxying)
- **Access**: `http://nginx.record-platform.svc.cluster.local:8080`

### API Gateway
- **Service Port**: 4000
- **Access**: `http://api-gateway.record-platform.svc.cluster.local:4000`

## Testing

### Run All Service Tests
```bash
./scripts/test-all-services.sh
```

### Run k6 Load Tests
```bash
# From inside cluster or with port-forward
k6 run scripts/load/all-in-one-k6.js \
  --env BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000 \
  --env MODE=mixed \
  --env RATE=50 \
  --env DURATION=5m
```

### Test Webapp
```bash
# Port-forward webapp
kubectl -n record-platform port-forward svc/webapp 3001:3001

# Access at http://localhost:3001
```

### Test Nginx (port 8080)
```bash
# Port-forward nginx
kubectl -n record-platform port-forward svc/nginx 8080:8080

# Access at http://localhost:8080
```

## Next Steps

1. **Rebuild and deploy services**:
   ```bash
   ./scripts/build-and-load.sh h3
   kubectl apply -k infra/k8s/overlays/dev
   ```

2. **Verify services are ready**:
   ```bash
   ./scripts/test-all-services.sh
   ```

3. **Check for any remaining issues**:
   ```bash
   kubectl -n record-platform get pods
   kubectl -n record-platform get endpoints
   ```

4. **Run k6 load tests** to verify pipeline:
   ```bash
   k6 run scripts/load/all-in-one-k6.js
   ```

## Known Issues

- **TLS Handshake on macOS/Kind**: NodePort 30443 has known TLS passthrough limitations. Test script automatically falls back to port-forward or in-cluster testing.
- **Database Routing**: `host.docker.internal` from Kind routes to local Postgres.app on macOS. Databases created in Postgres.app as workaround.

## Files Modified

1. `services/auction-monitor/src/server.ts` - Health check resilience
2. `services/social-service/src/server.ts` - Health check resilience
3. `infra/k8s/base/auction-monitor/deploy.yaml` - Probe timeouts
4. `infra/k8s/base/social-service/deploy.yaml` - Probe timeouts
5. `infra/k8s/base/kustomization.yaml` - Added webapp
6. `infra/k8s/base/webapp/deploy.yaml` - Created
7. `infra/k8s/base/webapp/service.yaml` - Created
8. `infra/k8s/base/webapp/kustomization.yaml` - Created
9. `scripts/test-all-services.sh` - Created

