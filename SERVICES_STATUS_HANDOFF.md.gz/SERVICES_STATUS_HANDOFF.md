# Services Status & Handoff Document

**Date:** December 2, 2025  
**Last Updated:** After CA rotation test script fixes and analytics service testing

## Executive Summary

This document provides a comprehensive overview of all services in the record-platform, their current status, configuration, and any known issues. This serves as a handoff document for ongoing development and maintenance.

---

## Service Status Overview

### ✅ **Core Services (Running)**

| Service | Status | Replicas | Restarts | Notes |
|---------|--------|----------|----------|-------|
| **API Gateway** | ✅ Running | 1/1 | 12 | Main entry point, handles routing |
| **Auth Service** | ✅ Running | 2/2 | 13 | Production-tier auth (OAuth, SMS, Passkey, MFA) |
| **Analytics Service** | ✅ Running | 1/1 | 1 | Database connection fixed, working |
| **Listings Service** | ✅ Running | 1/1 | 9 | Stable |
| **Shopping Service** | ✅ Running | 1/1 | 21 | Stable |
| **Python AI Service** | ✅ Running | 1/1 | 25 | Stable |
| **Records Service** | ✅ Running | 1/1 | 1 | Stable |
| **Cron Jobs** | ✅ Running | 1/1 | 0 | Scheduled tasks working |
| **Postgres (K8s)** | ✅ Running | 1/1 | 0 | Internal K8s Postgres |
| **Redis** | ✅ Running | 1/1 | 1 | Cache layer |

### ⚠️ **Services with Issues**

| Service | Status | Issue | Action Required |
|---------|--------|-------|----------------|
| **Auction Monitor** | ⚠️ CrashLoopBackOff | 2 pods crashing | Check logs, likely Kafka connectivity or config issue |
| **Social Service** | ⚠️ Mixed | 1 Running, 1 CrashLoopBackOff | One pod running, one crashing - check logs |

### ✅ **Infrastructure Services**

| Service | Status | Notes |
|---------|--------|-------|
| **Caddy H3** | ✅ Running | 2/2 replicas, NodePort 30443, HTTP/2 & HTTP/3 |
| **Ingress Nginx** | ✅ Running | 1/1, handles internal routing |
| **HAProxy** | ✅ Running | Load balancer |
| **Nginx** | ✅ Running | Web server |

### ✅ **Docker Compose Services (External)**

| Service | Status | Port | Notes |
|---------|--------|------|-------|
| **Kafka** | ✅ Healthy | 29092 | Message broker, 16 hours uptime |
| **Zookeeper** | ✅ Healthy | 2181 | Kafka coordination, 16 hours uptime |
| **Postgres (8 instances)** | ✅ Healthy | 5433-5440 | All 8 instances running |
| **Redis** | ✅ Healthy | 6379 | Cache, 16 hours uptime |
| **MailHog** | ✅ Healthy | 1025/8025 | Email testing |

---

## Detailed Service Information

### 1. API Gateway (`api-gateway`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 12 (last 68m ago)
- **Age:** 4h47m
- **Function:** Main entry point, routes requests to backend services
- **Port:** Internal cluster service
- **Health:** `/api/healthz`
- **Notes:** 
  - Proxy timeout increased to 30s for MFA setup
  - Handles OAuth, auth routes, and API routing

### 2. Auth Service (`auth-service`)

- **Status:** ✅ Running (2/2)
- **Restarts:** 13 (last 76m ago)
- **Age:** 4h47m
- **Function:** Authentication and authorization
- **Features:**
  - ✅ Google OAuth 2.0 (production-ready)
  - ✅ SMS/Phone verification (multi-provider: Mock, Twilio, AWS SNS, Vonage, MessageBird)
  - ✅ Passkey/WebAuthn (passwordless auth)
  - ✅ MFA/TOTP (time-based one-time passwords)
  - ✅ Privacy & Terms pages (`/privacy`, `/terms`)
- **Ports:** 4001 (HTTP), 50051 (gRPC)
- **Health:** `/api/auth/healthz`
- **Notes:**
  - OAuth credentials stored in Kubernetes secrets
  - Mock SMS provider enabled for development
  - Privacy/terms pages served directly from auth-service

### 3. Analytics Service (`analytics-service`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 1 (last 78m ago)
- **Age:** 107m
- **Function:** Analytics and data processing
- **Database:** `postgres-analytics-1` (Docker Compose, port 5439)
- **Ports:** Internal cluster service, gRPC 50054
- **Health:** `/api/analytics/healthz`
- **Notes:**
  - ✅ Database connection fixed (using `host.docker.internal:5439`)
  - ✅ Database schema created (analytics schema with `price_snapshots` table)
  - ✅ Kafka integration working (via `kafka-external` Kubernetes Service)
  - **Recent Changes:** Port 8080 testing for webapp integration (if configured)

### 4. Listings Service (`listings-service`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 9 (last 77m ago)
- **Age:** 4h47m
- **Function:** Record listings management
- **Database:** `postgres-listings-1` (Docker Compose, port 5435)
- **Ports:** Internal cluster service, gRPC 50057
- **Health:** `/api/listings/healthz`

### 5. Shopping Service (`shopping-service`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 21 (last 68m ago)
- **Age:** 4h47m
- **Function:** Shopping cart and purchase management
- **Database:** `postgres-shopping-1` (Docker Compose, port 5436)
- **Ports:** Internal cluster service, gRPC 50058
- **Health:** `/api/shopping/healthz`

### 6. Social Service (`social-service`)

- **Status:** ⚠️ Mixed (1 Running, 1 CrashLoopBackOff)
- **Running Pod:** `social-service-5789584986-lmzgp` (0/1 Running, 49 restarts)
- **Crashing Pod:** `social-service-6c49795587-rbcc9` (CrashLoopBackOff, 53 restarts)
- **Function:** Social features and user interactions
- **Database:** `postgres-social-1` (Docker Compose, port 5434)
- **Ports:** Internal cluster service, gRPC 50056
- **Issue:** One pod crashing repeatedly, likely Kafka connectivity or database issue
- **Action Required:** Check logs: `kubectl logs -n record-platform social-service-6c49795587-rbcc9`

### 7. Auction Monitor (`auction-monitor`)

- **Status:** ⚠️ CrashLoopBackOff
- **Pods:** 2 pods, both crashing
  - `auction-monitor-678c9bc474-gh4fk` (CrashLoopBackOff, 48 restarts)
  - `auction-monitor-857547f9bf-kpqt7` (Running but 50 restarts)
- **Function:** Auction monitoring and price tracking
- **Database:** `postgres-auction-monitor-1` (Docker Compose, port 5438)
- **Ports:** Internal cluster service, gRPC 50059
- **Issue:** Pods crashing, likely Kafka connectivity or configuration issue
- **Action Required:** 
  - Check logs: `kubectl logs -n record-platform auction-monitor-678c9bc474-gh4fk`
  - Verify Kafka connectivity: `kubectl get svc -n record-platform kafka-external`
  - Check ConfigMap: `kubectl get configmap -n record-platform app-config -o yaml | grep KAFKA`

### 8. Python AI Service (`python-ai-service`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 25 (last 69m ago)
- **Age:** 4h47m
- **Function:** AI/ML services for recommendations and analysis
- **Database:** `postgres-python-ai-1` (Docker Compose, port 5440)
- **Ports:** Internal cluster service, gRPC 50060
- **Health:** `/api/python-ai/healthz`

### 9. Records Service (`records-service`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 1 (last 3h53m ago)
- **Age:** 4h47m
- **Function:** Core records management
- **Ports:** Internal cluster service, gRPC 50051
- **Health:** `/api/records/healthz`

### 10. Cron Jobs (`cron-jobs`)

- **Status:** ✅ Running (1/1)
- **Restarts:** 0
- **Age:** 4h47m
- **Function:** Scheduled background jobs
- **Notes:** Fixed to use `dist/jobs.js` instead of `dist/server.js`

---

## Infrastructure Services

### Caddy H3 (HTTP/2 & HTTP/3 Reverse Proxy)

- **Status:** ✅ Running (2/2 replicas)
- **Service Type:** NodePort
- **NodePort:** 30443 (TCP & UDP)
- **ClusterIP:** 10.96.72.132
- **Function:** 
  - TLS termination (strict TLS 1.2/1.3)
  - HTTP/2 and HTTP/3 (QUIC) support
  - Routes to Ingress Nginx for REST APIs
  - Direct routes for gRPC and privacy/terms pages
- **Health:** `/_caddy/healthz`
- **Notes:**
  - ✅ CA rotation working (1-2 second rotation time)
  - ✅ Zero-downtime rotation with RollingUpdate strategy
  - ⚠️ NodePort TLS handshake issues on macOS/Kind (script uses port-forward fallback)
  - **Caddyfile:** Standard configuration (port 8080 used by nginx service for webapp, not in Caddyfile)

### Ingress Nginx

- **Status:** ✅ Running (1/1)
- **Function:** Internal routing for REST APIs
- **Port:** 443 (HTTPS)
- **Notes:** Routes requests from Caddy to backend services

### Kafka & Zookeeper (Docker Compose)

- **Status:** ✅ Both Healthy
- **Kafka Port:** 29092 (external)
- **Zookeeper Port:** 2181 (internal)
- **Kubernetes Service:** `kafka-external` (exposes Kafka to K8s cluster)
- **Function:** Message broker for event streaming
- **Uptime:** 16 hours
- **Notes:** 
  - ✅ Connected to Kubernetes via `kafka-external` Service
  - Used by analytics-service and social-service

### PostgreSQL Instances (8 Total)

All running in Docker Compose, exposed to Kubernetes via `host.docker.internal`:

| Instance | Port | Database | Status | Notes |
|----------|------|----------|--------|-------|
| `postgres-1` | 5433 | Default | ✅ Healthy | Base instance |
| `postgres-social-1` | 5434 | social | ✅ Healthy | Social service |
| `postgres-listings-1` | 5435 | records | ✅ Healthy | Listings service (with `listings` schema) |
| `postgres-shopping-1` | 5436 | shopping | ✅ Healthy | Shopping service |
| `postgres-auth-1` | 5437 | auth | ✅ Healthy | Auth service |
| `postgres-auction-monitor-1` | 5438 | auction_monitor | ✅ Healthy | Auction monitor |
| `postgres-analytics-1` | 5439 | analytics | ✅ Healthy | Analytics service |
| `postgres-python-ai-1` | 5440 | python_ai | ✅ Healthy | Python AI service |

**Note:** `host.docker.internal` from Kind cluster routes to local `Postgres.app` instance on macOS. Databases and schemas have been created in Postgres.app as a workaround.

### Redis (Docker Compose)

- **Status:** ✅ Healthy
- **Port:** 6379 (external)
- **Function:** Caching layer
- **Uptime:** 16 hours

---

## Recent Changes & Configuration

### CA Rotation Test Script Fixes

- **File:** `scripts/test-full-chain-with-rotation.sh`
- **Changes:**
  - ✅ Added `--resolve` flag to all curl commands (fixes TLS handshake)
  - ✅ Added automatic port-forward fallback when NodePort TLS fails
  - ✅ Increased intensity: 80 concurrent requests, 20000 total requests
  - ✅ Matches old working script pattern

### Caddyfile Updates

- **Port 8080 Testing:** Added configuration for analytics service and webapp testing
- **Routes:**
  - Privacy/Terms pages: Direct to auth-service
  - gRPC: Direct routing to services
  - REST APIs: Via Ingress Nginx
- **TLS:** Strict TLS 1.2/1.3 only

### Database Connection Fixes

- **Analytics Service:** 
  - ✅ Fixed database connection (using `host.docker.internal:5439`)
  - ✅ Created `analytics` database and schema in Postgres.app
  - ✅ Created `price_snapshots` table with proper schema

- **Listings Service:**
  - ✅ Using `host.docker.internal:5435` with `search_path=listings`
  - ✅ `listings` schema created in Postgres.app

### Kafka Connectivity

- **Kubernetes Service:** `kafka-external` created to expose Docker Compose Kafka to K8s
- **ConfigMap:** Updated with `KAFKA_BROKER` pointing to `kafka-external.record-platform.svc.cluster.local:29092`
- **Status:** ✅ Working for analytics-service and social-service

---

## Known Issues & Action Items

### 🔴 **Critical Issues**

1. **Auction Monitor CrashLoopBackOff**
   - **Status:** 2 pods crashing
   - **Root Cause:** Health check endpoint returns HTTP 503 when either database connection fails
   - **Issue:** Health check queries both `listingsPool` and `auctionPool` - if either fails, returns 503
   - **Evidence:** Server running, ports listening, but health check fails
   - **Action:** Fix health check to be more resilient (see `INVESTIGATION_FINDINGS_HANDOFF.md`)
   - **Command:** `kubectl logs -n record-platform auction-monitor-678c9bc474-gh4fk`
   - **Files to Fix:** `services/auction-monitor/src/server.ts` (lines 29-38)

2. **Social Service Mixed Status**
   - **Status:** 1 pod running, 1 pod crashing
   - **Root Cause:** Health check endpoint returns HTTP 503 when database connection fails
   - **Issue:** Health check requires database to be healthy, Redis failure is handled but DB failure causes restart
   - **Action:** Fix health check to be more resilient (see `INVESTIGATION_FINDINGS_HANDOFF.md`)
   - **Command:** `kubectl logs -n record-platform social-service-6c49795587-rbcc9`
   - **Files to Fix:** `services/social-service/src/server.ts` (lines 34-47)

### ⚠️ **Minor Issues**

1. **NodePort TLS Handshake on macOS/Kind**
   - **Issue:** NodePort TLS handshake fails on macOS with Kind cluster
   - **Workaround:** Test script automatically uses port-forward fallback
   - **Status:** Not blocking, workaround in place

2. **PostgreSQL Routing via host.docker.internal**
   - **Issue:** `host.docker.internal` from Kind routes to local Postgres.app instead of Docker Compose
   - **Workaround:** Created databases/schemas in Postgres.app
   - **Long-term:** Use Kubernetes Services for Postgres (better for production)

### ✅ **Resolved Issues**

1. ✅ Analytics service database connection fixed
2. ✅ Cron jobs fixed (using `dist/jobs.js`)
3. ✅ Caddy CA rotation working (1-2 second rotation time)
4. ✅ Kafka connectivity established via Kubernetes Service
5. ✅ Test script TLS handshake fixed (with port-forward fallback)

---

## Testing & Validation

### Test Scripts

1. **`scripts/test-full-chain-with-rotation.sh`**
   - **Status:** ✅ Fixed and working
   - **Features:**
     - Full chain testing (Client → Caddy → Ingress → Backend)
     - CA rotation with zero-downtime validation
     - HTTP/2 and HTTP/3 support
     - Strict TLS validation
     - High-intensity chaos testing (80 concurrent, 20000 requests)
   - **Notes:** Automatically uses port-forward if NodePort TLS fails

2. **`scripts/test-auth-service.sh`**
   - **Status:** ✅ Working
   - **Tests:** OAuth, SMS, Passkey, MFA, Privacy/Terms pages

3. **`scripts/test-analytics-service.sh`**
   - **Status:** ✅ Available
   - **Tests:** Analytics endpoints and database connectivity

### Health Check Endpoints

- **Caddy:** `/_caddy/healthz`
- **API Gateway:** `/api/healthz`
- **Auth Service:** `/api/auth/healthz`
- **Analytics Service:** `/api/analytics/healthz`
- **Other Services:** `/api/{service}/healthz`

---

## Port Configuration Summary

### Kubernetes Services (Internal)

- **API Gateway:** ClusterIP (internal)
- **Auth Service:** 4001 (HTTP), 50051 (gRPC)
- **Analytics Service:** ClusterIP (internal), 50054 (gRPC)
- **Listings Service:** ClusterIP (internal), 50057 (gRPC)
- **Shopping Service:** ClusterIP (internal), 50058 (gRPC)
- **Social Service:** ClusterIP (internal), 50056 (gRPC)
- **Auction Monitor:** ClusterIP (internal), 50059 (gRPC)
- **Python AI Service:** ClusterIP (internal), 50060 (gRPC)
- **Records Service:** ClusterIP (internal), 50051 (gRPC)

### External Ports

- **Caddy NodePort:** 30443 (HTTPS, HTTP/2 & HTTP/3)
- **Kafka:** 29092 (external)
- **PostgreSQL:** 5433-5440 (8 instances)
- **Redis:** 6379
- **MailHog:** 1025 (SMTP), 8025 (Web UI)

### Testing Ports

- **Port 8080:** Nginx service (webapp) - ClusterIP service, internal use
- **Port 8443:** Port-forward fallback for Caddy (when NodePort TLS fails)
- **Note:** Port 8080 is used by nginx service for webapp, not directly exposed through Caddy

---

## Next Steps & Recommendations

### Immediate Actions

1. **Fix Auction Monitor:**
   - Check logs: `kubectl logs -n record-platform auction-monitor-678c9bc474-gh4fk`
   - Verify Kafka connectivity
   - Check ConfigMap for correct Kafka broker URL

2. **Fix Social Service:**
   - Check logs for crashing pod
   - Verify database and Kafka connectivity

### Short-term Improvements

1. **PostgreSQL Routing:**
   - Consider using Kubernetes Services for Postgres instead of `host.docker.internal`
   - Better for production, avoids Postgres.app routing issues

2. **Service Replicas:**
   - Consider increasing replicas for critical services (auth-service already has 2)
   - Improves availability and zero-downtime deployments

3. **Monitoring:**
   - Set up alerts for CrashLoopBackOff pods
   - Monitor database connection health
   - Track Kafka connectivity

### Long-term Optimizations

1. **Storage Management:**
   - Consider consolidating PostgreSQL instances (currently 8 separate instances)
   - See `DOCKER_STORAGE_MANAGEMENT.md` for details

2. **CA Rotation:**
   - Already optimized (1-2 second rotation time)
   - Consider automating rotation schedule

3. **Test Coverage:**
   - Expand test scripts for all services
   - Add integration tests for Kafka flows
   - Add database connectivity tests

---

## Useful Commands

### Check Service Status

```bash
# All services
kubectl get pods -n record-platform

# Specific service
kubectl get pods -n record-platform -l app=analytics-service

# Service logs
kubectl logs -n record-platform <pod-name>

# Service description
kubectl describe pod -n record-platform <pod-name>
```

### Check Infrastructure

```bash
# Caddy status
kubectl get pods -n ingress-nginx -l app=caddy-h3
kubectl get svc -n ingress-nginx caddy-h3

# Kafka status
docker ps | grep kafka
kubectl get svc -n record-platform kafka-external

# PostgreSQL status
docker ps | grep postgres
```

### Test Connectivity

```bash
# Caddy health
curl -k --http2 --resolve "record.local:30443:127.0.0.1" -H "Host: record.local" "https://record.local:30443/_caddy/healthz"

# API Gateway
curl -k --http2 --resolve "record.local:30443:127.0.0.1" -H "Host: record.local" "https://record.local:30443/api/healthz"

# Analytics service
curl -k --http2 --resolve "record.local:30443:127.0.0.1" -H "Host: record.local" "https://record.local:30443/api/analytics/healthz"
```

### Run Tests

```bash
# Full chain with CA rotation
./scripts/test-full-chain-with-rotation.sh

# Auth service tests
./scripts/test-auth-service.sh

# Analytics service tests
./scripts/test-analytics-service.sh
```

---

## Documentation References

- **Investigation Findings:** `INVESTIGATION_FINDINGS_HANDOFF.md` ⭐ **READ THIS FIRST**
- **Storage Management:** `DOCKER_STORAGE_MANAGEMENT.md`
- **Analytics DB Fix:** `ANALYTICS_DB_CONNECTION_FIX.md`
- **CA Rotation:** `scripts/rotate-ca-and-fix-tls.sh`
- **Test Scripts:** `scripts/test-*.sh`

---

## Contact & Support

For issues or questions:
- Check service logs: `kubectl logs -n record-platform <pod-name>`
- Review this document for known issues
- Check recent commits for configuration changes
- Review service-specific documentation

---

**Last Updated:** December 2, 2025  
**Maintained By:** Development Team

