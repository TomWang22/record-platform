# Shopping Service k6 Load Test Suite

## Overview

Comprehensive k6 load test suite for shopping-service to find the upper bound of the user base and validate database performance under load.

## Test Suite Components

### 1. k6-shopping-stress.js
**Purpose**: Comprehensive stress testing of all shopping endpoints

**Features**:
- Cart operations (add, get, update, remove)
- Checkout with payment simulation
- Order management (get orders, order details)
- Purchase history (get, resell)
- Search history tracking
- Watchlist and wishlist operations
- Database validation

**Usage**:
```bash
# Basic stress test
k6 run --vus 50 --duration 5m scripts/load/k6-shopping-stress.js

# Aggressive ramp-up test
k6 run --stages 0s:10,30s:50,2m:100,5m:200,7m:300,10m:400,12m:500,15m:0 scripts/load/k6-shopping-stress.js

# Custom configuration
SHOPPING_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
HOST=record.local \
k6 run --vus 100 --duration 10m scripts/load/k6-shopping-stress.js
```

### 2. k6-shopping-ramp.js
**Purpose**: Progressive ramp-up test to find the upper bound

**Features**:
- Starts with low VUs and gradually increases
- Monitors error rates and response times
- Identifies the breaking point
- Tests all shopping endpoints under increasing load

**Usage**:
```bash
# Standard ramp-up (10 -> 500 VUs over 15 minutes)
k6 run scripts/load/k6-shopping-ramp.js

# Aggressive ramp-up (find absolute limit)
k6 run --stages 0s:10,30s:50,1m:100,2m:200,3m:300,4m:400,5m:500,6m:600,7m:700,8m:800,9m:900,10m:1000,12m:0 scripts/load/k6-shopping-ramp.js
```

### 3. k6-shopping-db-validation.js
**Purpose**: Database integrity and performance validation

**Features**:
- Verifies data consistency
- Checks database connection pool health
- Validates transaction integrity
- Monitors database query performance

**Usage**:
```bash
# Basic validation
k6 run --vus 20 --duration 5m scripts/load/k6-shopping-db-validation.js

# With database connection
DB_HOST=postgres-shopping.record-platform.svc.cluster.local \
DB_PORT=5432 \
DB_NAME=records \
DB_USER=postgres \
DB_PASSWORD=postgres \
k6 run --vus 50 --duration 10m scripts/load/k6-shopping-db-validation.js
```

## Port Mapping

### Critical: Correct Port Configuration

The k6 tests use **ClusterIP FQDN** for in-cluster testing, matching the pattern from `test-full-chain-with-rotation.sh`:

- **Shopping Service URL**: `https://caddy-h3.ingress-nginx.svc.cluster.local:443`
- **Auth Service URL**: `https://caddy-h3.ingress-nginx.svc.cluster.local:443`
- **Host Header**: `record.local`

This avoids:
- NodePort TLS handshake issues on macOS/Kind
- Port-forward bottlenecks (single-threaded, limited throughput)
- Network latency from external connections

### Database Configuration

- **Database Host**: `postgres-shopping-1` (Docker container) or `postgres-shopping.record-platform.svc.cluster.local` (K8s service)
- **Database Port**: `5436` (host) or `5432` (container/K8s service)
- **Database Name**: `records`
- **Schema**: `shopping`
- **Connection String**: `postgresql://postgres:postgres@localhost:5436/records`

## Running Tests in Kubernetes Cluster

### Using the Run Script

```bash
# Stress test
bash scripts/run-k6-shopping.sh stress

# Ramp-up test (upper bound discovery)
bash scripts/run-k6-shopping.sh ramp

# Database validation test
bash scripts/run-k6-shopping.sh db-validation
```

### Custom Configuration

```bash
# Custom VUs and duration
VUS=100 DURATION=10m bash scripts/run-k6-shopping.sh stress

# Custom URLs
SHOPPING_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
AUTH_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
HOST=record.local \
bash scripts/run-k6-shopping.sh stress
```

## Database Setup

### Shopping Database (Port 5436)

The shopping service uses a dedicated PostgreSQL instance on port 5436 with the `shopping` schema.

**Schema Files**:
- `infra/db/06-shopping-schema.sql` - Main schema (carts, watchlist, wishlist, orders, purchase history, search history)
- `infra/db/07-shopping-orders-migration.sql` - Orders migration
- `infra/db/08-shopping-notes-migration.sql` - Notes migration

**Prisma Schema**:
- `services/shopping-service/prisma/schema.prisma`

**Database Connection**:
- Environment variable: `POSTGRES_URL_SHOPPING`
- Default: `postgresql://postgres:postgres@localhost:5436/records`
- Connection pool: max 20 connections (see `services/shopping-service/src/lib/db.ts`)

### Setting Up Database

If the database doesn't exist:

```bash
# Create database (if using Docker)
docker exec -i postgres-shopping-1 psql -U postgres <<EOF
CREATE DATABASE records;
\c records
CREATE SCHEMA IF NOT EXISTS shopping;
EOF

# Run schema migrations
psql -h localhost -p 5436 -U postgres -d records -f infra/db/06-shopping-schema.sql
psql -h localhost -p 5436 -U postgres -d records -f infra/db/07-shopping-orders-migration.sql
psql -h localhost -p 5436 -U postgres -d records -f infra/db/08-shopping-notes-migration.sql
```

## Test Metrics

### Custom Metrics Tracked

- `cart_operations_success` - Cart operation success rate
- `checkout_operations_success` - Checkout operation success rate
- `order_operations_success` - Order operation success rate
- `purchase_history_success` - Purchase history operation success rate
- `resell_operations_success` - Resell operation success rate
- `search_history_success` - Search history operation success rate
- `watchlist_operations_success` - Watchlist operation success rate
- `wishlist_operations_success` - Wishlist operation success rate
- `db_query_success` - Database query success rate (db-validation test)
- `db_consistency_check` - Data consistency validation (db-validation test)
- `db_transaction_success` - Transaction success rate (db-validation test)
- `db_pool_health` - Connection pool health (db-validation test)

### Thresholds

**Stress Test**:
- HTTP request duration: p(95) < 2000ms, p(99) < 5000ms
- HTTP request failed: rate < 0.05 (5%)
- Cart operations: success rate > 0.90 (90%)
- Checkout operations: success rate > 0.85 (85%)
- Order operations: success rate > 0.90 (90%)

**Ramp-Up Test**:
- HTTP request duration: p(95) < 3000ms, p(99) < 5000ms
- HTTP request failed: rate < 0.10 (10% at high load)
- All operations: success rate > 0.70-0.85 (depending on load)

**Database Validation**:
- HTTP request duration: p(95) < 2000ms, p(99) < 5000ms
- HTTP request failed: rate < 0.05 (5%)
- Database queries: success rate > 0.95 (95%)
- Data consistency: success rate > 0.95 (95%)
- Transactions: success rate > 0.95 (95%)

## Interpreting Results

### Upper Bound Discovery

The ramp-up test (`k6-shopping-ramp.js`) will identify the upper bound by:

1. **Gradually increasing VUs** from 10 to 500+ over 15+ minutes
2. **Monitoring error rates** - when error rate exceeds 10%, that's near the upper bound
3. **Analyzing response times** - when p95/p99 latencies spike, that indicates saturation
4. **Tracking operation success rates** - when success rates drop below thresholds, that's the breaking point

### Example Output

```
Upper Bound Analysis:
  Estimated Upper Bound: 400 VUs
  ⚠️  Acceptable - Error rate < 10%
  ✅ High throughput achieved
  
  Recommendation:
  ⚠️  Service can handle ~400 concurrent users (with < 10% error rate)
```

### Success Criteria

- **Excellent**: Error rate < 5%, all operations > 95% success
- **Acceptable**: Error rate < 10%, all operations > 85% success
- **Degraded**: Error rate > 10%, operations < 85% success

## Troubleshooting

### Database Connection Issues

If database validation fails:

1. **Check database is running**:
   ```bash
   docker ps | grep postgres-shopping
   # or
   kubectl -n record-platform get pods -l app=postgres-shopping
   ```

2. **Verify database port**:
   ```bash
   # Docker: port 5436
   docker port postgres-shopping-1
   
   # K8s: port 5432 (service)
   kubectl -n record-platform get svc postgres-shopping
   ```

3. **Test database connection**:
   ```bash
   psql -h localhost -p 5436 -U postgres -d records -c "SELECT 1"
   ```

4. **Check schema exists**:
   ```bash
   psql -h localhost -p 5436 -U postgres -d records -c "\dn shopping"
   ```

### Authentication Issues

If auth errors occur:

1. **Verify auth service is running**:
   ```bash
   kubectl -n record-platform get pods -l app=auth-service
   ```

2. **Check auth service logs**:
   ```bash
   kubectl -n record-platform logs -l app=auth-service --tail=50
   ```

3. **Verify auth database** (port 5437):
   ```bash
   docker ps | grep postgres-auth
   ```

### Port Mapping Issues

If tests fail with connection errors:

1. **Verify ClusterIP FQDN is correct**:
   ```bash
   kubectl -n ingress-nginx get svc caddy-h3 -o jsonpath='{.spec.clusterIP}'
   # Should match: caddy-h3.ingress-nginx.svc.cluster.local
   ```

2. **Test from inside cluster**:
   ```bash
   kubectl -n k6-load run test-curl --rm -i --restart=Never \
     --image=curlimages/curl:latest -- \
     curl -k -sS -I --http2 \
     -H "Host: record.local" \
     "https://caddy-h3.ingress-nginx.svc.cluster.local/_caddy/healthz"
   ```

3. **Check Caddy pods are ready**:
   ```bash
   kubectl -n ingress-nginx get pods -l app=caddy-h3
   ```

## Files Created

1. **`scripts/load/k6-shopping-stress.js`** - Comprehensive stress test
2. **`scripts/load/k6-shopping-ramp.js`** - Upper bound discovery test
3. **`scripts/load/k6-shopping-db-validation.js`** - Database validation test
4. **`scripts/run-k6-shopping.sh`** - Run script for Kubernetes cluster
5. **`SHOPPING_SERVICE_K6_LOAD_TESTS.md`** - This documentation

## Next Steps

1. ✅ k6 test scripts created
2. ✅ Run script created
3. ⏳ Run initial stress test to establish baseline
4. ⏳ Run ramp-up test to find upper bound
5. ⏳ Run database validation test
6. ⏳ Document findings and recommendations

## References

- **Port Mapping Reference**: `scripts/test-full-chain-with-rotation.sh` (lines 260-280)
- **Service Configuration**: `scripts/test-microservices-http2-http3.sh` (lines 1180-1404)
- **Database Schema**: `infra/db/06-shopping-schema.sql`
- **Prisma Schema**: `services/shopping-service/prisma/schema.prisma`
- **Database Connection**: `services/shopping-service/src/lib/db.ts`

