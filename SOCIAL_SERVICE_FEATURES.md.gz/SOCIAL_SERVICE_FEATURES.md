# Social Service Features & Testing

## Overview

This document describes the social service features, including forum posts, group chats, messaging, and attachments. A comprehensive benchmark harness has been created to test database performance.

## Features Implemented

### 1. Forum Posts (Reddit-style)

- **Post Creation**: Create posts with title, content, flair, and upload_type
- **Upload Types**: `text`, `image`, `video`, `link`, `poll`
- **Flair System**: Categorize posts with custom flairs
- **Voting**: Upvote/downvote posts
- **Comments**: Nested comment threads with replies
- **Attachments**: Support for images, videos, PDFs, and other files on posts and comments
- **Pagination**: List posts with pagination and filtering by flair

### 2. Group Chats

- **Group Creation**: Create groups with name and description
- **Member Management**: Add/remove members (admin/moderator only)
- **Leave Group**: Users can leave groups (prevents leaving if only admin)
- **Group Messages**: Send messages to entire group
- **Reply to Messages**: WhatsApp-style reply to specific messages in group chats
- **Message Threading**: Threaded conversations with parent_message_id

### 3. Direct Messages

- **Send Messages**: Direct one-on-one messaging
- **Reply to Messages**: Reply to specific messages (WhatsApp-style)
- **Read Receipts**: Track message reads
- **Message Threading**: Threaded conversations

### 4. Attachments

- **Post Attachments**: Add images, videos, PDFs, and other files to forum posts
- **Comment Attachments**: Add attachments to comments
- **Message Attachments**: Add attachments to direct and group messages
- **File Types Supported**: `image`, `video`, `audio`, `document`, `other`
- **Metadata**: File size, MIME type, dimensions (for images/videos), duration (for videos/audio)

## API Endpoints

### Forum Posts

- `GET /forum/posts` - List posts (paginated, filterable by flair)
- `POST /forum/posts` - Create post (requires title, content, flair, optional upload_type)
- `GET /forum/posts/:postId` - Get post details
- `PUT /forum/posts/:postId` - Update post (author only)
- `DELETE /forum/posts/:postId` - Delete post (author only)
- `POST /forum/posts/:postId/vote` - Vote on post
- `POST /forum/posts/:postId/attachments` - Add attachment to post
- `GET /forum/posts/:postId/attachments` - Get attachments for post

### Forum Comments

- `GET /forum/posts/:postId/comments` - Get comments for post (nested structure)
- `POST /forum/posts/:postId/comments` - Add comment (optional parent_id for replies)
- `PUT /forum/comments/:commentId` - Update comment (author only)
- `DELETE /forum/comments/:commentId` - Delete comment (author only)
- `POST /forum/comments/:commentId/vote` - Vote on comment
- `POST /forum/comments/:commentId/attachments` - Add attachment to comment
- `GET /forum/comments/:commentId/attachments` - Get attachments for comment

### Messages

- `GET /messages` - List user's messages (inbox, paginated)
- `POST /messages` - Send new message (direct or group)
- `GET /messages/:messageId` - Get message details
- `POST /messages/:messageId/reply` - Reply to message (WhatsApp-style, includes parent message context)
- `PUT /messages/:messageId` - Update message (sender only)
- `DELETE /messages/:messageId` - Delete message (sender or recipient)
- `GET /messages/thread/:threadId` - Get full thread/conversation
- `POST /messages/:messageId/read` - Mark message as read
- `POST /messages/:messageId/attachments` - Add attachment to message
- `GET /messages/:messageId/attachments` - Get attachments for message

### Group Chats

- `POST /messages/groups` - Create a new group
- `GET /messages/groups` - List user's groups
- `GET /messages/groups/:groupId` - Get group details
- `POST /messages/groups/:groupId/members` - Add member to group (admin/moderator only)
- `DELETE /messages/groups/:groupId/leave` - User leaves group (prevents leaving if only admin)

## Database Schema

### Forum Schema

- `forum.posts` - Posts with title, content, flair, upload_type, votes, etc.
- `forum.post_attachments` - Attachments for posts (images, videos, PDFs)
- `forum.comments` - Nested comments with parent_id
- `forum.comment_attachments` - Attachments for comments
- `forum.post_votes` - Post votes (up/down)
- `forum.comment_votes` - Comment votes (up/down)

### Messages Schema

- `messages.groups` - Group chat groups
- `messages.group_members` - Group membership with roles (admin, moderator, member)
- `messages.messages` - Direct and group messages with threading support
- `messages.message_attachments` - Attachments for messages
- `messages.message_reads` - Read receipts for messages

## Benchmark Harness

A comprehensive benchmark harness has been created at `scripts/run_social_pgbench_sweep.sh` to test database performance for social service operations.

### Usage

```bash
# Quick mode (default)
./scripts/run_social_pgbench_sweep.sh

# Deep mode (more client counts)
MODE=deep ./scripts/run_social_pgbench_sweep.sh

# Custom configuration
./scripts/run_social_pgbench_sweep.sh -c 8,16,32,64 -d 120 -u <user-uuid>
```

### Benchmarks Included

- **forum_post**: Create forum posts
- **forum_list**: List forum posts
- **forum_comment**: Create forum comments
- **message_direct**: Create direct messages
- **message_group**: Create group messages
- **message_list**: List messages (inbox)
- **group_list**: List user's groups
- **noop**: Baseline overhead test

### Results

Results are saved to:
- `bench_logs/social_YYYYMMDD_HHMMSS/` - Log directory
- `social_bench_sweep_YYYYMMDD_HHMMSS.csv` - CSV results
- `social_bench_sweep.csv` - Latest results

## Database Migration

To add the `upload_type` column to existing databases:

```bash
# Run migration on social database (port 5434)
psql -h localhost -p 5434 -U postgres -d records -f infra/db/04-social-schema-upload-type-migration.sql
```

## Testing Checklist

- [x] Forum post creation with upload_type
- [x] Forum post attachments (images, videos, PDFs)
- [x] Forum comment attachments
- [x] Group chat creation
- [x] Group chat messaging
- [x] Reply to messages (WhatsApp-style with parent message context)
- [x] Leave group chat
- [x] Message attachments
- [x] Direct messaging
- [x] Message threading
- [x] Benchmark harness

## Kafka Integration

All social events are published to Kafka topics:
- `forum-posts` - Post creation events
- `forum-comments` - Comment creation events
- `messages` - Direct message events
- `group-messages` - Group message events

Kafka integration is optional and fails gracefully if Kafka is unavailable.

## Next Steps

1. Run the benchmark harness to establish baseline performance
2. Test all features manually via API endpoints
3. Add frontend UI for forum posts, group chats, and messaging
4. Implement file upload service for attachments
5. Add real-time notifications via WebSocket or Server-Sent Events

