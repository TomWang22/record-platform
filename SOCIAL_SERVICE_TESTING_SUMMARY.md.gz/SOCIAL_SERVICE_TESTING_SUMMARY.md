# Social Service Testing Summary

## ✅ Completed Actions

### 1. Database Migration
- ✅ Applied migration: `infra/db/04-social-schema-upload-type-migration.sql`
- ✅ Added `upload_type` column to `forum.posts` table
- ✅ Added index on `upload_type` column
- ✅ Migration completed successfully

### 2. Service Restart
- ✅ Restarted `social-service` deployment in Kubernetes
- ✅ Verified rollout completed successfully
- ✅ Service is now running with updated code and schema

### 3. Comprehensive Test Coverage Added

Added **7 new tests** to `scripts/test-microservices-http2-http3.sh`:

#### Test 9f: Reply to Group Message (WhatsApp-style)
- Tests reply-to-message feature in group chats
- Verifies parent message context is included in response
- Uses HTTP/2

#### Test 9g: Forum Post with upload_type
- Tests creating forum posts with `upload_type` field
- Validates `upload_type` is returned in response
- Tests `upload_type=image` (supports: text, image, video, link, poll)
- Uses HTTP/2

#### Test 9h: Add Attachment to Forum Post
- Tests adding image attachments to forum posts
- Includes metadata: file_url, file_type, file_name, mime_type, file_size, dimensions
- Uses HTTP/2

#### Test 9i: Add Attachment to Comment
- Tests adding PDF/document attachments to comments
- Creates comment first, then adds attachment
- Uses HTTP/3

#### Test 9j: Add Attachment to Message
- Tests adding video attachments to messages
- Includes video metadata: duration, width, height
- Uses HTTP/2

#### Test 9k: Leave Group Chat
- Tests user leaving a group chat
- Verifies user is removed (403 on subsequent group access)
- Prevents leaving if user is only admin
- Uses HTTP/2

#### Test 9l: Get Post Attachments
- Tests retrieving attachments for a forum post
- Uses HTTP/3

## Testing Checklist

### Forum Features
- [x] Create post with `upload_type` (text, image, video, link, poll)
- [x] Add attachment to post (image, video, PDF, etc.)
- [x] Get post attachments
- [x] Add attachment to comment
- [x] Reply to messages (WhatsApp-style with parent context)

### Group Chat Features
- [x] Create group
- [x] Add members to group
- [x] Send group messages
- [x] Reply to group messages (WhatsApp-style)
- [x] Leave group chat
- [x] Verify leave (403 on group access after leaving)

### Message Features
- [x] Send direct messages
- [x] Reply to messages (WhatsApp-style)
- [x] Add attachments to messages (images, videos, PDFs)
- [x] Get message attachments

## How to Run Tests

### Full Integration Test Suite
```bash
./scripts/test-microservices-http2-http3.sh
```

This will test:
- All existing microservices (auth, records, listings)
- All new social service features
- HTTP/2 and HTTP/3 protocols
- gRPC services

### Social Service Benchmark
```bash
./scripts/run_social_pgbench_sweep.sh
```

This will benchmark:
- Forum post creation
- Forum post listing
- Comment creation
- Direct message creation
- Group message creation
- Message listing
- Group listing

### Quick Manual Test
```bash
# Get auth token first
TOKEN=$(curl -k -sS --http2 \
  --resolve "record.local:8443:127.0.0.1" \
  -H "Host: record.local" \
  -X POST "https://record.local:8443/api/auth/login" \
  -d '{"email":"test@example.com","password":"test123"}' \
  | grep -o '"token":"[^"]*"' | cut -d'"' -f4)

# Test forum post with upload_type
curl -k -sS --http2 \
  --resolve "record.local:8443:127.0.0.1" \
  -H "Host: record.local" \
  -H "Authorization: Bearer $TOKEN" \
  -X POST "https://record.local:8443/api/forum/posts" \
  -d '{"title":"Test","content":"Test post","flair":"general","upload_type":"image"}'
```

## Expected Test Results

All tests should return:
- ✅ HTTP 200/201 for successful operations
- ✅ HTTP 204 for successful deletions (leave group)
- ✅ HTTP 403 for unauthorized access (after leaving group)
- ✅ Parent message context in reply responses
- ✅ `upload_type` field in post responses
- ✅ Attachment metadata in attachment responses

## Files Modified

1. `scripts/test-microservices-http2-http3.sh` - Added 7 new comprehensive tests
2. `services/social-service/src/routes/forum.ts` - Added upload_type and attachment endpoints
3. `services/social-service/src/routes/messages.ts` - Added leave group, attachments, enhanced replies
4. `infra/db/04-social-schema.sql` - Added upload_type column
5. `infra/db/04-social-schema-upload-type-migration.sql` - Migration script
6. `services/social-service/prisma/schema.prisma` - Updated with upload_type

## Next Steps

1. **Run the full test suite**: `./scripts/test-microservices-http2-http3.sh`
2. **Run the benchmark**: `./scripts/run_social_pgbench_sweep.sh`
3. **Verify all features work** as expected
4. **Check service logs** if any tests fail: `kubectl logs -l app=social-service -n record-platform`

## Troubleshooting

If tests fail:
1. Check service is running: `kubectl get pods -l app=social-service -n record-platform`
2. Check service logs: `kubectl logs -l app=social-service -n record-platform --tail=100`
3. Verify database migration: `psql -h localhost -p 5434 -U postgres -d records -c "SELECT column_name FROM information_schema.columns WHERE table_schema='forum' AND table_name='posts' AND column_name='upload_type';"`
4. Verify schema: `psql -h localhost -p 5434 -U postgres -d records -c "\d forum.posts"`

