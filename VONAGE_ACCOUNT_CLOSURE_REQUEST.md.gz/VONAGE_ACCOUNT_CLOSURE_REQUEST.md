# Vonage API Account Closure Request

## Support Request Template

**Subject:** Request to Terminate/Delete Vonage API Account

---

**To:** Vonage Support  
**Subject:** Request to Terminate/Delete Vonage API Account

Dear Vonage Support Team,

I am writing to request the termination and deletion of my Vonage API account.

**Account Information:**
- **API Key:** `5d84962c`
- **Email:** [Your registered email address]
- **Phone Number:** [Your registered phone number, if applicable]

I understand that:
- Deleting my Vonage API account will result in permanent removal of my account and all customer data
- Some data may remain on Vonage's servers in an aggregated or anonymized form that does not specifically identify me
- Account information is held for 1 year, after which my account information will also be deleted
- If I wish to open a new Vonage API account in the future, I will not be able to reuse my previous email or phone number associated with this deleted account

Please proceed with the account termination and deletion process.

Thank you for your assistance.

Best regards,  
[Your Name]

---

## How to Submit

1. **Go to Vonage Support Portal:**
   - Visit: https://support.nexmo.com/hc/en-us/requests/new
   - Or log into your Vonage dashboard and submit a support ticket

2. **Select Request Type:**
   - Category: Account Management
   - Subject: Account Termination/Deletion

3. **Paste the email above** (fill in your email and phone number)

4. **Include your API Key:** `5d84962c`

5. **Submit the request**

---

## After Submission

- You should receive a confirmation email from Vonage
- The account closure process typically takes a few business days
- You'll receive confirmation once the account is deleted

---

## Note

Since we're using the Mock SMS Provider now, closing your Vonage account won't affect the auth-service functionality. The mock provider is already active and working.

