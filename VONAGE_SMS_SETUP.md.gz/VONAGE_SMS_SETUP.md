# Vonage SMS Setup Guide

Vonage (formerly Nexmo) offers a free tier with 10,000 SMS messages per month, making it an excellent alternative to Twilio for SMS verification.

## Step 1: Sign Up for Vonage

1. Go to https://www.vonage.com/communications-apis/sms/
2. Click "Get Started" or "Sign Up"
3. Create an account (free tier available)
4. Verify your email address

## Step 2: Get Your API Credentials

1. Log in to the Vonage Dashboard: https://dashboard.nexmo.com/
2. Navigate to **Settings** → **API Credentials**
3. You'll see:
   - **API Key** (e.g., `12345678`)
   - **API Secret** (e.g., `abcdefghijklmnop`)
4. Copy both values (you'll need them for configuration)

## Step 3: Get a Virtual Number (Optional but Recommended)

For production, you'll want a dedicated phone number:

1. In the Vonage Dashboard, go to **Numbers** → **Buy Numbers**
2. Select your country
3. Choose a number (you can get a free number for testing)
4. Purchase the number (prices vary by country)

**Note**: For testing, you can use Vonage's test numbers or skip this step if you're just testing.

## Step 4: Configure in Kubernetes

### Update app-secrets.yaml

```yaml
# Vonage for SMS Verification (FREE tier: 10,000 messages/month)
# Get credentials from: https://dashboard.nexmo.com/
VONAGE_API_KEY: "your_api_key_here"           # e.g., "12345678"
VONAGE_API_SECRET: "your_api_secret_here"     # e.g., "abcdefghijklmnop"
VONAGE_FROM_NUMBER: "+1234567890"             # Your Vonage number (optional for testing)
```

### Update app-config.yaml

```yaml
# SMS Provider Configuration
SMS_PROVIDER: "vonage"  # Use Vonage as SMS provider
# or set to "auto" to auto-detect based on available credentials
```

## Step 5: Install Vonage SDK (if not already installed)

The Vonage SDK is lazy-loaded, but you can install it for better TypeScript support:

```bash
cd services/auth-service
pnpm add @vonage/server-sdk
```

Or add to `services/auth-service/package.json`:

```json
{
  "dependencies": {
    "@vonage/server-sdk": "^3.0.0"
  }
}
```

## Step 6: Apply Configuration

```bash
# Apply secrets
kubectl apply -f infra/k8s/base/config/app-secrets.yaml

# Apply config
kubectl apply -f infra/k8s/base/config/app-config.yaml

# Restart auth service
kubectl rollout restart deployment/auth-service -n record-platform
```

## Step 7: Test SMS Sending

### Using curl:

```bash
# Send verification code
curl -X POST https://record.local:8443/api/auth/verification/phone/send \
  -H "Content-Type: application/json" \
  -d '{"phone": "+1234567890"}'

# Check logs to see if SMS was sent
kubectl logs -n record-platform -l app=auth-service -c app --tail=50 | grep -i vonage
```

### Using test script:

```bash
./scripts/test-auth-service.sh
# Test 9 should now work with real SMS
```

## Troubleshooting

### Error: "Vonage SDK not installed"
- Install the SDK: `pnpm add @vonage/server-sdk`
- Rebuild the Docker image
- Restart the service

### Error: "Invalid API credentials"
- Double-check your API Key and API Secret
- Ensure there are no extra spaces or quotes
- Verify credentials in Vonage Dashboard

### Error: "Invalid from number"
- Make sure `VONAGE_FROM_NUMBER` is in E.164 format: `+1234567890`
- For testing, you can use Vonage's test numbers
- Verify the number is active in your Vonage account

### SMS Not Received
- Check Vonage Dashboard → **Reports** → **SMS** for delivery status
- Verify the destination number is valid
- Check if you've exceeded the free tier limit (10,000/month)
- Review Vonage logs in the dashboard

## Free Tier Limits

- **10,000 SMS messages per month** (free)
- Additional messages: ~$0.005-0.01 per SMS (varies by country)
- No credit card required for free tier

## Cost Comparison

| Provider | Free Tier | Cost per SMS (after free tier) |
|----------|-----------|--------------------------------|
| Vonage | 10,000/month | ~$0.005-0.01 |
| AWS SNS | None | ~$0.00645 |
| MessageBird | 1,000/month | ~$0.01 |
| Twilio | Trial credits | ~$0.0075 |

## Production Checklist

- [ ] Vonage account created and verified
- [ ] API Key and Secret obtained
- [ ] Virtual number purchased (for production)
- [ ] Credentials added to `app-secrets.yaml`
- [ ] `SMS_PROVIDER` set to `"vonage"` in `app-config.yaml`
- [ ] Vonage SDK installed (optional but recommended)
- [ ] Configuration applied to Kubernetes
- [ ] Auth service restarted
- [ ] Test SMS sent successfully
- [ ] Verified SMS received on test phone

## Additional Resources

- Vonage SMS API Docs: https://developer.vonage.com/messaging/sms/overview
- Vonage Dashboard: https://dashboard.nexmo.com/
- Vonage Pricing: https://www.vonage.com/communications-apis/pricing/
- Support: https://developer.vonage.com/support

