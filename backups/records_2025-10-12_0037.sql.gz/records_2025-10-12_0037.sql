--
-- PostgreSQL database dump
--

\restrict 9bjv2Witcr0j8rPIpyNsbgGYRhjTdWhLlN7avbuqhdQVcma2gOVXGLyJq3Latd9

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: records; Type: SCHEMA; Schema: -; Owner: record_owner
--

CREATE SCHEMA records;


ALTER SCHEMA records OWNER TO record_owner;

--
-- Name: add_record(uuid, text, text, text, text, text, text, jsonb, date, numeric, text); Type: FUNCTION; Schema: records; Owner: record_owner
--

CREATE FUNCTION records.add_record(p_user uuid, p_artist text, p_name text, p_format text, p_catalog text DEFAULT NULL::text, p_record_grade text DEFAULT NULL::text, p_sleeve_grade text DEFAULT NULL::text, p_flags jsonb DEFAULT '{}'::jsonb, p_purchased date DEFAULT NULL::date, p_price numeric DEFAULT NULL::numeric, p_notes text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE rid UUID;
BEGIN
  INSERT INTO records.records(user_id, artist, name, format, catalog_number, record_grade, sleeve_grade,
    has_insert, has_booklet, has_obi_strip, has_factory_sleeve, is_promo, purchased_at, price_paid, notes)
  VALUES (p_user, p_artist, p_name, p_format, p_catalog, p_record_grade, p_sleeve_grade,
    COALESCE((p_flags->>'has_insert')::boolean, FALSE),
    COALESCE((p_flags->>'has_booklet')::boolean, FALSE),
    COALESCE((p_flags->>'has_obi_strip')::boolean, FALSE),
    COALESCE((p_flags->>'has_factory_sleeve')::boolean, FALSE),
    COALESCE((p_flags->>'is_promo')::boolean, FALSE), p_purchased, p_price, p_notes)
  RETURNING id INTO rid;
  RETURN rid;
END; $$;


ALTER FUNCTION records.add_record(p_user uuid, p_artist text, p_name text, p_format text, p_catalog text, p_record_grade text, p_sleeve_grade text, p_flags jsonb, p_purchased date, p_price numeric, p_notes text) OWNER TO record_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: records; Type: TABLE; Schema: records; Owner: record_owner
--

CREATE TABLE records.records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    artist character varying(256) NOT NULL,
    name character varying(256) NOT NULL,
    format character varying(64) NOT NULL,
    catalog_number character varying(64),
    record_grade character varying(16),
    sleeve_grade character varying(16),
    has_insert boolean DEFAULT false,
    has_booklet boolean DEFAULT false,
    has_obi_strip boolean DEFAULT false,
    has_factory_sleeve boolean DEFAULT false,
    is_promo boolean DEFAULT false,
    notes text,
    purchased_at date,
    price_paid numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    insert_grade character varying(16),
    booklet_grade character varying(16),
    obi_strip_grade character varying(16),
    factory_sleeve_grade character varying(16),
    release_year integer,
    release_date date,
    pressing_year integer,
    label character varying(128),
    label_code character varying(64)
);


ALTER TABLE records.records OWNER TO record_owner;

--
-- Name: search_records(uuid, text, integer, integer); Type: FUNCTION; Schema: records; Owner: record_owner
--

CREATE FUNCTION records.search_records(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0) RETURNS SETOF records.records
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM records.records r
  WHERE r.user_id = p_user AND (
    r.artist ILIKE '%'||p_q||'%' OR r.name ILIKE '%'||p_q||'%' OR r.catalog_number ILIKE '%'||p_q||'%')
  ORDER BY r.updated_at DESC
  LIMIT p_limit OFFSET p_offset;
END; $$;


ALTER FUNCTION records.search_records(p_user uuid, p_q text, p_limit integer, p_offset integer) OWNER TO record_owner;

--
-- Name: touch_rm_updated_at(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.touch_rm_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;


ALTER FUNCTION records.touch_rm_updated_at() OWNER TO postgres;

--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: records; Owner: record_owner
--

CREATE FUNCTION records.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;


ALTER FUNCTION records.touch_updated_at() OWNER TO record_owner;

--
-- Name: record_media; Type: TABLE; Schema: records; Owner: postgres
--

CREATE TABLE records.record_media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    record_id uuid NOT NULL,
    index integer NOT NULL,
    kind text NOT NULL,
    size_inch integer,
    speed_rpm integer,
    disc_grade character varying(16),
    sides jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE records.record_media OWNER TO postgres;

--
-- Data for Name: record_media; Type: TABLE DATA; Schema: records; Owner: postgres
--

COPY records.record_media (id, record_id, index, kind, size_inch, speed_rpm, disc_grade, sides, notes, created_at, updated_at) FROM stdin;
7fe3737a-b6b5-493a-8b86-3d80cb9e0f4a	eb3080e5-0b9a-4900-aac8-3c20619e647a	1	VINYL	12	33	NM	{"A": "NM", "B": "VG_PLUS"}	\N	2025-10-12 03:20:16.03+00	2025-10-12 03:20:16.03+00
1a96e3c6-2fc0-41b5-b540-89d1f0253f7e	9e5da394-0ff8-4b5c-abb2-b1e91a09f022	1	VINYL	7	45	VG+	{"A": "NM", "B": "VG+"}	\N	2025-10-12 04:03:49.564+00	2025-10-12 04:03:49.564+00
9ddc4fe3-de88-46bf-8c60-0ab66138ab29	9e5da394-0ff8-4b5c-abb2-b1e91a09f022	2	VINYL	12	33	EX-	{"C": "EX", "D": "VG+"}	\N	2025-10-12 04:03:49.564+00	2025-10-12 04:03:49.564+00
\.


--
-- Data for Name: records; Type: TABLE DATA; Schema: records; Owner: record_owner
--

COPY records.records (id, user_id, artist, name, format, catalog_number, record_grade, sleeve_grade, has_insert, has_booklet, has_obi_strip, has_factory_sleeve, is_promo, notes, purchased_at, price_paid, created_at, updated_at, insert_grade, booklet_grade, obi_strip_grade, factory_sleeve_grade, release_year, release_date, pressing_year, label, label_code) FROM stdin;
9362cb53-20b1-4264-bb03-2442d96689d5	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:00:31.166+00	2025-10-12 00:00:31.166+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
39f1b4a4-41cd-4d96-b22c-13692726a875	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:00:44.352+00	2025-10-12 00:00:44.352+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
b73a3400-ec25-4882-9f10-76a37815ed3d	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:06:03.612+00	2025-10-12 00:06:03.612+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
cfe33e99-77af-450b-9718-6218d8a9058b	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:07:28.645+00	2025-10-12 00:07:28.645+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
08d34331-c98f-40c3-b63d-75e20016690e	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:33:22.845+00	2025-10-12 00:33:22.845+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
c0906f72-1f1b-43e2-b0be-b37e2fa9a5ab	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 00:51:24.869+00	2025-10-12 00:51:24.869+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
48e652e4-8371-4fd4-91d8-ce2f80fe982c	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 01:05:29.864+00	2025-10-12 01:05:29.864+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
50f8248c-7dea-4e5e-ace5-b1de0f60bf4f	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	\N	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 01:12:13.695+00	2025-10-12 01:12:13.695+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
eb3080e5-0b9a-4900-aac8-3c20619e647a	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	LP	\N	NM	\N	f	f	f	f	f	\N	\N	\N	2025-10-12 01:19:01.859+00	2025-10-12 03:12:25.056+00	\N	\N	\N	\N	\N	\N	\N	\N	\N
9e5da394-0ff8-4b5c-abb2-b1e91a09f022	fa1fc8f1-9ed5-4f46-b392-4ffa27d6b2a6	David Bowie	Low	EP	PL 12030	VG+	VG+	f	t	f	t	f	\N	\N	\N	2025-10-12 03:53:07.29+00	2025-10-12 04:03:49.564865+00	\N	NM-	\N	G+	1977	1977-01-14	1977	RCA	PL 12030
\.


--
-- Name: record_media record_media_pkey; Type: CONSTRAINT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.record_media
    ADD CONSTRAINT record_media_pkey PRIMARY KEY (id);


--
-- Name: record_media record_media_record_id_index_key; Type: CONSTRAINT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.record_media
    ADD CONSTRAINT record_media_record_id_index_key UNIQUE (record_id, index);


--
-- Name: records records_pkey; Type: CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_pkey PRIMARY KEY (id);


--
-- Name: idx_records_artist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_artist_trgm ON records.records USING gin (artist public.gin_trgm_ops);


--
-- Name: idx_records_catalog; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_catalog ON records.records USING btree (catalog_number);


--
-- Name: idx_records_combo; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_combo ON records.records USING btree (artist, name, format);


--
-- Name: idx_records_label; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_label ON records.records USING btree (label);


--
-- Name: idx_records_name_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_name_trgm ON records.records USING gin (name public.gin_trgm_ops);


--
-- Name: idx_records_release_year; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_release_year ON records.records USING btree (release_year);


--
-- Name: idx_records_user; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user ON records.records USING btree (user_id);


--
-- Name: record_media trg_record_media_touch; Type: TRIGGER; Schema: records; Owner: postgres
--

CREATE TRIGGER trg_record_media_touch BEFORE UPDATE ON records.record_media FOR EACH ROW EXECUTE FUNCTION records.touch_rm_updated_at();


--
-- Name: records trg_records_touch; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_records_touch BEFORE UPDATE ON records.records FOR EACH ROW EXECUTE FUNCTION records.touch_updated_at();


--
-- Name: record_media record_media_record_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.record_media
    ADD CONSTRAINT record_media_record_id_fkey FOREIGN KEY (record_id) REFERENCES records.records(id) ON DELETE CASCADE;


--
-- Name: records records_user_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA records; Type: ACL; Schema: -; Owner: record_owner
--

GRANT USAGE ON SCHEMA records TO record_readwrite;
GRANT USAGE ON SCHEMA records TO record_readonly;


--
-- Name: TABLE records; Type: ACL; Schema: records; Owner: record_owner
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.records TO record_readwrite;
GRANT SELECT ON TABLE records.records TO record_readonly;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: records; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA records GRANT ALL ON SEQUENCES TO record_readwrite;
ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA records GRANT SELECT,USAGE ON SEQUENCES TO record_readonly;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: records; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA records GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO record_readwrite;
ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA records GRANT SELECT ON TABLES TO record_readonly;


--
-- PostgreSQL database dump complete
--

\unrestrict 9bjv2Witcr0j8rPIpyNsbgGYRhjTdWhLlN7avbuqhdQVcma2gOVXGLyJq3Latd9

