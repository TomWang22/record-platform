--
-- PostgreSQL database cluster dump
--

\restrict ekgyFyY5yKYqVTcfuQAr97sqxFv58j0aCn6kGSwqT2LjE1x5kWZwLicyQNyuy5A

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:/slvcOyYIUm0dZ5B/hiwYw==$cEnWGyuKtIlKaXQ2rtTDrByO68A9gFfPLPUJqdSOP80=:Yy5W/6k0XfkWaNT0iCkPQiVdf8JG9SNxe0aBcSL9/oI=';
CREATE ROLE record_app;
ALTER ROLE record_app WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:uu165snHDIERmu6uPX28Ag==$TFlbDMaqO/ORCFixIncX9VeGUzaebuqCx0XoLBp9H7w=:baBCbTkLqssz5tINXOf2VN70i0FvEeFUDkl7ZGly6Hw=';
CREATE ROLE record_owner;
ALTER ROLE record_owner WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;

--
-- User Configurations
--








\unrestrict ekgyFyY5yKYqVTcfuQAr97sqxFv58j0aCn6kGSwqT2LjE1x5kWZwLicyQNyuy5A

--
-- PostgreSQL database cluster dump complete
--

