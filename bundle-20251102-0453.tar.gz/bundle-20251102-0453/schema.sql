--
-- PostgreSQL database dump
--

\restrict PAuGCBRjJvReBLiTFvXZLKrm0PGOcd6gDZ7D64r16zZrnjmrUaKtoXFeb9ou11C

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: record_owner
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO record_owner;

--
-- Name: records; Type: SCHEMA; Schema: -; Owner: record_owner
--

CREATE SCHEMA records;


ALTER SCHEMA records OWNER TO record_owner;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_prewarm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_prewarm WITH SCHEMA public;


--
-- Name: EXTENSION pg_prewarm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_prewarm IS 'prewarm relation data';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: choice(anyarray); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.choice(anyarray) RETURNS anyelement
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $_$
  SELECT $1[1 + floor(random()*array_length($1,1))::int]
$_$;


ALTER FUNCTION public.choice(anyarray) OWNER TO postgres;

--
-- Name: norm_text(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norm_text(t text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  SELECT regexp_replace(lower(unaccent(coalesce(t,''))), '\s+', ' ', 'g')
$$;


ALTER FUNCTION public.norm_text(t text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: records; Type: TABLE; Schema: records; Owner: record_owner
--

CREATE TABLE records.records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    artist text NOT NULL,
    name text NOT NULL,
    format text NOT NULL,
    catalog_number text,
    record_grade text,
    sleeve_grade text,
    has_insert boolean DEFAULT false,
    has_booklet boolean DEFAULT false,
    has_obi_strip boolean DEFAULT false,
    has_factory_sleeve boolean DEFAULT false,
    is_promo boolean DEFAULT false,
    notes text,
    purchased_at date,
    price_paid numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    insert_grade text,
    booklet_grade text,
    obi_strip_grade text,
    factory_sleeve_grade text,
    release_year integer,
    release_date date,
    pressing_year integer,
    label text,
    label_code text,
    artist_norm text,
    name_norm text,
    label_norm text,
    catalog_norm text,
    search_norm text
)
WITH (autovacuum_vacuum_cost_limit='2000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_threshold='1000', autovacuum_analyze_threshold='500');


ALTER TABLE records.records OWNER TO record_owner;

--
-- Name: records_recent(uuid, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.records_recent(p_user uuid, p_limit integer DEFAULT 50) RETURNS SETOF records.records
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT * FROM records.records
  WHERE user_id = p_user
  ORDER BY updated_at DESC
  LIMIT GREATEST(1, LEAST(200, COALESCE(p_limit,50)));
$$;


ALTER FUNCTION public.records_recent(p_user uuid, p_limit integer) OWNER TO postgres;

--
-- Name: search_autocomplete(uuid, text, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer DEFAULT 10, p_field text DEFAULT 'artist'::text) RETURNS TABLE(term text, hits integer, dist real)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE qn text := norm_text(coalesce(p_q,''));
BEGIN
  IF p_field = 'label' THEN
    RETURN QUERY
    SELECT r.label AS term, COUNT(*)::int AS hits, MIN(similarity(r.label_norm, qn)) AS dist
    FROM records.records r
    WHERE r.user_id = p_user
      AND ((length(qn)<=2 AND r.label_norm LIKE qn||'%')
        OR (length(qn)> 2 AND r.label_norm % qn))
    GROUP BY r.label
    ORDER BY dist DESC, hits DESC
    LIMIT LEAST(50, GREATEST(1, COALESCE(p_k,10)));

  ELSIF p_field = 'catalog' THEN
    RETURN QUERY
    SELECT r.catalog_number AS term, COUNT(*)::int AS hits, MIN(similarity(r.catalog_norm, qn)) AS dist
    FROM records.records r
    WHERE r.user_id = p_user
      AND ((length(qn)<=2 AND r.catalog_norm LIKE qn||'%')
        OR (length(qn)> 2 AND r.catalog_norm % qn))
    GROUP BY r.catalog_number
    ORDER BY dist DESC, hits DESC
    LIMIT LEAST(50, GREATEST(1, COALESCE(p_k,10)));

  ELSE
    -- artist autocomplete via MV (tiny, indexable)
    RETURN QUERY
    WITH params AS (SELECT qn AS q)
    SELECT t.term_raw AS term,
           SUM(t.hits)::int AS hits,
           MIN(similarity(t.term_norm, (SELECT q FROM params))) AS dist
    FROM records.autocomplete_terms_mv t
    WHERE t.user_id = p_user
      AND (
        (length((SELECT q FROM params)) <= 2 AND t.term_norm LIKE (SELECT q FROM params) || '%')
        OR
        (length((SELECT q FROM params))  > 2 AND t.term_norm %    (SELECT q FROM params))
      )
    GROUP BY t.term_raw
    ORDER BY dist DESC, hits DESC
    LIMIT LEAST(50, GREATEST(1, COALESCE(p_k,10)));
  END IF;
END$$;


ALTER FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text) OWNER TO postgres;

--
-- Name: search_facets(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_facets(p_user uuid, p_q text) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE qn text := norm_text(p_q);
BEGIN
  RETURN jsonb_build_object(
    'format', (
      SELECT jsonb_agg(jsonb_build_object('term',format,'hits',cnt) ORDER BY cnt DESC)
      FROM (SELECT format, COUNT(*) AS cnt
            FROM records.records r
            WHERE r.user_id=p_user
              AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
                   OR (length(qn)>2  AND r.search_norm % qn))
            GROUP BY 1 ORDER BY 2 DESC LIMIT 20) t),
    'label', (
      SELECT jsonb_agg(jsonb_build_object('term',label,'hits',cnt) ORDER BY cnt DESC)
      FROM (SELECT label, COUNT(*) AS cnt
            FROM records.records r
            WHERE r.user_id=p_user AND label IS NOT NULL AND label<>''
              AND ((length(qn)<=2 AND r.label_norm LIKE qn||'%')
                   OR (length(qn)>2  AND r.label_norm % qn))
            GROUP BY 1 ORDER BY 2 DESC LIMIT 20) t),
    'year', (
      SELECT jsonb_agg(jsonb_build_object('term',release_year,'hits',cnt) ORDER BY cnt DESC)
      FROM (SELECT release_year, COUNT(*) AS cnt
            FROM records.records r
            WHERE r.user_id=p_user AND release_year IS NOT NULL
              AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
                   OR (length(qn)>2  AND r.search_norm % qn))
            GROUP BY 1 ORDER BY 2 DESC LIMIT 20) t)
  );
END; $$;


ALTER FUNCTION public.search_facets(p_user uuid, p_q text) OWNER TO postgres;

--
-- Name: search_price_stats(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_price_stats(p_user uuid, p_q text) RETURNS TABLE(n integer, min numeric, p50 numeric, avg numeric, p90 numeric, max numeric)
    LANGUAGE sql STABLE
    AS $$
  WITH ids AS (
    SELECT id FROM public.search_records_fuzzy_ids(p_user, p_q, 600, 0) -- bounded top-K
  )
  SELECT
    COUNT(*)::int,
    MIN((r.price_paid)::numeric),
    percentile_cont(0.5) WITHIN GROUP (ORDER BY ((r.price_paid)::numeric)::double precision),
    AVG((r.price_paid)::numeric),
    percentile_cont(0.9) WITHIN GROUP (ORDER BY ((r.price_paid)::numeric)::double precision),
    MAX((r.price_paid)::numeric)
  FROM records.records r
  JOIN ids USING (id)
  WHERE r.price_paid IS NOT NULL;
$$;


ALTER FUNCTION public.search_price_stats(p_user uuid, p_q text) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids(uuid, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids(p_user uuid, p_q text, p_limit bigint DEFAULT 100, p_offset bigint DEFAULT 0) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  WITH
  _set AS (
    SELECT set_config('pg_trgm.similarity_threshold','0.35', true)
  ),
  qn AS (
    SELECT norm_text(coalesce(p_q,'')) AS q,
           length(norm_text(coalesce(p_q,''))) AS L
    FROM _set
  ),
  base_knn AS (
    SELECT r.id, r.search_norm,
           (r.search_norm <-> (SELECT q FROM qn)) AS dist
    FROM records.records r
    WHERE r.user_id = p_user
      AND (SELECT L FROM qn) > 2
    ORDER BY r.search_norm <-> (SELECT q FROM qn)
    LIMIT LEAST(3000, GREATEST(300, p_limit*30))
  ),
  base_long AS (
    SELECT id, 1 - dist AS rank
    FROM base_knn
    WHERE (search_norm % (SELECT q FROM qn))
       OR dist <= 0.75
  ),
  base_short AS (
    SELECT r.id, 1.0 AS rank
    FROM records.records r
    WHERE r.user_id = p_user
      AND (SELECT L FROM qn) <= 2
      AND (
        r.artist_norm  LIKE (SELECT q FROM qn) || '%'
        OR r.name_norm LIKE (SELECT q FROM qn) || '%'
        OR r.label_norm LIKE (SELECT q FROM qn) || '%'
        OR r.catalog_norm LIKE (SELECT q FROM qn) || '%'
      )
    LIMIT LEAST(5000, GREATEST(200, p_limit*50))
  ),
  alias_long AS (
    SELECT a.record_id AS id, 1 - (a.alias_norm <-> (SELECT q FROM qn)) AS rank
    FROM records.aliases_mv a
    WHERE a.user_id = p_user
      AND (SELECT L FROM qn) > 2
      AND a.alias_norm % (SELECT q FROM qn)
    ORDER BY a.alias_norm <-> (SELECT q FROM qn)
    LIMIT LEAST(2000, GREATEST(200, p_limit*20))
  ),
  alias_short AS (
    SELECT a.record_id AS id, 1.0 AS rank
    FROM records.aliases_mv a
    WHERE a.user_id = p_user
      AND (SELECT L FROM qn) <= 2
      AND a.alias_norm LIKE (SELECT q FROM qn) || '%'
    LIMIT LEAST(5000, GREATEST(200, p_limit*50))
  ),
  allhits AS (
    SELECT * FROM base_long
    UNION ALL SELECT * FROM base_short
    UNION ALL SELECT * FROM alias_long
    UNION ALL SELECT * FROM alias_short
  )
  SELECT id, max(rank) AS rank
  FROM allhits
  GROUP BY id
  ORDER BY rank DESC
  LIMIT LEAST(1000, GREATEST(1, p_limit))
  OFFSET GREATEST(0, p_offset);
$$;


ALTER FUNCTION public.search_records_fuzzy_ids(p_user uuid, p_q text, p_limit bigint, p_offset bigint) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_core(uuid, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_core(p_user uuid, p_q text, p_limit bigint DEFAULT 100, p_offset bigint DEFAULT 0) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  WITH qn AS (
    SELECT norm_text(coalesce(p_q,'')) AS q, length(norm_text(coalesce(p_q,''))) AS L
  ),
  base_long AS (
    SELECT r.id, 1 - (r.search_norm <-> (SELECT q FROM qn)) AS rank
    FROM records.records r
    WHERE r.user_id = p_user
      AND (SELECT L FROM qn) > 2
      AND r.search_norm % (SELECT q FROM qn)
    ORDER BY r.search_norm <-> (SELECT q FROM qn)
    LIMIT LEAST(500, GREATEST(100, p_limit*5))
  ),
  base_short AS (
    SELECT r.id, 1.0 AS rank
    FROM records.records r
    WHERE r.user_id = p_user
      AND (SELECT L FROM qn) <= 2
      AND (
        r.artist_norm  LIKE (SELECT q FROM qn) || '%'
        OR r.name_norm LIKE (SELECT q FROM qn) || '%'
        OR r.label_norm LIKE (SELECT q FROM qn) || '%'
        OR r.catalog_norm LIKE (SELECT q FROM qn) || '%'
      )
    LIMIT LEAST(3000, GREATEST(200, p_limit*30))
  ),
  alias_long AS (
    SELECT a.record_id AS id, 1 - (a.alias_norm <-> (SELECT q FROM qn)) AS rank
    FROM records.aliases_mv a
    WHERE a.user_id = p_user
      AND (SELECT L FROM qn) > 2
      AND a.alias_norm % (SELECT q FROM qn)
    ORDER BY a.alias_norm <-> (SELECT q FROM qn)
    LIMIT LEAST(500, GREATEST(100, p_limit*5))
  ),
  alias_short AS (
    SELECT a.record_id AS id, 1.0 AS rank
    FROM records.aliases_mv a
    WHERE a.user_id = p_user
      AND (SELECT L FROM qn) <= 2
      AND a.alias_norm LIKE (SELECT q FROM qn) || '%'
    LIMIT LEAST(3000, GREATEST(200, p_limit*30))
  ),
  allhits AS (
    SELECT * FROM base_long
    UNION ALL SELECT * FROM base_short
    UNION ALL SELECT * FROM alias_long
    UNION ALL SELECT * FROM alias_short
  )
  SELECT id, max(rank) AS rank
  FROM allhits
  GROUP BY id
  ORDER BY rank DESC
  LIMIT LEAST(1000, GREATEST(1, p_limit))
  OFFSET GREATEST(0, p_offset);
$$;


ALTER FUNCTION public.search_records_fuzzy_ids_core(p_user uuid, p_q text, p_limit bigint, p_offset bigint) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_knn_bias(uuid, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_knn_bias(p_user uuid, p_q text, p_limit bigint DEFAULT 100, p_offset bigint DEFAULT 0) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  PERFORM set_config('enable_bitmapscan','off', true);
  PERFORM set_config('enable_seqscan','off', true);
  RETURN QUERY
    SELECT * FROM public.search_records_fuzzy_ids(p_user, p_q, p_limit, p_offset);
END;
$$;


ALTER FUNCTION public.search_records_fuzzy_ids_knn_bias(p_user uuid, p_q text, p_limit bigint, p_offset bigint) OWNER TO postgres;

--
-- Name: search_structured(uuid, text, text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_structured(p_user uuid, p_artist text, p_name text, p_format text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0) RETURNS SETOF records.records
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT *
  FROM records.records r
  WHERE r.user_id = p_user
    AND (p_artist IS NULL OR r.artist ILIKE '%'||p_artist||'%')
    AND (p_name   IS NULL OR r.name   ILIKE '%'||p_name||'%')
    AND (p_format IS NULL OR r.format ILIKE '%'||p_format||'%')
  ORDER BY r.updated_at DESC
  LIMIT GREATEST(1, LEAST(200, COALESCE(p_limit,100)))
  OFFSET GREATEST(0, COALESCE(p_offset,0));
$$;


ALTER FUNCTION public.search_structured(p_user uuid, p_artist text, p_name text, p_format text, p_limit integer, p_offset integer) OWNER TO postgres;

--
-- Name: cache_invalidate_notify(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.cache_invalidate_notify() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE payload jsonb;
BEGIN
  payload := jsonb_build_object(
    'user_id', COALESCE(NEW.user_id, OLD.user_id),
    'table', TG_TABLE_NAME,
    'op', TG_OP
  );
  PERFORM pg_notify('records_cache_invalidate', payload::text);
  RETURN COALESCE(NEW, OLD);
END$$;


ALTER FUNCTION records.cache_invalidate_notify() OWNER TO postgres;

--
-- Name: make_search_norm(text, text, text, text); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.make_search_norm(a text, n text, l text, c text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT public.norm_text(coalesce(a,'')||' '||coalesce(n,'')||' '||coalesce(l,'')||' '||coalesce(c,''));
$$;


ALTER FUNCTION records.make_search_norm(a text, n text, l text, c text) OWNER TO postgres;

--
-- Name: refresh_aliases_mv_concurrent(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.refresh_aliases_mv_concurrent() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    EXECUTE 'REFRESH MATERIALIZED VIEW CONCURRENTLY records.aliases_mv';
  EXCEPTION WHEN OBJECT_NOT_IN_PREREQUISITE_STATE THEN
    EXECUTE 'REFRESH MATERIALIZED VIEW records.aliases_mv';
  END;
END$$;


ALTER FUNCTION records.refresh_aliases_mv_concurrent() OWNER TO postgres;

--
-- Name: seed_aliases_for_user(uuid); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.seed_aliases_for_user(p_user uuid) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE added bigint := 0;
BEGIN
  WITH tgt AS (
    SELECT id, artist_norm
    FROM records.records
    WHERE user_id = p_user
  )
  SELECT sum(records.upsert_aliases(id,
           CASE
             WHEN artist_norm LIKE '%teresa%'  OR artist_norm LIKE '%鄧麗君%' OR artist_norm LIKE '%邓丽君%' THEN ARRAY['Teresa Teng','鄧麗君','邓丽君','テレサ・テン']
             WHEN artist_norm LIKE '%anita%'   OR artist_norm LIKE '%梅艷芳%' OR artist_norm LIKE '%梅艳芳%' THEN ARRAY['Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ']
             WHEN artist_norm LIKE '%faye%'    OR artist_norm LIKE '%王菲%'                                  THEN ARRAY['Faye Wong','王菲','ワン・フェイ']
             WHEN artist_norm LIKE '%leslie%'  OR artist_norm LIKE '%張國榮%' OR artist_norm LIKE '%张国荣%' THEN ARRAY['Leslie Cheung','張國榮','张国荣','レスリー・チャン']
             ELSE ARRAY[]::text[]
           END))
    INTO added
  FROM tgt;

  PERFORM records.refresh_aliases_mv_concurrent();
  RETURN coalesce(added,0);
END$$;


ALTER FUNCTION records.seed_aliases_for_user(p_user uuid) OWNER TO postgres;

--
-- Name: seed_demo(uuid, integer); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.seed_demo(p_user uuid, p_n integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  i int;
  artists text[] := ARRAY[
    'Teresa Teng','鄧麗君','邓丽君','テレサ・テン',
    'Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ',
    'Faye Wong','王菲','ワン・フェイ',
    'Leslie Cheung','張國榮','张国荣','レスリー・チャン'
  ];
  fmts   text[] := ARRAY['LP','EP','12in','7in','CD'];
  labels text[] := ARRAY['Polydor','PolyGram','Trio','CBS','Warner','EMI'];
  grades text[] := ARRAY['NM','EX','VG+','VG'];
  y int; m int; d int;
BEGIN
  FOR i IN 1..p_n LOOP
    y := 1970 + floor(random()*45)::int;
    m := 1 + floor(random()*12)::int;
    d := 1 + floor(random()*28)::int;
    INSERT INTO records.records(
      user_id, artist, name, format, catalog_number, notes, purchased_at, price_paid,
      record_grade, sleeve_grade, release_year, release_date, pressing_year,
      label, label_code
    ) VALUES (
      p_user,
      artists[1 + floor(random()*array_length(artists,1))::int],
      'Album '||i,
      fmts[1 + floor(random()*array_length(fmts,1))::int],
      (ARRAY['HK','TW','JP','CN','US'])[1+floor(random()*5)::int] || '-' || to_char(1+floor(random()*999)::int,'FM000'),
      (ARRAY['','great','first press','promo'])[1+floor(random()*4)::int],
      (date '2018-01-01' + (random()* (date '2024-12-31' - date '2018-01-01'))::int),
      round((5 + random()*35)::numeric, 2),    -- cast fixed
      grades[1 + floor(random()*array_length(grades,1))::int],
      grades[1 + floor(random()*array_length(grades,1))::int],
      y, make_date(y,m,d), y,
      labels[1 + floor(random()*array_length(labels,1))::int],
      upper(left(labels[1 + floor(random()*array_length(labels,1))::int],2)) || '-' || to_char(1+floor(random()*999)::int,'FM000')
    );
  END LOOP;
END$$;


ALTER FUNCTION records.seed_demo(p_user uuid, p_n integer) OWNER TO postgres;

--
-- Name: set_norm_cols(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.set_norm_cols() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.artist_norm  := norm_text(NEW.artist);
  NEW.name_norm    := norm_text(NEW.name);
  NEW.label_norm   := norm_text(NEW.label);
  NEW.catalog_norm := norm_text(NEW.catalog_number);
  NEW.search_norm  := trim(both ' ' FROM concat_ws(' ',
     NEW.artist_norm, NEW.name_norm, coalesce(NEW.catalog_norm,''), coalesce(NEW.label_norm,'')));
  RETURN NEW;
END$$;


ALTER FUNCTION records.set_norm_cols() OWNER TO postgres;

--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (OLD IS DISTINCT FROM NEW) THEN NEW.updated_at := now(); END IF;
  RETURN NEW;
END$$;


ALTER FUNCTION records.touch_updated_at() OWNER TO postgres;

--
-- Name: upsert_alias(uuid, text); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.upsert_alias(p_record uuid, p_alias text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO records.aliases(record_id, alias)
  VALUES (p_record, p_alias)
  ON CONFLICT (record_id, alias) DO NOTHING;
END$$;


ALTER FUNCTION records.upsert_alias(p_record uuid, p_alias text) OWNER TO postgres;

--
-- Name: upsert_aliases(uuid, text[]); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.upsert_aliases(p_record uuid, p_terms text[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE t text; added bigint := 0;
BEGIN
  IF p_terms IS NULL THEN RETURN 0; END IF;
  FOREACH t IN ARRAY p_terms LOOP
    INSERT INTO records.aliases(record_id, alias)
    VALUES (p_record, t)
    ON CONFLICT (record_id, alias) DO NOTHING;
    IF FOUND THEN added := added + 1; END IF;
  END LOOP;
  RETURN added;
END$$;


ALTER FUNCTION records.upsert_aliases(p_record uuid, p_terms text[]) OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email public.citext NOT NULL,
    password_hash text,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE auth.users OWNER TO postgres;

--
-- Name: aliases; Type: TABLE; Schema: records; Owner: record_owner
--

CREATE TABLE records.aliases (
    record_id uuid NOT NULL,
    alias text NOT NULL
)
WITH (autovacuum_vacuum_scale_factor='0.10', autovacuum_vacuum_threshold='2000', autovacuum_analyze_scale_factor='0.05', autovacuum_analyze_threshold='1000');


ALTER TABLE records.aliases OWNER TO record_owner;

--
-- Name: aliases_mv; Type: MATERIALIZED VIEW; Schema: records; Owner: postgres
--

CREATE MATERIALIZED VIEW records.aliases_mv
WITH (autovacuum_vacuum_scale_factor='0.20', autovacuum_vacuum_threshold='20000', autovacuum_analyze_scale_factor='0.02', autovacuum_analyze_threshold='200') AS
 SELECT r.user_id,
    a.record_id,
    public.norm_text(a.alias) AS alias_norm
   FROM (records.aliases a
     JOIN records.records r ON ((r.id = a.record_id)))
  WITH NO DATA;


ALTER MATERIALIZED VIEW records.aliases_mv OWNER TO postgres;

--
-- Name: record_aliases; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.record_aliases AS
 SELECT user_id,
    record_id,
    alias_norm
   FROM records.aliases_mv;


ALTER VIEW public.record_aliases OWNER TO postgres;

--
-- Name: artist_seed; Type: TABLE; Schema: records; Owner: postgres
--

CREATE TABLE records.artist_seed (
    canon text NOT NULL,
    aliases text[] NOT NULL,
    aid bigint NOT NULL
);


ALTER TABLE records.artist_seed OWNER TO postgres;

--
-- Name: artist_seed_aid_seq; Type: SEQUENCE; Schema: records; Owner: postgres
--

CREATE SEQUENCE records.artist_seed_aid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE records.artist_seed_aid_seq OWNER TO postgres;

--
-- Name: artist_seed_aid_seq; Type: SEQUENCE OWNED BY; Schema: records; Owner: postgres
--

ALTER SEQUENCE records.artist_seed_aid_seq OWNED BY records.artist_seed.aid;


--
-- Name: autocomplete_terms_mv; Type: MATERIALIZED VIEW; Schema: records; Owner: postgres
--

CREATE MATERIALIZED VIEW records.autocomplete_terms_mv AS
 WITH terms AS (
         SELECT r.user_id,
            r.artist AS term_raw,
            r.artist_norm AS term_norm,
            (count(*))::integer AS hits
           FROM records.records r
          GROUP BY r.user_id, r.artist, r.artist_norm
        UNION ALL
         SELECT r.user_id,
            r.artist AS term_raw,
            a.alias_norm AS term_norm,
            (count(*))::integer AS hits
           FROM (records.aliases_mv a
             JOIN records.records r ON ((r.id = a.record_id)))
          GROUP BY r.user_id, r.artist, a.alias_norm
        )
 SELECT user_id,
    term_raw,
    term_norm,
    (sum(hits))::integer AS hits
   FROM terms
  GROUP BY user_id, term_raw, term_norm
  WITH NO DATA;


ALTER MATERIALIZED VIEW records.autocomplete_terms_mv OWNER TO postgres;

--
-- Name: records_staging_v2; Type: TABLE; Schema: records; Owner: postgres
--

CREATE UNLOGGED TABLE records.records_staging_v2 (
    user_id uuid NOT NULL,
    artist text NOT NULL,
    name text NOT NULL,
    format text NOT NULL,
    catalog_number text NOT NULL,
    notes text,
    purchased_at date,
    price_paid numeric(8,2),
    record_grade text,
    sleeve_grade text,
    release_year integer,
    release_date date,
    pressing_year integer,
    label text,
    label_code text,
    artist_norm text,
    name_norm text,
    label_norm text,
    catalog_norm text,
    search_norm text
);


ALTER TABLE records.records_staging_v2 OWNER TO postgres;

--
-- Name: artist_seed aid; Type: DEFAULT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.artist_seed ALTER COLUMN aid SET DEFAULT nextval('records.artist_seed_aid_seq'::regclass);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: aliases aliases_pkey; Type: CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.aliases
    ADD CONSTRAINT aliases_pkey PRIMARY KEY (record_id, alias);


--
-- Name: artist_seed artist_seed_pkey; Type: CONSTRAINT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.artist_seed
    ADD CONSTRAINT artist_seed_pkey PRIMARY KEY (canon);


--
-- Name: records records_pkey; Type: CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_pkey PRIMARY KEY (id);


--
-- Name: ac_terms_mv_uid_term_uq; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX ac_terms_mv_uid_term_uq ON records.autocomplete_terms_mv USING btree (user_id, term_raw, term_norm);


--
-- Name: ac_terms_user_hits; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX ac_terms_user_hits ON records.autocomplete_terms_mv USING btree (user_id, hits DESC);


--
-- Name: ac_terms_user_term_gist; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX ac_terms_user_term_gist ON records.autocomplete_terms_mv USING gist (user_id, term_norm public.gist_trgm_ops);


--
-- Name: aliases_mv_uniq_btree; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX aliases_mv_uniq_btree ON records.aliases_mv USING btree (user_id, record_id, alias_norm);


--
-- Name: aliases_mv_user_alias_gist; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX aliases_mv_user_alias_gist ON records.aliases_mv USING gist (user_id, alias_norm public.gist_trgm_ops);


--
-- Name: aliases_mv_user_alias_norm_gist; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX aliases_mv_user_alias_norm_gist ON records.aliases_mv USING gist (user_id, alias_norm public.gist_trgm_ops);


--
-- Name: artist_seed_aid_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX artist_seed_aid_idx ON records.artist_seed USING btree (aid);


--
-- Name: idx_records_artist_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_artist_gist_trgm ON records.records USING gist (artist_norm public.gist_trgm_ops);


--
-- Name: idx_records_artist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_artist_trgm ON records.records USING gin (artist public.gin_trgm_ops);


--
-- Name: idx_records_catalog; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_catalog ON records.records USING btree (catalog_number);


--
-- Name: idx_records_catalog_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_catalog_gist_trgm ON records.records USING gist (catalog_norm public.gist_trgm_ops);


--
-- Name: idx_records_id_inc_user; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_id_inc_user ON records.records USING btree (id) INCLUDE (user_id);


--
-- Name: idx_records_knn_user_search_gist; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_knn_user_search_gist ON records.records USING gist (search_norm public.gist_trgm_ops, user_id);


--
-- Name: idx_records_label_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_label_gist_trgm ON records.records USING gist (label_norm public.gist_trgm_ops);


--
-- Name: idx_records_name_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_name_gist_trgm ON records.records USING gist (name_norm public.gist_trgm_ops);


--
-- Name: idx_records_name_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_name_trgm ON records.records USING gin (name public.gin_trgm_ops);


--
-- Name: idx_records_search_gin_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_search_gin_trgm ON records.records USING gin (search_norm public.gin_trgm_ops);


--
-- Name: idx_records_user; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user ON records.records USING btree (user_id);


--
-- Name: idx_records_user_artist_norm_gist; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_artist_norm_gist ON records.records USING gist (user_id, artist_norm public.gist_trgm_ops);


--
-- Name: idx_records_user_catalog_norm_gist; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_catalog_norm_gist ON records.records USING gist (user_id, catalog_norm public.gist_trgm_ops);


--
-- Name: idx_records_user_label_norm_gist; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_label_norm_gist ON records.records USING gist (user_id, label_norm public.gist_trgm_ops);


--
-- Name: idx_records_user_search_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_search_gist_trgm ON records.records USING gist (user_id, search_norm public.gist_trgm_ops);


--
-- Name: idx_records_user_search_gist_trgm_price; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_search_gist_trgm_price ON records.records USING gist (user_id, search_norm public.gist_trgm_ops) INCLUDE (price_paid);


--
-- Name: idx_records_user_search_trgm_price; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_search_trgm_price ON records.records USING gist (user_id, search_norm public.gist_trgm_ops) WHERE (price_paid IS NOT NULL);


--
-- Name: idx_records_user_updated; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_updated ON records.records USING btree (user_id, updated_at DESC);


--
-- Name: records_staging_v2_artist_name_format_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_artist_name_format_idx ON records.records_staging_v2 USING btree (artist, name, format);


--
-- Name: records_staging_v2_catalog_number_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_catalog_number_idx ON records.records_staging_v2 USING btree (catalog_number);


--
-- Name: records_staging_v2_user_id_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_user_id_idx ON records.records_staging_v2 USING btree (user_id);


--
-- Name: st_user_alias; Type: STATISTICS; Schema: public; Owner: postgres
--

CREATE STATISTICS public.st_user_alias (ndistinct, dependencies) ON user_id, alias_norm FROM records.aliases_mv;


ALTER STATISTICS public.st_user_alias OWNER TO postgres;

--
-- Name: st_user_search; Type: STATISTICS; Schema: public; Owner: postgres
--

CREATE STATISTICS public.st_user_search (ndistinct, dependencies) ON user_id, search_norm FROM records.records;


ALTER STATISTICS public.st_user_search OWNER TO postgres;

--
-- Name: aliases trg_cache_inv_aliases; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_cache_inv_aliases AFTER INSERT OR DELETE OR UPDATE ON records.aliases FOR EACH ROW EXECUTE FUNCTION records.cache_invalidate_notify();


--
-- Name: records trg_cache_inv_records; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_cache_inv_records AFTER INSERT OR DELETE OR UPDATE ON records.records FOR EACH ROW EXECUTE FUNCTION records.cache_invalidate_notify();


--
-- Name: records trg_records_norm; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_records_norm BEFORE INSERT OR UPDATE OF artist, name, label, catalog_number ON records.records FOR EACH ROW EXECUTE FUNCTION records.set_norm_cols();


--
-- Name: records trg_records_touch; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_records_touch BEFORE UPDATE ON records.records FOR EACH ROW WHEN ((old.* IS DISTINCT FROM new.*)) EXECUTE FUNCTION records.touch_updated_at();


--
-- Name: aliases aliases_record_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.aliases
    ADD CONSTRAINT aliases_record_id_fkey FOREIGN KEY (record_id) REFERENCES records.records(id) ON DELETE CASCADE;


--
-- Name: records records_user_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: record_owner
--

GRANT USAGE ON SCHEMA auth TO record_app;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO record_app;


--
-- Name: SCHEMA records; Type: ACL; Schema: -; Owner: record_owner
--

GRANT USAGE ON SCHEMA records TO record_app;


--
-- Name: FUNCTION citextin(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextin(cstring) TO record_app;


--
-- Name: FUNCTION citextout(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextout(public.citext) TO record_app;


--
-- Name: FUNCTION citextrecv(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextrecv(internal) TO record_app;


--
-- Name: FUNCTION citextsend(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextsend(public.citext) TO record_app;


--
-- Name: FUNCTION gbtreekey16_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey16_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey16_out(public.gbtreekey16); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey16_out(public.gbtreekey16) TO record_app;


--
-- Name: FUNCTION gbtreekey2_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey2_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey2_out(public.gbtreekey2); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey2_out(public.gbtreekey2) TO record_app;


--
-- Name: FUNCTION gbtreekey32_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey32_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey32_out(public.gbtreekey32); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey32_out(public.gbtreekey32) TO record_app;


--
-- Name: FUNCTION gbtreekey4_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey4_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey4_out(public.gbtreekey4); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey4_out(public.gbtreekey4) TO record_app;


--
-- Name: FUNCTION gbtreekey8_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey8_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey8_out(public.gbtreekey8); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey8_out(public.gbtreekey8) TO record_app;


--
-- Name: FUNCTION gbtreekey_var_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey_var_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey_var_out(public.gbtreekey_var); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey_var_out(public.gbtreekey_var) TO record_app;


--
-- Name: FUNCTION gtrgm_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_in(cstring) TO record_app;


--
-- Name: FUNCTION gtrgm_out(public.gtrgm); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_out(public.gtrgm) TO record_app;


--
-- Name: FUNCTION citext(boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(boolean) TO record_app;


--
-- Name: FUNCTION citext(character); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(character) TO record_app;


--
-- Name: FUNCTION citext(inet); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(inet) TO record_app;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO record_app;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO record_app;


--
-- Name: FUNCTION autoprewarm_dump_now(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.autoprewarm_dump_now() TO record_app;


--
-- Name: FUNCTION autoprewarm_start_worker(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.autoprewarm_start_worker() TO record_app;


--
-- Name: FUNCTION cash_dist(money, money); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cash_dist(money, money) TO record_app;


--
-- Name: FUNCTION choice(anyarray); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.choice(anyarray) TO record_app;


--
-- Name: FUNCTION citext_cmp(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_cmp(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_eq(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_eq(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_ge(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_ge(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_gt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_gt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_hash(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_hash(public.citext) TO record_app;


--
-- Name: FUNCTION citext_hash_extended(public.citext, bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_hash_extended(public.citext, bigint) TO record_app;


--
-- Name: FUNCTION citext_larger(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_larger(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_le(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_le(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_lt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_lt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_ne(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_ne(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_cmp(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_cmp(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_ge(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_ge(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_gt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_gt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_le(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_le(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_lt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_lt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_smaller(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_smaller(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO record_app;


--
-- Name: FUNCTION date_dist(date, date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.date_dist(date, date) TO record_app;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO record_app;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO record_app;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO record_app;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION float4_dist(real, real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.float4_dist(real, real) TO record_app;


--
-- Name: FUNCTION float8_dist(double precision, double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.float8_dist(double precision, double precision) TO record_app;


--
-- Name: FUNCTION gbt_bit_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_consistent(internal, bit, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_consistent(internal, bit, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_consistent(internal, boolean, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_consistent(internal, boolean, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_same(public.gbtreekey2, public.gbtreekey2, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_same(public.gbtreekey2, public.gbtreekey2, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bpchar_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bpchar_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bpchar_consistent(internal, character, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bpchar_consistent(internal, character, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_consistent(internal, bytea, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_consistent(internal, bytea, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_consistent(internal, money, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_consistent(internal, money, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_distance(internal, money, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_distance(internal, money, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_date_consistent(internal, date, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_consistent(internal, date, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_distance(internal, date, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_distance(internal, date, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_date_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_consistent(internal, anyenum, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_consistent(internal, anyenum, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_consistent(internal, real, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_consistent(internal, real, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_distance(internal, real, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_distance(internal, real, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_consistent(internal, double precision, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_consistent(internal, double precision, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_distance(internal, double precision, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_distance(internal, double precision, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_consistent(internal, inet, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_consistent(internal, inet, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_consistent(internal, smallint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_consistent(internal, smallint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_distance(internal, smallint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_distance(internal, smallint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_same(public.gbtreekey4, public.gbtreekey4, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_same(public.gbtreekey4, public.gbtreekey4, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_consistent(internal, integer, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_consistent(internal, integer, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_distance(internal, integer, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_distance(internal, integer, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_consistent(internal, bigint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_consistent(internal, bigint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_distance(internal, bigint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_distance(internal, bigint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_consistent(internal, interval, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_consistent(internal, interval, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_distance(internal, interval, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_distance(internal, interval, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_same(public.gbtreekey32, public.gbtreekey32, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_same(public.gbtreekey32, public.gbtreekey32, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_consistent(internal, macaddr8, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_consistent(internal, macaddr8, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_consistent(internal, macaddr, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_consistent(internal, macaddr, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_consistent(internal, numeric, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_consistent(internal, numeric, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_consistent(internal, oid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_consistent(internal, oid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_distance(internal, oid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_distance(internal, oid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_text_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_consistent(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_time_consistent(internal, time without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_consistent(internal, time without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_distance(internal, time without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_distance(internal, time without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_time_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_timetz_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_timetz_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_timetz_consistent(internal, time with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_timetz_consistent(internal, time with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_consistent(internal, timestamp without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_consistent(internal, timestamp without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_distance(internal, timestamp without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_distance(internal, timestamp without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_consistent(internal, timestamp with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_consistent(internal, timestamp with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_distance(internal, timestamp with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_distance(internal, timestamp with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_consistent(internal, uuid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_consistent(internal, uuid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_same(public.gbtreekey32, public.gbtreekey32, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_same(public.gbtreekey32, public.gbtreekey32, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_var_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_var_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_var_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_var_fetch(internal) TO record_app;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO record_app;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO record_app;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO record_app;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO record_app;


--
-- Name: FUNCTION gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gin_extract_value_trgm(text, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_value_trgm(text, internal) TO record_app;


--
-- Name: FUNCTION gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_compress(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_consistent(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_decompress(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_distance(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_distance(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_options(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_options(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_same(public.gtrgm, public.gtrgm, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_same(public.gtrgm, public.gtrgm, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_union(internal, internal) TO record_app;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO record_app;


--
-- Name: FUNCTION int2_dist(smallint, smallint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int2_dist(smallint, smallint) TO record_app;


--
-- Name: FUNCTION int4_dist(integer, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int4_dist(integer, integer) TO record_app;


--
-- Name: FUNCTION int8_dist(bigint, bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int8_dist(bigint, bigint) TO record_app;


--
-- Name: FUNCTION interval_dist(interval, interval); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.interval_dist(interval, interval) TO record_app;


--
-- Name: FUNCTION norm_text(t text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.norm_text(t text) TO record_app;


--
-- Name: FUNCTION oid_dist(oid, oid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.oid_dist(oid, oid) TO record_app;


--
-- Name: FUNCTION pg_prewarm(regclass, mode text, fork text, first_block bigint, last_block bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_prewarm(regclass, mode text, fork text, first_block bigint, last_block bigint) TO record_app;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO record_app;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO record_app;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO record_app;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO record_app;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO record_app;


--
-- Name: TABLE records; Type: ACL; Schema: records; Owner: record_owner
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.records TO record_app;


--
-- Name: FUNCTION records_recent(p_user uuid, p_limit integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.records_recent(p_user uuid, p_limit integer) TO record_app;


--
-- Name: FUNCTION regexp_match(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_match(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_match(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_match(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_matches(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_matches(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_matches(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_matches(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_replace(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_replace(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_replace(public.citext, public.citext, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_replace(public.citext, public.citext, text, text) TO record_app;


--
-- Name: FUNCTION regexp_split_to_array(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_array(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_split_to_array(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_array(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_split_to_table(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_table(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_split_to_table(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_table(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION replace(public.citext, public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.replace(public.citext, public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text) TO record_app;


--
-- Name: FUNCTION search_facets(p_user uuid, p_q text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_facets(p_user uuid, p_q text) TO record_app;


--
-- Name: FUNCTION set_limit(real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_limit(real) TO record_app;


--
-- Name: FUNCTION show_limit(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_limit() TO record_app;


--
-- Name: FUNCTION show_trgm(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_trgm(text) TO record_app;


--
-- Name: FUNCTION similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity(text, text) TO record_app;


--
-- Name: FUNCTION similarity_dist(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_dist(text, text) TO record_app;


--
-- Name: FUNCTION similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION split_part(public.citext, public.citext, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.split_part(public.citext, public.citext, integer) TO record_app;


--
-- Name: FUNCTION strict_word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION strpos(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strpos(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticlike(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticlike(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticlike(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticlike(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticnlike(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticnlike(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticnlike(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticnlike(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticregexeq(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexeq(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticregexeq(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexeq(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticregexne(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexne(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticregexne(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexne(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION time_dist(time without time zone, time without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.time_dist(time without time zone, time without time zone) TO record_app;


--
-- Name: FUNCTION translate(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.translate(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION ts_dist(timestamp without time zone, timestamp without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.ts_dist(timestamp without time zone, timestamp without time zone) TO record_app;


--
-- Name: FUNCTION tstz_dist(timestamp with time zone, timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.tstz_dist(timestamp with time zone, timestamp with time zone) TO record_app;


--
-- Name: FUNCTION unaccent(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent(text) TO record_app;


--
-- Name: FUNCTION unaccent(regdictionary, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent(regdictionary, text) TO record_app;


--
-- Name: FUNCTION unaccent_init(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent_init(internal) TO record_app;


--
-- Name: FUNCTION unaccent_lexize(internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent_lexize(internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION seed_demo(p_user uuid, p_n integer); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.seed_demo(p_user uuid, p_n integer) TO record_app;


--
-- Name: FUNCTION set_norm_cols(); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.set_norm_cols() TO record_app;


--
-- Name: FUNCTION touch_updated_at(); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.touch_updated_at() TO record_app;


--
-- Name: FUNCTION max(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.max(public.citext) TO record_app;


--
-- Name: FUNCTION min(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.min(public.citext) TO record_app;


--
-- Name: TABLE aliases; Type: ACL; Schema: records; Owner: record_owner
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.aliases TO record_app;


--
-- Name: TABLE aliases_mv; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.aliases_mv TO record_app;


--
-- Name: TABLE artist_seed; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.artist_seed TO record_app;


--
-- Name: SEQUENCE artist_seed_aid_seq; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE records.artist_seed_aid_seq TO record_app;


--
-- Name: TABLE autocomplete_terms_mv; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.autocomplete_terms_mv TO record_app;


--
-- Name: TABLE records_staging_v2; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.records_staging_v2 TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA public GRANT USAGE ON SEQUENCES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: records; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA records GRANT SELECT,USAGE ON SEQUENCES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: records; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA records GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO record_app;


--
-- PostgreSQL database dump complete
--

\unrestrict PAuGCBRjJvReBLiTFvXZLKrm0PGOcd6gDZ7D64r16zZrnjmrUaKtoXFeb9ou11C

