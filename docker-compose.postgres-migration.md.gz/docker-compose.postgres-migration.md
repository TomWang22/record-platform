# Postgres Migration Guide

## Current State
- 8 postgres containers running in docker-compose (local dev)
- Services configured to use docker-compose postgres via service names
- 43.86GB disk space used by postgres volumes

## Migration Steps

### Option 1: Comment Out (Safest - Can Revert)
1. Comment out postgres services in docker-compose.yml
2. Update DATABASE_URL env vars to use external postgres
3. Remove depends_on references
4. Stop containers: `docker-compose stop postgres*`
5. Remove volumes: `docker volume rm record-platform_pgdata*`

### Option 2: Use External Postgres for Local Dev
Update .env with external postgres URLs:
```bash
# External postgres (replace with your actual connection strings)
DATABASE_URL=postgresql://user:pass@external-host:5432/records
POSTGRES_URL_ANALYTICS=postgresql://user:pass@external-host:5432/analytics
POSTGRES_URL_LISTINGS=postgresql://user:pass@external-host:5432/listings
# ... etc
```

Then update docker-compose.yml to use these env vars instead of service names.

### Option 3: Keep One Shared Postgres
Replace 8 separate postgres containers with 1 shared postgres that hosts all databases.

