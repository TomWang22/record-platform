# Auth Database Migration - Complete ✅

## Summary

The auth-service now has its own dedicated database on port 5437, consistent with other services (social, listings, shopping).

## What Was Done

### 1. Database Setup
- ✅ Created `postgres-auth` service in `docker-compose.yml` (port 5437)
- ✅ Created database schema (`infra/db/07-auth-schema.sql`)
- ✅ Created setup script (`scripts/setup-auth-db.sh`)
- ✅ Updated `app-config.yaml` to point `POSTGRES_URL_AUTH` to port 5437

### 2. User Migration
- ✅ Migrated 8 users from main database (port 5433) to auth database (port 5437)
- ✅ Created migration script (`scripts/migrate-auth-users.sh`)
- ✅ Verified all users migrated successfully with password hashes intact

### 3. Service Updates
- ✅ Restarted API Gateway (routes now working correctly)
- ✅ Restarted auth-service (now using new database)
- ✅ Verified authentication works with new database

### 4. Route Verification
- ✅ Ingress rewrite working: `/api/forum/posts` → `/forum/posts`
- ✅ Routes returning 401 (auth required) instead of 404 (route not found)
- ✅ Forum endpoint working with valid authentication

## Database Topology

| Service | Database Port | Schemas |
|---------|--------------|---------|
| Main DB | 5433 | records, analytics |
| **Auth DB** | **5437** | **auth** |
| Social DB | 5434 | forum, messages |
| Listings DB | 5435 | listings |
| Shopping DB | 5436 | shopping |

## Verification

### Test Authentication
```bash
# Register new user
curl -k --http2 -H "Host: record.local" \
  -H "Content-Type: application/json" \
  -X POST "https://record.local:8443/api/auth/register" \
  -d '{"email":"test@example.com","password":"test123"}'

# Login
curl -k --http2 -H "Host: record.local" \
  -H "Content-Type: application/json" \
  -X POST "https://record.local:8443/api/auth/login" \
  -d '{"email":"test@example.com","password":"test123"}'

# Use token to access protected routes
TOKEN="your-token-here"
curl -k --http2 -H "Host: record.local" \
  -H "Authorization: Bearer $TOKEN" \
  "https://record.local:8443/api/forum/posts"
```

### Check Database
```bash
# Check users in auth database
PGPASSWORD=postgres psql -h localhost -p 5437 -U postgres -d records \
  -c "SELECT COUNT(*) FROM auth.users;"

# Check users in main database (should still exist for now)
PGPASSWORD=postgres psql -h localhost -p 5433 -U postgres -d records \
  -c "SELECT COUNT(*) FROM auth.users;"
```

## Next Steps (Optional)

1. **Test all authentication flows** with migrated users
2. **Update any hardcoded database references** to use `POSTGRES_URL_AUTH`
3. **Once verified, optionally remove auth.users from main database**:
   ```sql
   -- Only after thorough testing!
   -- PGPASSWORD=postgres psql -h localhost -p 5433 -U postgres -d records \
   --   -c "DROP TABLE IF EXISTS auth.users CASCADE;"
   ```

## Troubleshooting

### If authentication fails:
1. Check auth-service logs: `kubectl -n record-platform logs -l app=auth-service`
2. Verify database connection: Check `POSTGRES_URL_AUTH` in ConfigMap
3. Verify users exist: Check auth database on port 5437

### If routes return 404:
1. Check API Gateway logs: `kubectl -n record-platform logs -l app=api-gateway`
2. Verify ingress rewrite: Check ingress annotations
3. Verify routes are defined in `services/api-gateway/src/server.ts`

## Files Modified

- `docker-compose.yml` - Added postgres-auth service
- `infra/db/07-auth-schema.sql` - New auth database schema
- `infra/k8s/base/config/app-config.yaml` - Updated POSTGRES_URL_AUTH
- `scripts/setup-auth-db.sh` - Database setup script
- `scripts/migrate-auth-users.sh` - User migration script

## Status

✅ **Migration Complete** - All users migrated, services updated, routes verified.

