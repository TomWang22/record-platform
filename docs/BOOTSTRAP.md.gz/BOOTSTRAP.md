# Record Platform Bootstrap Guide

Complete guide for one-command platform deployment and disaster recovery.

## Overview

The bootstrap script (`scripts/bootstrap-platform.sh`) provides a complete, automated way to deploy the entire Record Platform infrastructure. It orchestrates:

- **Terraform**: Infrastructure provisioning (namespaces, base configs)
- **Ansible**: Service deployment and configuration
- **Docker**: Image building and loading into Kind
- **Kubernetes**: Resource deployment via Kustomize
- **Health Checks**: Waits for all services to be ready

## Prerequisites

Before running the bootstrap script, ensure you have:

- **Terraform** (>= 1.0) - `brew install terraform`
- **Ansible** (>= 2.9) - `pip install ansible`
- **kubectl** - `brew install kubectl`
- **Kind** - `brew install kind`
- **Docker** - Docker Desktop or Docker Engine

## Quick Start

### Full Bootstrap

Deploy everything from scratch:

```bash
./scripts/bootstrap-platform.sh
```

This will:
1. Check all prerequisites
2. Create/verify Kind cluster
3. Initialize Terraform
4. Apply Terraform (creates namespace, base configs)
5. Install Ansible collections
6. Deploy services with Ansible
7. Build Docker images
8. Load images into Kind
9. Apply Kubernetes resources
10. Wait for deployments
11. Show status

### Dry Run (Preview)

See what would be deployed without making changes:

```bash
./scripts/bootstrap-platform.sh --dry-run
```

### Skip Docker Builds

If you've already built images or want to use existing ones:

```bash
./scripts/bootstrap-platform.sh --skip-build
```

### Custom Configuration

```bash
# Use specific Kind cluster
./scripts/bootstrap-platform.sh --cluster my-cluster

# Deploy to production environment
./scripts/bootstrap-platform.sh --env prod

# Combine options
./scripts/bootstrap-platform.sh --env staging --skip-build
```

## Disaster Recovery / Teardown

### Complete Teardown

Remove all infrastructure:

```bash
./scripts/bootstrap-platform.sh --destroy
```

This will:
- Destroy all Terraform resources
- Remove Kubernetes resources (via Terraform)
- **Note**: Does not delete Kind cluster (preserve for reuse)

### Selective Cleanup

If you need more granular control:

```bash
# Destroy Terraform resources only
cd infra/terraform
terraform destroy

# Delete Kubernetes namespace (removes all resources)
kubectl delete namespace record-platform

# Delete Kind cluster
kind delete cluster --name h3
```

## What Gets Deployed

### Infrastructure (Terraform)

- Kubernetes namespace (`record-platform`)
- Base ConfigMaps and Secrets
- Service port configurations

### Services (Ansible + Kustomize)

- **API Gateway** (port 4000)
- **Auth Service** (port 4001)
- **Records Service** (port 4002)
- **Listings Service** (port 4003)
- **Analytics Service** (port 4004)
- **Social Service** (port 4006)
- **Shopping Service** (port 4007)
- **Auction Monitor** (port 4008)
- **Python AI Service** (port 5005)

### Supporting Infrastructure

- **HAProxy** (load balancing, port 8081)
- **Nginx** (edge server, port 8080)
- **Redis** (caching, port 6379)
- **Kafka** (event streaming, port 9092)
- **Zookeeper** (Kafka coordination)
- **PostgreSQL** (databases - external via Docker Compose)
- **Monitoring** (Prometheus, Grafana, Jaeger)

## Verification

After bootstrap completes, verify everything is running:

```bash
# Check all pods
kubectl -n record-platform get pods

# Check services
kubectl -n record-platform get svc

# Check deployments
kubectl -n record-platform get deployments

# View logs
kubectl -n record-platform logs -f deployment/api-gateway

# Run integration tests
./scripts/test-microservices-http2-http3.sh
```

## Troubleshooting

### Bootstrap Fails at Prerequisites

**Error**: "Missing required tools"

**Solution**: Install missing tools:
```bash
brew install terraform ansible kubectl kind
pip install ansible
```

### Bootstrap Fails at Kind Cluster

**Error**: "Kind cluster not found"

**Solution**: The script will prompt to create one, or create manually:
```bash
kind create cluster --name h3
```

### Bootstrap Fails at Terraform

**Error**: "Terraform initialization failed"

**Solution**: Check kubeconfig:
```bash
kubectl config current-context
# Should show: kind-h3 (or your cluster)
```

### Bootstrap Fails at Docker Build

**Error**: "Failed to build image"

**Solution**: 
- Check Docker is running: `docker ps`
- Try building manually: `docker build -t api-gateway:dev -f services/api-gateway/Dockerfile .`
- Use `--skip-build` to skip image builds

### Services Not Starting

**Error**: "Deployments not ready"

**Solution**:
```bash
# Check pod status
kubectl -n record-platform get pods

# Check events
kubectl -n record-platform get events --sort-by='.lastTimestamp'

# Check logs
kubectl -n record-platform logs -f deployment/api-gateway

# Check resource limits
kubectl -n record-platform describe pod <pod-name>
```

### Database Connection Issues

**Note**: Databases run outside Kubernetes in Docker Compose.

**Solution**: Ensure Docker Compose is running:
```bash
docker-compose up -d
```

## Advanced Usage

### Custom Environment Variables

Set environment variables before running:

```bash
export KIND_CLUSTER=my-cluster
export NAMESPACE=my-namespace
export ENVIRONMENT=staging
./scripts/bootstrap-platform.sh
```

### Partial Deployment

If you only want to deploy specific components:

```bash
# Terraform only
cd infra/terraform
terraform init
terraform apply

# Ansible only
cd infra/ansible
ansible-playbook playbooks/deploy-services.yml

# Kubernetes only
kubectl apply -k infra/k8s/base
kubectl apply -k infra/k8s/overlays/dev
```

### State Management

**Terraform State**: Stored locally by default. For production, configure remote backend:

```hcl
# infra/terraform/main.tf
backend "s3" {
  bucket = "your-terraform-state-bucket"
  key    = "record-platform/terraform.tfstate"
  region = "us-east-1"
}
```

**Ansible State**: Stateless - uses Kubernetes API directly.

## Best Practices

1. **Always use `--dry-run` first** to preview changes
2. **Use version control** for Terraform and Ansible configs
3. **Backup state files** before major changes
4. **Test in dev environment** before production
5. **Monitor resource usage** after deployment
6. **Keep Kind cluster** for faster re-deployments

## Next Steps

After successful bootstrap:

1. **Run integration tests**: `./scripts/test-microservices-http2-http3.sh`
2. **Set up observability**: Access Grafana, Prometheus, Jaeger
3. **Configure secrets**: Update `infra/k8s/base/config/app-secrets.yaml`
4. **Set up CI/CD**: Integrate bootstrap script into pipeline
5. **Monitor services**: Set up alerts and dashboards

## Support

For issues:
1. Check troubleshooting section above
2. Review bootstrap script output
3. Check Kubernetes events: `kubectl get events -n record-platform`
4. Review logs: `kubectl logs -n record-platform <pod-name>`

