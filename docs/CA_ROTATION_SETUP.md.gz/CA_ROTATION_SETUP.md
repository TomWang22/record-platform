# CA Rotation Setup Guide

## Current Status

✅ **RollingUpdate strategy** configured  
✅ **Admin API enabled** (localhost:2019) for zero-downtime reload  
⚠️ **2 replicas configured** but requires multiple nodes

## For 100% Success Rate

### Option 1: Multiple Nodes (Recommended)

With `hostNetwork: true`, only 1 pod per node can bind to port 443. For 2 replicas, you need 2+ nodes.

**Setup multi-node Kind cluster:**
```bash
cat > kind-multi-node.yaml <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: h3
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 443
    hostPort: 8443
    protocol: TCP
  - containerPort: 443
    hostPort: 8443
    protocol: UDP
- role: worker
- role: worker
EOF

kind delete cluster --name h3
kind create cluster --config kind-multi-node.yaml --name h3
```

**Then apply production config:**
```bash
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml
```

**Result:**
- Pod 1 on node 1 (port 443)
- Pod 2 on node 2 (port 443)
- During rotation: Old pod stays up, new pod starts on different node
- **100% success rate** ✅

### Option 2: Admin API Reload (Current Single-Node Solution)

With 1 replica on single-node cluster, use admin API reload:

**How it works:**
1. Update TLS secret
2. Port-forward to admin API (localhost:2019)
3. Call `/load` endpoint to reload certificate
4. No pod restart = zero downtime

**Result:**
- **100% success rate** ✅ (if admin API works)
- No pod restart needed

### Option 3: Remove hostNetwork (Alternative)

If you can't use multiple nodes, remove `hostNetwork` and use NodePort/LoadBalancer:

```yaml
spec:
  # Remove: hostNetwork: true
  containers:
  - ports:
    - containerPort: 443
      # Multiple pods can run on same node
```

Then use a Service:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
spec:
  type: NodePort
  ports:
  - port: 443
    targetPort: 443
```

**Result:**
- Multiple replicas on same node
- **100% success rate** ✅

## Testing

```bash
# Test CA rotation
./scripts/test-full-chain-with-rotation.sh

# Expected output with proper setup:
# ✅ Zero-downtime rotation confirmed! (100% success rate - 120/120 requests)
```

## Current Configuration

- **Strategy**: RollingUpdate
- **Replicas**: 2 (requires multiple nodes)
- **MaxUnavailable**: 0
- **MaxSurge**: 1
- **Admin API**: Enabled (localhost:2019)

## Troubleshooting

**If success rate < 100%:**
1. Check if you have multiple nodes: `kubectl get nodes`
2. Check if pods are scheduled: `kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide`
3. Check if admin API is accessible: `kubectl port-forward -n ingress-nginx <pod> 2019:2019`
4. Check rotation script logs for admin API usage

**If pods are Pending:**
- With `hostNetwork` + 1 node, only 1 pod can run
- Either add more nodes OR reduce replicas to 1

