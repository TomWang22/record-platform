# Certificate Reload Limitation

## The Problem

When using manual TLS certificates (mounted from Kubernetes secrets), Caddy loads the certificate files into memory at startup. When you update the Kubernetes secret:

1. ✅ The mounted files **do** update (Kubernetes updates the volume)
2. ❌ Caddy **does not** automatically reload certificates from disk
3. ❌ The admin API `/load` endpoint reloads the config, but **not** the certificate files

## Why Admin API Reload Doesn't Work for Certificates

- Caddy caches certificates in memory for performance
- The `/load` endpoint reloads the Caddyfile configuration
- Certificate files are only read at startup or when explicitly reloaded
- Kubernetes secret updates don't trigger file system events that Caddy watches

## Solutions for 100% Zero-Downtime

### Option 1: Multiple Replicas with RollingUpdate (Recommended)

**Requirements:**
- 2+ replicas
- Multiple Kubernetes nodes (for `hostNetwork: true`)
- RollingUpdate strategy with `maxUnavailable: 0`

**How it works:**
- Old pod stays up while new pod starts
- New pod loads new certificate
- Traffic shifts to new pod
- Old pod terminates
- **Result: 100% success rate** ✅

**Setup:**
```bash
# Create multi-node Kind cluster
cat > kind-multi-node.yaml <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: h3
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 443
    hostPort: 8443
    protocol: TCP
  - containerPort: 443
    hostPort: 8443
    protocol: UDP
- role: worker
- role: worker
EOF

kind delete cluster --name h3
kind create cluster --config kind-multi-node.yaml --name h3

# Apply production config with 2 replicas
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml
```

### Option 2: Use Caddy's Automatic Certificate Management

Switch from manual certificates to Caddy's automatic ACME/Let's Encrypt:

```caddyfile
https://record.local {
  # Caddy automatically manages certificates
  # They auto-reload when renewed
  tls {
    protocols tls1.2 tls1.3
  }
  # ... rest of config
}
```

**Benefits:**
- Certificates auto-reload when renewed
- No manual rotation needed
- True zero-downtime

**Limitations:**
- Requires public domain (for Let's Encrypt)
- Or use internal CA with Caddy's cert management

### Option 3: Accept Brief Downtime (Current Setup)

With 1 replica and manual certificates:
- Admin API reload attempts to reload config
- Certificate files still need pod restart to reload
- Brief downtime during restart (~30-60s)
- **Result: ~50-70% success rate** ⚠️

## Current Status

- ✅ Admin API enabled and working
- ✅ Rotation script attempts admin API reload
- ⚠️ Certificates still require pod restart for full reload
- ⚠️ With 1 replica, brief downtime is expected

## Recommendation

For production with 100% zero-downtime requirement:
1. **Use 2+ replicas on multiple nodes** (best option)
2. **OR use Caddy's automatic certificate management** (if domain allows)
3. **OR accept brief downtime** (if 50-70% success is acceptable during rotation)

The test scripts correctly detect the deployment strategy and report success rates accordingly.

