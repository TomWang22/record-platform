# Colima Migration Guide - Docker Desktop to Colima with containerd

**Date**: January 6, 2026  
**Status**: Ready for Migration  
**Related ADR**: [ADR-001: Migrate from Docker Desktop to Colima with containerd](./adr/001-migrate-docker-desktop-to-colima-containerd.md)

## Overview

This guide walks through migrating record-platform from Docker Desktop to Colima with containerd runtime.

**Why Migrate**:
- Docker Desktop VM wedged (256GB Docker.raw, should be <40-60GB)
- Docker CLI commands hanging for 15+ hours
- RP workload exceeds Docker Desktop's design limits
- Colima + containerd is production-aligned and stable under load

**Time Estimate**: ~1 hour (one-time migration)

## Prerequisites

- macOS (Colima supports Linux too, but this guide is for macOS)
- Homebrew installed
- Docker Desktop **stopped** (quit the application)
- Kind cluster config (`kind-h3.yaml`) ready

## Step 1: Quit Docker Desktop

**IMPORTANT**: Quit Docker Desktop before starting migration.

```bash
# Quit Docker Desktop application
osascript -e 'quit app "Docker"'

# Verify it's stopped (should return nothing)
ps aux | grep -i docker | grep -v grep
```

## Step 2: Run Setup Script

Use the automated setup script:

```bash
cd /Users/tom/record-platform
./scripts/setup-colima-containerd.sh
```

**What the script does**:
1. Checks prerequisites (Homebrew, kubectl, kind)
2. Installs Colima via Homebrew (if not installed)
3. Configures Colima with containerd runtime
4. Sets resource limits (CPU: 8, Memory: 12GB, Disk: 200GB)
5. Configures Docker context for Colima
6. Configures kubectl for Colima Kubernetes (optional)
7. Verifies setup

**Manual Setup** (if script doesn't work):

```bash
# Install Colima
brew install colima

# Start Colima with containerd
colima start \
    --cpu 8 \
    --memory 12 \
    --disk 200 \
    --runtime containerd \
    --kubernetes

# Configure Docker context
docker context use colima

# Configure kubectl
export KUBECONFIG="$HOME/.colima/default/kubernetes/kubeconfig"
```

## Step 3: Verify Colima Setup

```bash
# Check Colima status
colima status

# Test containerd connection (use nerdctl for containerd runtime)
colima nerdctl ps

# Verify containerd runtime (use nerdctl for containerd runtime)
colima nerdctl ps
# Should list containers (or show empty if none running)

# Test kubectl (if Kubernetes enabled)
kubectl cluster-info
```

**Expected Output**:
```
✅ Colima running
✅ Docker accessible
✅ containerd runtime active
✅ kubectl working (if Kubernetes enabled)
```

## Step 4: Create Kind Cluster

**Delete old Kind cluster** (if exists):
```bash
# If old cluster exists (may not if Docker Desktop is reset)
kind delete cluster --name h3 2>/dev/null || true
```

**Create new Kind cluster in Colima**:
```bash
cd /Users/tom/record-platform
kind create cluster --name h3 --config kind-h3.yaml
```

**Verify cluster**:
```bash
kubectl get nodes
kubectl cluster-info
```

## Step 5: Rebuild and Load Images

**Build all service images** (with containerd runtime):
```bash
cd /Users/tom/record-platform

# Use nerdctl for containerd runtime
colima nerdctl build -t shopping-service:dev services/shopping-service

# Or set alias first (see Step 3)
alias docker='colima nerdctl'
docker build -t shopping-service:dev services/shopping-service

# Load into Kind (Kind uses containerd directly, so it can access images)
kind load docker-image shopping-service:dev --name h3

# Note: If you set the alias, 'docker' commands work normally
```

**Or use the build script** (if it's updated for nerdctl):
```bash
./scripts/build-and-load-images.sh
# Note: Script may need updating to use 'colima nerdctl' instead of 'docker'
```

## Step 6: Deploy Services

```bash
# Apply base manifests
kubectl apply -k infra/k8s/base

# Verify services are deploying
kubectl get pods -n record-platform --watch
```

## Step 7: Verify Services Health

```bash
# Check all pods are running
kubectl get pods -n record-platform

# Check service health
./scripts/check-all-services-health.sh

# Run smoke test
./scripts/test-microservices-http2-http3.sh
```

## Post-Migration Verification

### Check Colima Disk Usage

```bash
# Check Colima disk size (should stay reasonable)
ls -lh ~/.colima/default/disk.img

# Compare to old Docker.raw size
# Before: 256GB
# After: Should start ~10-20GB and grow slowly
```

### Monitor Resource Usage

```bash
# Check Colima resource usage
colima status

# Check Docker disk usage
docker system df

# Check Kubernetes resource usage
kubectl top nodes
kubectl top pods -n record-platform
```

### Test Load Tests

```bash
# Run k6 comprehensive test
./scripts/run-k6-comprehensive-strict-tls.sh

# Should complete without Docker hanging
```

## Troubleshooting

### Colima Not Starting

```bash
# Check Colima logs
colima logs

# Delete and recreate
colima delete
colima start --cpu 8 --memory 12 --disk 200 --runtime containerd --kubernetes
```

### Containerd Runtime (No Docker Socket)

**If you're using containerd runtime** (recommended), there's no Docker socket. Use nerdctl instead:

```bash
# Use nerdctl directly
colima nerdctl ps
colima nerdctl images

# Or set alias for convenience
alias docker='colima nerdctl'
docker ps

# Set up alias permanently
./scripts/colima-nerdctl-alias.sh
```

**If you need Docker runtime** (not recommended for Kind):
```bash
# Stop Colima
colima stop

# Restart with Docker runtime
colima start --runtime docker --cpu 8 --memory 12 --disk 200 --kubernetes

# Then configure Docker context
docker context use colima
docker ps
```

### Kubernetes Not Accessible

```bash
# Check if Kubernetes is enabled
colima status

# Enable Kubernetes
colima start --kubernetes

# Set KUBECONFIG
export KUBECONFIG="$HOME/.colima/default/kubernetes/kubeconfig"

# Test kubectl
kubectl cluster-info
```

### Kind Cluster Creation Fails

```bash
# Check Docker is accessible
docker ps

# Check Kind can access Docker
kind get clusters

# Delete old clusters
kind delete cluster --name h3 2>/dev/null || true

# Create new cluster
kind create cluster --name h3 --config kind-h3.yaml
```

## Daily Operations

### Start Colima

```bash
colima start
```

### Stop Colima

```bash
colima stop
```

### Check Status

```bash
colima status
docker ps
kubectl get nodes
```

### Update Resources

```bash
# Stop Colima
colima stop

# Restart with new resources
colima start --cpu 8 --memory 16 --disk 200 --runtime containerd --kubernetes
```

### Cleanup Containerd

```bash
# With containerd runtime, use nerdctl
# Prune unused images
colima nerdctl image prune -af

# Prune unused containers
colima nerdctl container prune -af

# System cleanup (if available)
colima nerdctl system prune -af 2>/dev/null || echo "system prune not available in nerdctl"

# Check disk usage (Colima disk)
ls -lh ~/.colima/default/disk.img

# Or set alias and use normal commands
alias docker='colima nerdctl'
docker image prune -af
```

## Benefits After Migration

✅ **No More VM Wedging**: Colima uses real ext4 filesystem (no Docker.raw ballooning)

✅ **Faster Builds**: Better caching and parallel layer downloads

✅ **Stable Under Load**: Designed for production workloads

✅ **Production-Aligned**: Development environment matches production (containerd)

✅ **Predictable Disk Usage**: Real filesystem behavior (no hidden growth)

✅ **Better Kind Support**: Kind designed to work with containerd

## Rollback Plan

If Colima doesn't work for any reason:

```bash
# Stop Colima
colima stop
colima delete

# Reinstall Docker Desktop
brew install --cask docker

# Reset Docker Desktop
# Docker Desktop → Settings → Troubleshoot → Reset to factory defaults

# Recreate Kind cluster
kind create cluster --name h3 --config kind-h3.yaml

# Rebuild images
./scripts/build-and-load-images.sh
```

**However**: ADR-001 assumes Colima will work based on community feedback and production usage.

## Related Documentation

- [ADR-001: Migrate from Docker Desktop to Colima with containerd](./adr/001-migrate-docker-desktop-to-colima-containerd.md)
- [Docker Desktop Recovery Guide](../DOCKER_DESKTOP_RECOVERY.md)
- [Runbook - Critical Issue #22](../Runbook.md#critical-issue-22-docker-desktop-vm-wedged---storagemetadata-pressure-january-6-2026)

## Support

- [Colima Documentation](https://github.com/abiosoft/colima)
- [containerd Documentation](https://containerd.io/)
- [Kind Documentation](https://kind.sigs.k8s.io/)

---

**Last Updated**: January 6, 2026  
**Status**: Ready for Migration
