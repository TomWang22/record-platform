# Colima Setup Script Fixes - containerd Runtime Support

**Date**: January 6, 2026  
**Issue**: Script hung at verification step when using containerd runtime  
**Status**: ✅ Fixed

## Problem

The setup script (`scripts/setup-colima-containerd.sh`) was hanging because:

1. **Verification step tried to use `docker info`**:
   - With containerd runtime, there's no Docker socket
   - Docker commands hang when context is set to desktop-linux (even though Docker Desktop was quit)

2. **Docker context still pointing to desktop-linux**:
   - Even after quitting Docker Desktop, Docker context wasn't switched
   - `docker` commands tried to connect to non-existent Docker Desktop socket

3. **containerd requires `nerdctl` instead of `docker`**:
   - containerd runtime doesn't provide Docker socket
   - Must use `colima nerdctl` commands instead

## Fixes Applied

### 1. Updated Verification Step (lines 157-176)

**Before** (HUNG):
```bash
docker info 2>/dev/null | grep -i runtime
```

**After** (WORKS):
```bash
if [[ "${COLIMA_RUNTIME}" == "containerd" ]]; then
    # For containerd runtime, use nerdctl
    colima nerdctl ps >/dev/null 2>&1
    colima nerdctl info 2>/dev/null | head -5
else
    # For docker runtime, use docker
    docker info 2>/dev/null | grep -i runtime
fi
```

### 2. Updated Docker Context Configuration (lines 178-204)

**Before**: Always tried to configure Docker context (would hang with containerd)

**After**: Skips Docker context for containerd runtime and shows nerdctl usage:
```bash
if [[ "${COLIMA_RUNTIME}" == "containerd" ]]; then
    print_warning "Using containerd runtime - Docker socket not available"
    echo "Use 'colima nerdctl' commands instead of 'docker' commands:"
    echo "  colima nerdctl ps        # List containers"
    echo "  colima nerdctl images    # List images"
    echo "  colima nerdctl build     # Build images"
    echo "Or set an alias: alias docker='colima nerdctl'"
    return 0
fi
```

### 3. Updated Verification Function (lines 246-279)

**Before**: Always tried `docker info` (would hang)

**After**: Uses `colima nerdctl` for containerd runtime:
```bash
if [[ "${COLIMA_RUNTIME}" == "containerd" ]]; then
    echo "2. containerd runtime (via nerdctl):"
    colima nerdctl ps
    colima nerdctl images
else
    echo "2. Docker info:"
    docker info
fi
```

### 4. Created Helper Script

**New file**: `scripts/colima-nerdctl-alias.sh`

Sets up Docker alias for convenience:
```bash
alias docker='colima nerdctl'
```

This allows using `docker` commands normally (they're mapped to `colima nerdctl`).

## Current Status

✅ **Script fixed** - No longer hangs with containerd runtime  
✅ **Colima running** - Colima is already started with containerd runtime  
✅ **Verification updated** - Uses nerdctl instead of docker commands  
✅ **Helper script created** - Easy alias setup for nerdctl  

## Next Steps

Since Colima is already running with containerd:

### Option 1: Continue with Setup Script

The script will detect Colima is running and continue:
```bash
cd /Users/tom/record-platform
./scripts/setup-colima-containerd.sh
# It will skip Colima startup (already running) and continue with verification
```

### Option 2: Manual Verification

If you prefer to verify manually:
```bash
# Check Colima status
colima status

# Verify containerd via nerdctl
colima nerdctl ps
colima nerdctl images

# Configure kubectl
export KUBECONFIG="$HOME/.colima/default/kubernetes/kubeconfig"
kubectl cluster-info
```

### Option 3: Set Up Docker Alias (Optional but Recommended)

For convenience, set up the alias so you can use `docker` commands:
```bash
./scripts/colima-nerdctl-alias.sh

# Or manually
alias docker='colima nerdctl'
echo "alias docker='colima nerdctl'" >> ~/.zshrc
source ~/.zshrc
```

## Using nerdctl

With containerd runtime, use `colima nerdctl` instead of `docker`:

```bash
# List containers
colima nerdctl ps

# List images
colima nerdctl images

# Build images
colima nerdctl build -t my-image:tag .

# Run containers
colima nerdctl run -it my-image:tag

# Load images into Kind (Kind uses containerd directly)
kind load docker-image my-image:tag --name h3
# Note: Kind can access containerd images directly, no need for Docker socket
```

## Troubleshooting

### Script Still Hangs

If the script still hangs:
1. Kill any hung Docker processes:
   ```bash
   pkill -9 docker
   ```
2. Make sure Docker Desktop is completely quit:
   ```bash
   ps aux | grep -i docker | grep -v grep
   # Should return nothing
   ```
3. Run the script again

### nerdctl Commands Not Working

Check Colima is running:
```bash
colima status
# Should show: RUNNING with runtime: containerd
```

If not running:
```bash
colima start --runtime containerd --cpu 8 --memory 12 --disk 200 --kubernetes
```

### Kind Can't Load Images

Kind uses containerd directly, so it should work. If not:
1. Verify Kind can access containerd:
   ```bash
   kind get clusters
   ```
2. Make sure Kind is pointing to Colima's Kubernetes:
   ```bash
   export KUBECONFIG="$HOME/.colima/default/kubernetes/kubeconfig"
   kubectl get nodes
   ```
3. Use `kind load docker-image` (works with containerd):
   ```bash
   colima nerdctl build -t my-image:tag .
   kind load docker-image my-image:tag --name h3
   ```

## Summary

✅ **Script fixed** - Now handles containerd runtime correctly  
✅ **No more hangs** - Uses nerdctl instead of docker for containerd  
✅ **Helper script** - Easy alias setup for convenience  
✅ **Documentation updated** - Migration guide includes nerdctl instructions  

The script should now work correctly with containerd runtime!

---

**Last Updated**: January 6, 2026
