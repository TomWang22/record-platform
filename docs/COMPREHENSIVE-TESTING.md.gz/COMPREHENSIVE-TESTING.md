# Comprehensive Testing Guide

This document describes the comprehensive testing suite for the record-platform, covering HTTP/2, HTTP/3, gRPC, and all microservices.

## Test Scripts

### 1. `scripts/test-microservices-http2-http3.sh`

**Purpose**: End-to-end testing of all microservices via HTTP/2 and HTTP/3, including multi-user scenarios.

**Coverage**:
- ✅ **Authentication**: Registration and login for two users (User 1 and User 2)
- ✅ **Records Service**: CRUD operations via HTTP/2 and HTTP/3
- ✅ **Social Service**:
  - Forum posts (create, get) via HTTP/2 and HTTP/3
  - Forum comments (User 2 comments on User 1's post) via HTTP/3
  - P2P direct messaging (User 1 → User 2, User 2 → User 1) via HTTP/2 and HTTP/3
  - Group chat (create group, add members, send group messages) via HTTP/2 and HTTP/3
- ✅ **Listings Service**: Health checks, search, create, get my listings via HTTP/2 and HTTP/3
- ✅ **Logout**: Token revocation and verification
- ✅ **gRPC Services**: Health checks for all services (auth, records, social, listings, analytics)

**Features**:
- Multi-user testing (creates two users and tests interactions)
- JWT token extraction and user ID parsing
- Real-world scenarios (P2P messaging, group chat, forum interactions)
- Protocol verification (HTTP/2 and HTTP/3)
- Token revocation testing

**Usage**:
```bash
./scripts/test-microservices-http2-http3.sh
```

### 2. `scripts/test-grpc-http2-http3.sh`

**Purpose**: Comprehensive gRPC testing via HTTP/2 and HTTP/3.

**Coverage**:
- ✅ HTTP/2 and HTTP/3 health checks
- ✅ API Gateway connectivity
- ✅ Authentication via HTTP/2
- ✅ Records CRUD operations via HTTP/2 and HTTP/3
- ✅ **gRPC Services**:
  - Auth Service (HealthCheck, Authenticate)
  - Records Service (HealthCheck)
  - Social Service (HealthCheck)
  - Listings Service (HealthCheck)
  - Analytics Service (HealthCheck)
- ✅ Logout with token revocation verification

**Requirements**:
- `grpcurl` must be installed:
  ```bash
  brew install grpcurl
  # Or
  go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest
  ```

**Usage**:
```bash
./scripts/test-grpc-http2-http3.sh
```

### 3. `scripts/test-grpc-http2-http3-alpn.sh`

**Purpose**: ALPN (Application-Layer Protocol Negotiation) testing for gRPC.

**Coverage**:
- ✅ HTTP/2 with prior knowledge
- ✅ HTTP/3 (QUIC)
- ✅ gRPC health check via HTTP/2
- ✅ ALPN negotiation details

**Usage**:
```bash
./scripts/test-grpc-http2-http3-alpn.sh
```

## Test Coverage Matrix

| Service | HTTP/2 | HTTP/3 | gRPC | Multi-User | Logout |
|---------|--------|--------|------|------------|--------|
| Auth Service | ✅ | ✅ | ✅ | ✅ | ✅ |
| Records Service | ✅ | ✅ | ✅ | ✅ | - |
| Social Service | ✅ | ✅ | ✅ | ✅ | - |
| Listings Service | ✅ | ✅ | ✅ | ✅ | - |
| Analytics Service | ✅ | ✅ | ✅ | - | - |
| API Gateway | ✅ | ✅ | - | - | - |

## Multi-User Testing Scenarios

### P2P Direct Messaging
1. User 1 sends a direct message to User 2 via HTTP/2
2. User 2 replies to User 1 via HTTP/3
3. Both users can retrieve their messages

### Group Chat
1. User 1 creates a group chat
2. User 1 adds User 2 to the group
3. User 1 sends a group message via HTTP/3
4. User 2 can view group details

### Forum Interactions
1. User 1 creates a forum post via HTTP/2
2. User 2 adds a comment to User 1's post via HTTP/3
3. Both users can view posts and comments

## gRPC Service Endpoints

All gRPC services are accessible via the ingress at `record.local:8443`:

- **Auth Service**: `/auth.AuthService/*` (port 50051)
- **Records Service**: `/records.RecordsService/*` (port 50051)
- **Social Service**: `/social.SocialService/*` (port 50056)
- **Listings Service**: `/listings.ListingsService/*` (port 50057)
- **Analytics Service**: `/analytics.AnalyticsService/*` (port 50054)

### Example gRPC Calls

```bash
# Health check
grpcurl -insecure -H "Host: record.local" \
  -d '{}' \
  record.local:8443 auth.AuthService/HealthCheck

# Authenticate
grpcurl -insecure -H "Host: record.local" \
  -d '{"email":"user@example.com","password":"password"}' \
  record.local:8443 auth.AuthService/Authenticate

# Search records
grpcurl -insecure -H "Host: record.local" \
  -d '{"user_id":"<user-id>","query":"vinyl","limit":10}' \
  record.local:8443 records.RecordsService/SearchRecords
```

## Logout Testing

The logout endpoint revokes JWT tokens by storing them in Redis with a TTL matching the token's expiration time.

**Test Flow**:
1. User logs in and receives a token
2. User calls `/api/auth/logout` with the token
3. Token is revoked in Redis
4. Subsequent requests with the revoked token return 401

**Verification**:
- After logout, protected endpoints should return 401
- Token revocation is verified by attempting to access a protected resource

## Protocol Verification

### HTTP/2
- Uses `--http2` flag with curl
- Verified via ALPN negotiation
- Confirmed in response headers

### HTTP/3
- Uses `http3_curl` helper (runs curl inside Kind cluster)
- Uses `--http3-only` flag
- Verified via QUIC protocol
- Confirmed in response headers

### gRPC
- Uses `grpcurl` tool
- gRPC runs over HTTP/2
- Verified via service health checks
- Confirmed via successful RPC calls

## Running All Tests

To run the complete test suite:

```bash
# 1. Test all microservices (HTTP/2, HTTP/3, gRPC, multi-user, logout)
./scripts/test-microservices-http2-http3.sh

# 2. Test gRPC specifically
./scripts/test-grpc-http2-http3.sh

# 3. Test ALPN negotiation
./scripts/test-grpc-http2-http3-alpn.sh
```

## Troubleshooting

### grpcurl not found
```bash
brew install grpcurl
# Or
go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest
```

### HTTP/3 tests failing
- HTTP/3 requires QUIC, which may have UDP port mapping issues on macOS
- The `http3_curl` helper runs curl inside the Kind cluster to bypass this
- Check `scripts/lib/http3.sh` for the implementation

### gRPC tests failing
- Verify services are running: `kubectl -n record-platform get pods`
- Check gRPC ingress: `kubectl -n record-platform get ingress record-platform-grpc`
- Verify proto files are mounted: `kubectl -n record-platform describe configmap proto-files`

### Token revocation not working
- Check Redis is running: `kubectl -n record-platform get pods -l app=redis`
- Verify Redis connection in auth-service logs
- Check token has `jti` claim (required for revocation)

## Next Steps

- [ ] Add gRPC streaming tests
- [ ] Add performance/load testing
- [ ] Add integration tests for Kafka message delivery
- [ ] Add tests for error scenarios and edge cases
- [ ] Add tests for rate limiting and security features

