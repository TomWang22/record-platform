# Database Topology Report

**Date**: 2025-11-21  
**Status**: Mixed deployment (Docker Compose + Kubernetes)

## Overview

The platform uses a **hybrid database topology**:
- **Main database (records)**: Available in both Docker Compose AND Kubernetes
- **Social database (forum/messages)**: Docker Compose only (NOT in Kubernetes)
- **Listings database**: Docker Compose only (NOT in Kubernetes)

## Database Inventory

### 1. Main Database (Records)
- **Purpose**: Core records, auth, analytics, listings search history
- **Schemas**: `records`, `records_hot`, `auth`, `analytics`, `listings` (legacy search history)
- **Location**: **BOTH**
  - ✅ Docker Compose: `postgres` service on port **5433** (host) → 5432 (container)
  - ✅ Kubernetes: `postgres` deployment in `record-platform` namespace (internal port 5432)
- **Connection from K8s pods**: `host.docker.internal:5432` (routes to Docker Compose port 5433)
- **Volume**: `pgdata` (Docker Compose) / `pgdata-big` PVC (Kubernetes)

**Status**: ✅ **Dual deployment** - Can be accessed from both environments

### 2. Social Database (Forum/Messages)
- **Purpose**: Forum posts, comments, messaging, groups
- **Schemas**: `forum`, `messages`
- **Location**: **Docker Compose ONLY** ⚠️
  - ✅ Docker Compose: `postgres-social` service on port **5434** (host) → 5432 (container)
  - ❌ Kubernetes: **NOT DEPLOYED**
- **Connection from K8s pods**: `host.docker.internal:5434`
- **Volume**: `pgdata-social` (Docker Compose only)

**Status**: ⚠️ **External to Kubernetes** - Running in Docker Compose, accessed via `host.docker.internal`

### 3. Listings Database
- **Purpose**: User listings, auctions, bids, offers, watchlists
- **Schemas**: `listings`
- **Location**: **Docker Compose ONLY** ⚠️
  - ✅ Docker Compose: `postgres-listings` service on port **5435** (host) → 5432 (container)
  - ❌ Kubernetes: **NOT DEPLOYED**
- **Connection from K8s pods**: `host.docker.internal:5435`
- **Volume**: `pgdata-listings` (Docker Compose only)

**Status**: ⚠️ **External to Kubernetes** - Running in Docker Compose, accessed via `host.docker.internal`

## Connection String Configuration

### Kubernetes ConfigMap (`infra/k8s/base/config/app-config.yaml`)

```yaml
# Main database (Docker Compose, accessed from K8s)
POSTGRES_URL:         postgresql://postgres:postgres@host.docker.internal:5432/records
POSTGRES_URL_AUTH:    postgresql://postgres:postgres@host.docker.internal:5432/records?search_path=auth
POSTGRES_URL_RECORDS: postgresql://postgres:postgres@host.docker.internal:5432/records

# Social database (Docker Compose only)
POSTGRES_URL_SOCIAL:  postgresql://postgres:postgres@host.docker.internal:5434/records

# Listings database (Docker Compose only)
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@host.docker.internal:5435/records
```

**Key Points**:
- All connections use `host.docker.internal` to reach Docker Compose from Kubernetes
- Port mapping: Docker Compose exposes 5433/5434/5435, but K8s connects to 5432 internally
- The `host.docker.internal:5432` connection actually routes to Docker Compose port 5433

## Deployment Architecture

### Docker Compose Services

```
┌─────────────────────────────────────────┐
│        Docker Compose Stack             │
│                                         │
│  ┌─────────────┐  ┌─────────────┐     │
│  │  postgres   │  │ postgres-   │     │
│  │  :5433      │  │ social      │     │
│  │  (Main DB)  │  │ :5434       │     │
│  └─────────────┘  └─────────────┘     │
│                                         │
│  ┌─────────────┐                       │
│  │ postgres-   │                       │
│  │ listings    │                       │
│  │ :5435       │                       │
│  └─────────────┘                       │
└─────────────────────────────────────────┘
          ↑
          │ host.docker.internal
          │
┌─────────────────────────────────────────┐
│      Kubernetes Cluster                 │
│  (record-platform namespace)            │
│                                         │
│  ┌──────────────┐  ┌──────────────┐   │
│  │ auth-service │  │social-service│   │
│  │              │  │              │   │
│  └──────────────┘  └──────────────┘   │
│                                         │
│  ┌──────────────┐  ┌──────────────┐   │
│  │records-service│  │listings-    │   │
│  │              │  │ service      │   │
│  └──────────────┘  └──────────────┘   │
│                                         │
│  ┌──────────────┐                      │
│  │ postgres     │  (Also exists in K8s│
│  │ (K8s deploy) │   but unused)        │
│  └──────────────┘                      │
└─────────────────────────────────────────┘
```

## Port Mapping Reference

| Database | Docker Compose | Container Port | Kubernetes Service | Status |
|----------|---------------|----------------|-------------------|---------|
| Main (records) | 5433 | 5432 | 5432 (internal) | ✅ Both locations |
| Social | 5434 | 5432 | ❌ Not in K8s | ⚠️ Docker Compose only |
| Listings | 5435 | 5432 | ❌ Not in K8s | ⚠️ Docker Compose only |

## Why This Architecture?

### Historical Context
1. **Main database**: Originally deployed in Kubernetes for production readiness
2. **Social/Listings databases**: Added later as separate services, deployed in Docker Compose for:
   - Faster local development
   - Separate schema isolation
   - Easier testing without affecting main DB

### Current Rationale
- **Main DB**: Needs to be in K8s for production (tuned, backed up, monitored)
- **Social/Listings DBs**: Can stay in Docker Compose for now because:
  - They're new services
  - Schema is still evolving
  - Easier to reset/recreate locally
  - Accessible via `host.docker.internal` from K8s pods

## Access Patterns

### From Kubernetes Pods
```bash
# Main DB
postgresql://postgres:postgres@host.docker.internal:5432/records

# Social DB  
postgresql://postgres:postgres@host.docker.internal:5434/records

# Listings DB
postgresql://postgres:postgres@host.docker.internal:5435/records
```

### From Host Machine
```bash
# Main DB
psql -h localhost -p 5433 -U postgres -d records

# Social DB
psql -h localhost -p 5434 -U postgres -d records

# Listings DB
psql -h localhost -p 5435 -U postgres -d records
```

### From Docker Compose Network
```bash
# Main DB
psql -h postgres -p 5432 -U postgres -d records

# Social DB
psql -h postgres-social -p 5432 -U postgres -d records

# Listings DB
psql -h postgres-listings -p 5432 -U postgres -d records
```

## Migration Considerations

### Moving Social/Listings to Kubernetes

If you want to move social/listings databases to Kubernetes (like main DB):

1. **Create Kubernetes deployments** similar to `infra/k8s/base/postgres/`
2. **Create PVCs** for persistent storage
3. **Create Services** to expose them internally
4. **Update connection strings** in `app-config.yaml`:
   ```yaml
   POSTGRES_URL_SOCIAL: postgresql://postgres:postgres@postgres-social.record-platform.svc.cluster.local:5432/records
   POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@postgres-listings.record-platform.svc.cluster.local:5432/records
   ```
5. **Migrate data** from Docker Compose volumes to K8s PVCs

**Current State**: No migration needed - works fine as-is for development

## Current Status Summary

| Database | Location | Accessible from K8s? | Notes |
|----------|----------|---------------------|-------|
| **Main (records)** | Both | ✅ Yes | Dual deployment, K8s version used in production. Target: 2.4M rows |
| **Social** | Docker Compose only | ✅ Yes (via host.docker.internal) | External to K8s, accessed via bridge. Setup scripts available |
| **Listings** | Docker Compose only | ✅ Yes (via host.docker.internal) | External to K8s, accessed via bridge. Setup scripts available |

## Setup Scripts

### Main Database
- ✅ `scripts/rehydrate-and-tune.sh` - Complete restore + tuning pipeline
- ✅ `scripts/optimize-db-for-performance.sh` - Performance optimizations
- ✅ `scripts/run_pgbench_sweep.sh` - Benchmark suite (target: 28k TPS, 2.4M rows)

### Social Database
- ✅ `scripts/setup-social-db.sh` - Basic schema setup
- ✅ `scripts/setup-and-optimize-social-db.sh` - **NEW** - Comprehensive setup (like main DB)
- ✅ `scripts/optimize-social-db-for-performance.sh` - **NEW** - Performance optimizations

### Listings Database
- ✅ `scripts/setup-listings-db.sh` - Basic schema setup
- ✅ `scripts/setup-and-optimize-listings-db.sh` - **NEW** - Comprehensive setup (like main DB)
- ✅ `scripts/optimize-listings-db-for-performance.sh` - **NEW** - Performance optimizations

## PostgreSQL GPT Analysis

- ✅ `scripts/generate-postgresql-gpt-analysis.sh` - **NEW** - Generate analysis files for PostgreSQL GPT
- ✅ `docs/POSTGRESQL-GPT-ANALYSIS-PLANS.md` - **NEW** - Complete analysis plans for all databases

### How to Generate Analysis

```bash
# Generate comprehensive analysis for all databases
./scripts/generate-postgresql-gpt-analysis.sh

# This creates analysis files in:
# docs/postgresql-gpt-analysis/<timestamp>/
#   - main-analysis.txt
#   - social-analysis.txt
#   - listings-analysis.txt
```

These files can be sent directly to PostgreSQL GPT along with:
- Schema files (`infra/db/*.sql`)
- Query plans (from `run_pgbench_sweep.sh` or manual EXPLAIN)
- Performance metrics

## Recommendations

### For Development
- ✅ **Current setup is fine** - Docker Compose databases are easier to manage locally
- ✅ **Separate databases** provide good isolation

### For Production
- ⚠️ **Consider migrating** social/listings to Kubernetes for:
  - Better orchestration (restarts, scaling)
  - Persistent volumes with backup/restore
  - Service mesh integration
  - Consistent deployment model

### For Testing
- ✅ **Current setup works** - All databases accessible from both environments
- ✅ **Can test** K8s services → Docker Compose databases via `host.docker.internal`

## Verification Commands

```bash
# Check Docker Compose databases
docker-compose ps | grep postgres

# Check Kubernetes database
kubectl -n record-platform get pod -l app=postgres

# Test connections from host
psql -h localhost -p 5433 -U postgres -d records -c "SELECT COUNT(*) FROM records.records;"
psql -h localhost -p 5434 -U postgres -d records -c "SELECT COUNT(*) FROM forum.posts;"
psql -h localhost -p 5435 -U postgres -d records -c "SELECT COUNT(*) FROM listings.listings;"

# Test from K8s pod (if you exec into a pod)
# These use host.docker.internal which routes to Docker Compose
psql "postgresql://postgres:postgres@host.docker.internal:5434/records" -c "SELECT 1;"
psql "postgresql://postgres:postgres@host.docker.internal:5435/records" -c "SELECT 1;"
```

## Next Steps (Optional)

If you want to standardize on Kubernetes:

1. Create `infra/k8s/base/postgres-social/` with deployment + service + PVC
2. Create `infra/k8s/base/postgres-listings/` with deployment + service + PVC
3. Update connection strings to use K8s service DNS
4. Migrate data from Docker Compose volumes to K8s PVCs
5. Remove Docker Compose postgres-social and postgres-listings services

**For now, the current hybrid approach works well for development and testing.**

