# Disk Space Management

## Current Status
- **Host Disk**: 88% full (378Gi/460Gi used)
- **Docker Volumes**: 52.99GB total, 10.2GB reclaimable
- **Largest Volumes**: 
  - `minikube`: 5.1GB (unused)
  - `postgres-external-data`: 4.9GB (unused)
  - `record-platform_pgdata`: 2.6GB (active)
  - `record-platform_pgdata-listings`: 2.4GB (active)

## Regular Cleanup

### Automatic Cleanup Script
Run the comprehensive cleanup script:
```bash
./scripts/cleanup-disk-space.sh
```

This script will:
- Clean old backups (keeps last 3)
- Clean old benchmark logs (keeps last 7 days)
- Clean Docker build cache
- Clean unused Docker images
- Show unused volumes (doesn't delete without confirmation)

### Manual Cleanup Options

1. **Clean old benchmark results**:
   ```bash
   ./scripts/cleanup-old-bench-results.sh 7  # Keep last 7 days
   ```

2. **Clean Docker resources**:
   ```bash
   docker system prune -a --volumes -f  # ⚠️  Dangerous - removes all unused resources
   docker volume prune -f  # Remove unused volumes only
   ```

3. **Remove specific unused volumes**:
   ```bash
   docker volume ls -f "dangling=true"  # List unused volumes
   docker volume rm <volume-name>  # Remove specific volume
   ```

## Auth Database Disk Space Issue

### Problem
The auth database (port 5437) ran out of disk space and couldn't start. The container was in a restart loop.

### Temporary Solution
Auth-service is currently using the main database (port 5433) where users exist. This works fine for now.

### Permanent Fix
When ready to recreate the auth database:

```bash
./scripts/fix-auth-db-disk-space.sh
```

This script will:
1. Stop and remove the problematic auth DB container
2. Remove the corrupted volume
3. Recreate the database with a fresh volume
4. Set up the schema
5. Migrate users back from main DB (if needed)

After running the fix script:
```bash
# Update auth-service to use port 5437
kubectl -n record-platform set env deploy/auth-service \
  POSTGRES_URL_AUTH='postgresql://postgres:postgres@host.docker.internal:5437/records?search_path=auth&connect_timeout=5'

# Restart auth-service
kubectl -n record-platform rollout restart deploy/auth-service
```

## Monitoring Disk Space

### Check Host Disk
```bash
df -h .
```

### Check Docker Disk Usage
```bash
docker system df
docker system df -v  # Detailed view
```

### Check Largest Volumes
```bash
docker system df -v | grep -A 20 "Local Volumes"
```

## Prevention

1. **Regular Cleanup**: Run `./scripts/cleanup-disk-space.sh` weekly
2. **Monitor Bench Logs**: Clean old benchmark results regularly
3. **Monitor Backups**: Keep only necessary backups
4. **Remove Unused Volumes**: Periodically clean up unused Docker volumes

## Emergency Cleanup

If disk space is critically low:

```bash
# 1. Clean everything possible
./scripts/cleanup-disk-space.sh
docker system prune -a --volumes -f

# 2. Remove unused volumes (⚠️  make sure you have backups!)
docker volume prune -f

# 3. Remove specific large unused volumes
docker volume rm minikube  # 5.1GB if not needed
docker volume rm postgres-external-data  # 4.9GB if not needed
```

## Notes

- The auth database volume was removed to free space (it was corrupted anyway)
- Auth-service is using main DB (port 5433) temporarily
- Users can login and use all services normally
- When disk space is available, run the fix script to recreate auth DB
