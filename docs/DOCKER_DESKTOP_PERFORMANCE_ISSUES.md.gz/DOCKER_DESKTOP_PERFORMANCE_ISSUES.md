# Docker Desktop Performance Issues Investigation

**Date:** December 16, 2024  
**Issue:** Docker Desktop hanging (`docker system df`), UI glitches (showing "000%"), and general sluggishness

---

## 🔍 Root Cause Analysis

### Primary Issue: Zombie `docker stats` Processes

**Problem:** Docker Desktop is spawning `docker stats` processes that never terminate, accumulating over time.

**Evidence:**
- **49 zombie `docker stats` processes** currently running
- Oldest process: **13+ days old** (PID 82057, running since Dec 3rd)
- Other processes: 8 days, 4 days, 24+ hours old
- These processes are spawned by Docker Desktop's UI for monitoring containers

**Impact:**
1. **`docker system df` hangs** - Waiting for these processes to respond
2. **Docker Desktop UI glitches** - "000%" display errors due to process communication failures
3. **Resource consumption** - Each process consumes memory (6-17MB each ≈ 250-800MB total)
4. **API/CLI slowdowns** - Docker daemon gets overwhelmed by orphaned stats requests

### Secondary Issue: Large Docker Data Directory

**Current state:**
- Docker data directory: **59GB** at `/Users/tom/Library/Containers/com.docker.docker/Data`
- VM storage: **59GB** (most of it in `vms` directory)
- This is expected for multiple Kubernetes clusters (h3, kind clusters) but could be optimized

---

## 🛠️ Immediate Fixes

### Fix 1: Kill Zombie `docker stats` Processes

**One-time cleanup:**
```bash
# Find and kill all hanging docker stats processes
ps aux | grep "docker stats" | grep -v grep | awk '{print $2}' | xargs kill -9

# Verify they're gone
ps aux | grep "docker stats" | grep -v grep | wc -l  # Should return 0
```

**After cleanup:**
- `docker system df` should work immediately
- Docker Desktop UI should respond normally
- Monitor to see if they accumulate again

### Fix 2: Prevent Future Accumulation

**Option A: Restart Docker Desktop** (Simplest)
```bash
osascript -e 'quit app "Docker"'
sleep 5
open -a Docker
```
This clears all processes and should prevent immediate re-accumulation.

**Option B: Configure Docker Desktop**
1. Open Docker Desktop
2. Go to **Settings** → **Resources** → **Advanced**
3. Reduce **CPU/Memory** limits if set too high
4. Go to **Settings** → **General**
5. Uncheck **"Start Docker Desktop when you log in"** if not needed
6. Restart Docker Desktop

**Option C: Script-based monitoring** (if issue persists)
Create a cron job or launchd service to periodically kill zombie processes:
```bash
#!/bin/bash
# Clean up docker stats zombies every hour
ps aux | grep "[d]ocker stats" | awk '{if ($10 > 3600) print $2}' | xargs -r kill -9
```

---

## 📊 Current Docker Status

**Containers:**
- 9 containers running (h3 cluster: 3 nodes, buildkit, postgres, webapp, zookeeper)
- 17 total containers (including stopped)

**Images:**
- 8 images tagged `:dev` (all services)
- Likely many more intermediate/build cache layers

**Volumes:**
- 18 volumes (Kubernetes data, postgres data, etc.)

**Docker Processes:**
- Main Docker Desktop: PID 29099 (running since Nov 25, 333 hours CPU time)
- Backend services: PID 28578 (running since Nov 25, 2110 hours CPU time)
- **49 zombie `docker stats` processes** ⚠️

---

## 🔄 Verification Steps

After applying fixes:

1. **Test `docker system df`:**
   ```bash
   time docker system df
   ```
   Should complete in < 2 seconds (not hang)

2. **Check Docker Desktop UI:**
   - Open Docker Desktop
   - Navigate to containers/volumes/images tabs
   - Verify no "000%" or blank percentages
   - Stats should update smoothly

3. **Monitor process accumulation:**
   ```bash
   # Check for new zombie processes after 1 hour
   ps aux | grep "docker stats" | grep -v grep | wc -l
   ```

---

## 🚨 Known Docker Desktop Bug

This appears to be a known issue with Docker Desktop for Mac where:
- The UI spawns `docker stats` processes for container monitoring
- These processes don't properly terminate when containers stop or UI tabs are closed
- Over time, they accumulate and cause performance degradation

**Workaround:** Periodic cleanup or Docker Desktop restart

**Reported to Docker:** This is a known issue (no public tracking number found, but documented in various GitHub issues)

---

## 📈 Long-term Recommendations

1. **Regular Cleanup:**
   - Schedule weekly Docker Desktop restarts
   - Monitor and kill zombie processes monthly
   - Use `docker system prune` to clean unused resources

2. **Resource Management:**
   - Periodically review and clean Docker images/volumes
   - Use `docker builder prune` to clean build cache
   - Consider increasing Docker Desktop memory if working with large clusters

3. **Alternative Approach:**
   - If issues persist, consider using `colima` or `orbstack` as Docker Desktop alternatives
   - These are lighter-weight and may not have the same process accumulation issues

4. **Docker Desktop Updates:**
   - Keep Docker Desktop updated to latest version
   - Newer versions may have fixes for this issue

---

## 🔧 Docker Cleanup Commands

If you need to free up space:

```bash
# Remove unused containers, networks, images (dangling)
docker system prune

# Remove unused volumes (BE CAREFUL - this removes data!)
docker volume prune

# Remove all unused images, containers, networks, volumes
docker system prune -a --volumes

# Clean build cache (safest, recovers space)
docker builder prune -a

# See what would be removed first
docker system df -v
```

---

## ✅ Expected Outcome After Fix

- `docker system df` completes in < 2 seconds
- Docker Desktop UI shows correct percentages and stats
- No zombie `docker stats` processes
- Improved overall Docker performance
- Normal resource usage

---

## 🚨 Critical Update: Daemon Overwhelmed

**Current Status (Dec 16, 2024 8:08 PM):**
- Docker daemon is **completely overwhelmed** and blocking
- Even basic commands like `docker ps` are hanging (PID 22921)
- `docker stats` processes keep re-spawning immediately after cleanup
- Docker daemon backend (PID 28578) has been running for 2111+ hours (since Nov 25)

**Root Cause:** The Docker daemon has accumulated too many blocked operations and cannot process new API requests. Killing zombie processes provides only temporary relief because Docker Desktop UI immediately spawns new ones, creating a cycle.

**Required Action:** Docker Desktop **restart is necessary** to reset the daemon state. However, this will:
- Stop all running containers (including Kubernetes clusters)
- Interrupt any ongoing builds
- Require re-starting services/clusters

### Immediate Workaround (if restart not possible now):

1. **Close Docker Desktop UI completely** to stop spawning new `docker stats` processes:
   ```bash
   osascript -e 'quit app "Docker Desktop"'
   ```
   Note: This keeps the Docker daemon running, just closes the UI.

2. **Use Docker CLI directly** (may work if UI is closed):
   ```bash
   # Kill all UI-spawned processes first
   pkill -9 -f "docker stats"
   pkill -9 -f "docker system df"
   pkill -9 -f "docker ps"
   
   # Try commands with timeout wrapper
   (timeout 5 docker ps || killall docker 2>/dev/null) 2>&1
   ```

3. **If you must restart Docker Desktop** (recommended when possible):
   ```bash
   # Save current context if needed
   docker context ls
   
   # Full restart (stops everything)
   osascript -e 'quit app "Docker"'
   sleep 10
   open -a Docker
   
   # Wait for Docker to be ready
   while ! docker info >/dev/null 2>&1; do sleep 2; done
   ```

---

**Status:** Investigation complete, **Docker Desktop restart required for full recovery**  
**Next Steps:** Schedule Docker Desktop restart when builds can be interrupted

