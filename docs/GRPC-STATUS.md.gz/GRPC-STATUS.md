# gRPC Service Status

## Overview
This document tracks the gRPC implementation status for all microservices in the record-platform.

## Service Status

### ✅ Auth Service
- **gRPC Port**: 50051
- **Status**: ✅ Configured and Running
- **Proto**: `auth.proto`
- **Ingress Route**: `/auth.AuthService`
- **Logs**: `[gRPC] Server started on port 50051 (HTTP/2 only, no HTTP/1.1 fallback)`

### ✅ Records Service
- **gRPC Port**: 50051
- **Status**: ✅ Configured and Running
- **Proto**: `records.proto`
- **Ingress Route**: `/records.RecordsService`
- **Logs**: `[records gRPC] server listening on 50051`
- **Note**: Uses same port as auth-service (different services, different pods)

### ✅ Social Service
- **gRPC Port**: 50056
- **Status**: ✅ Configured and Running
- **Proto**: `social.proto`
- **Ingress Route**: `/social.SocialService`
- **Features**: Forum posts, comments, messaging (P2P and group chat)

### ✅ Listings Service
- **gRPC Port**: 50057
- **Status**: ✅ Configured and Running
- **Proto**: `listings.proto`
- **Ingress Route**: `/listings.ListingsService`
- **Features**: CRUD, auctions, offers, watchlist

### ✅ Shopping Service
- **gRPC Port**: 50058
- **Status**: ✅ Configured and Running
- **Proto**: `shopping.proto`
- **Ingress Route**: `/shopping.ShoppingService`
- **Features**: Shopping cart, checkout

### ✅ Analytics Service
- **gRPC Port**: 50054
- **Status**: ✅ Configured (Service port added)
- **Proto**: `analytics.proto`
- **Ingress Route**: `/analytics.AnalyticsService`
- **Features**: Price prediction, search history, trending searches
- **Note**: Service port was missing and has been added

### ❌ Python AI Service
- **gRPC Port**: N/A
- **Status**: ❌ No gRPC implementation
- **HTTP Port**: 5005
- **Note**: Python service, may not need gRPC if only used for AI inference

### ❌ Auction Monitor
- **gRPC Port**: N/A
- **Status**: ❌ No gRPC implementation
- **Note**: Worker service, may not need gRPC (consumes from Kafka)

## gRPC Ingress Configuration

All gRPC services are exposed via the `record-platform-grpc` Ingress:
- **Host**: `record.local`
- **Protocol**: gRPC over HTTP/2
- **TLS**: Required (TLS 1.2/1.3)
- **Path Format**: `/{ServiceName}.{ServiceName}Service/{Method}`

Example:
```bash
grpcurl -insecure -H "Host: record.local" \
  -d '{}' \
  record.local:8443 \
  /auth.AuthService/HealthCheck
```

## Testing

### Direct Service Testing (from within cluster)
```bash
# Auth Service
grpcurl -plaintext auth-service.record-platform.svc.cluster.local:50051 auth.AuthService/HealthCheck

# Records Service
grpcurl -plaintext records-service.record-platform.svc.cluster.local:50051 records.RecordsService/HealthCheck

# Social Service
grpcurl -plaintext social-service.record-platform.svc.cluster.local:50056 social.SocialService/HealthCheck

# Listings Service
grpcurl -plaintext listings-service.record-platform.svc.cluster.local:50057 listings.ListingsService/HealthCheck

# Shopping Service
grpcurl -plaintext shopping-service.record-platform.svc.cluster.local:50058 shopping.ShoppingService/HealthCheck

# Analytics Service
grpcurl -plaintext analytics-service.record-platform.svc.cluster.local:50054 analytics.AnalyticsService/HealthCheck
```

### Via Ingress (from host)
```bash
# All services use the same ingress endpoint with different paths
grpcurl -insecure -H "Host: record.local" \
  -d '{}' \
  record.local:8443 \
  /{ServiceName}.{ServiceName}Service/HealthCheck
```

## Configuration Checklist

For each service, verify:
- [x] `grpc-server.ts` file exists
- [x] `ENABLE_GRPC` env var set to `"true"` (or not `"false"`)
- [x] `GRPC_PORT` env var set correctly
- [x] Container port exposed in `deploy.yaml`
- [x] Service port exposed in `service.yaml`
- [x] Proto file in `proto-files` ConfigMap
- [x] Ingress route in `ingress-grpc.yaml`
- [x] gRPC server starts in logs

## Known Issues

1. **Logout endpoint**: Still returning 401 - route defined but not matching (needs investigation)
2. **Group chat endpoints**: Proxied to HTTP (not gRPC) - may need proto update
3. **gRPC tests**: May hang if services are not ready - test scripts need better error handling

## Next Steps

1. ✅ Fix analytics-service gRPC service port (DONE)
2. ⏳ Test all gRPC endpoints via ingress
3. ⏳ Fix logout endpoint routing issue
4. ⏳ Add gRPC methods for group chat to social.proto (if needed)
5. ⏳ Verify gRPC client connections from API Gateway

