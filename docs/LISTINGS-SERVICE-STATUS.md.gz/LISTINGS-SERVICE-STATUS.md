# Listings Service - Current Status

**Last Updated**: 2025-11-21

## ✅ What's Working

### Database
- ✅ PostgreSQL database on port 5435
- ✅ Schema `listings` with 7 tables:
  - `listings` - Main listings table
  - `auction_details` - Auction-specific data
  - `bids` - Auction bids
  - `listing_images` - Image uploads
  - `offers` - OBO/Best Offer
  - `watchlist` - User watchlists
  - `listing_views` - Analytics

### Prisma
- ✅ **Prisma generation works** - Use `npx prisma generate` directly
- ⚠️ `pnpm prisma:generate` script has issues, but direct `npx` works
- ✅ Prisma client available at `generated/client`

### Direct PostgreSQL Client (Backup)
- ✅ Created `src/lib/db.ts` with full CRUD operations
- ✅ Works independently of Prisma
- ✅ All listing operations implemented:
  - Create, read, update, delete listings
  - Image management
  - Auction bidding
  - OBO/Best Offer
  - Watchlist management
  - Search functionality

### API Endpoints
- ✅ All endpoints created in `src/routes/listings.ts`
- ✅ Integrated into main server (`src/server.ts`)
- ✅ Health check includes DB connectivity check

## 📋 Available Endpoints

All endpoints require authentication (Bearer token).

### Listings CRUD
- `GET /listings/my-listings` - Get user's listings
- `GET /listings/search?q=...` - Search listings
- `GET /listings/:id` - Get listing details
- `POST /listings` - Create listing
- `PUT /listings/:id` - Update listing
- `DELETE /listings/:id` - Delete listing (soft delete)

### Images
- `POST /listings/:id/images` - Add image to listing

### Auctions
- `POST /listings/:id/bid` - Place bid on auction

### Offers
- `POST /listings/:id/offer` - Make offer (OBO/Best Offer)

### Watchlist
- `POST /listings/:id/watch` - Add to watchlist
- `DELETE /listings/:id/watch` - Remove from watchlist
- `GET /listings/watchlist/mine` - Get user's watchlist

## 🔧 How to Use

### Generate Prisma Client
```bash
cd services/listings-service
POSTGRES_URL_LISTINGS="postgresql://postgres:postgres@localhost:5435/records" npx prisma generate
```

### Run Service
```bash
cd services/listings-service
pnpm dev
# or
pnpm build && pnpm start
```

### Test Endpoints
```bash
# Get auth token first, then:
curl -H "Authorization: Bearer $TOKEN" http://localhost:4003/listings/my-listings
```

## ⚠️ Known Issues

1. **Prisma Script Issue**: `pnpm prisma:generate` fails, but `npx prisma generate` works
   - **Workaround**: Use `npx prisma generate` directly
   - **Alternative**: Use direct PostgreSQL client (`src/lib/db.ts`)

2. **Image Upload**: Endpoints accept image URLs, but file upload handling needs to be added
   - Need to integrate with storage service (S3, R2, etc.)
   - Frontend needs upload component

## 🚧 Next Steps

1. **Wire to Frontend**:
   - Update `webapp/app/(dashboard)/market/page.tsx`
   - Create listing creation form
   - Add image upload component

2. **File Upload**:
   - Implement actual file upload (multipart/form-data)
   - Integrate with storage service
   - Generate thumbnails

3. **API Gateway Integration**:
   - Add listings routes to API Gateway
   - Configure gRPC if needed

4. **Testing**:
   - Add unit tests for DB functions
   - Add integration tests for endpoints
   - Test auction bidding flow
   - Test OBO offer flow

## 📝 Notes

- Service uses **direct PostgreSQL client** (`pg`) as primary approach
- Prisma client is available but optional
- All database operations are in `src/lib/db.ts`
- Service is ready for frontend integration

