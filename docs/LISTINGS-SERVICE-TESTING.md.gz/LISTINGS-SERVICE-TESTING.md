# Listings Service - Testing Guide

**Service**: listings-service  
**HTTP Port**: 4003  
**gRPC Port**: 50057  
**Database**: PostgreSQL port 5435 (schema: `listings`)

## Testing Checklist

### 1. HTTP/2 & HTTP/3 Tests

#### HTTP/2 Tests
```bash
# Health check
curl --http2 -k https://record.local:8443/api/listings/healthz

# Search listings
curl --http2 -k -H "Authorization: Bearer $TOKEN" \
  "https://record.local:8443/api/listings/search?q=vinyl"

# Get user's listings
curl --http2 -k -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/my-listings
```

#### HTTP/3 Tests
```bash
# Health check
curl --http3-only -k https://record.local:8443/api/listings/healthz

# Search listings
curl --http3-only -k -H "Authorization: Bearer $TOKEN" \
  "https://record.local:8443/api/listings/search?q=vinyl"
```

### 2. gRPC Tests

#### Direct gRPC Call (Port 50057)
```bash
# Health check
grpcurl -plaintext localhost:50057 \
  listings.ListingsService/HealthCheck

# Get listing
grpcurl -plaintext -H "Authorization: Bearer $TOKEN" \
  -d '{"listing_id": "..."}' \
  localhost:50057 \
  listings.ListingsService/GetListing

# Search listings
grpcurl -plaintext -H "Authorization: Bearer $TOKEN" \
  -d '{"query": "vinyl", "limit": 10}' \
  localhost:50057 \
  listings.ListingsService/SearchListings
```

#### gRPC via Ingress
```bash
# Health check via ingress
grpcurl -insecure -H "Host: record.local" \
  record.local:8443 \
  listings.ListingsService/HealthCheck

# Get listing via ingress
grpcurl -insecure -H "Host: record.local" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"listing_id": "..."}' \
  record.local:8443/listings.ListingsService/GetListing
```

### 3. Endpoint Tests

#### CRUD Operations
```bash
# Create listing
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Vinyl Record",
    "description": "Mint condition",
    "price": 29.99,
    "listing_type": "fixed_price",
    "condition": "Mint",
    "category": "Vinyl"
  }' \
  https://record.local:8443/api/listings

# Get listing
curl -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/{listing_id}

# Update listing
curl -X PUT -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"price": 24.99}' \
  https://record.local:8443/api/listings/{listing_id}

# Delete listing
curl -X DELETE -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/{listing_id}
```

#### Auction Operations
```bash
# Create auction listing
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Rare Vinyl Auction",
    "price": 50.00,
    "listing_type": "auction",
    "expires_at": "2025-12-01T00:00:00Z"
  }' \
  https://record.local:8443/api/listings

# Place bid
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"bid_amount": 55.00}' \
  https://record.local:8443/api/listings/{listing_id}/bid
```

#### OBO/Best Offer Operations
```bash
# Create OBO listing
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Make an Offer",
    "price": 100.00,
    "listing_type": "obo"
  }' \
  https://record.local:8443/api/listings

# Make offer
curl -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"offer_amount": 85.00, "message": "Would you accept this?"}' \
  https://record.local:8443/api/listings/{listing_id}/offer
```

#### Watchlist Operations
```bash
# Add to watchlist
curl -X POST -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/{listing_id}/watch

# Get watchlist
curl -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/watchlist/mine

# Remove from watchlist
curl -X DELETE -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/listings/{listing_id}/watch
```

### 4. Database Connectivity

```bash
# Test database connection
PGPASSWORD=postgres psql -h localhost -p 5435 -U postgres -d records -c \
  "SELECT COUNT(*) FROM listings.listings;"

# Verify schema
PGPASSWORD=postgres psql -h localhost -p 5435 -U postgres -d records -c \
  "\dt listings.*"
```

### 5. Integration Tests

#### Full Flow Test
1. Create listing (fixed_price)
2. Search for listing
3. Add to watchlist
4. Create auction listing
5. Place bid
6. Create OBO listing
7. Make offer
8. Update listing
9. Delete listing

### 6. Performance Tests

```bash
# Load test search endpoint
ab -n 1000 -c 10 -H "Authorization: Bearer $TOKEN" \
  "https://record.local:8443/api/listings/search?q=vinyl"
```

## Test Scripts to Update

### `scripts/test-microservices-http2-http3.sh`
Add listings-service tests:
- HTTP/2 health check
- HTTP/2 search endpoint
- HTTP/3 health check
- HTTP/3 search endpoint

### `scripts/test-grpc-http2-http3-alpn.sh`
Add listings-service gRPC tests:
- Direct gRPC call (port 50057)
- gRPC via ingress
- ALPN negotiation verification

## Expected Results

### HTTP/2/3
- ✅ All endpoints respond over HTTP/2
- ✅ All endpoints respond over HTTP/3
- ✅ ALPN negotiation works correctly
- ✅ TLS handshake succeeds

### gRPC
- ✅ Direct gRPC calls work (port 50057)
- ✅ gRPC via ingress works (`/listings.ListingsService`)
- ✅ HTTP/2 used for gRPC transport
- ✅ Authentication via metadata works

### Database
- ✅ Connection to port 5435 succeeds
- ✅ All CRUD operations work
- ✅ Auction bidding works
- ✅ OBO offers work
- ✅ Watchlist operations work

## Known Issues

None currently. Report any issues to the testing agent.

## Next Steps

1. ✅ Add listings-service to test scripts
2. ✅ Verify HTTP/2/3 endpoints
3. ✅ Verify gRPC endpoints
4. ✅ Test all CRUD operations
5. ✅ Test auction bidding flow
6. ✅ Test OBO offer flow
7. ✅ Performance testing

