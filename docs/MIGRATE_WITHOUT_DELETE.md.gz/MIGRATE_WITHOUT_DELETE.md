# Migrating to Multi-Node Without Deleting Cluster

## The Challenge

Kind doesn't support adding nodes to an existing cluster. We need alternative approaches that don't require deleting your current cluster.

## Option 1: Create New Cluster and Migrate Resources (Recommended)

This approach creates a new multi-node cluster alongside your existing one, then migrates resources.

### Step 1: Create New Multi-Node Cluster

```bash
# Create new cluster with different name
CLUSTER_NAME=h3-multi ./scripts/setup-multi-node-cluster.sh

# Or manually:
cat > /tmp/kind-multi-node.yaml <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: h3-multi
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 443
    hostPort: 8443
    protocol: TCP
  - containerPort: 443
    hostPort: 8443
    protocol: UDP
- role: worker
- role: worker
EOF

kind create cluster --config /tmp/kind-multi-node.yaml --name h3-multi
```

### Step 2: Export Resources from Old Cluster

```bash
# Switch to old cluster
kubectl config use-context kind-h3

# Export all resources (adjust namespaces as needed)
kubectl get all -n ingress-nginx -o yaml > /tmp/ingress-nginx-resources.yaml
kubectl get all -n record-platform -o yaml > /tmp/record-platform-resources.yaml
kubectl get configmaps,secrets -n ingress-nginx -o yaml > /tmp/ingress-nginx-config.yaml
kubectl get configmaps,secrets -n record-platform -o yaml > /tmp/record-platform-config.yaml
```

### Step 3: Switch to New Cluster and Apply

```bash
# Switch to new cluster
kubectl config use-context kind-h3-multi

# Create namespaces
kubectl create namespace ingress-nginx
kubectl create namespace record-platform

# Apply resources (may need to remove cluster-specific fields)
kubectl apply -f /tmp/ingress-nginx-resources.yaml
kubectl apply -f /tmp/record-platform-resources.yaml
kubectl apply -f /tmp/ingress-nginx-config.yaml
kubectl apply -f /tmp/record-platform-config.yaml

# Apply base resources
kubectl apply -k infra/k8s/base

# Apply production overlay with 2 replicas
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml
```

### Step 4: Verify and Test

```bash
# Check pods are on different nodes
kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide

# Test CA rotation
./scripts/test-full-chain-with-rotation.sh
```

### Step 5: Switch Default Context (Optional)

```bash
# Make new cluster the default
kubectl config use-context kind-h3-multi

# Or keep both and switch as needed
kubectl config get-contexts
```

## Option 2: Remove hostNetwork (Allows Multiple Replicas on Same Node)

If you can't create a new cluster, remove `hostNetwork` to allow multiple replicas on the same node.

### Modify Deployment

```yaml
# Remove hostNetwork
spec:
  # hostNetwork: true  # Comment out or remove
  containers:
  - ports:
    - containerPort: 443
      # No hostNetwork, so multiple pods can bind to different ports
```

### Create Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
  namespace: ingress-nginx
spec:
  type: NodePort  # Or LoadBalancer
  ports:
  - port: 443
    targetPort: 443
    nodePort: 30443  # Or let Kubernetes assign
  selector:
    app: caddy-h3
```

### Update Port Mappings

You'll need to update:
- Caddyfile (if it references specific ports)
- Client connections (use NodePort instead of hostPort)
- Port-forward commands

**Pros:**
- ✅ Multiple replicas on same node
- ✅ True zero-downtime with RollingUpdate
- ✅ No cluster migration needed

**Cons:**
- ⚠️ Requires changing port mappings
- ⚠️ May need to update client configurations
- ⚠️ NodePort/LoadBalancer instead of direct host access

## Option 3: Use K3d or Minikube (Alternative to Kind)

These tools may support adding nodes more easily:

### K3d

```bash
# Install k3d
brew install k3d

# Create multi-node cluster
k3d cluster create h3-multi \
  --servers 1 \
  --agents 2 \
  -p "8443:443@loadbalancer"

# Migrate resources (similar to Kind process)
```

### Minikube

```bash
# Install minikube
brew install minikube

# Create multi-node cluster
minikube start --nodes 3

# Migrate resources
```

## Option 4: Accept Current Limitation

If migration isn't feasible right now:

- Keep 1 replica
- Accept ~50-70% success during rotation
- Plan migration for maintenance window
- Document the limitation

## Recommendation

**Best approach:** Option 1 (New cluster + migrate)
- Clean separation
- No risk to existing cluster
- Can test before switching
- Can keep both clusters running temporarily

**Quickest approach:** Option 2 (Remove hostNetwork)
- No cluster migration
- Faster to implement
- Requires port mapping changes

## Migration Script

Here's a helper script to export/import resources:

```bash
#!/bin/bash
# migrate-cluster.sh

OLD_CLUSTER="${1:-h3}"
NEW_CLUSTER="${2:-h3-multi}"

echo "Exporting from $OLD_CLUSTER..."
kubectl config use-context kind-$OLD_CLUSTER
kubectl get all,configmaps,secrets -A -o yaml > /tmp/cluster-export.yaml

echo "Importing to $NEW_CLUSTER..."
kubectl config use-context kind-$NEW_CLUSTER
kubectl apply -f /tmp/cluster-export.yaml

echo "Done! Verify with: kubectl get all -A"
```

## Summary

Since Kind doesn't support adding nodes, you have these options:

1. ✅ **Create new multi-node cluster** (safest, recommended)
2. ✅ **Remove hostNetwork** (fastest, requires changes)
3. ✅ **Use different tool** (k3d/minikube)
4. ⚠️ **Accept limitation** (keep 1 replica)

Choose based on your constraints and timeline!

