# Migration to Multi-Node Cluster for 100% Zero-Downtime

## Overview

This guide walks you through migrating from a single-node cluster to a multi-node cluster to achieve **100% success rate** during CA rotation.

## Why Multi-Node?

With `hostNetwork: true`, only **1 pod per node** can bind to port 443. For zero-downtime with 2 replicas, you need:
- **2+ nodes** (one pod per node)
- **RollingUpdate strategy** with `maxUnavailable: 0`
- **Pod anti-affinity** to ensure pods are on different nodes

## Step-by-Step Migration

### Step 1: Backup Current State

```bash
# Export current resources (optional, for reference)
kubectl get all -A -o yaml > /tmp/cluster-backup.yaml

# Note your current Caddy configuration
kubectl get configmap -n ingress-nginx caddy-h3 -o yaml > /tmp/caddy-configmap.yaml
kubectl get secret -n ingress-nginx record-local-tls -o yaml > /tmp/caddy-tls-secret.yaml
```

### Step 2: Set Up Multi-Node Cluster

```bash
# Run the setup script
./scripts/setup-multi-node-cluster.sh
```

This will:
- Delete existing single-node cluster (with confirmation)
- Create new multi-node cluster:
  - 1 control-plane node (with port 8443 mappings)
  - 2 worker nodes
- Wait for all nodes to be ready

### Step 3: Verify Cluster

```bash
# Check nodes
kubectl get nodes -o wide

# Should show 3 nodes:
# - h3-control-plane (control-plane)
# - h3-worker (worker)
# - h3-worker2 (worker)
```

### Step 4: Re-apply Base Resources

```bash
# Apply base Kubernetes resources
kubectl apply -k infra/k8s/base

# Wait for all pods to be ready
kubectl wait --for=condition=Ready pods --all -A --timeout=300s
```

### Step 5: Apply Production Overlay

```bash
# Apply production config with 2 replicas
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml
```

### Step 6: Verify Pod Distribution

```bash
# Check that pods are on different nodes
kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide

# Should show:
# - caddy-h3-xxx-xxx on h3-worker
# - caddy-h3-yyy-yyy on h3-worker2
# Both should be Running and Ready
```

### Step 7: Test CA Rotation

```bash
# Run the full chain test with rotation
./scripts/test-full-chain-with-rotation.sh
```

**Expected result:**
```
✅ Zero-downtime rotation confirmed! (100% success rate - 120/120 requests)
```

## How It Works

### Before (Single-Node, 1 Replica)
```
Node 1: [Caddy Pod] (port 443)
        ↓
Rotation: Pod restarts → Brief downtime → ~50-70% success
```

### After (Multi-Node, 2 Replicas)
```
Node 1: [Caddy Pod 1] (port 443) ← Old pod stays up
Node 2: [Caddy Pod 2] (port 443) ← New pod starts here
        ↓
Rotation: Old pod serves traffic while new pod starts
         → Zero downtime → 100% success ✅
```

### RollingUpdate Process

1. **Update secret** with new certificate
2. **Kubernetes starts new pod** on Node 2 (old pod still on Node 1)
3. **New pod loads new certificate** from updated secret
4. **New pod becomes Ready** (readiness probe passes)
5. **Traffic shifts** to new pod (via service/load balancer)
6. **Old pod terminates** gracefully
7. **Result:** Zero downtime, 100% success rate

## Verification Commands

```bash
# Check deployment strategy
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.strategy}'

# Check replica count
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.replicas}'

# Check pod distribution
kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide

# Check pod anti-affinity
kubectl get deployment -n ingress-nginx caddy-h3 -o yaml | grep -A 10 affinity

# Monitor during rotation
watch kubectl get pods -n ingress-nginx -l app=caddy-h3
```

## Troubleshooting

### Pods Stuck in Pending

**Symptom:** One pod is `Pending`, other is `Running`

**Cause:** Not enough nodes, or pod anti-affinity too strict

**Solution:**
```bash
# Check node count
kubectl get nodes

# Check why pod is pending
kubectl describe pod -n ingress-nginx <pending-pod-name>

# If needed, add more worker nodes to cluster
```

### Port Conflict

**Symptom:** Pods can't bind to port 443

**Cause:** Multiple pods trying to bind to same port on same node

**Solution:**
- Verify pod anti-affinity is working
- Ensure pods are on different nodes
- Check `kubectl get pods -o wide` to see node distribution

### Rotation Still Shows < 100%

**Symptom:** Test shows < 100% success rate

**Possible causes:**
1. Pods on same node (check with `kubectl get pods -o wide`)
2. Readiness probe too slow (pods not ready when traffic shifts)
3. RollingUpdate not working (check deployment strategy)

**Solution:**
```bash
# Verify pod distribution
kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide

# Check readiness probe timing
kubectl get deployment -n ingress-nginx caddy-h3 -o yaml | grep -A 5 readinessProbe

# Check deployment strategy
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.strategy}'
```

## Rollback (If Needed)

If you need to go back to single-node:

```bash
# Delete multi-node cluster
kind delete cluster --name h3

# Recreate single-node cluster (your original setup)
# Then apply with replicas: 1
```

## Next Steps

After successful migration:
1. ✅ Test CA rotation: `./scripts/test-full-chain-with-rotation.sh`
2. ✅ Verify 100% success rate
3. ✅ Document any custom configurations
4. ✅ Update CI/CD pipelines if needed

## Summary

- **Before:** Single-node, 1 replica → ~50-70% success
- **After:** Multi-node, 2 replicas → 100% success ✅

The multi-node setup enables true zero-downtime CA rotation with RollingUpdate strategy!

