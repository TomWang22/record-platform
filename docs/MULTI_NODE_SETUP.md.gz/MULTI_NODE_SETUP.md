# Multi-Node Setup for True Zero-Downtime CA Rotation

## Overview

To achieve **100% success rate** during CA rotation with 2+ replicas, you need multiple Kubernetes nodes. This is because `hostNetwork: true` means only 1 pod per node can bind to port 443.

## Current Limitation (Single-Node)

- **Current Setup**: 1 node cluster
- **Replicas**: 1 (can't run 2 with hostNetwork on single node)
- **Strategy**: RollingUpdate
- **Success Rate**: Should be 100% even with 1 replica (old pod stays up until new is ready)

## Multi-Node Setup

### Option 1: Add Worker Nodes to Kind Cluster

```bash
# Create multi-node Kind cluster
cat > kind-multi-node.yaml <<EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
name: h3
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 443
    hostPort: 8443
    protocol: TCP
  - containerPort: 443
    hostPort: 8443
    protocol: UDP
- role: worker
- role: worker
EOF

kind create cluster --config kind-multi-node.yaml --name h3
```

### Option 2: Use Production Kubernetes Cluster

Deploy to a production cluster with multiple nodes (GKE, EKS, AKS, etc.)

## Configuration for Multi-Node

Once you have multiple nodes, update the deployment:

```yaml
replicas: 2  # Or more, one per node
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

With pod anti-affinity (already configured), pods will be scheduled on different nodes:
- Node 1: Pod 1 (port 443)
- Node 2: Pod 2 (port 443)

During CA rotation:
1. New pod starts on Node 2 (old pod still on Node 1)
2. New pod ready → traffic shifts
3. Old pod terminates
4. **Result**: 100% success rate, zero downtime

## Testing

After setting up multi-node cluster:

```bash
# Apply production config
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml

# Verify pods are on different nodes
kubectl get pods -n ingress-nginx -l app=caddy-h3 -o wide

# Test CA rotation
./scripts/test-full-chain-with-rotation.sh

# Expected: ✅ Zero-downtime rotation confirmed! (100% success rate)
```

## Alternative: Remove hostNetwork

If you can't use multiple nodes, consider removing `hostNetwork` and using NodePort/LoadBalancer:

```yaml
spec:
  # Remove hostNetwork
  # hostNetwork: true  # Comment out or remove
  containers:
  - ports:
    - containerPort: 443
      # No hostNetwork, so multiple pods can run on same node
```

Then use a Service:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: caddy-h3
spec:
  type: NodePort  # Or LoadBalancer
  ports:
  - port: 443
    targetPort: 443
```

This allows multiple replicas on the same node, but requires updating port mappings and Caddyfile.

