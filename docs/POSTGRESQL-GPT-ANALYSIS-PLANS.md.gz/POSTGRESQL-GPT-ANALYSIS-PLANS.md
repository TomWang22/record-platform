# PostgreSQL GPT Analysis Plans

**Purpose**: Comprehensive analysis plans that can be sent to PostgreSQL GPT for database tuning and optimization.

## Database Inventory

### 1. Main Database (Records) - Port 5433
- **Database**: `records`
- **Schemas**: `records`, `records_hot`, `auth`, `analytics`, `listings` (legacy search history)
- **Target Scale**: **2.4M rows** (not 1.2M - reference corrected)
- **Hot Tenant**: `0dc268d0-a86f-4e12-8d10-9db0f1b735e0` (~110k rows in hot slice)
- **Connection**: `postgresql://postgres:postgres@localhost:5433/records`

### 2. Social Database - Port 5434
- **Database**: `records`
- **Schemas**: `forum`, `messages`
- **Target Scale**: Similar to main DB (2.4M reference)
- **Connection**: `postgresql://postgres:postgres@localhost:5434/records`

### 3. Listings Database - Port 5435
- **Database**: `records`
- **Schema**: `listings`
- **Target Scale**: Similar to main DB (2.4M reference)
- **Connection**: `postgresql://postgres:postgres@localhost:5435/records`

## Analysis Plan for Main Database (Records)

### Step 1: Collect Current State

```sql
-- Connection string
-- postgresql://postgres:postgres@localhost:5433/records

-- 1. Table Statistics
SELECT 
  schemaname,
  relname AS tablename,
  n_live_tup AS row_count,
  n_dead_tup AS dead_rows,
  last_vacuum,
  last_autovacuum,
  last_analyze,
  last_autoanalyze,
  pg_size_pretty(pg_total_relation_size((schemaname||'.'||relname)::regclass)) AS total_size,
  pg_size_pretty(pg_relation_size((schemaname||'.'||relname)::regclass)) AS table_size,
  pg_size_pretty(pg_total_relation_size((schemaname||'.'||relname)::regclass) - 
                 pg_relation_size((schemaname||'.'||relname)::regclass)) AS index_size
FROM pg_stat_user_tables 
WHERE schemaname IN ('records', 'records_hot', 'auth', 'analytics')
ORDER BY schemaname, pg_total_relation_size((schemaname||'.'||relname)::regclass) DESC;

-- 2. Index Statistics
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan AS index_scans,
  idx_tup_read AS tuples_read,
  idx_tup_fetch AS tuples_fetched,
  pg_size_pretty(pg_relation_size((schemaname||'.'||indexname)::regclass)) AS size
FROM pg_stat_user_indexes
WHERE schemaname IN ('records', 'records_hot', 'auth', 'analytics')
ORDER BY pg_relation_size((schemaname||'.'||indexname)::regclass) DESC
LIMIT 50;

-- 3. Query Plans for Key Queries
-- Run EXPLAIN (ANALYZE, BUFFERS) for:
-- - search_records_fuzzy_ids() function calls
-- - TRGM queries
-- - KNN queries
-- Save output to: docs/bench/explains/<timestamp>/

-- 4. PostgreSQL Configuration
SELECT name, setting, unit, source, context
FROM pg_settings
WHERE name IN (
  'shared_buffers',
  'effective_cache_size',
  'work_mem',
  'maintenance_work_mem',
  'random_page_cost',
  'cpu_index_tuple_cost',
  'cpu_tuple_cost',
  'enable_seqscan',
  'jit',
  'max_parallel_workers',
  'max_parallel_workers_per_gather',
  'track_io_timing',
  'effective_io_concurrency',
  'checkpoint_completion_target',
  'max_wal_size',
  'synchronous_commit',
  'max_connections',
  'pg_trgm.similarity_threshold'
)
ORDER BY name;

-- 5. Function Definition
SELECT pg_get_functiondef('public.search_records_fuzzy_ids(uuid,text,bigint,bigint)'::regprocedure);
```

### Step 2: Performance Analysis

```sql
-- 1. pg_stat_statements (if enabled)
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  stddev_exec_time,
  max_exec_time,
  (shared_blks_hit::float / NULLIF(shared_blks_hit + shared_blks_read, 0)) * 100 AS cache_hit_ratio
FROM pg_stat_statements
WHERE query LIKE '%search_records_fuzzy_ids%'
   OR query LIKE '%similarity%'
   OR query LIKE '%trgm%'
ORDER BY total_exec_time DESC
LIMIT 20;

-- 2. Slow Queries
SELECT 
  query,
  calls,
  mean_exec_time,
  max_exec_time
FROM pg_stat_statements
WHERE mean_exec_time > 10  -- queries taking > 10ms on average
ORDER BY mean_exec_time DESC
LIMIT 20;

-- 3. Index Usage Analysis
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan,
  idx_tup_read,
  idx_tup_fetch,
  CASE 
    WHEN idx_scan = 0 THEN 'UNUSED'
    WHEN idx_scan < 10 THEN 'RARELY_USED'
    ELSE 'ACTIVE'
  END AS usage_status
FROM pg_stat_user_indexes
WHERE schemaname IN ('records', 'records_hot')
  AND idx_scan = 0
ORDER BY pg_relation_size((schemaname||'.'||indexname)::regclass) DESC;
```

### Step 3: Tuning Recommendations

**Key Areas for PostgreSQL GPT Analysis**:
1. **Index Strategy**: Partial indexes vs global indexes for 2.4M row dataset
2. **Query Plan Optimization**: FTS + TRGM function tuning
3. **Connection Pooling**: max_connections=400 vs work_mem tradeoffs
4. **Cache Configuration**: shared_buffers, effective_cache_size for dataset size
5. **Vacuum/Analyze**: Autovacuum tuning for high write volume
6. **Hot Partition**: records_hot schema optimization for frequently accessed data

## Analysis Plan for Social Database

### Step 1: Collect Current State

```sql
-- Connection string
-- postgresql://postgres:postgres@localhost:5434/records

-- 1. Schema Overview
SELECT 
  schemaname,
  tablename,
  n_live_tup AS row_count,
  pg_size_pretty(pg_total_relation_size((schemaname||'.'||tablename)::regclass)) AS total_size
FROM pg_stat_user_tables
WHERE schemaname IN ('forum', 'messages')
ORDER BY schemaname, tablename;

-- 2. Index Analysis
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan,
  pg_size_pretty(pg_relation_size((schemaname||'.'||indexname)::regclass)) AS size
FROM pg_stat_user_indexes
WHERE schemaname IN ('forum', 'messages')
ORDER BY pg_relation_size((schemaname||'.'||indexname)::regclass) DESC;

-- 3. Query Plans for Key Operations
-- Forum queries:
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM forum.posts 
WHERE is_active = true 
ORDER BY created_at DESC 
LIMIT 50;

EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM forum.posts 
WHERE user_id = '...'::uuid 
ORDER BY created_at DESC;

-- Message queries:
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM messages.messages
WHERE recipient_id = '...'::uuid
  AND is_read = false
ORDER BY created_at DESC;

EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM messages.messages
WHERE group_id = '...'::uuid
ORDER BY created_at DESC;

-- 4. Configuration Check
SELECT name, setting, unit
FROM pg_settings
WHERE name IN (
  'shared_buffers',
  'effective_cache_size',
  'work_mem',
  'random_page_cost',
  'max_connections'
);
```

### Step 2: Performance Analysis

```sql
-- 1. Attachment Table Sizes (file uploads)
SELECT 
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size((schemaname||'.'||tablename)::regclass)) AS size,
  n_live_tup AS row_count
FROM pg_stat_user_tables
WHERE tablename LIKE '%attachment%'
ORDER BY pg_total_relation_size((schemaname||'.'||tablename)::regclass) DESC;

-- 2. Read Receipt Analysis
SELECT 
  COUNT(*) AS total_reads,
  COUNT(*) FILTER (WHERE read_by_sender = true) AS sender_visible_reads,
  AVG(EXTRACT(EPOCH FROM (read_at - created_at))) AS avg_seconds_to_read
FROM messages.message_reads mr
JOIN messages.messages m ON mr.message_id = m.id;

-- 3. Forum Post Popularity
SELECT 
  upvotes,
  COUNT(*) AS post_count,
  AVG(comment_count) AS avg_comments
FROM forum.posts
GROUP BY upvotes
ORDER BY upvotes DESC
LIMIT 20;
```

### Step 3: Tuning Recommendations for PostgreSQL GPT

**Key Areas**:
1. **TRGM Indexes**: Forum post/comment search optimization
2. **Attachment Storage**: Large file reference optimization
3. **Read Receipts**: Efficient tracking of message reads
4. **Group Messaging**: Query optimization for group message threads
5. **Vote Aggregation**: Efficient upvote/downvote counting

## Analysis Plan for Listings Database

### Step 1: Collect Current State

```sql
-- Connection string
-- postgresql://postgres:postgres@localhost:5435/records

-- 1. Schema Overview
SELECT 
  schemaname,
  tablename,
  n_live_tup AS row_count,
  pg_size_pretty(pg_total_relation_size((schemaname||'.'||tablename)::regclass)) AS total_size
FROM pg_stat_user_tables
WHERE schemaname = 'listings'
ORDER BY tablename;

-- 2. Index Analysis
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_scan,
  pg_size_pretty(pg_relation_size((schemaname||'.'||indexname)::regclass)) AS size
FROM pg_stat_user_indexes
WHERE schemaname = 'listings'
ORDER BY pg_relation_size((schemaname||'.'||indexname)::regclass) DESC;

-- 3. Query Plans for Key Operations
-- Search listings:
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM listings.listings
WHERE is_active = true
  AND title ILIKE '%vinyl%'
ORDER BY created_at DESC
LIMIT 50;

-- Auction queries:
EXPLAIN (ANALYZE, BUFFERS)
SELECT l.*, ad.current_bid, ad.end_time
FROM listings.listings l
JOIN listings.auction_details ad ON l.id = ad.listing_id
WHERE l.listing_type = 'auction'
  AND ad.end_time > now()
ORDER BY ad.end_time ASC;

-- Watchlist queries:
EXPLAIN (ANALYZE, BUFFERS)
SELECT l.*
FROM listings.listings l
JOIN listings.watchlist w ON l.id = w.listing_id
WHERE w.user_id = '...'::uuid
  AND l.is_active = true
ORDER BY w.created_at DESC;

-- 4. Configuration Check
SELECT name, setting, unit
FROM pg_settings
WHERE name IN (
  'shared_buffers',
  'effective_cache_size',
  'work_mem',
  'random_page_cost',
  'max_connections'
);
```

### Step 2: Performance Analysis

```sql
-- 1. Auction Performance
SELECT 
  COUNT(*) AS active_auctions,
  AVG(bid_count) AS avg_bids,
  MAX(bid_count) AS max_bids,
  AVG(EXTRACT(EPOCH FROM (end_time - start_time))) AS avg_duration_seconds
FROM listings.auction_details
WHERE end_time > now();

-- 2. Listing Type Distribution
SELECT 
  listing_type,
  COUNT(*) AS count,
  AVG(price) AS avg_price,
  AVG(view_count) AS avg_views
FROM listings.listings
WHERE is_active = true
GROUP BY listing_type;

-- 3. Image Storage Analysis
SELECT 
  COUNT(*) AS total_images,
  SUM(file_size) AS total_bytes,
  pg_size_pretty(SUM(file_size)) AS total_size,
  AVG(file_size) AS avg_file_size
FROM listings.listing_images;
```

### Step 3: Tuning Recommendations for PostgreSQL GPT

**Key Areas**:
1. **Search Optimization**: TRGM indexes for title/description search
2. **Auction Bidding**: Real-time bid update performance
3. **Image References**: Efficient image metadata queries
4. **Price Range Queries**: Index optimization for price filtering
5. **Watchlist Scalability**: Efficient watchlist query patterns

## How to Generate Analysis for PostgreSQL GPT

### Automated Analysis Script

```bash
#!/usr/bin/env bash
# scripts/generate-postgresql-gpt-analysis.sh

# For each database, generate comprehensive analysis
for db in "main:5433" "social:5434" "listings:5435"; do
  name=$(echo $db | cut -d: -f1)
  port=$(echo $db | cut -d: -f2)
  
  echo "=== Generating analysis for $name database (port $port) ==="
  
  PGPASSWORD=postgres psql \
    -h localhost -p $port -U postgres -d records \
    -f "docs/analysis-queries/${name}-analysis.sql" \
    -o "docs/postgresql-gpt-analysis/${name}-$(date +%Y%m%d_%H%M%S).txt"
done
```

### Manual Analysis Steps

1. **Connect to database**:
   ```bash
   psql -h localhost -p 5433 -U postgres -d records  # Main
   psql -h localhost -p 5434 -U postgres -d records  # Social
   psql -h localhost -p 5435 -U postgres -d records  # Listings
   ```

2. **Run analysis queries** (from this document)

3. **Save EXPLAIN plans**:
   ```sql
   EXPLAIN (ANALYZE, BUFFERS, VERBOSE) <your_query>;
   ```

4. **Send to PostgreSQL GPT** with:
   - Database schema (from Prisma or SQL migrations)
   - Current configuration (pg_settings output)
   - Query plans (EXPLAIN output)
   - Performance metrics (pg_stat_* views)
   - Target: 2.4M row scale, 28k TPS reference

## Key Metrics to Track

### Main Database
- TPS: Target 28,000 TPS
- Latency: Target 1.5ms avg, <30ms p95
- Row count: 2.4M total, 110k hot tenant
- Index efficiency: Partial indexes for hot tenant

### Social Database
- Forum query latency: <50ms p95
- Message query latency: <20ms p95
- Attachment query performance
- Read receipt tracking efficiency

### Listings Database
- Search query latency: <50ms p95
- Auction bid update latency: <10ms
- Image metadata queries: <20ms p95
- Watchlist query performance

## Next Steps

1. **Run comprehensive setup**:
   ```bash
   ./scripts/setup-and-optimize-social-db.sh
   ./scripts/setup-and-optimize-listings-db.sh
   ```

2. **Generate analysis**:
   ```bash
   # Run analysis queries for each database
   # Save EXPLAIN plans
   # Document current state
   ```

3. **Send to PostgreSQL GPT**:
   - Include schema files
   - Include query plans
   - Include performance metrics
   - Reference 2.4M row scale target
   - Ask for optimization recommendations

