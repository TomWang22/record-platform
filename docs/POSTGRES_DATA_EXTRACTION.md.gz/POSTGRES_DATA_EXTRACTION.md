# PostgreSQL Data Extraction Guide

**Date:** January 2025  
**Purpose:** Extract PostgreSQL databases from Docker volumes into SQL dumps for backup and migration

---

## Overview

This guide explains how to extract PostgreSQL databases from Docker Compose volumes into SQL dump files. This is useful for:
- Creating backups before major changes
- Migrating data between environments
- Extracting data from Docker Desktop volumes when moving to Colima
- Creating permanent backups outside of Docker volumes

---

## Architecture

The record-platform uses **8 dedicated PostgreSQL instances** running in Docker Compose:

| Service | Port | Database | Schema | Volume |
|---------|------|----------|--------|--------|
| postgres | 5433 | postgres | records | pgdata |
| postgres-auth | 5437 | postgres | auth | pgdata-auth |
| postgres-social | 5434 | postgres | social | pgdata-social |
| postgres-listings | 5435 | postgres | listings | pgdata-listings |
| postgres-shopping | 5436 | postgres | shopping | pgdata-shopping |
| postgres-auction-monitor | 5438 | postgres | auction_monitor | pgdata-auction-monitor |
| postgres-analytics | 5439 | postgres | analytics | pgdata-analytics |
| postgres-python-ai | 5440 | postgres | python_ai | pgdata-python-ai |

**Data Location:**
- **Docker Volumes**: Data is stored in Docker volumes (not in `Docker.raw` directly)
- **Volume Names**: `record-platform_pgdata*`
- **Access**: Data is accessed through running containers via `pg_dump`

---

## Quick Start

### Extract All Databases

```bash
# Extract all databases to ./backups/extracted-TIMESTAMP/
./scripts/extract-postgres-databases.sh
```

### Extract Without Compression

```bash
COMPRESS=false ./scripts/extract-postgres-databases.sh
```

### Extract to Custom Directory

```bash
BACKUP_DIR=/path/to/backups ./scripts/extract-postgres-databases.sh
```

---

## Extraction Script: `extract-postgres-databases.sh`

### Features

- ✅ Extracts all 8 PostgreSQL databases
- ✅ Schema-specific dumps (only relevant schemas)
- ✅ Fallback to full database dumps if schema extraction fails
- ✅ Optional compression (gzip)
- ✅ Health checks before extraction
- ✅ Detailed logging and summary

### Usage

```bash
# Basic usage
./scripts/extract-postgres-databases.sh

# With environment variables
BACKUP_DIR=/custom/path COMPRESS=false ./scripts/extract-postgres-databases.sh
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BACKUP_DIR` | `./backups/extracted-TIMESTAMP` | Directory to save SQL dumps |
| `COMPRESS` | `true` | Compress SQL files with gzip |

### Output

The script creates:
- **SQL dump files**: One per database/schema (`.sql` or `.sql.gz`)
- **Log files**: Extraction logs (`.sql.log`)
- **Summary file**: `extraction-summary.txt` with details

Example output structure:
```
backups/extracted-20250107-123456/
├── postgres-records-20250107-123456.sql.gz
├── postgres-records-20250107-123456.sql.log
├── postgres-auth-auth-20250107-123456.sql.gz
├── postgres-auth-auth-20250107-123456.sql.log
├── ...
└── extraction-summary.txt
```

---

## Restore Script: `restore-postgres-databases.sh`

### Features

- ✅ Restores from both compressed (`.sql.gz`) and uncompressed (`.sql`) files
- ✅ Automatically finds the most recent backup for each database
- ✅ Schema-only or full database restore modes
- ✅ Safety prompts (unless `FORCE=true`)

### Usage

```bash
# Restore from default backup directory
./scripts/restore-postgres-databases.sh

# Restore from custom directory
BACKUP_DIR=/path/to/backups ./scripts/restore-postgres-databases.sh

# Force restore without prompts
FORCE=true ./scripts/restore-postgres-databases.sh

# Full database restore (drops and recreates database)
RESTORE_MODE=full FORCE=true ./scripts/restore-postgres-databases.sh
```

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BACKUP_DIR` | `./backups` | Directory containing SQL dumps |
| `RESTORE_MODE` | `schema` | `schema` (schema-only) or `full` (full database) |
| `FORCE` | `false` | Skip confirmation prompts |

---

## Manual Extraction

If you need to extract a single database manually:

### Extract Schema Only

```bash
docker compose exec -T postgres-auth pg_dump \
  -U postgres \
  -d postgres \
  --schema=auth \
  --clean \
  --if-exists \
  --no-owner \
  --no-privileges \
  > backups/auth-schema.sql
```

### Extract Full Database

```bash
docker compose exec -T postgres-auth pg_dump \
  -U postgres \
  -d postgres \
  --clean \
  --if-exists \
  --create \
  --no-owner \
  --no-privileges \
  > backups/auth-full.sql
```

### Compress Output

```bash
docker compose exec -T postgres-auth pg_dump \
  -U postgres \
  -d postgres \
  --schema=auth \
  --clean \
  --if-exists \
  --no-owner \
  --no-privileges \
  | gzip > backups/auth-schema.sql.gz
```

---

## Existing Backups

The `backups/` directory already contains SQL dumps from January 1, 2025:

| File | Size | Description |
|------|------|-------------|
| `record-platform-postgres-1-all-20260101-223214.sql` | 1.0G | Main records database |
| `record-platform-postgres-listings-1-all-20260101-223214.sql` | 658M | Listings database |
| `record-platform-postgres-social-1-all-20260101-223214.sql` | 165M | Social database |
| `record-platform-postgres-auth-1-all-20260101-223214.sql` | 36M | Auth database |
| `record-platform-postgres-shopping-1-all-20260101-223214.sql` | 16M | Shopping database |
| `record-platform-postgres-python-ai-1-all-20260101-223214.sql` | 13M | Python AI database |
| `record-platform-postgres-auction-monitor-1-all-20260101-223214.sql` | 65K | Auction Monitor database |
| `record-platform-postgres-analytics-1-all-20260101-223214.sql` | 22K | Analytics database |

**Note:** These are full database dumps (all schemas), not schema-specific.

---

## Data Migration: Docker Desktop → Colima

### Background

When moving from Docker Desktop to Colima:
- **Docker volumes persist** - Data is not lost
- **Volume names remain the same** - `record-platform_pgdata*`
- **Access method changes** - Use `docker compose` (now using Colima's Docker socket)

### Migration Steps

1. **Extract data from Docker Desktop** (if Docker Desktop is still accessible):
   ```bash
   # Switch to Docker Desktop context if needed
   docker context use desktop-linux
   ./scripts/extract-postgres-databases.sh
   ```

2. **Start Docker Compose with Colima**:
   ```bash
   # Colima should be running and Docker context set to Colima
   docker compose up -d
   ```

3. **Restore data into Colima**:
   ```bash
   BACKUP_DIR=./backups/extracted-TIMESTAMP ./scripts/restore-postgres-databases.sh
   ```

---

## Troubleshooting

### Container Not Healthy

**Error:** `Container postgres-auth is not healthy/running`

**Solution:**
```bash
# Check container status
docker compose ps postgres-auth

# Check logs
docker compose logs postgres-auth

# Restart container
docker compose restart postgres-auth

# Wait for health check
docker compose ps postgres-auth  # Should show "healthy"
```

### Permission Denied

**Error:** `Permission denied` when accessing volumes

**Solution:**
- Ensure Docker Compose is running: `docker compose ps`
- Check container is healthy: `docker compose ps <service>`
- Verify Docker socket permissions

### Schema Not Found

**Error:** `schema "auth" does not exist`

**Solution:**
- The schema might not exist yet. The restore script will create it automatically.
- For manual creation:
  ```bash
  docker compose exec -T postgres-auth psql -U postgres -c "CREATE SCHEMA IF NOT EXISTS auth;"
  ```

### Out of Disk Space

**Error:** `No space left on device`

**Solution:**
- Check disk space: `df -h`
- Use compression: `COMPRESS=true ./scripts/extract-postgres-databases.sh`
- Extract to a different location: `BACKUP_DIR=/external/drive/backups ./scripts/extract-postgres-databases.sh`

---

## Best Practices

1. **Regular Backups**: Run extraction script before major changes or migrations
2. **Verify Backups**: Check that SQL files are not empty and have reasonable sizes
3. **Compression**: Use compression for storage efficiency (saves ~70-90% space)
4. **Test Restores**: Periodically test restore process to ensure backups are valid
5. **Multiple Locations**: Store backups in multiple locations (local + cloud/external drive)
6. **Version Control**: Include timestamps in backup filenames for version tracking

---

## Related Files

- **Extraction Script**: `scripts/extract-postgres-databases.sh`
- **Restore Script**: `scripts/restore-postgres-databases.sh`
- **Backup Directory**: `backups/`
- **Docker Compose Config**: `docker-compose.yml`
- **Schema Definitions**: `infra/db/*.sql`

---

## References

- [PostgreSQL pg_dump Documentation](https://www.postgresql.org/docs/current/app-pgdump.html)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Colima Documentation](https://github.com/abiosoft/colima)
