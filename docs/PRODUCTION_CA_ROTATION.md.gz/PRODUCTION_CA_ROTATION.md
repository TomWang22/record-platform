# Production CA Rotation Guide

## Overview

This guide explains how to configure zero-downtime CA rotation for production using Kubernetes RollingUpdate strategy.

## Current Setup (Development)

- **Strategy**: `Recreate` (single replica)
- **Behavior**: Old pod terminates → downtime → new pod starts
- **Success Rate**: ~50-70% during rotation (expected with Recreate)
- **Downtime**: ~30-60 seconds during restart

## Production Setup (Zero-Downtime)

- **Strategy**: `RollingUpdate` (1+ replicas)
- **Behavior**: Old pod stays up → new pod starts → old pod terminates
- **Success Rate**: 100% during rotation (zero-downtime)
- **Downtime**: None

## Important: hostNetwork Limitation

**⚠️ With `hostNetwork: true`, only 1 pod per node can bind to port 443.**

This means:
- **Single-node cluster**: Can only run 1 replica (still better than Recreate!)
- **Multi-node cluster**: Can run 1 pod per node (2+ replicas for true HA)

### Options for True Multi-Replica Zero-Downtime

1. **Multiple Nodes** (Recommended for production)
   - Deploy 2+ nodes
   - Run 1 Caddy pod per node
   - RollingUpdate will update one pod at a time

2. **NodePort/LoadBalancer Service** (Alternative)
   - Remove `hostNetwork: true`
   - Use NodePort or LoadBalancer service
   - Multiple pods can run on same node
   - Requires updating Caddyfile and port mappings

## Migration Steps

### 1. Apply Production Configuration

```bash
# Apply production overlay
kubectl apply -f infra/k8s/overlays/prod/caddy-rolling-update.yaml

# Verify deployment
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.strategy.type}'
# Should output: RollingUpdate
```

### 2. Verify Deployment

```bash
# Check deployment strategy
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.strategy.type}'
# Should output: RollingUpdate

# Check replicas
kubectl get deployment -n ingress-nginx caddy-h3 -o jsonpath='{.spec.replicas}'
# Single-node: 1, Multi-node: 2+

# Check pods
kubectl get pods -n ingress-nginx -l app=caddy-h3
# Should show pods running
```

### 3. Test CA Rotation

```bash
# Run the rotation test (should now show 100% success rate)
./scripts/test-full-chain-with-rotation.sh
```

## Configuration Details

### RollingUpdate Strategy

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1          # Allow 1 extra pod during update
    maxUnavailable: 0    # Keep at least 1 pod available (zero-downtime)
```

### Replicas

- **Development (single-node)**: 1 replica (sufficient for testing)
- **Production (multi-node)**: 2+ replicas (high availability)

### Graceful Shutdown

```yaml
terminationGracePeriodSeconds: 30  # Longer grace period for connection draining
lifecycle:
  preStop:
    exec:
      command: ["/bin/sh", "-c", "sleep 5"]  # Drain connections before termination
```

## How It Works

1. **CA Rotation Triggered**: Secret updated with new certificate
2. **New Pod Starts**: Kubernetes starts new pod with new certificate
3. **New Pod Ready**: New pod passes readiness probe
4. **Traffic Shifts**: Kubernetes routes traffic to new pod
5. **Old Pod Drains**: Old pod receives termination signal
6. **Old Pod Terminates**: Old pod gracefully shuts down after connections drain

**Result**: Zero downtime - at least one pod is always available to serve traffic.

## Expected Test Results

### With RollingUpdate (1 replica, single-node)
- **Success Rate**: 100% (zero-downtime)
- **Test Output**: `✅ Zero-downtime rotation confirmed! (100% success rate)`

### With RollingUpdate (2+ replicas, multi-node)
- **Success Rate**: 100% (zero-downtime)
- **Test Output**: `✅ Zero-downtime rotation confirmed! (100% success rate)`

### With Recreate (old setup)
- **Success Rate**: ~50-70% (downtime during restart)
- **Test Output**: `⚠️ Low success rate during rotation (51% - 53/102 requests)`

## Monitoring

### Check Rotation Success

```bash
# Monitor pods during rotation
watch kubectl get pods -n ingress-nginx -l app=caddy-h3

# Check rollout status
kubectl rollout status deployment/caddy-h3 -n ingress-nginx
```

### Verify Zero-Downtime

```bash
# Run continuous requests during rotation
./scripts/test-full-chain-with-rotation.sh

# Expected: 100% success rate (all requests succeed)
```

## Troubleshooting

### Issue: Pods Not Rolling

**Symptom**: Only one pod updates, other stays on old certificate

**Solution**:
```bash
# Force rollout restart
kubectl rollout restart deployment/caddy-h3 -n ingress-nginx
```

### Issue: Traffic Still Going to Old Pod

**Symptom**: New pod ready but traffic still hits old pod

**Solution**:
- Check readiness probe: `kubectl describe pod -n ingress-nginx <pod-name>`
- Verify service endpoints: `kubectl get endpoints -n ingress-nginx caddy-h3`

### Issue: Port Conflicts (hostNetwork)

**Symptom**: New pod can't bind to port 443

**Solution**:
- With `hostNetwork: true`, only one pod per node can bind to port 443
- **Single-node**: Use 1 replica (still zero-downtime with RollingUpdate!)
- **Multi-node**: Ensure pods are scheduled on different nodes
- **Alternative**: Use NodePort/LoadBalancer instead of hostNetwork

## Best Practices

1. **Always use RollingUpdate in production** - Never use Recreate for critical services
2. **Use 1+ replicas** - Even 1 replica with RollingUpdate is better than Recreate
3. **Use 2+ replicas for HA** - Requires multiple nodes with hostNetwork
4. **Monitor during rotation** - Watch pod status and traffic patterns
5. **Test in staging first** - Verify zero-downtime behavior before production
6. **Set appropriate grace periods** - Allow time for connection draining

## Files

- **Production Config**: `infra/k8s/overlays/prod/caddy-rolling-update.yaml`
- **Test Script**: `scripts/test-full-chain-with-rotation.sh`
- **Current Dev Config**: `infra/k8s/caddy-h3-deploy.yaml`
