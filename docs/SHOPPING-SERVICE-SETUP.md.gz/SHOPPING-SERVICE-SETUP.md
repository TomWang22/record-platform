# Shopping Service Setup Guide

**Service**: `shopping-service`  
**Purpose**: Shopping/collector behavior service with cart, watchlist, wishlist, history, and LFU/LRU caching  
**Database**: PostgreSQL port 5436 (Docker Compose only, NOT in Kubernetes)  
**HTTP Port**: 4007  
**gRPC Port**: 50058

## Features

- ✅ **Shopping Cart** - Add, remove, update, clear items
- ✅ **Watchlist** - Monitor items for price changes, availability
- ✅ **Recently Viewed** - LRU cache for viewed items
- ✅ **Wishlist** - Priority-based wishlist with notes
- ✅ **Purchase History** - Complete purchase tracking
- ✅ **Search History** - Query tracking with trending searches
- ✅ **LFU/LRU Caching** - Redis-based cache with Lua scripts
- ✅ **Kafka Integration** - Real-time events for cart and purchases
- ✅ **gRPC Support** - HTTP/2/3 compatible
- ✅ **Separate Database** - Port 5436, isolated from main DB

## Quick Start

### 1. Start Database

```bash
# Start postgres-shopping container
docker-compose up -d postgres-shopping

# Wait for it to be healthy
docker-compose ps postgres-shopping
```

### 2. Setup Database

```bash
# Comprehensive setup (schema + optimizations)
./scripts/setup-and-optimize-shopping-db.sh

# Or step-by-step:
./scripts/setup-shopping-db.sh              # Schema only
./scripts/optimize-shopping-db-for-performance.sh  # Optimizations
```

### 3. Start Service

```bash
# Docker Compose
docker-compose up -d shopping-service

# Or build and run locally
cd services/shopping-service
pnpm install
pnpm build
pnpm dev
```

### 4. Verify Setup

```bash
# Check service health
curl http://localhost:4007/healthz

# Check database
psql -h localhost -p 5436 -U postgres -d records -c "
  SELECT schemaname, tablename 
  FROM pg_tables 
  WHERE schemaname = 'shopping'
  ORDER BY tablename;
"
```

## Database Schema

The shopping database uses the `shopping` schema with the following tables:

- `shopping_cart` - Temporary cart items
- `watchlist` - Items to monitor
- `recently_viewed` - LRU-tracked viewed items
- `wishlist` - Priority-based wishlist
- `purchase_history` - Completed purchases
- `search_history` - User search queries
- `cache_metadata` - LFU/LRU cache statistics

See `infra/db/06-shopping-schema.sql` for full schema definition.

## API Endpoints

### Shopping Cart
- `GET /api/shopping/cart` - Get user's cart
- `POST /api/shopping/cart` - Add item to cart
- `DELETE /api/shopping/cart/:itemId` - Remove item from cart
- `DELETE /api/shopping/cart` - Clear entire cart

### Watchlist
- `GET /api/shopping/watchlist` - Get user's watchlist
- `POST /api/shopping/watchlist` - Add to watchlist
- `DELETE /api/shopping/watchlist/:itemType/:itemId` - Remove from watchlist

### Recently Viewed
- `GET /api/shopping/recently-viewed` - Get recently viewed items (LRU)
- `POST /api/shopping/recently-viewed` - Add recently viewed item

### Wishlist
- `GET /api/shopping/wishlist` - Get user's wishlist
- `POST /api/shopping/wishlist` - Add to wishlist
- `DELETE /api/shopping/wishlist/:itemType/:itemId` - Remove from wishlist

### Purchase History
- `GET /api/shopping/purchases` - Get purchase history
- `POST /api/shopping/purchases` - Add purchase record

### Search History
- `GET /api/shopping/searches` - Get search history
- `POST /api/shopping/searches` - Add search query
- `GET /api/shopping/searches/trending` - Get trending searches

## gRPC Endpoints

All endpoints are available via gRPC on port 50058:
- `shopping.ShoppingService/GetCart`
- `shopping.ShoppingService/AddToCart`
- `shopping.ShoppingService/GetWatchlist`
- `shopping.ShoppingService/GetRecentlyViewed`
- `shopping.ShoppingService/GetWishlist`
- `shopping.ShoppingService/GetPurchaseHistory`
- `shopping.ShoppingService/GetSearchHistory`
- `shopping.ShoppingService/GetTrendingSearches`
- `shopping.ShoppingService/GetCacheStats`
- `shopping.ShoppingService/EvictCache`

See `proto/shopping.proto` for full gRPC definitions.

## LFU/LRU Cache

The service implements both LFU (Least Frequently Used) and LRU (Least Recently Used) caching strategies:

### LFU (Least Frequently Used)
- Tracks access count per item
- Evicts items with lowest access count
- Used for: Cart items, watchlist items, wishlist items

### LRU (Least Recently Used)
- Tracks last access time per item
- Evicts oldest accessed items
- Used for: Recently viewed items

### Cache Operations
- `incrementLFU(key, userId)` - Increment access count
- `updateLRU(key, userId)` - Update last access time
- `evictLFU(userId, maxItems)` - Evict least frequently used
- `evictLRU(userId, maxItems)` - Evict least recently used

## Kafka Integration

The service publishes events to Kafka topics:
- `shopping-cart` - Cart add/remove events
- `purchases` - Purchase completion events

## Database Configuration

- **Port**: 5436 (separate from main DB on 5433, social on 5434, listings on 5435)
- **Database**: `records`
- **Schema**: `shopping`
- **Connection**: `postgresql://postgres:postgres@localhost:5436/records`
- **NOT in Kubernetes** - Docker Compose only (like social and listings)

## Performance Optimizations

The shopping database uses the same optimization patterns as the main database:
- `shared_buffers = 512MB`
- `effective_cache_size = 2GB`
- `work_mem = 32MB`
- `random_page_cost = 1.1`
- `max_connections = 200`
- Indexes on all foreign keys and frequently queried columns
- `pg_prewarm` on critical indexes

See `scripts/optimize-shopping-db-for-performance.sh` for full optimization details.

## Testing

See `docs/SHOPPING-SERVICE-TESTING.md` for comprehensive testing guide including:
- HTTP/2/3 endpoint tests
- gRPC endpoint tests
- Database connectivity tests
- LFU/LRU cache tests
- Kafka integration tests
- Performance tests

## Architecture

```
┌─────────────┐
│ API Gateway │
│  (HTTP/2/3) │
└──────┬──────┘
       │
       ├─► gRPC ──► shopping-service:50058
       │
       └─► HTTP ──► shopping-service:4007
                    │
                    ├─► PostgreSQL:5436 (shopping schema)
                    ├─► Redis (LFU/LRU cache)
                    └─► Kafka (events)
```

## Key Differences from Other Services

| Feature | Main DB | Social | Listings | Shopping |
|---------|---------|--------|----------|----------|
| Port | 5433 | 5434 | 5435 | 5436 |
| Schema | records, auth | forum, messages | listings | shopping |
| Cache | Redis | Redis + Lua | Redis | Redis + LFU/LRU Lua |
| Kafka | No | Yes (messages) | No | Yes (cart, purchases) |
| Scale Ref | 2.4M rows | 2.4M ref | 2.4M ref | 2.4M ref |

## Next Steps

1. ✅ **Database setup complete** - Run `./scripts/setup-and-optimize-shopping-db.sh`
2. ✅ **Service running** - Start with `docker-compose up shopping-service`
3. ✅ **Test endpoints** - See `docs/SHOPPING-SERVICE-TESTING.md`
4. ✅ **Verify gRPC** - Test via API Gateway or direct gRPC calls
5. ✅ **Monitor performance** - Check metrics at `/metrics` endpoint

## Troubleshooting

### Database Connection Issues
```bash
# Check if postgres-shopping is running
docker-compose ps postgres-shopping

# Test connection
psql -h localhost -p 5436 -U postgres -d postgres -c "SELECT 1;"
```

### Service Not Starting
```bash
# Check logs
docker-compose logs shopping-service

# Check environment variables
docker-compose exec shopping-service env | grep POSTGRES_URL_SHOPPING
```

### Redis Connection Issues
```bash
# Test Redis
docker-compose exec redis redis-cli ping

# Check Redis keys
docker-compose exec redis redis-cli KEYS "cache:*"
```

## Reference

- **Schema**: `infra/db/06-shopping-schema.sql`
- **Prisma Schema**: `services/shopping-service/prisma/schema.prisma`
- **gRPC Proto**: `proto/shopping.proto`
- **Testing Guide**: `docs/SHOPPING-SERVICE-TESTING.md`
- **Database Topology**: `docs/DATABASE-TOPOLOGY-REPORT.md`

