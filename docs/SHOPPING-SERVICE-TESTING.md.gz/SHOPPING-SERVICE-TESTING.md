# Shopping Service Testing Guide

**Service**: `shopping-service`  
**HTTP Port**: 4007  
**gRPC Port**: 50058  
**Database**: PostgreSQL port 5436 (Docker Compose only, NOT in Kubernetes)  
**Features**: Shopping cart, watchlist, recently viewed (LRU), wishlist, purchase history, search history, LFU/LRU caching

## Prerequisites

1. **Database Setup**:
   ```bash
   # Setup shopping database (port 5436)
   ./scripts/setup-and-optimize-shopping-db.sh
   ```

2. **Service Running**:
   ```bash
   # Docker Compose
   docker-compose up shopping-service

   # Or Kubernetes
   kubectl -n record-platform get pod -l app=shopping-service
   ```

3. **Authentication**: Get a JWT token from auth service:
   ```bash
   TOKEN=$(curl --http2 -X POST https://record.local:8443/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","password":"password"}' \
     | jq -r '.token')
   ```

## HTTP/2 Testing

### Health Check
```bash
curl --http2 -I https://record.local:8443/api/shopping/healthz
```

### Shopping Cart Operations

#### Get Cart
```bash
curl --http2 https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN"
```

#### Add to Cart
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "quantity": 2,
    "price": 29.99,
    "metadata": {"title": "Vinyl Record", "artist": "Artist Name"}
  }'
```

#### Remove from Cart
```bash
curl --http2 -X DELETE https://record.local:8443/api/shopping/cart/{cart_item_id} \
  -H "Authorization: Bearer $TOKEN"
```

#### Clear Cart
```bash
curl --http2 -X DELETE https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN"
```

### Watchlist Operations

#### Get Watchlist
```bash
curl --http2 https://record.local:8443/api/shopping/watchlist \
  -H "Authorization: Bearer $TOKEN"
```

#### Add to Watchlist
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/watchlist \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "notify_on": ["price_drop", "availability"]
  }'
```

#### Remove from Watchlist
```bash
curl --http2 -X DELETE https://record.local:8443/api/shopping/watchlist/listing/{item_id} \
  -H "Authorization: Bearer $TOKEN"
```

### Recently Viewed (LRU Cache)

#### Get Recently Viewed
```bash
curl --http2 "https://record.local:8443/api/shopping/recently-viewed?item_type=listing&limit=50" \
  -H "Authorization: Bearer $TOKEN"
```

#### Add Recently Viewed
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/recently-viewed \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000"
  }'
```

### Wishlist Operations

#### Get Wishlist
```bash
curl --http2 https://record.local:8443/api/shopping/wishlist \
  -H "Authorization: Bearer $TOKEN"
```

#### Add to Wishlist
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/wishlist \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "priority": 5,
    "notes": "Want this for birthday"
  }'
```

### Purchase History

#### Get Purchase History
```bash
curl --http2 "https://record.local:8443/api/shopping/purchases?limit=50&offset=0" \
  -H "Authorization: Bearer $TOKEN"
```

#### Add Purchase
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/purchases \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "order-123",
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "quantity": 1,
    "price_paid": 29.99,
    "currency": "USD",
    "purchase_type": "buy_now",
    "status": "completed"
  }'
```

### Search History

#### Get Search History
```bash
curl --http2 "https://record.local:8443/api/shopping/searches?query_type=listing&limit=50" \
  -H "Authorization: Bearer $TOKEN"
```

#### Add Search
```bash
curl --http2 -X POST https://record.local:8443/api/shopping/searches \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "vinyl records",
    "query_type": "listing",
    "result_count": 42
  }'
```

#### Get Trending Searches
```bash
curl --http2 "https://record.local:8443/api/shopping/searches/trending?time_range=24h&limit=20" \
  -H "Authorization: Bearer $TOKEN"
```

## HTTP/3 Testing

### Health Check
```bash
curl --http3-only -I https://record.local:8443/api/shopping/healthz
```

### Shopping Cart (HTTP/3)
```bash
curl --http3-only https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN"
```

## gRPC Testing

### Health Check
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  record.local:8443 \
  shopping.ShoppingService/HealthCheck
```

### Shopping Cart (gRPC)
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  -d '{"user_id": "YOUR_USER_ID"}' \
  record.local:8443 \
  shopping.ShoppingService/GetCart
```

### Add to Cart (gRPC)
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  -d '{
    "user_id": "YOUR_USER_ID",
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "quantity": 1,
    "price": 29.99
  }' \
  record.local:8443 \
  shopping.ShoppingService/AddToCart
```

## Database Connectivity

### Test Connection
```bash
psql -h localhost -p 5436 -U postgres -d records -c "
  SELECT schemaname, tablename 
  FROM pg_tables 
  WHERE schemaname = 'shopping'
  ORDER BY tablename;
"
```

### Verify Data
```bash
psql -h localhost -p 5436 -U postgres -d records -c "
  SELECT COUNT(*) FROM shopping.shopping_cart;
  SELECT COUNT(*) FROM shopping.watchlist;
  SELECT COUNT(*) FROM shopping.recently_viewed;
  SELECT COUNT(*) FROM shopping.wishlist;
  SELECT COUNT(*) FROM shopping.purchase_history;
  SELECT COUNT(*) FROM shopping.search_history;
"
```

## LFU/LRU Cache Testing

### Test LFU Cache (via gRPC)
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  -d '{"user_id": "YOUR_USER_ID", "cache_type": "lfu"}' \
  record.local:8443 \
  shopping.ShoppingService/GetCacheStats
```

### Test LRU Cache (via gRPC)
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  -d '{"user_id": "YOUR_USER_ID", "cache_type": "lru"}' \
  record.local:8443 \
  shopping.ShoppingService/GetCacheStats
```

### Evict Cache
```bash
grpcurl -plaintext \
  -H "authorization: bearer $TOKEN" \
  -d '{
    "user_id": "YOUR_USER_ID",
    "cache_type": "lfu",
    "max_items": 100
  }' \
  record.local:8443 \
  shopping.ShoppingService/EvictCache
```

## Kafka Integration

The shopping service publishes events to Kafka topics:
- `shopping-cart` - Cart add/remove events
- `purchases` - Purchase completion events

### Verify Kafka Topics
```bash
# List topics
docker-compose exec kafka kafka-topics --list --bootstrap-server localhost:9092

# Consume shopping-cart topic
docker-compose exec kafka kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --topic shopping-cart \
  --from-beginning
```

## Performance Testing

### Load Test Shopping Cart
```bash
# Add 100 items to cart
for i in {1..100}; do
  curl --http2 -X POST https://record.local:8443/api/shopping/cart \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
      \"item_type\": \"listing\",
      \"item_id\": \"550e8400-e29b-41d4-a716-44665544000$i\",
      \"quantity\": 1
    }" &
done
wait
```

### Test Recently Viewed LRU Eviction
```bash
# Add 150 items (should evict oldest 50 if max=100)
for i in {1..150}; do
  curl --http2 -X POST https://record.local:8443/api/shopping/recently-viewed \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{
      \"item_type\": \"listing\",
      \"item_id\": \"550e8400-e29b-41d4-a716-44665544000$i\"
    }" &
done
wait

# Verify only 100 remain
curl --http2 "https://record.local:8443/api/shopping/recently-viewed?limit=200" \
  -H "Authorization: Bearer $TOKEN" | jq '.items | length'
```

## Integration Flow Test

### Complete Shopping Flow
```bash
# 1. Add item to cart
CART_ITEM=$(curl --http2 -X POST https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "quantity": 1,
    "price": 29.99
  }' | jq -r '.cart_item_id')

# 2. Add to watchlist
curl --http2 -X POST https://record.local:8443/api/shopping/watchlist \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000"
  }'

# 3. Add to recently viewed
curl --http2 -X POST https://record.local:8443/api/shopping/recently-viewed \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000"
  }'

# 4. Complete purchase
curl --http2 -X POST https://record.local:8443/api/shopping/purchases \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "order-123",
    "item_type": "listing",
    "item_id": "550e8400-e29b-41d4-a716-446655440000",
    "quantity": 1,
    "price_paid": 29.99,
    "purchase_type": "buy_now"
  }'

# 5. Clear cart
curl --http2 -X DELETE https://record.local:8443/api/shopping/cart \
  -H "Authorization: Bearer $TOKEN"
```

## Troubleshooting

### Service Not Responding
```bash
# Check service logs
docker-compose logs shopping-service
# Or Kubernetes
kubectl -n record-platform logs -l app=shopping-service --tail=100
```

### Database Connection Issues
```bash
# Test database connection
psql -h localhost -p 5436 -U postgres -d records -c "SELECT 1;"

# Check if database exists
psql -h localhost -p 5436 -U postgres -d postgres -c "
  SELECT datname FROM pg_database WHERE datname = 'records';
"
```

### Redis Connection Issues
```bash
# Test Redis connection
docker-compose exec redis redis-cli ping

# Check Redis keys
docker-compose exec redis redis-cli KEYS "cache:*"
```

### gRPC Connection Issues
```bash
# Test gRPC health
grpcurl -plaintext \
  record.local:8443 \
  shopping.ShoppingService/HealthCheck

# Check ingress route
kubectl -n record-platform get ingress record-platform-grpc -o yaml | grep shopping
```

## Expected Behavior

1. **Shopping Cart**: Items persist across sessions, quantity updates work
2. **Watchlist**: Items can be added/removed, notifications configurable
3. **Recently Viewed**: LRU cache evicts oldest items when limit reached
4. **Wishlist**: Priority-based sorting, notes support
5. **Purchase History**: All purchases tracked with full metadata
6. **Search History**: Queries logged, trending searches calculated
7. **LFU/LRU**: Cache stats available, eviction works correctly
8. **Kafka**: Events published for cart changes and purchases

## Performance Targets

- Shopping cart operations: <50ms p95
- Watchlist queries: <30ms p95
- Recently viewed (LRU): <20ms p95
- Purchase history: <50ms p95
- Search history: <30ms p95
- LFU/LRU cache operations: <10ms p95

