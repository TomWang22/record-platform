# Social Service Database Schema

## Overview
The social-service uses a separate PostgreSQL database on **port 5433** (separate from the main DB on port 5432). This follows the same pattern as auth-service and records-service but uses a dedicated database instance.

## Database Setup

### Connection String
- **Development (Docker)**: `postgresql://postgres:postgres@host.docker.internal:5433/records?connect_timeout=5`
- **Kubernetes**: Configured via `POSTGRES_URL_SOCIAL` in `app-config.yaml`

### Setup Script
Run the setup script to create the database and apply the schema:
```bash
./scripts/setup-social-db.sh
```

Or manually:
```bash
# Create database
psql -h host.docker.internal -p 5433 -U postgres -d postgres -c "CREATE DATABASE records;"

# Apply schema
psql -h host.docker.internal -p 5433 -U postgres -d records -f infra/db/04-social-schema.sql
```

## Schema Structure

### Forum Schema (`forum`)

#### `forum.posts`
- Main forum posts table
- Fields: `id`, `user_id`, `title`, `content`, `flair`, `upvotes`, `downvotes`, `comment_count`, `is_pinned`, `is_locked`, `created_at`, `updated_at`
- Indexes: user_id, flair, created_at, pinned+created_at, upvotes+created_at, TRGM on title/content
- Triggers: Auto-update `updated_at`, auto-update `comment_count` when comments are added/removed

#### `forum.comments`
- Nested comments (replies via `parent_id`)
- Fields: `id`, `post_id`, `user_id`, `parent_id`, `content`, `upvotes`, `downvotes`, `created_at`, `updated_at`
- Indexes: post_id, user_id, parent_id, created_at
- Triggers: Auto-update `updated_at`, increment/decrement post `comment_count`

#### `forum.post_votes`
- User votes on posts (up/down)
- Fields: `id`, `post_id`, `user_id`, `vote_type` ('up' or 'down'), `created_at`
- Unique constraint: (post_id, user_id) - one vote per user per post
- Triggers: Auto-update post `upvotes`/`downvotes` counts

#### `forum.comment_votes`
- User votes on comments (up/down)
- Fields: `id`, `comment_id`, `user_id`, `vote_type` ('up' or 'down'), `created_at`
- Unique constraint: (comment_id, user_id) - one vote per user per comment
- Triggers: Auto-update comment `upvotes`/`downvotes` counts

### Messages Schema (`messages`)

#### `messages.groups`
- Groups for group messaging
- Fields: `id`, `name`, `description`, `created_by`, `created_at`, `updated_at`
- Indexes: created_by, created_at

#### `messages.group_members`
- Group membership table
- Fields: `id`, `group_id`, `user_id`, `role` ('admin', 'moderator', 'member'), `joined_at`
- Unique constraint: (group_id, user_id) - one membership per user per group
- Indexes: group_id, user_id

#### `messages.messages`
- Messages table (supports both direct and group messages)
- Fields: `id`, `sender_id`, `recipient_id` (NULL if group), `group_id` (NULL if direct), `parent_message_id`, `thread_id`, `message_type`, `subject`, `content`, `is_read`, `created_at`, `updated_at`
- Constraint: Either `recipient_id` OR `group_id` must be set (not both, not neither)
- Indexes: sender_id, recipient_id, group_id, thread_id, parent_message_id, created_at, is_read+recipient_id, TRGM on subject/content
- Triggers: Auto-set `thread_id` on insert (for threading), auto-update `updated_at`

#### `messages.message_reads`
- Read receipts for messages
- Fields: `id`, `message_id`, `user_id`, `read_at`
- Unique constraint: (message_id, user_id) - one read record per user per message
- Indexes: message_id, user_id, read_at
- Triggers: Auto-update message `is_read` flag when read record is inserted

## Key Features

### 1. Nested Comments
- Comments support nested replies via `parent_id`
- Self-referential foreign key: `forum.comments.parent_id` → `forum.comments.id`
- Can build comment trees using recursive CTEs

### 2. Vote System
- Separate vote tables for posts and comments
- One vote per user per item (enforced by unique constraint)
- Vote counts automatically maintained via triggers
- Supports vote changes (up → down, down → up)

### 3. Message Threading
- Messages can be replies via `parent_message_id`
- `thread_id` automatically set to root message ID (via trigger)
- Enables threaded conversations

### 4. Group Messaging
- Groups can be created with members
- Messages can be sent to groups (set `group_id`, leave `recipient_id` NULL)
- Group members can see all messages in the group

### 5. Read Receipts
- `message_reads` table tracks when users read messages
- `is_read` flag on messages automatically updated via trigger
- Supports both direct and group message read tracking

## Prisma Schema

The Prisma schema is located at `services/social-service/prisma/schema.prisma`. It mirrors the PostgreSQL schema and is used for type-safe database access.

### Generate Prisma Client
```bash
cd services/social-service
pnpm prisma generate
```

### Run Migrations (if using Prisma migrations)
```bash
cd services/social-service
pnpm prisma migrate dev
```

## Indexes & Performance

### Forum Indexes
- **Posts**: User lookups, flair filtering, sorting by date/popularity, full-text search (TRGM)
- **Comments**: Post lookups, user lookups, parent-child relationships, sorting
- **Votes**: Fast vote lookups, user vote history

### Messages Indexes
- **Messages**: Sender/recipient lookups, group lookups, thread traversal, unread filtering, full-text search (TRGM)
- **Groups**: Creator lookups, sorting
- **Group Members**: Fast membership checks
- **Read Receipts**: Read status queries

## Triggers & Functions

1. **`forum.touch_updated_at()`**: Auto-update `updated_at` on posts/comments
2. **`forum.update_comment_count()`**: Auto-increment/decrement post `comment_count`
3. **`forum.update_post_votes()`**: Auto-update post vote counts
4. **`forum.update_comment_votes()`**: Auto-update comment vote counts
5. **`messages.touch_updated_at()`**: Auto-update `updated_at` on groups/messages
6. **`messages.set_thread_id()`**: Auto-set `thread_id` for message threading
7. **`messages.update_message_read()`**: Auto-update message `is_read` flag

## Future Enhancements

- [ ] Add full-text search indexes (GIN) for better search performance
- [ ] Add materialized views for popular posts/comments
- [ ] Add notification system integration
- [ ] Add message attachments support
- [ ] Add post/comment moderation flags
- [ ] Add user blocking/muting features

