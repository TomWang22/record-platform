# Social & Listings Database Setup Guide

**Purpose**: Complete setup guide for social and listings databases, matching the main database setup (2.4M row reference).

## Quick Start

### Social Database (Port 5434)

```bash
# Comprehensive setup (schema + optimizations)
./scripts/setup-and-optimize-social-db.sh

# Or step-by-step:
./scripts/setup-social-db.sh              # Schema only
./scripts/optimize-social-db-for-performance.sh  # Optimizations
```

### Listings Database (Port 5435)

```bash
# Comprehensive setup (schema + optimizations)
./scripts/setup-and-optimize-listings-db.sh

# Or step-by-step:
./scripts/setup-listings-db.sh            # Schema only
./scripts/optimize-listings-db-for-performance.sh  # Optimizations
```

## What These Scripts Do

### Main Database Reference (Port 5433)
- ✅ **2.4M rows** target (corrected from 1.2M confusion)
- ✅ Performance optimizations (28k TPS target)
- ✅ Partial indexes for hot tenant
- ✅ Comprehensive tuning scripts

### Social Database (Port 5434)
- ✅ **Mirrors main DB setup** - Same optimization patterns
- ✅ Forum schema (`forum` schema)
- ✅ Messages schema (`messages` schema)
- ✅ Performance tuning identical to main DB
- ✅ Extensions: `pg_trgm`, `pgcrypto`, `citext`, `pg_prewarm`

### Listings Database (Port 5435)
- ✅ **Mirrors main DB setup** - Same optimization patterns
- ✅ Listings schema (`listings` schema)
- ✅ Performance tuning identical to main DB
- ✅ Extensions: `pg_trgm`, `pgcrypto`, `citext`, `pg_prewarm`, `btree_gist`

## Performance Optimizations Applied

All three databases use the same optimization strategy:

### System-Level Settings
- `random_page_cost = 1.1` (SSD-optimized)
- `cpu_index_tuple_cost = 0.0005`
- `cpu_tuple_cost = 0.01`
- `effective_cache_size = 2GB` (main DB uses 4GB)
- `work_mem = 32MB`
- `shared_buffers = 512MB` (main DB uses 1GB)
- `max_connections = 200` (main DB uses 400)
- `effective_io_concurrency = 200` (or 0 on macOS)

### Database-Level Settings
- Same as system-level (applied to database)
- Ensures consistency across connections

### Extensions
- `pg_trgm` - Trigram similarity search
- `pgcrypto` - Encryption/hashing
- `citext` - Case-insensitive text
- `pg_prewarm` - Cache warming
- `btree_gist` - Additional index types (listings only)

### Maintenance
- `ANALYZE` run on all tables for fresh statistics
- `pg_prewarm` on all indexes
- Autovacuum tuned for high-write scenarios

## PostgreSQL GPT Analysis

### Generate Analysis Files

```bash
# Generate comprehensive analysis for all databases
./scripts/generate-postgresql-gpt-analysis.sh
```

This creates analysis files in:
```
docs/postgresql-gpt-analysis/<timestamp>/
  ├── main-analysis.txt
  ├── social-analysis.txt
  └── listings-analysis.txt
```

### Analysis Includes

For each database:
1. **Database Overview** - Size, version, connection info
2. **Table Statistics** - Row counts, sizes, vacuum/analyze times
3. **Index Statistics** - Index usage, sizes, scan counts
4. **Configuration** - All performance-related settings
5. **Extensions** - Installed extensions
6. **Size Breakdown** - Schema-level size analysis

### Manual Analysis

See `docs/POSTGRESQL-GPT-ANALYSIS-PLANS.md` for:
- Complete SQL queries for analysis
- EXPLAIN (ANALYZE, BUFFERS) examples
- Performance metric collection
- Tuning recommendation areas

## Verification

### Check Database Status

```bash
# Main database
psql -h localhost -p 5433 -U postgres -d records -c "
  SELECT 'Main DB: ' || pg_size_pretty(pg_database_size('records'));
"

# Social database
psql -h localhost -p 5434 -U postgres -d records -c "
  SELECT 'Social DB: ' || pg_size_pretty(pg_database_size('records'));
  SELECT schemaname, COUNT(*) AS table_count
  FROM pg_tables WHERE schemaname IN ('forum', 'messages')
  GROUP BY schemaname;
"

# Listings database
psql -h localhost -p 5435 -U postgres -d records -c "
  SELECT 'Listings DB: ' || pg_size_pretty(pg_database_size('records'));
  SELECT COUNT(*) AS table_count
  FROM pg_tables WHERE schemaname = 'listings';
"
```

### Check Optimizations

```bash
# Check configuration for any database
psql -h localhost -p <PORT> -U postgres -d records -c "
  SELECT name, setting, unit
  FROM pg_settings
  WHERE name IN (
    'shared_buffers',
    'effective_cache_size',
    'work_mem',
    'random_page_cost',
    'max_connections'
  )
  ORDER BY name;
"
```

## Key Differences from Main DB

| Setting | Main DB | Social/Listings DB |
|---------|---------|-------------------|
| `shared_buffers` | 1GB | 512MB |
| `effective_cache_size` | 4GB | 2GB |
| `max_connections` | 400 | 200 |
| Scale Reference | 2.4M rows | Same (2.4M reference) |

**Rationale**: Social and listings databases are expected to have lower concurrent load initially, so smaller buffers are appropriate. Both still follow the same optimization patterns as the main database.

## Troubleshooting

### Port Conflicts
If ports 5434 or 5435 are in use:
```bash
# Check what's using the port
lsof -i :5434
lsof -i :5435

# Stop conflicting service or change port in docker-compose.yml
```

### Connection Issues
```bash
# Test connection
psql -h localhost -p 5434 -U postgres -d postgres -c "SELECT 1;"

# Check if Docker container is running
docker-compose ps | grep postgres
```

### Optimization Not Applied
If optimizations don't seem applied:
```bash
# Check if PostgreSQL needs restart (for max_connections)
docker restart record-platform-postgres-social-1
docker restart record-platform-postgres-listings-1

# Verify settings after restart
psql -h localhost -p <PORT> -U postgres -d records -c "
  SHOW max_connections;
  SHOW shared_buffers;
"
```

## Next Steps

1. ✅ **Run comprehensive setup** for both databases
2. ✅ **Generate PostgreSQL GPT analysis** files
3. ✅ **Run EXPLAIN (ANALYZE, BUFFERS)** on key queries
4. ✅ **Send analysis to PostgreSQL GPT** for tuning recommendations
5. ✅ **Monitor performance** and adjust settings as needed

## Reference Documents

- `docs/DATABASE-TOPOLOGY-REPORT.md` - Complete database architecture
- `docs/POSTGRESQL-GPT-ANALYSIS-PLANS.md` - Analysis query templates
- `scripts/run_pgbench_sweep.sh` - Benchmark suite (main DB only)
- `scripts/optimize-db-for-performance.sh` - Main DB optimization reference

