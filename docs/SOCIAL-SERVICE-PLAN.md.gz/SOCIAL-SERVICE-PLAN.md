# Social Service Architecture Plan

## Overview
Create a new `social-service` to handle both **Forum** and **Messaging** features. This follows the existing microservice pattern and keeps related social features together.

## Service Architecture Pattern (from existing services)

### Current Pattern:
1. **API Gateway** (`api-gateway`):
   - Routes `/api/*` paths to services
   - Handles JWT auth, injects `x-user-id`, `x-user-email`, `x-user-jti` headers
   - Some routes use direct gRPC calls (auth, records)
   - Others use HTTP proxy middleware (listings, analytics, ai)

2. **Services**:
   - Express HTTP server
   - Read user identity from `x-user-id` header (injected by gateway)
   - Own Postgres connection (Prisma or `pg` client)
   - `/healthz` and `/metrics` endpoints
   - Rate limiting (optional, per-service)

### Decision: Single `social-service`
**Rationale:**
- Forum and messaging are both social/community features
- Share similar patterns (user content, threading, notifications)
- Easier to manage than two separate services
- Can share common utilities (user validation, rate limiting, etc.)
- Follows the pattern of `records-service` (single service, multiple related features)

## Service Structure

```
services/social-service/
├── src/
│   ├── server.ts          # Express app, routes, middleware
│   ├── routes/
│   │   ├── forum.ts       # Forum endpoints
│   │   └── messages.ts    # Messaging endpoints
│   ├── lib/
│   │   ├── db.ts          # Postgres connection pool
│   │   └── auth.ts        # User identity helpers
│   └── types.ts           # TypeScript types
├── package.json
├── tsconfig.json
├── Dockerfile
└── pm2.config.cjs
```

## API Endpoints (to be implemented)

### Forum Endpoints
```
GET    /forum/posts                    # List posts (paginated, filterable by flair)
POST   /forum/posts                    # Create post
GET    /forum/posts/:postId            # Get post details
PUT    /forum/posts/:postId            # Update post (author only)
DELETE /forum/posts/:postId            # Delete post (author or admin)
POST   /forum/posts/:postId/vote       # Upvote/downvote post
GET    /forum/posts/:postId/comments   # Get comments for post
POST   /forum/posts/:postId/comments   # Add comment
PUT    /forum/comments/:commentId      # Update comment (author only)
DELETE /forum/comments/:commentId      # Delete comment (author or admin)
POST   /forum/comments/:commentId/vote # Vote on comment
```

### Messaging Endpoints
```
GET    /messages                       # List user's messages (inbox)
POST   /messages                       # Send new message
GET    /messages/:messageId            # Get message details
POST   /messages/:messageId/reply      # Reply to message (creates thread)
PUT    /messages/:messageId            # Update message (sender only)
DELETE /messages/:messageId            # Delete message (sender or recipient)
GET    /messages/thread/:threadId      # Get full thread/conversation
POST   /messages/:messageId/read       # Mark as read
```

## Gateway Integration

Add to `services/api-gateway/src/server.ts`:

```typescript
/* Social Service — protected, requires auth */
app.use(
  "/forum",
  injectIdentityHeadersIfAny,
  createProxyMiddleware({
    target: "http://social-service:4006",
    changeOrigin: true,
    pathRewrite: { "^/forum": "/forum" },
    proxyTimeout: 15000,
    agent: keepAliveAgent,
    on: {
      error(err, _req, res) {
        console.error("[gw] social proxy error:", err);
        sendJson502(res as NodeServerResponse | Socket, "social upstream error");
      },
    },
  })
);

app.use(
  "/messages",
  injectIdentityHeadersIfAny,
  createProxyMiddleware({
    target: "http://social-service:4006",
    changeOrigin: true,
    pathRewrite: { "^/messages": "/messages" },
    proxyTimeout: 15000,
    agent: keepAliveAgent,
    on: {
      error(err, _req, res) {
        console.error("[gw] social proxy error:", err);
        sendJson502(res as NodeServerResponse | Socket, "social upstream error");
      },
    },
  })
);
```

## Frontend API Routes (Next.js)

The webapp expects these routes (from your description):
- `/api/forum/posts` → Gateway → `social-service:4006/forum/posts`
- `/api/forum/posts/[postId]/comments` → Gateway → `social-service:4006/forum/posts/:postId/comments`
- `/api/forum/posts/[postId]/vote` → Gateway → `social-service:4006/forum/posts/:postId/vote`
- `/api/messages/send` → Gateway → `social-service:4006/messages`

**Note:** The gateway strips `/api` prefix (nginx ingress rewrites), so:
- Frontend calls: `https://record.local:8443/api/forum/posts`
- Gateway sees: `/forum/posts`
- Gateway proxies to: `http://social-service:4006/forum/posts`

## Implementation Phases

### Phase 1: Service Scaffold (Code structure, no DB yet) ✅ COMPLETE
- [x] Create `services/social-service/` directory structure
- [x] Add `package.json` with dependencies (express, pg, @grpc/grpc-js, kafkajs, @common/utils, etc.)
- [x] Create `src/server.ts` with Express app, healthz, metrics
- [x] Create `src/grpc-server.ts` with gRPC server implementation
- [x] Create `src/lib/db.ts` with Postgres pool (placeholder, no schema yet)
- [x] Create `src/lib/auth.ts` to read `x-user-id` from headers
- [x] Create route stubs (`src/routes/forum.ts`, `src/routes/messages.ts`)
- [x] Add Dockerfile, tsconfig.json, pm2.config.cjs
- [x] Create `proto/social.proto` with Forum + Messages service definitions

### Phase 2: Gateway Integration ✅ COMPLETE
- [x] Add gRPC-backed routes to `api-gateway/src/server.ts` (like auth/records)
- [x] Add `createSocialClient` to `@common/utils/grpc-clients`
- [x] Add service to K8s manifests (`infra/k8s/base/social-service/`)
- [x] Add gRPC ingress route in `ingress-grpc.yaml`
- [x] Add to docker-compose.yml with Kafka dependency
- [x] Test routing: `curl -H "Authorization: Bearer $TOKEN" http://api-gateway:4000/forum/posts`

### Phase 3: Endpoint Implementation (Placeholder responses) ✅ COMPLETE
- [x] Implement all forum gRPC methods with placeholder responses
- [x] Implement all messaging gRPC methods with placeholder responses
- [x] Add Kafka integration for real-time message delivery
- [x] Match frontend expected response shapes
- [x] Add input validation, error handling

### Phase 4: Database Schema (Next agent)
- [ ] Design tables: `forum.posts`, `forum.comments`, `forum.votes`, `messages.messages`, `messages.threads`
- [ ] Create migrations
- [ ] Wire up real DB queries in gRPC handlers
- [ ] Add Kafka consumer for message persistence

## Dependencies

```json
{
  "dependencies": {
    "@common/utils": "workspace:*",
    "express": "^4.19.2",
    "pg": "^8.11.3",
    "prom-client": "^15.1.3"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/pg": "^8.10.9",
    "tsx": "^4.16.2",
    "typescript": "^5.5.4"
  }
}
```

## Port Assignment

- `social-service:4006` (HTTP)
- Future: `social-service:50056` (gRPC, if needed)

## Environment Variables

```bash
SOCIAL_PORT=4006
DATABASE_URL=postgresql://record_app:SUPER_STRONG_APP_PASSWORD@postgres.record-platform.svc.cluster.local:5432/records
REDIS_URL=redis://redis.record-platform.svc.cluster.local:6379/0  # Optional, for caching
```

## Next Steps

1. **Create service scaffold** (Phase 1) - This agent
2. **Wire up gateway** (Phase 2) - This agent
3. **Implement placeholder endpoints** (Phase 3) - This agent
4. **Database design & implementation** (Phase 4) - Next agent

