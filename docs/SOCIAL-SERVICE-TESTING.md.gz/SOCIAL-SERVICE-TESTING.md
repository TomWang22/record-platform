# Social Service Testing Guide

## Overview
The **social-service** is a new microservice that handles Forum and Messaging features. It uses gRPC (like auth/records services) and needs to be tested for HTTP/2, HTTP/3, and end-to-end functionality.

## Service Details

### Service Information
- **Service Name**: `social-service`
- **HTTP Port**: `4006`
- **gRPC Port**: `50056`
- **Protocol**: gRPC (HTTP/2) + HTTP REST endpoints
- **Database**: Separate PostgreSQL on port `5434` (schemas: `forum`, `messages`)
- **Dependencies**: Redis (caching), Kafka (real-time messaging)

### API Endpoints

#### Forum Endpoints (gRPC-backed via API Gateway)
- `GET /api/forum/posts` - List posts
- `POST /api/forum/posts` - Create post
- `GET /api/forum/posts/:postId` - Get post details
- `POST /api/forum/posts/:postId/vote` - Vote on post
- `GET /api/forum/posts/:postId/comments` - Get comments
- `POST /api/forum/posts/:postId/comments` - Add comment

#### Messaging Endpoints (gRPC-backed via API Gateway)
- `GET /api/messages` - List user's messages
- `POST /api/messages` - Send message (publishes to Kafka)
- `POST /api/messages/:messageId/reply` - Reply to message (publishes to Kafka)
- `GET /api/messages/thread/:threadId` - Get thread

### gRPC Service
- **Service**: `social.SocialService`
- **Proto**: `proto/social.proto`
- **Ingress Path**: `/social.SocialService` (in `ingress-grpc.yaml`)

## Testing Checklist

### 1. Service Health & Deployment
- [ ] Verify `social-service` pod is running and healthy
- [ ] Check `/healthz` endpoint returns `{ ok: true, db: 'connected', redis: 'PONG', cpu_cores: N }`
- [ ] Verify database connection to port 5434
- [ ] Verify Redis connection
- [ ] Check service is exposed on ports 4006 (HTTP) and 50056 (gRPC)

### 2. HTTP/2 Testing
- [ ] Test forum endpoints over HTTP/2:
  ```bash
  TOKEN="<jwt-token>"
  curl -k --http2 -H "Authorization: Bearer $TOKEN" \
    https://record.local:8443/api/forum/posts
  ```
- [ ] Test messaging endpoints over HTTP/2:
  ```bash
  curl -k --http2 -H "Authorization: Bearer $TOKEN" \
    -X POST https://record.local:8443/api/messages \
    -d '{"recipient_id":"...","subject":"Test","content":"Hello","message_type":"General"}'
  ```
- [ ] Verify ALPN negotiation shows `h2` in logs
- [ ] Check API Gateway → social-service gRPC communication

### 3. HTTP/3 Testing
- [ ] Test forum endpoints over HTTP/3:
  ```bash
  curl -k --http3-only -H "Authorization: Bearer $TOKEN" \
    https://record.local:8443/api/forum/posts
  ```
- [ ] Test messaging endpoints over HTTP/3:
  ```bash
  curl -k --http3-only -H "Authorization: Bearer $TOKEN" \
    https://record.local:8443/api/messages
  ```
- [ ] Verify QUIC handshake succeeds
- [ ] Check Caddy → nginx → API Gateway → social-service chain

### 4. gRPC Testing
- [ ] Test direct gRPC calls (if grpcurl available):
  ```bash
  grpcurl -plaintext -H "authorization: Bearer $TOKEN" \
    social-service:50056 social.SocialService/HealthCheck
  ```
- [ ] Verify gRPC ingress route `/social.SocialService` works
- [ ] Test gRPC methods: `ListPosts`, `CreatePost`, `SendMessage`, etc.
- [ ] Verify gRPC uses HTTP/2 (ALPN negotiation)

### 5. End-to-End Testing
- [ ] **Forum Flow**:
  1. Create a post via `POST /api/forum/posts`
  2. Retrieve post via `GET /api/forum/posts/:postId`
  3. Add comment via `POST /api/forum/posts/:postId/comments`
  4. Vote on post via `POST /api/forum/posts/:postId/vote`
  5. Verify data persists in database (port 5434)

- [ ] **Messaging Flow**:
  1. Send message via `POST /api/messages`
  2. Verify message published to Kafka topic `messages`
  3. Retrieve messages via `GET /api/messages`
  4. Reply to message via `POST /api/messages/:messageId/reply`
  5. Get thread via `GET /api/messages/thread/:threadId`
  6. Verify data persists in database (port 5434)

- [ ] **Group Messaging** (if implemented):
  1. Create group
  2. Add members to group
  3. Send group message
  4. Verify all members can see message

### 6. Database Verification
- [ ] Verify data in `forum.posts` table
- [ ] Verify data in `forum.comments` table
- [ ] Verify data in `messages.messages` table
- [ ] Check Redis cache is working (forum posts/comments cached)
- [ ] Verify triggers work (vote counts, comment counts, etc.)

### 7. Kafka Integration
- [ ] Verify messages are published to Kafka topic `messages`
- [ ] Check Kafka consumer (if implemented) processes messages
- [ ] Verify message delivery for real-time features

### 8. Caching & Performance
- [ ] Test Redis caching (forum posts should be cached)
- [ ] Verify cache invalidation on updates
- [ ] Check singleflight pattern prevents cache stampede
- [ ] Monitor CPU usage (should use `os.cpus().length()` for parallel processing)

### 9. Error Handling
- [ ] Test with invalid JWT token (should return 401)
- [ ] Test with missing required fields (should return 400)
- [ ] Test with non-existent post/message ID (should return 404)
- [ ] Test database connection failure (should return 503)

### 10. Ingress & Caddy Configuration
- [ ] Verify `ingress-grpc.yaml` includes `/social.SocialService` route
- [ ] Check Caddy configuration includes social-service routes
- [ ] Verify TLS termination works correctly
- [ ] Test both HTTP/2 and HTTP/3 through Caddy

## Test Scripts

### Existing Scripts (Need Updates)
- `scripts/test-microservices-http2-http3.sh` - **TODO**: Add social-service endpoints
- `scripts/test-grpc-http2-http3-alpn.sh` - **TODO**: Add social-service gRPC tests
- `scripts/test-http2-http3-strict-tls.sh` - Should already work (tests ingress)

### New Test Script Needed
Create `scripts/test-social-service.sh`:
```bash
#!/usr/bin/env bash
# Test social-service endpoints over HTTP/2 and HTTP/3
# Should test forum and messaging endpoints
```

## Integration with Existing Tests

### Update `test-microservices-http2-http3.sh`
Add social-service tests after records tests:
```bash
# Test social-service forum endpoint (HTTP/2)
curl --http2 -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/forum/posts

# Test social-service messaging endpoint (HTTP/3)
curl --http3-only -H "Authorization: Bearer $TOKEN" \
  https://record.local:8443/api/messages
```

### Update `test-grpc-http2-http3-alpn.sh`
Add social-service gRPC health check:
```bash
# Test social-service gRPC health
grpcurl -plaintext social-service:50056 social.SocialService/HealthCheck
```

## Known Issues & Notes

1. **Database**: Social-service uses separate database on port 5434 (not the main records DB)
2. **Kafka**: Messages are published to Kafka but consumer may not be implemented yet
3. **Redis**: Caching is implemented but cache invalidation on updates may need work
4. **gRPC**: Service uses insecure gRPC (no TLS) in development - should match auth/records pattern

## Connection Strings

- **Database**: `postgresql://postgres:postgres@localhost:5434/records` (dev)
- **Kubernetes**: `postgresql://postgres:postgres@host.docker.internal:5434/records`
- **Service**: `http://social-service:4006` (HTTP), `social-service:50056` (gRPC)

## Verification Commands

```bash
# Check service is running
kubectl -n record-platform get pods -l app=social-service

# Check service endpoints
kubectl -n record-platform get svc social-service

# Test database connection
PGPASSWORD=postgres psql -h localhost -p 5434 -U postgres -d records -c "SELECT COUNT(*) FROM forum.posts;"

# Test service health
curl http://localhost:4006/healthz  # if port-forwarded
```

## Next Steps for Testing Agent

1. **Update existing test scripts** to include social-service endpoints
2. **Create dedicated test script** for social-service (`test-social-service.sh`)
3. **Run full test suite** including social-service
4. **Verify gRPC ingress** route for social-service works
5. **Test Kafka integration** for real-time messaging
6. **Document any issues** found during testing

