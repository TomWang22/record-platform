# Test Scripts Coverage Matrix

This document outlines what each test script covers to ensure comprehensive testing of HTTP/2, HTTP/3, gRPC, TLS, and CA rotation.

## Script Overview

### 1. `test-http2-http3-strict-tls.sh`
**Purpose**: Basic HTTP/2, HTTP/3, and strict TLS verification

**Coverage**:
- ✅ HTTP/2 health check
- ✅ HTTP/3 health check (uses `http3_curl` helper)
- ✅ HTTP/2 API endpoint
- ✅ HTTP/3 API endpoint (uses `http3_curl` helper)
- ✅ TLS 1.3 support
- ✅ TLS 1.2 support
- ✅ TLS 1.1 rejection (strict TLS)
- ✅ Caddy TLS configuration verification
- ✅ **CA Rotation with zero-downtime** (Test 9, can be skipped with `SKIP_ROTATION=1`)

**When to use**: Quick verification of protocol support and TLS configuration

**Usage**:
```bash
./scripts/test-http2-http3-strict-tls.sh
# Skip CA rotation (faster):
SKIP_ROTATION=1 ./scripts/test-http2-http3-strict-tls.sh
```

---

### 2. `test-full-chain-with-rotation.sh`
**Purpose**: End-to-end chain testing with CA rotation

**Coverage**:
- ✅ HTTP/2 health check
- ✅ HTTP/3 health check (uses `http3_curl` helper)
- ✅ Full chain HTTP/2 (Client -> Caddy -> Ingress -> Backend)
- ✅ Full chain HTTP/3 (Client -> Caddy -> Ingress -> Backend)
- ✅ Strict TLS verification
- ✅ **CA Rotation with zero-downtime monitoring** (Test 6)
- ✅ Certificate verification after rotation
- ✅ Full chain API endpoint test

**When to use**: Comprehensive end-to-end testing including CA rotation

**Usage**:
```bash
./scripts/test-full-chain-with-rotation.sh
```

---

### 3. `test-microservices-http2-http3.sh`
**Purpose**: Microservices-specific testing (Auth, Records)

**Coverage**:
- ✅ Auth service registration via HTTP/2
- ✅ Auth service login via HTTP/3 (uses `http3_curl` helper)
- ✅ Records service CRUD via HTTP/2
- ✅ Records service CRUD via HTTP/3 (uses `http3_curl` helper)
- ✅ Health checks (HTTP/2 and HTTP/3)
- ✅ API Gateway health

**When to use**: Testing actual microservice workflows over HTTP/2/3

**Usage**:
```bash
./scripts/test-microservices-http2-http3.sh
```

---

### 4. `test-grpc-http2-http3.sh`
**Purpose**: gRPC service testing over HTTP/2/3

**Coverage**:
- ✅ Test user creation/authentication
- ✅ HTTP/2 health check
- ✅ HTTP/3 health check (uses `http3_curl` helper)
- ✅ API endpoints via HTTP/2
- ✅ API endpoints via HTTP/3 (uses `http3_curl` helper)
- ✅ Authentication via HTTP/2
- ✅ Records CRUD via HTTP/2
- ✅ Records CRUD via HTTP/3 (uses `http3_curl` helper)
- ✅ Protocol verification

**When to use**: Testing gRPC services and CRUD operations

**Usage**:
```bash
./scripts/test-grpc-http2-http3.sh
```

---

### 5. `test-grpc-http2-http3-alpn.sh`
**Purpose**: ALPN negotiation and gRPC protocol testing

**Coverage**:
- ✅ HTTP/2 with prior knowledge
- ✅ HTTP/3 (QUIC) (uses `http3_curl` helper)
- ✅ gRPC health check via HTTP/2
- ✅ ALPN negotiation details

**When to use**: Debugging protocol negotiation issues

**Usage**:
```bash
./scripts/test-grpc-http2-http3-alpn.sh
```

---

## Coverage Matrix

| Feature | test-http2-http3-strict-tls.sh | test-full-chain-with-rotation.sh | test-microservices-http2-http3.sh | test-grpc-http2-http3.sh | test-grpc-http2-http3-alpn.sh |
|---------|-------------------------------|----------------------------------|-----------------------------------|--------------------------|-------------------------------|
| HTTP/2 health | ✅ | ✅ | ✅ | ✅ | ✅ |
| HTTP/3 health | ✅ | ✅ | ✅ | ✅ | ✅ |
| HTTP/2 API | ✅ | ✅ | ✅ | ✅ | - |
| HTTP/3 API | ✅ | ✅ | ✅ | ✅ | - |
| TLS 1.2/1.3 | ✅ | ✅ | - | - | - |
| TLS 1.1 rejection | ✅ | ✅ | - | - | - |
| **CA Rotation** | ✅ (opt) | ✅ | ❌ | ❌ | ❌ |
| Full chain | - | ✅ | - | - | - |
| Microservices | - | - | ✅ | ✅ | - |
| gRPC | - | - | - | ✅ | ✅ |
| ALPN | - | - | - | - | ✅ |

## HTTP/3 Testing Helper

All scripts now use the `http3_curl` helper from `scripts/lib/http3.sh` for reliable HTTP/3 testing on macOS. This helper runs `alpine/curl-http3` inside the Kind control-plane network namespace to bypass Docker-for-mac UDP limitations.

## Recommended Test Sequence

1. **Quick verification** (no rotation):
   ```bash
   SKIP_ROTATION=1 ./scripts/test-http2-http3-strict-tls.sh
   ```

2. **Full chain with rotation**:
   ```bash
   ./scripts/test-full-chain-with-rotation.sh
   ```

3. **Microservices workflows**:
   ```bash
   ./scripts/test-microservices-http2-http3.sh
   ```

4. **gRPC services**:
   ```bash
   ./scripts/test-grpc-http2-http3.sh
   ```

5. **Protocol debugging** (if needed):
   ```bash
   ./scripts/test-grpc-http2-http3-alpn.sh
   ```

## Notes

- **CA Rotation**: Only `test-http2-http3-strict-tls.sh` (optional) and `test-full-chain-with-rotation.sh` test CA rotation. This is intentional as rotation is a destructive operation that should be tested separately.
- **HTTP/3 Helper**: All scripts use `http3_curl` for consistent HTTP/3 testing across macOS and Linux.
- **Zero-downtime**: CA rotation tests monitor requests during rotation to verify zero-downtime behavior.

