# ADR-001: Migrate from Docker Desktop to Colima with containerd

**Status**: Accepted  
**Date**: January 6, 2026  
**Deciders**: Tom  
**Technical Story**: Docker Desktop VM wedged due to storage/metadata pressure (256GB Docker.raw)

## Context

The record-platform (RP) microservices stack has outgrown Docker Desktop's design limits:

**Symptoms**:
- Docker CLI commands (`docker ps`, `docker system df`, `docker info`) hanging for 15+ hours
- Docker.raw file size: 256GB (should be <40-60GB)
- LinuxKit VM wedged in metadata traversal (overlay2, image layers, volume references)
- Docker backend processes alive but unresponsive

**Root Cause**:
- RP workload exceeds Docker Desktop's happy path:
  - 8 PostgreSQL databases
  - Kafka + Zookeeper
  - Kind clusters (nested Kubernetes)
  - Frequent service rebuilds
  - k6 load tests (50-100 VUs)
  - Long-running containers
  - Large logs accumulating
- Docker Desktop's LinuxKit VM with Docker.raw filesystem cannot handle this scale long-term

**Why This Matters**:
- Development velocity blocked by Docker Desktop failures
- Cannot reliably run load tests
- Cannot rebuild services (Python AI build hung for hours)
- Production-grade development environment needed

## Decision

**We will migrate from Docker Desktop to Colima with containerd runtime**.

### Why Colima?

**Colima Advantages**:
1. **Real ext4 filesystem** (no Docker.raw ballooning)
   - Uses native Linux filesystem via QEMU
   - Predictable disk usage
   - No VM metadata corruption

2. **containerd runtime** (production-grade)
   - Kubernetes-native runtime
   - Better resource management
   - Faster image pulls and layer management
   - Industry standard (what Kubernetes uses)

3. **Stable under load**
   - Designed for production workloads
   - No VM wedging under metadata pressure
   - Predictable I/O performance

4. **Better Kind support**
   - Kind designed to work with containerd
   - Cleaner networking
   - Faster cluster operations

5. **Faster rebuilds**
   - Better caching
   - Parallel layer downloads
   - No Docker Desktop overhead

6. **Open source**
   - Community-driven
   - Actively maintained
   - Transparent issues/roadmap

### Why containerd over Docker runtime?

**containerd Advantages**:
1. **Kubernetes-native**: Kind and Kubernetes use containerd by default
2. **Faster**: Lower overhead than Docker daemon
3. **Production-ready**: Used in production Kubernetes clusters
4. **Better resource management**: More efficient memory/CPU usage
5. **Compatible**: Docker CLI still works (via containerd shim)

**Docker Runtime Considered**:
- Works but adds unnecessary overhead
- Docker daemon layer not needed for Kubernetes workloads
- containerd is what production Kubernetes uses

## Consequences

### Positive

1. **Reliability**: No more VM wedging or storage bloat issues
2. **Performance**: Faster builds, pulls, and cluster operations
3. **Scalability**: Can handle RP's full workload without degradation
4. **Predictability**: Real filesystem behavior (no hidden Docker.raw growth)
5. **Production alignment**: Development environment matches production (containerd)

### Negative

1. **Migration effort**: ~1 hour to migrate (one-time cost)
2. **Learning curve**: Minor differences in CLI behavior (mostly transparent)
3. **macOS-specific**: Colima is macOS/Linux only (not Windows)
4. **Resource management**: Need to configure resources manually (CPU/memory)

### Neutral / Mitigated

1. **Image compatibility**: All Docker images work with containerd (OCI standard)
2. **Kind cluster**: Works better with containerd (native runtime)
3. **Docker Compose**: Can use `docker compose` or migrate to `docker compose v2` (recommended)
4. **Tooling**: Docker CLI, kubectl, kind all work the same

## Alternatives Considered

### Alternative 1: Reset Docker Desktop + Hygiene Rules

**Pros**:
- No migration required
- Familiar interface

**Cons**:
- Only delays the failure (will happen again)
- Requires constant maintenance (daily cleanup)
- Resource caps limit development
- Still has Docker.raw ballooning risk

**Verdict**: ❌ Not sustainable for RP's workload

### Alternative 2: OrbStack

**Pros**:
- Excellent macOS integration
- Faster than Docker Desktop
- Good UX

**Cons**:
- Proprietary (less transparent)
- May have similar issues at scale
- containerd support newer

**Verdict**: ⚠️ Good option, but Colima + containerd is more production-aligned

### Alternative 3: UTM + Linux VM

**Pros**:
- Full control
- Production-like environment

**Cons**:
- Significant setup overhead
- More resource usage
- Manual networking configuration

**Verdict**: ❌ Too much overhead for development

### Alternative 4: Stay on Docker Desktop

**Pros**:
- No migration required

**Cons**:
- Will wedge again (proven by 256GB Docker.raw)
- Blocks development velocity
- Not suitable for RP's workload

**Verdict**: ❌ Not viable - already failed multiple times

## Implementation Plan

### Phase 1: Colima Setup (30 minutes)

1. Install Colima via Homebrew
2. Configure Colima with containerd runtime
3. Set resource limits (CPU: 8, Memory: 12GB, Disk: 200GB)
4. Verify containerd runtime

### Phase 2: Kind Cluster Migration (20 minutes)

1. Export existing Kind cluster config (if needed)
2. Delete Docker Desktop Kind cluster
3. Create new Kind cluster in Colima
4. Verify cluster connectivity

### Phase 3: Image Migration (10 minutes)

1. Rebuild and load all service images
2. Deploy services
3. Verify all services healthy

### Phase 4: Documentation (10 minutes)

1. Update setup guides
2. Document Colima commands
3. Update troubleshooting guides

**Total Time**: ~1 hour (one-time migration)

## Success Criteria

- [ ] Colima running with containerd runtime
- [ ] Kind cluster created and working
- [ ] All services deployed and healthy
- [ ] Load tests running successfully
- [ ] Docker.raw equivalent stays <50GB under normal load
- [ ] No VM wedging or storage issues after 1 week of normal use

## Monitoring

Track these metrics post-migration:
- Disk usage (should stay <50GB, not grow to 256GB)
- Build times (should be faster)
- Cluster startup time (should be faster)
- Load test success rates (should be stable)

## Rollback Plan

If Colima doesn't work:
1. Stop Colima: `colima stop`
2. Reinstall Docker Desktop
3. Reset Docker Desktop to factory defaults
4. Recreate Kind cluster
5. Rebuild images

However, this ADR assumes Colima will work (based on community feedback and production usage).

## References

- [Colima Documentation](https://github.com/abiosoft/colima)
- [containerd Documentation](https://containerd.io/)
- [Kind with containerd](https://kind.sigs.k8s.io/docs/user/quick-start/#installation)
- [Docker Desktop Recovery Runbook](./../../Runbook.md#critical-issue-22-docker-desktop-vm-wedged---storagemetadata-pressure-january-6-2026)

## Notes

- This is a **development environment change** (production uses Kubernetes with containerd anyway)
- Migration is **reversible** but not recommended (Docker Desktop will fail again)
- **RP is reproducible** (all services can be rebuilt), so losing images during migration is fine

---

**Last Updated**: January 6, 2026  
**Status**: ✅ Accepted and Ready for Implementation
