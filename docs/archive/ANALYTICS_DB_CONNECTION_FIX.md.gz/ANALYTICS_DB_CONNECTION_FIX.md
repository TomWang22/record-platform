# Analytics Service Database Connection Fix

## Problem

The `analytics-service` in Kubernetes is failing to connect to PostgreSQL databases because:
- `host.docker.internal` from Kind cluster may not route correctly to Docker Compose containers
- Port 5435 might be connecting to Postgres.app on the host instead of Docker Compose `postgres-listings`
- The Kind cluster needs a reliable way to reach Docker Compose PostgreSQL instances

## Current Configuration

**Docker Compose PostgreSQL Containers:**
- `postgres-listings`: Port 5435 → Contains `records` database
- `postgres-analytics`: Port 5439 → Contains `analytics` database

**Kubernetes ConfigMap (`app-config.yaml`):**
```yaml
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@host.docker.internal:5435/records?connect_timeout=5
POSTGRES_URL_ANALYTICS: postgresql://postgres:postgres@host.docker.internal:5439/analytics?connect_timeout=5
```

## Solution Options

### Option 1: Use Host Machine IP (Quick Fix)

If `host.docker.internal` doesn't work from Kind cluster, use the actual host IP:

```bash
# Get your host IP
HOST_IP=$(ipconfig getifaddr en0)  # macOS
# or
HOST_IP=$(hostname -I | awk '{print $1}')  # Linux

# Update ConfigMap
kubectl patch configmap app-config -n record-platform --type merge -p "{
  \"data\": {
    \"POSTGRES_URL_ANALYTICS\": \"postgresql://postgres:postgres@${HOST_IP}:5439/analytics?connect_timeout=5\",
    \"POSTGRES_URL_LISTINGS\": \"postgresql://postgres:postgres@${HOST_IP}:5435/records?connect_timeout=5\"
  }
}"

# Restart analytics-service
kubectl rollout restart deployment/analytics-service -n record-platform
```

### Option 2: Use Kubernetes Services (Better for Production)

Create Kubernetes Services that forward to Docker Compose:

```yaml
# infra/k8s/base/postgres/external-services.yaml
apiVersion: v1
kind: Service
metadata:
  name: postgres-listings-external
  namespace: record-platform
spec:
  type: ExternalName
  externalName: host.docker.internal
  ports:
    - port: 5435
      targetPort: 5435
---
apiVersion: v1
kind: Service
metadata:
  name: postgres-analytics-external
  namespace: record-platform
spec:
  type: ExternalName
  externalName: host.docker.internal
  ports:
    - port: 5439
      targetPort: 5439
```

Then update ConfigMap to use service names:
```yaml
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@postgres-listings-external.record-platform.svc.cluster.local:5435/records
POSTGRES_URL_ANALYTICS: postgresql://postgres:postgres@postgres-analytics-external.record-platform.svc.cluster.local:5439/analytics
```

### Option 3: Port Forward from Kind to Host (Development Only)

Use `kubectl port-forward` to expose Docker Compose ports:

```bash
# In separate terminals
kubectl port-forward -n record-platform svc/postgres-listings 5435:5435
kubectl port-forward -n record-platform svc/postgres-analytics 5439:5439
```

## Automated Fix Script

Run the automated fix script:

```bash
./scripts/fix-analytics-db-connection.sh
```

This script will:
1. ✅ Verify databases exist in Docker Compose
2. ✅ Test connections from host
3. ✅ Test connections from Kind cluster
4. ✅ Update ConfigMap if needed
5. ✅ Restart analytics-service
6. ✅ Verify the fix worked

## Verification

After applying the fix, verify the connection:

```bash
# Check analytics-service logs
kubectl logs -n record-platform -l app=analytics-service --tail=50

# Check if health check passes
kubectl get pods -n record-platform -l app=analytics-service

# Test health endpoint
kubectl port-forward -n record-platform svc/analytics-service 4004:4004
curl http://localhost:4004/healthz
```

## Troubleshooting

### Issue: "Connection refused" or "ECONNREFUSED"

**Causes:**
- Docker Compose PostgreSQL containers not running
- Firewall blocking connections
- Wrong port number

**Fix:**
```bash
# Check Docker Compose containers
docker ps | grep postgres

# Check if ports are listening
lsof -i :5435
lsof -i :5439

# Test from host
psql -h localhost -p 5435 -U postgres -d records -c "SELECT 1;"
psql -h localhost -p 5439 -U postgres -d analytics -c "SELECT 1;"
```

### Issue: "Database does not exist"

**Fix:**
```bash
# Create analytics database
docker exec -it record-platform-postgres-analytics-1 psql -U postgres -c "CREATE DATABASE analytics;"

# Create records database in postgres-listings
docker exec -it record-platform-postgres-listings-1 psql -U postgres -c "CREATE DATABASE records;"
```

### Issue: "host.docker.internal" doesn't resolve

**Fix:**
- Use actual host IP instead (see Option 1)
- Or use Kubernetes Services (see Option 2)

## Long-Term Solution

For production, consider:
1. **Move PostgreSQL to Kubernetes**: Use StatefulSets with PersistentVolumes
2. **Use Database Services**: Expose PostgreSQL via Kubernetes Services
3. **Connection Pooling**: Use PgBouncer for better connection management
4. **Service Mesh**: Use Istio/Linkerd for better service-to-service communication

## Related Files

- `infra/k8s/base/config/app-config.yaml` - Database connection strings
- `infra/k8s/base/analytics-service/deploy.yaml` - Analytics service deployment
- `services/analytics-service/src/db.ts` - Database connection code
- `scripts/fix-analytics-db-connection.sh` - Automated fix script

