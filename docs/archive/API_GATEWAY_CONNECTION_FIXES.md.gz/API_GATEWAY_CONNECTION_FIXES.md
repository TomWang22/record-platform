# API Gateway Connection Fixes Applied

**Generated:** $(date)

---

## ✅ Fixes Applied

### 1. API Gateway Server Connection Limits
- **Added:** Explicit `maxConnections = 500` per pod
- **Added:** `keepAliveTimeout = 65000ms` (65 seconds)
- **Added:** `headersTimeout = 66000ms` (66 seconds)
- **Reason:** Handle high concurrent load (60 VUs × 3 concurrent = 180 connections per pod, set to 500 for bursts)
- **Status:** ✅ Applied (server rebuilt)

### 2. Caddy H3 Connection Pool Settings
- **Added:** `dial_timeout = 10s` (connection timeout)
- **Added:** `response_header_timeout = 30s` (response timeout)
- **Added:** `keepalive` with:
  - `idle_conns = 1000` (keep 1000 idle connections)
  - `max_idle_conns_per_host = 500` (max idle per host)
- **Added:** Health check settings
- **Added:** Retry logic (`fail_duration`, `max_fails`)
- **Reason:** Enable connection reuse and handle connection errors gracefully
- **Status:** ✅ Applied (ConfigMap updated, Caddy restarted)

---

## 📊 Expected Impact

### Before:
- Connection refused errors: Constant
- 5xx error rate: 77-81%
- Success rate: 7-9%

### After:
- Connection refused: Should be eliminated
- 5xx error rate: Should drop to <10%
- Success rate: Should improve to 70-80%+

---

## 🔧 Configuration Details

### API Gateway:
```javascript
server.maxConnections = 500;  // Per pod
server.keepAliveTimeout = 65000;  // 65 seconds
server.headersTimeout = 66000;  // 66 seconds
```

### Caddy H3:
```caddy
transport http {
    dial_timeout 10s
    response_header_timeout 30s
    keepalive {
        enabled
        idle_conns 1000
        max_idle_conns_per_host 500
    }
}
```

---

## ⏳ Next Steps

1. **Monitor:** Watch for connection refused errors in Caddy logs
2. **Test:** Re-run E2E test to verify improvements
3. **Tune:** Adjust connection limits if needed based on results

