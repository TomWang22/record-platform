# API Gateway Connection Refused - Final Root Cause

**Generated:** $(date)

---

## 🔴 Problem

Caddy H3 getting "connection refused" errors to API Gateway, despite:
- ✅ Network connectivity working (connection test shows OPEN)
- ✅ API Gateway pods running (3/3)
- ✅ Port 4000 listening
- ✅ Service endpoints configured

---

## 🔍 Root Cause Analysis

### Key Finding:
**Connection test shows OPEN, but Caddy still gets "connection refused"**

This indicates the issue is NOT network connectivity, but rather:
1. **Server-side connection limits** (Express/Node.js)
2. **Connection pool exhaustion** (Caddy H3)
3. **Rate limiting** (API Gateway)
4. **Ephemeral port exhaustion** (Caddy H3)

### Current Configuration:
- **API Gateway:**
  - Replicas: 3
  - Outgoing connection pool: maxSockets=2000 (for backend services)
  - Incoming connections: No explicit limit (Node.js default)
  - Port: 4000 (listening)

- **Caddy H3:**
  - Connection pool: Need to check
  - Timeout settings: Need to check

---

## 🔧 Likely Root Causes

### 1. Node.js Default Connection Limits
- Node.js HTTP server has default connection handling
- Under high load, may refuse new connections
- No explicit maxConnections set

### 2. Caddy H3 Connection Pool Exhaustion
- Caddy may be exhausting its connection pool
- Each request creates a new connection
- Connections not being reused properly

### 3. Load Balancer Connection Distribution
- Service load balancer may have issues
- Connections not distributed evenly
- Health check interference

---

## 🔧 Fixes Needed

### IMMEDIATE:
1. **Check Caddy H3 Connection Pool Settings**
   - Increase connection pool if too low
   - Enable connection reuse
   - Adjust timeout settings

2. **Check API Gateway Server Limits**
   - Set explicit maxConnections if needed
   - Check for rate limiting
   - Verify server can handle load

3. **Scale Services**
   - More API Gateway replicas if needed
   - More Caddy H3 replicas if needed

