# Auction Monitor Service - Architecture & Design Brainstorm

## Overview

The Auction Monitor service is designed to track, monitor, and analyze auction listings across multiple platforms (eBay, Buyee, YahooJP, CarousellHK, RecordCity, etc.) based on user-defined search criteria. The service integrates with the Analytics service to provide price analysis and historical sales comparisons.

> **📋 See [AUCTION_MONITOR_DATA_PIPELINE.md](./AUCTION_MONITOR_DATA_PIPELINE.md) for comprehensive data pipeline architecture, implementation details, and platform-specific adapters.**

## Quick Start: Data Pipeline Summary

**Core Challenge**: Ingest high-quality auction data from diverse sources (APIs + scraping) with varying formats, rate limits, and reliability, then consolidate into a unified model for analytics and AI.

**Solution Architecture**:
1. **Extraction Layer**: Platform adapters (eBay API, Discogs API, Buyee/YahooJP/CarousellHK/RecordCity scraping)
2. **Transformation Layer**: Schema normalization, field mapping, validation
3. **Quality Engine**: Deduplication, confidence scoring, data enrichment
4. **Staging Layer**: Raw → Normalized → Validated pipeline
5. **Analytics Integration**: Clean data → Statistical analysis → Price percentiles → Python AI

**Key Platforms**:
- ✅ **eBay** (Official API) - High reliability, structured data
- ✅ **Discogs** (Official API) - High reliability, music-focused
- ⚠️ **Buyee** (Scraping) - Medium reliability, proxy service integration
- ⚠️ **YahooJP** (Scraping) - Medium reliability, Japanese language
- ⚠️ **CarousellHK** (Scraping) - Medium reliability, Hong Kong marketplace
- ⚠️ **RecordCity** (Scraping) - Medium reliability, multi-region (UK/US/EU)

**Data Quality Strategy**: 
- Confidence scoring (0.0-1.0) based on completeness, source reliability, freshness, enrichment
- Only feed high-confidence data (≥0.7) to Analytics Service and Python AI
- Comprehensive monitoring and quality metrics tracking

## Core Functionality

### 1. User Input & Search Criteria

**User-Defined Parameters:**
- **Search Terms**: Artist, album, catalog number, format, condition
- **Location**: User's geographic location (critical for shipping, taxes, restrictions)
- **Price Range**: Min/max acceptable prices
- **Platform Preferences**: Which platforms to monitor (eBay, Buyee, YahooJP, etc.)
- **Notification Preferences**: Email, push, in-app alerts
- **Watch Duration**: How long to monitor (indefinite, until found, time-bound)

**Location Impact:**
- **Shipping Restrictions**: Some sellers don't ship to certain countries
- **Import Taxes/Duties**: Varies by country (e.g., Japan → US has different rules than EU → US)
- **Currency Conversion**: Real-time exchange rates affect final price
- **Platform Availability**: Some platforms are region-locked (e.g., YahooJP primarily Japan)
- **Payment Methods**: PayPal, credit cards, bank transfers vary by region
- **Legal Restrictions**: Certain items may be restricted in specific countries (e.g., vinyl with explicit content, cultural artifacts)

### 2. Review Restrictions & User Eligibility

**Review-Based Restrictions:**
- **New User Restrictions**: Platforms like eBay may restrict new users from bidding on high-value items
- **Account Age Requirements**: Some sellers require buyers to have accounts older than X months
- **Feedback Score Thresholds**: Minimum feedback score required (e.g., "Buyers with < 10 feedback cannot bid")
- **Payment Verification**: Some sellers require verified payment methods
- **Geographic Restrictions**: Sellers may restrict bidding to specific countries/regions

**Flagging Strategy:**
- **Reference-Only Flag**: When a user cannot bid due to restrictions, flag the listing as "reference only"
- **Reason Tracking**: Store why it's reference-only (review restriction, location, payment method, etc.)
- **Eligibility Check**: Pre-check user's eligibility before showing listings
- **Alternative Suggestions**: If user can't bid, suggest similar items they CAN bid on

### 3. Platform Integration

#### eBay
- **API Access**: eBay Finding API, Browse API, Trading API
- **Data Points**: Title, description, images, seller feedback, shipping info, bid history
- **Completed Listings**: Historical sales data via Completed Items API
- **Real-Time Monitoring**: Webhook support for new listings matching criteria
- **Challenges**: Rate limits, API key management, OAuth for user-specific searches

#### Buyee (Japan Proxy Service)
- **Scraping Required**: No official API (may need web scraping with proper ToS compliance)
- **Data Points**: YahooJP listings, shipping to proxy warehouse, proxy fees, international shipping
- **Additional Costs**: Proxy service fees, consolidation fees, international shipping
- **Currency**: JPY → User's currency conversion
- **Challenges**: ToS compliance, rate limiting, HTML parsing

#### YahooJP Auctions
- **Scraping Required**: No official API
- **Data Points**: Title, images, seller rating, shipping options, bid history
- **Language**: Japanese titles/descriptions (may need translation)
- **Proxy Service**: Usually requires Buyee or similar proxy for international buyers
- **Challenges**: Language barriers, proxy service integration, scraping reliability

#### Discogs Marketplace
- **API Available**: Discogs API v2.0
- **Data Points**: Release information, seller ratings, price history, condition notes
- **Advantages**: Structured data, official API, music-focused
- **Integration**: Can cross-reference with Discogs database for catalog numbers, formats

#### Other Platforms (Future)
- **Mercari**: Japan-based marketplace
- **Rakuten**: Japan-based marketplace
- **Grailed**: Fashion/streetwear (if expanding beyond music)
- **Heritage Auctions**: High-end collectibles
- **Christie's/Sotheby's**: Premium auctions (if expanding)

### 4. Data Collection & Storage

**Real-Time Monitoring:**
- **Polling Strategy**: Periodic checks (every 5-15 minutes) for new listings
- **Webhook Integration**: Where available (eBay, some platforms)
- **Change Detection**: Track price changes, bid count, time remaining
- **Historical Tracking**: Store snapshots of listings over time

**Data Schema Considerations:**
```sql
-- Core listing data
auction_listings:
  - id, platform, external_id, url
  - title, description, images
  - current_price, starting_price, buy_it_now_price
  - currency, shipping_cost, estimated_total
  - seller_info (id, feedback_score, location)
  - listing_dates (start, end, time_remaining)
  - condition, format, catalog_number
  - location_restrictions, payment_restrictions
  - review_restrictions (min_feedback, account_age, etc.)
  - user_eligibility_status (eligible, restricted, reference_only)
  - restriction_reasons (array of reasons)

-- User watch criteria
user_watches:
  - user_id, search_criteria (JSON)
  - platforms, price_range, location
  - notification_preferences
  - created_at, expires_at, status

-- Historical price data
price_history:
  - listing_id, timestamp, price
  - bid_count, watchers_count
  - snapshot_data (JSON)

-- Completed sales (for analytics)
completed_sales:
  - platform, external_id, sold_price
  - sold_date, condition, format
  - seller_location, buyer_location (if available)
  - shipping_cost, total_cost
  - catalog_number, artist, title
```

### 5. Analytics Service Integration

**Data Pipeline:**
```
Auction Monitor → Data Collection → Analytics Service → Price Analysis → User Notifications
```

**Analytics Service Responsibilities:**
1. **Price Analysis**:
   - Compare current listing price vs. historical sales
   - Calculate price percentiles (p25, p50, p75, p95, p99)
   - Identify outliers (too high, too low)
   - Trend analysis (prices increasing/decreasing over time)

2. **Historical Sales Comparison**:
   - **Discogs API**: Price history for specific releases
   - **Popsike**: Historical eBay sales data (if accessible)
   - **Gripsweat**: Historical sales data (if accessible)
   - **eBay Completed Items**: Recent completed sales
   - **Internal Database**: Our own collected completed sales

3. **Data Completeness Challenges**:
   - **Missing Historical Data**: Not all items have complete sales history
   - **Condition Variations**: "Mint" vs "Near Mint" vs "VG+" affects price significantly
   - **Format Variations**: LP vs 7" vs CD vs cassette
   - **Geographic Price Variations**: Prices differ by region (Japan vs US vs EU)
   - **Time-Based Variations**: Prices fluctuate over time (inflation, market trends)

**Handling Incomplete Data:**
- **Confidence Scores**: Rate analysis confidence (high/medium/low) based on data completeness
- **Partial Matches**: Use fuzzy matching for catalog numbers, artist names
- **Similar Item Analysis**: If exact match not found, analyze similar items (same artist, similar format)
- **Market Trends**: Use broader market trends when specific item data is unavailable
- **Flagging**: Clearly indicate when analysis is based on incomplete data

### 6. Price Analysis Algorithms

**Multi-Source Price Comparison:**
```
Current Listing Price: $50.00
├─ Discogs Price History:
│  ├─ Last 6 months: $45, $48, $52, $47, $49 (avg: $48.20)
│  └─ Confidence: High (5 recent sales)
├─ eBay Completed Sales:
│  ├─ Last 3 months: $52, $55, $48, $51 (avg: $51.50)
│  └─ Confidence: Medium (4 sales, but condition varies)
├─ Popsike Historical:
│  ├─ All-time average: $46.00
│  └─ Confidence: Low (old data, may not reflect current market)
└─ Recommendation: "Fair price, slightly above average but within normal range"
```

**Price Recommendation Logic:**
- **Excellent Deal**: Current price < p25 (25th percentile)
- **Good Deal**: Current price between p25 and p50
- **Fair Price**: Current price between p50 and p75
- **Above Average**: Current price between p75 and p95
- **Overpriced**: Current price > p95

**Confidence Scoring:**
- **High**: 10+ recent sales, multiple sources, consistent data
- **Medium**: 5-9 sales, 2+ sources, some data gaps
- **Low**: <5 sales, single source, significant data gaps

### 7. Notification System

**Trigger Events:**
- New listing matching criteria
- Price drop (below user's max price)
- Price increase (above user's threshold)
- Time remaining (e.g., "ending in 1 hour")
- Eligibility change (e.g., user's feedback score increased, now eligible)

**Notification Channels:**
- **In-App**: Real-time notifications in webapp
- **Email**: Daily/weekly digests or immediate alerts
- **Push Notifications**: Mobile app (if available)
- **Webhook**: For third-party integrations

**Notification Content:**
- Listing title, images, current price
- Price analysis (deal rating, historical comparison)
- Eligibility status (can bid vs reference only)
- Time remaining, seller info
- Direct link to listing

### 8. User Experience Considerations

**Dashboard Features:**
- **Active Watches**: List of items being monitored
- **Recent Matches**: New listings found
- **Price Alerts**: Items that dropped in price
- **Reference-Only Items**: Items user can't bid on but are tracking
- **Analytics View**: Price trends, market analysis
- **Saved Searches**: Reusable search criteria

**Filtering & Sorting:**
- By platform (eBay, Buyee, YahooJP, etc.)
- By price range
- By deal rating (excellent, good, fair, etc.)
- By eligibility (can bid, reference only)
- By time remaining
- By confidence score (high/medium/low)

**Reference-Only Items:**
- Clearly marked with badge/icon
- Show reason for restriction (hover tooltip)
- Option to "dismiss" or "keep as reference"
- Suggest similar items user CAN bid on
- Track price trends even if can't bid (for market research)

### 9. Technical Architecture

**Service Components:**
```
┌─────────────────────────────────────────────────────────────┐
│                    Auction Monitor Service                   │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Platform   │  │   Platform   │  │   Platform   │      │
│  │   Scraper    │  │   Scraper    │  │   Scraper    │      │
│  │   (eBay)     │  │  (Buyee)     │  │ (YahooJP)    │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         │                  │                  │            │
│         └──────────────────┼──────────────────┘            │
│                            │                                │
│                   ┌────────▼────────┐                       │
│                   │  Data Processor │                       │
│                   │  (Normalize,    │                       │
│                   │   Validate)     │                       │
│                   └────────┬────────┘                       │
│                            │                                │
│         ┌──────────────────┼──────────────────┐            │
│         │                  │                  │            │
│  ┌──────▼──────┐  ┌────────▼────────┐  ┌──────▼──────┐    │
│  │  Eligibility│  │   Analytics    │  │ Notification │    │
│  │   Checker   │  │   Integration  │  │   Service    │    │
│  └─────────────┘  └─────────────────┘  └──────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

**Database:**
- **PostgreSQL**: Primary data store (listings, watches, history)
- **Redis**: Caching (frequently accessed listings, price data)
- **TimescaleDB** (optional): For time-series price data if needed

**External APIs:**
- **Discogs API**: Release data, price history
- **eBay API**: Listings, completed sales
- **Currency Exchange API**: Real-time conversion rates
- **Geolocation API**: User location validation, shipping cost estimation

**Message Queue:**
- **Kafka**: For async processing (scraping jobs, notifications)
- **Topics**: `auction-listings`, `price-updates`, `notifications`

### 10. Data Completeness Strategy

**Tiered Data Approach:**

**Tier 1: High Confidence (Complete Data)**
- Exact catalog number match
- Multiple recent sales (10+)
- Consistent condition ratings
- Multiple platform sources
- **Action**: Provide detailed analysis, high confidence recommendations

**Tier 2: Medium Confidence (Partial Data)**
- Fuzzy catalog number match
- Some recent sales (5-9)
- Condition variations present
- 2+ platform sources
- **Action**: Provide analysis with confidence warnings, suggest similar items

**Tier 3: Low Confidence (Minimal Data)**
- No exact matches, similar items only
- Few sales (<5) or old data
- Significant condition/format variations
- Single source
- **Action**: Flag as "limited data", show market trends instead of specific recommendations

**Handling Missing Data:**
- **Gap Filling**: Use similar items (same artist, similar format/condition)
- **Market Trends**: Use broader category trends (e.g., "vinyl prices up 15% this year")
- **User Education**: Explain why data is limited, what it means
- **Continuous Improvement**: As more data is collected, confidence increases

### 11. Review Restrictions Implementation

**Pre-Bid Eligibility Check:**
```javascript
async function checkUserEligibility(userId, listing) {
  const user = await getUser(userId);
  const restrictions = listing.restrictions;
  
  const checks = {
    feedbackScore: user.feedbackScore >= restrictions.minFeedback,
    accountAge: user.accountAgeMonths >= restrictions.minAccountAge,
    location: restrictions.allowedCountries.includes(user.country),
    paymentVerified: user.paymentVerified || !restrictions.requiresVerifiedPayment,
  };
  
  const eligible = Object.values(checks).every(check => check === true);
  const reasons = Object.entries(checks)
    .filter(([_, passed]) => !passed)
    .map(([reason, _]) => reason);
  
  return {
    eligible,
    reasons,
    listingStatus: eligible ? 'can_bid' : 'reference_only'
  };
}
```

**Reference-Only Handling:**
- Store listings even if user can't bid
- Track price trends for market research
- Notify user if they become eligible (e.g., feedback score increased)
- Show "Why can't I bid?" tooltip with specific reasons

### 12. Location-Based Considerations

**Shipping Cost Calculation:**
- **Seller Location** → **User Location**: Calculate shipping cost
- **Proxy Services**: If using Buyee/YahooJP, add proxy fees + international shipping
- **Import Taxes**: Estimate based on user's country (varies by country, item value)
- **Currency Conversion**: Convert all prices to user's preferred currency

**Total Cost Calculation:**
```
Item Price: ¥5,000 (JPY)
+ Proxy Fee: ¥500 (10%)
+ Consolidation: ¥300 (if multiple items)
+ International Shipping: ¥2,000
+ Import Tax (estimated): ¥800 (16% for items > $800 in US)
= Total: ¥8,600 ≈ $58.50 USD
```

**Location Restrictions:**
- Some sellers don't ship internationally
- Some platforms are region-locked
- Some items have legal restrictions (cultural artifacts, explicit content)
- Payment methods vary by region

### 13. Future Enhancements

**Machine Learning Integration:**
- **Price Prediction**: Predict future prices based on trends
- **Deal Detection**: ML model to identify "too good to be true" deals (potential scams)
- **Recommendation Engine**: Suggest items user might be interested in

**Advanced Analytics:**
- **Market Trends**: Track price trends over time (inflation, market shifts)
- **Seasonal Patterns**: Identify seasonal price variations
- **Seller Analysis**: Track seller reliability, pricing patterns

**Multi-User Features:**
- **Shared Watches**: Groups/friends can share watch lists
- **Community Insights**: Aggregate user data (anonymized) for market insights
- **Price Alerts for Friends**: "Your friend is watching this item"

**Integration with Other Services:**
- **Listings Service**: Cross-reference with user's own listings
- **Shopping Service**: Add to cart directly from auction monitor
- **Social Service**: Share finds with friends, discuss deals

## Implementation Phases

### Phase 1: Foundation & Data Pipeline (Weeks 1-4)
**Goal**: Build solid data ingestion foundation with high-quality data sources

1. **Database Schema** (Week 1)
   - Create `auction_monitor` schema in PostgreSQL
   - Implement staging tables (`raw_listings`, `normalized_listings`)
   - Set up price history time-series tables
   - Create indexes and constraints

2. **Platform Adapters - Official APIs** (Week 2)
   - eBay API adapter (Finding API, Browse API)
   - Discogs API adapter (Database API, Marketplace API)
   - Rate limiting and retry logic
   - Error handling and monitoring

3. **Data Normalization & Validation** (Week 3)
   - Schema mapper (platform-specific → unified schema)
   - Field normalizer (prices, currencies, conditions, dates)
   - Validation engine (required fields, data types, business rules)
   - Completeness and confidence scoring

4. **Staging Pipeline** (Week 4)
   - Raw → Normalized transformation
   - Validation and quality checks
   - Deduplication engine
   - Data enrichment (Discogs catalog matching)

**Deliverable**: High-quality data from eBay + Discogs flowing into normalized schema

### Phase 2: Scraping Infrastructure (Weeks 5-8)
**Goal**: Add scraping platforms with proper rate limiting and error handling

1. **Scraping Infrastructure** (Week 5)
   - Puppeteer setup and browser pool management
   - Rate limiting per platform
   - CAPTCHA handling strategy
   - Error recovery and retry logic

2. **Buyee & YahooJP Adapters** (Week 6)
   - Buyee adapter (proxy service integration)
   - YahooJP adapter (Japanese language handling)
   - Translation service integration (optional)
   - Proxy fee calculation

3. **CarousellHK & RecordCity Adapters** (Week 7)
   - CarousellHK adapter (Hong Kong marketplace)
   - RecordCity adapters (UK, US, EU regions)
   - Multi-region support and currency handling

4. **Data Quality Hardening** (Week 8)
   - Enhanced deduplication (fuzzy matching)
   - Improved confidence scoring
   - Platform health monitoring
   - Quality metrics dashboards

**Deliverable**: Multi-platform data ingestion with quality controls

### Phase 3: Analytics Integration (Weeks 9-12)
**Goal**: Connect Auction Monitor to Analytics Service for price analysis

1. **Analytics Service Integration** (Week 9)
   - Ingestion pipeline from `normalized_listings`
   - Price snapshot storage (time-series)
   - Historical price tracking

2. **Statistical Analysis** (Week 10)
   - Price percentile calculation (p25, p50, p75, p95)
   - Similar item matching
   - Trend analysis
   - Confidence intervals

3. **Data Quality Reporting** (Week 11)
   - Quality metrics tracking
   - Platform health dashboards
   - Alerting for low-quality data
   - Data completeness reports

4. **User Watch System** (Week 12)
   - User watch criteria storage
   - Matching engine (listings → watches)
   - Notification system (email, in-app)
   - Reference-only item handling

**Deliverable**: Full analytics pipeline with price analysis and user notifications

### Phase 4: Python AI Integration (Weeks 13-16)
**Goal**: Feed clean data to Python AI Service for ML/AI features

1. **Python AI Service Setup** (Week 13)
   - FastAPI service for ML model serving
   - Hugging Face Transformers integration
   - Model caching and optimization

2. **Price Prediction Models** (Week 14)
   - Train regression models on Analytics data
   - Price prediction API
   - Deal detection (too good to be true)
   - Confidence scoring for predictions

3. **Content Generation** (Week 15)
   - Title optimization (GPT-2/T5)
   - Description generation
   - Keyword extraction
   - SEO optimization

4. **Negotiation AI** (Week 16)
   - Sentiment analysis (RoBERTa)
   - Response generation (DialoGPT)
   - Negotiation coaching
   - Mood tracking

**Deliverable**: AI-powered features using high-quality auction data

### Phase 5: Production Hardening (Weeks 17-20)
**Goal**: Production-ready system with monitoring, scaling, and reliability

1. **Performance Optimization** (Week 17)
   - Database query optimization
   - Caching strategies (Redis)
   - Batch processing for large datasets
   - Load testing and tuning

2. **Monitoring & Observability** (Week 18)
   - Prometheus metrics
   - Grafana dashboards
   - Alerting rules
   - Log aggregation

3. **Error Handling & Recovery** (Week 19)
   - Circuit breakers for platform adapters
   - Graceful degradation
   - Data recovery procedures
   - Backup and restore

4. **Documentation & Testing** (Week 20)
   - API documentation
   - Architecture diagrams
   - Integration tests
   - Load testing results

**Deliverable**: Production-ready Auction Monitor with full observability

## Open Questions & Considerations

1. **Scraping Legal/Ethical**: 
   - Ensure compliance with ToS for each platform
   - Rate limiting to avoid being blocked
   - Consider official API alternatives where available

2. **Data Retention**:
   - How long to keep historical price data?
   - Storage costs for large datasets
   - GDPR/privacy considerations

3. **Rate Limiting**:
   - Platform-specific rate limits (eBay, Discogs, etc.)
   - Queue management for scraping jobs
   - Caching strategies to reduce API calls

4. **Error Handling**:
   - Platform API changes/outages
   - Scraping failures (HTML structure changes)
   - Data validation and cleaning

5. **User Privacy**:
   - How much user location data to store?
   - Anonymization for analytics
   - GDPR compliance for EU users

6. **Cost Management**:
   - API costs (eBay, Discogs may have usage fees)
   - Scraping infrastructure costs
   - Storage costs for historical data

## Analytics Service Integration (Data Science Core)

### Analytics Service Role

The **Analytics Service** serves as the **data science core** of the platform. It focuses on:
- **Data Collection & Aggregation**: Collecting data from multiple sources (Discogs, eBay, Popsike, Gripsweat, internal sales)
- **Statistical Analysis**: Price percentiles, trends, correlations, market analysis
- **Data Processing**: Cleaning, normalization, validation, enrichment
- **Historical Data Management**: Storing and querying historical sales data
- **Real-Time Metrics**: Calculating KPIs, price indices, market trends

**Key Responsibilities:**
- **Data Pipeline**: ETL (Extract, Transform, Load) from external sources
- **Time-Series Analysis**: Price trends over time, seasonal patterns
- **Statistical Modeling**: Regression analysis, price prediction models (traditional ML)
- **Data Quality**: Ensuring data completeness, accuracy, consistency
- **API for Data Access**: Providing clean, structured data to other services

**Technology Stack:**
- **Python** (Pandas, NumPy, SciPy for data science)
- **PostgreSQL** (TimescaleDB for time-series data)
- **Redis** (Caching frequently accessed data)
- **Apache Spark** (for large-scale data processing, if needed)
- **Jupyter Notebooks** (for data exploration and analysis)

### Analytics Service Data Flow

```
External Sources → Analytics Service → Processed Data → Python AI Service
     ↓                    ↓                  ↓                ↓
Discogs API         Data Cleaning      Structured      ML/AI Models
eBay API           Normalization      Data Store      (Hugging Face)
Popsike            Validation         (PostgreSQL)    Predictions
Gripsweat          Enrichment         (Redis Cache)   Recommendations
Internal Sales     Aggregation
```

## Python AI Service Integration (ML/AI Layer)

### Python AI Service Role

The **Python AI Service** serves as the **ML/AI layer** that consumes processed data from the Analytics service. It focuses on:
- **Machine Learning Models**: Training and serving ML models
- **Natural Language Processing**: Text analysis, sentiment analysis, content generation
- **Deep Learning**: Using Hugging Face Transformers for advanced AI capabilities
- **Predictive Analytics**: Price predictions, demand forecasting, recommendation systems
- **Intelligent Automation**: Automated insights, smart recommendations

**Key Responsibilities:**
- **Model Training**: Training ML models on Analytics service data
- **Inference**: Real-time predictions and recommendations
- **NLP Processing**: Analyzing text (descriptions, titles, messages)
- **Content Generation**: Generating optimized listings, responses, suggestions
- **Sentiment Analysis**: Understanding user intent, negotiation mood

**Technology Stack:**
- **Python** (PyTorch, TensorFlow for deep learning)
- **Hugging Face Transformers**: Pre-trained models for NLP, text generation
- **scikit-learn**: Traditional ML models (when deep learning isn't needed)
- **FastAPI**: API for serving models
- **Redis**: Model caching, inference results caching
- **GPU Support**: For transformer model inference (optional, can use CPU)

### Separation of Concerns

**Analytics Service (Data Science Core):**
- ✅ Data collection and aggregation
- ✅ Statistical analysis and metrics
- ✅ Data cleaning and validation
- ✅ Historical data management
- ✅ Traditional ML (regression, classification)
- ❌ NOT responsible for: Deep learning, NLP, content generation

**Python AI Service (ML/AI Layer):**
- ✅ Deep learning models (Hugging Face Transformers)
- ✅ NLP and text processing
- ✅ Content generation
- ✅ Advanced predictions (using Analytics data)
- ✅ Sentiment analysis
- ❌ NOT responsible for: Raw data collection, data cleaning, statistical analysis

**Data Flow:**
```
Raw Data → Analytics Service → Clean Data → Python AI Service → AI Insights
```

## Integration Patterns Across Services

### 1. Auction Monitor + Analytics + Python AI

**Use Case**: Intelligent price analysis and recommendations

**Flow:**
```
Auction Monitor → Analytics Service → Python AI Service → Recommendations
     ↓                    ↓                  ↓                    ↓
New Listing      Price History      ML Price        "Excellent Deal"
Found            Statistical        Prediction      "Fair Price"
                 Analysis           + Confidence    "Overpriced"
```

**Analytics Service Contribution:**
- Collects historical price data from Discogs, eBay, Popsike, Gripsweat
- Calculates price percentiles (p25, p50, p75, p95)
- Identifies price trends and patterns
- Provides structured data: `{price_history, percentiles, trends, confidence}`

**Python AI Service Contribution:**
- Uses Hugging Face Transformers to analyze listing descriptions
- Predicts optimal listing price based on historical data + current market
- Generates natural language recommendations ("This is 15% below average")
- Sentiment analysis of seller descriptions (trustworthy, suspicious, etc.)

**Example:**
```python
# Analytics Service provides:
analytics_data = {
    "price_history": [45, 48, 52, 47, 49, 50],
    "percentiles": {"p25": 46, "p50": 48, "p75": 51, "p95": 55},
    "trend": "increasing",
    "confidence": "high"
}

# Python AI Service processes:
ai_insights = python_ai_service.analyze_listing(
    listing_description="Mint condition, sealed",
    current_price=50,
    analytics_data=analytics_data
)

# Returns:
{
    "recommendation": "Good deal",
    "confidence": 0.85,
    "reasoning": "Price is at 50th percentile, but description suggests mint condition which typically sells at 75th percentile. This is a good opportunity.",
    "predicted_final_price": 52,
    "sentiment": "positive"  # Seller description is trustworthy
}
```

### 2. Listings Service + Analytics + Python AI

**Use Case**: Optimize seller listings for maximum views and highest selling price

**Flow:**
```
Seller Creates → Analytics Service → Python AI Service → Optimized Listing
   Listing            ↓                    ↓                    ↓
                 Market Data        Title Optimization    "Best Title"
                 Price Analysis     Description Gen       "Best Description"
                 View Patterns       Image Suggestions     "Best Price"
```

**Analytics Service Contribution:**
- Analyzes successful listings (high views, high sales)
- Identifies keywords that drive views
- Price optimization based on historical sales
- View-to-sale conversion rates by listing attributes

**Python AI Service Contribution:**
- **Title Generation**: Uses Hugging Face Transformers to generate optimized titles
  - Model: GPT-2 or T5 for text generation
  - Input: Item details (artist, album, condition, format)
  - Output: SEO-optimized title with high-performing keywords
- **Description Generation**: Creates compelling descriptions
  - Analyzes top-performing descriptions
  - Generates descriptions that match successful listing patterns
- **Price Suggestion**: ML model predicts optimal listing price
  - Input: Item details + Analytics market data
  - Output: Price range for maximum visibility and sales

**Example:**
```python
# Seller inputs:
listing_draft = {
    "artist": "The Beatles",
    "album": "Abbey Road",
    "format": "LP",
    "condition": "Near Mint",
    "catalog_number": "SO-383",
    "price": 25.00
}

# Analytics Service provides:
analytics_insights = {
    "successful_listings": [...],  # Top 100 similar listings
    "keyword_performance": {"sealed": 0.15, "original": 0.12, "stereo": 0.08},
    "price_analysis": {"optimal_range": [28, 35], "sweet_spot": 32},
    "view_patterns": {"peak_days": ["Friday", "Sunday"], "peak_hours": [18, 20]}
}

# Python AI Service generates:
optimized_listing = python_ai_service.optimize_listing(
    listing_draft,
    analytics_insights
)

# Returns:
{
    "optimized_title": "The Beatles - Abbey Road (1969, Stereo, Near Mint) Original UK Pressing",
    "optimized_description": "Original 1969 UK stereo pressing of The Beatles' iconic Abbey Road. Near mint condition with minimal wear. Includes original inner sleeve. Catalog number SO-383. A must-have for any Beatles collector.",
    "suggested_price": 32.00,  # Based on ML prediction
    "price_range": [28, 35],
    "keywords": ["original", "stereo", "1969", "UK pressing"],
    "posting_schedule": {"best_day": "Friday", "best_time": "18:00"},
    "expected_views": 150,  # ML prediction
    "expected_sale_probability": 0.75
}
```

**Hugging Face Models Used:**
- **Text Generation**: `gpt2`, `distilgpt2`, or `t5-base` for title/description generation
- **Text Classification**: `distilbert-base-uncased` for keyword extraction
- **Regression**: Custom model for price prediction (trained on Analytics data)

### 3. Shopping Service + Analytics + Python AI

**Use Case**: Help buyers determine if item is worth buying and suggest negotiation prices

**Flow:**
```
Buyer Views → Analytics Service → Python AI Service → Buying Recommendation
   Item            ↓                    ↓                    ↓
              Price History      Value Analysis      "Worth It?"
              Market Trends       Negotiation AI      "Suggested Offer"
              Similar Items       Risk Assessment     "Fair Price Range"
```

**Analytics Service Contribution:**
- Historical price data for the item
- Price trends (increasing/decreasing)
- Similar item sales (same artist, format, condition)
- Market demand indicators (views, watchers, bid counts)

**Python AI Service Contribution:**
- **Value Assessment**: ML model predicts if price is fair
  - Input: Current price + Analytics historical data
  - Output: "Excellent deal", "Fair price", "Overpriced" with confidence
- **Negotiation Suggestion**: AI suggests optimal negotiation price
  - Analyzes seller behavior (accepts offers? how much discount?)
  - Suggests starting offer and maximum acceptable price
- **Risk Analysis**: Sentiment analysis of listing description
  - Detects suspicious language, potential scams
  - Analyzes seller feedback patterns

**Example:**
```python
# Buyer views item:
item = {
    "listing_id": "12345",
    "current_price": 50.00,
    "seller_feedback": 98.5,
    "description": "Mint condition, sealed, original pressing"
}

# Analytics Service provides:
analytics_data = {
    "price_history": [45, 48, 52, 47, 49, 50],
    "percentiles": {"p25": 46, "p50": 48, "p75": 51, "p95": 55},
    "similar_sales": [
        {"price": 48, "condition": "Near Mint", "sold_date": "2024-01-15"},
        {"price": 52, "condition": "Mint", "sold_date": "2024-01-20"}
    ],
    "market_trend": "stable",
    "demand_indicator": "high"  # Many watchers, bids
}

# Python AI Service analyzes:
buying_advice = python_ai_service.analyze_purchase(
    item,
    analytics_data
)

# Returns:
{
    "worth_it": True,
    "confidence": 0.82,
    "value_assessment": "Fair price - slightly above median but condition justifies it",
    "negotiation_suggestion": {
        "starting_offer": 45.00,  # 10% below asking
        "maximum_acceptable": 52.00,  # Based on similar sales
        "success_probability": 0.65  # Seller likely to accept 45-48 range
    },
    "risk_assessment": {
        "scam_risk": "low",
        "description_sentiment": "positive",  # Trustworthy description
        "seller_reliability": "high"  # Based on feedback analysis
    },
    "recommendation": "Good opportunity - try negotiating to $45-48 range"
}
```

**Hugging Face Models Used:**
- **Sentiment Analysis**: `cardiffnlp/twitter-roberta-base-sentiment-latest` for description analysis
- **Text Classification**: Custom model for scam detection
- **Regression**: Price prediction model (trained on Analytics data)

### 4. Social Service + Analytics + Python AI

**Use Case**: Negotiation chatbot that understands the "mood" of negotiations

**Flow:**
```
Buyer/Seller → Social Service → Analytics + Python AI → Negotiation Assistant
   Chat            ↓                    ↓                        ↓
              Message Text      Sentiment Analysis        "Suggest Response"
              Context           Mood Detection            "Tone Adjustment"
                                Price Context             "Negotiation Strategy"
```

**Analytics Service Contribution:**
- Provides price context (market value, fair price range)
- Historical negotiation data (what prices were accepted/rejected)
- Seller/buyer behavior patterns (negotiation style, typical discounts)

**Python AI Service Contribution:**
- **Sentiment Analysis**: Real-time analysis of message tone
  - Detects frustration, enthusiasm, hesitation, aggression
  - Tracks mood changes throughout conversation
- **Response Generation**: Suggests appropriate responses
  - Uses Hugging Face Transformers (GPT-2, DialoGPT) for response generation
  - Considers negotiation context, price data, mood
- **Negotiation Coaching**: Provides strategic advice
  - "Seller seems frustrated, maybe offer slightly higher"
  - "Buyer is enthusiastic, this is a good time to negotiate"

**Example:**
```python
# Conversation context:
conversation = [
    {"role": "buyer", "message": "Hi, is this still available?", "timestamp": "10:00"},
    {"role": "seller", "message": "Yes, it is!", "timestamp": "10:05"},
    {"role": "buyer", "message": "Would you consider $45?", "timestamp": "10:10"},
    {"role": "seller", "message": "That's too low, I can't go below $50", "timestamp": "10:15"},
    {"role": "buyer", "message": "But I've seen similar items for $40", "timestamp": "10:20"}
]

# Analytics Service provides:
price_context = {
    "market_value": 48.00,
    "fair_range": [45, 52],
    "seller_typical_discount": 0.10,  # Usually accepts 10% off
    "similar_sales": [45, 48, 50]
}

# Python AI Service analyzes:
negotiation_insights = python_ai_service.analyze_negotiation(
    conversation,
    price_context
)

# Returns:
{
    "current_mood": {
        "buyer": "frustrated",  # Sentiment analysis
        "seller": "firm",
        "overall": "tense"
    },
    "mood_trend": "deteriorating",  # Getting more tense
    "suggested_response": {
        "for_buyer": "I understand your position. Based on recent sales, $48 seems fair. Would you consider meeting in the middle at $46.50?",
        "tone": "diplomatic",
        "strategy": "compromise"
    },
    "price_analysis": {
        "buyer_offer": 45,  # Below market
        "seller_counter": 50,  # Above market
        "fair_middle": 47.50,
        "recommendation": "Suggest $47.50 as compromise"
    },
    "negotiation_health": 0.6,  # Moderate - still salvageable
    "next_steps": [
        "Acknowledge seller's position",
        "Reference market data (Analytics)",
        "Suggest fair compromise",
        "Maintain positive tone"
    ]
}
```

**Hugging Face Models Used:**
- **Sentiment Analysis**: `cardiffnlp/twitter-roberta-base-sentiment-latest` for mood detection
- **Dialogue Generation**: `microsoft/DialoGPT-medium` for response suggestions
- **Text Classification**: Custom model for negotiation stage detection (opening, bargaining, closing)

## Complete Service Integration Architecture

### Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         External Data Sources                        │
│  (Discogs, eBay, Popsike, Gripsweat, Internal Sales)                │
└────────────────────────────┬──────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Analytics Service                              │
│                   (Data Science Core)                                │
│  • Data Collection & Aggregation                                     │
│  • Statistical Analysis (Pandas, NumPy, SciPy)                     │
│  • Price Percentiles, Trends, Correlations                           │
│  • Historical Data Management (PostgreSQL, TimescaleDB)              │
│  • Data Cleaning, Validation, Enrichment                             │
└────────────────────────────┬──────────────────────────────────────┘
                              │
                              ▼ Clean, Structured Data
┌─────────────────────────────────────────────────────────────────────┐
│                      Python AI Service                              │
│                      (ML/AI Layer)                                   │
│  • Hugging Face Transformers (GPT-2, T5, RoBERTa, DialoGPT)         │
│  • Deep Learning Models (PyTorch, TensorFlow)                        │
│  • NLP: Text Generation, Sentiment Analysis, Classification         │
│  • Predictive Analytics: Price Prediction, Demand Forecasting       │
│  • Content Generation: Titles, Descriptions, Responses               │
└────────────────────────────┬──────────────────────────────────────┘
                              │
                              ▼ AI Insights & Recommendations
         ┌───────────────────┼───────────────────┐
         │                   │                   │
         ▼                   ▼                   ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   Listings   │    │   Shopping   │    │   Social     │
│   Service    │    │   Service    │    │   Service    │
│              │    │              │    │              │
│ • Optimize   │    │ • Value      │    │ • Negotiation│
│   Titles     │    │   Assessment │    │   Chatbot    │
│ • Optimize   │    │ • Negotiation│    │ • Mood       │
│   Descriptions│   │   Suggestions│    │   Analysis   │
│ • Price      │    │ • Risk       │    │ • Response   │
│   Suggestions│    │   Analysis   │    │   Generation │
└──────────────┘    └──────────────┘    └──────────────┘
```

### Service Communication Patterns

**1. Synchronous (Real-Time):**
- **Listings Service** → Analytics → Python AI → Optimized Listing (user creating listing)
- **Shopping Service** → Analytics → Python AI → Buying Recommendation (user viewing item)
- **Social Service** → Python AI → Response Suggestion (real-time chat)

**2. Asynchronous (Background Jobs):**
- **Auction Monitor** → Analytics → Price Analysis (periodic updates)
- **Analytics** → Python AI → Model Training (scheduled, e.g., daily)
- **Python AI** → Analytics → Model Performance Metrics (feedback loop)

**3. Event-Driven:**
- New listing created → Analytics analyzes → Python AI optimizes → Notify seller
- Price change detected → Analytics updates → Python AI re-evaluates → Notify watchers
- New message in negotiation → Python AI analyzes mood → Suggest response

## Hugging Face Transformers Integration

### Models for Different Use Cases

**1. Text Generation (Listings Service):**
- **GPT-2** (`gpt2`, `gpt2-medium`): Generate titles and descriptions
- **T5** (`t5-base`, `t5-small`): Text-to-text generation (better for structured output)
- **Fine-tuning**: Train on successful listing data from Analytics service

**2. Sentiment Analysis (Shopping, Social Services):**
- **RoBERTa** (`cardiffnlp/twitter-roberta-base-sentiment-latest`): General sentiment
- **DistilBERT** (`distilbert-base-uncased-finetuned-sst-2-english`): Fast sentiment analysis
- **Custom Fine-tuning**: Train on negotiation messages, listing descriptions

**3. Text Classification (All Services):**
- **BERT** (`bert-base-uncased`): Keyword extraction, category classification
- **DistilBERT**: Faster classification for real-time use cases
- **Custom Models**: Scam detection, condition assessment, format detection

**4. Dialogue Generation (Social Service):**
- **DialoGPT** (`microsoft/DialoGPT-medium`): Conversation response generation
- **GPT-2**: General text generation for responses
- **Fine-tuning**: Train on successful negotiation conversations

**5. Regression/Price Prediction (Shopping, Listings Services):**
- **Custom Models**: Train regression models on Analytics data
- **Transformer-based**: Use BERT embeddings + regression head for price prediction
- **Ensemble**: Combine multiple models for better accuracy

### Model Serving Architecture

```python
# Python AI Service - Model Serving Example
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer
import torch

class PythonAIService:
    def __init__(self):
        # Load models (lazy loading, cached)
        self.title_generator = pipeline("text-generation", model="gpt2")
        self.sentiment_analyzer = pipeline("sentiment-analysis", 
                                          model="cardiffnlp/twitter-roberta-base-sentiment-latest")
        self.dialogue_generator = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")
        
    def optimize_listing_title(self, item_details, analytics_data):
        # Use Analytics data + item details to generate title
        prompt = f"Generate an optimized eBay listing title for: {item_details}"
        generated = self.title_generator(prompt, max_length=80, num_return_sequences=1)
        return generated[0]['generated_text']
    
    def analyze_negotiation_mood(self, conversation_history):
        # Analyze sentiment of each message
        sentiments = []
        for message in conversation_history:
            sentiment = self.sentiment_analyzer(message['text'])
            sentiments.append({
                'role': message['role'],
                'sentiment': sentiment[0]['label'],
                'score': sentiment[0]['score']
            })
        return sentiments
```

### Model Training Pipeline

**Training Data Source: Analytics Service**
```
Analytics Service → Export Training Data → Python AI Service → Model Training
     ↓                      ↓                      ↓                  ↓
Historical Sales      Structured JSON      Data Preprocessing    Fine-tune
Price Data           (CSV, Parquet)        Feature Engineering   Hugging Face
Successful Listings  Labeled Examples       Train/Val Split       Models
Negotiations         (for supervised)      Training Loop         Save Models
```

**Example Training Flow:**
1. **Analytics Service** exports successful listing data (titles, descriptions, views, sales)
2. **Python AI Service** preprocesses data (tokenization, formatting)
3. **Fine-tune GPT-2** on successful listing titles/descriptions
4. **Evaluate** model performance on validation set
5. **Deploy** model for production use
6. **Monitor** model performance, retrain periodically with new data

## Implementation Considerations

### Performance Optimization

**1. Model Caching:**
- Cache loaded models in memory (avoid reloading on each request)
- Use Redis for caching inference results (same input → cached output)

**2. Batch Processing:**
- Batch multiple requests together for model inference
- Process listings in batches (e.g., optimize 10 listings at once)

**3. Model Selection:**
- Use smaller models (DistilBERT, DistilGPT-2) for real-time use cases
- Use larger models (GPT-2 Medium, RoBERTa Large) for batch processing

**4. GPU vs CPU:**
- GPU for training and batch inference
- CPU for real-time, low-latency requests (if GPU not available)

### Cost Management

**1. API Rate Limiting:**
- Limit Hugging Face API calls (if using hosted models)
- Cache model outputs to reduce redundant inference

**2. Model Size:**
- Use quantized models (8-bit, 4-bit) to reduce memory usage
- Use model distillation (smaller models trained from larger ones)

**3. Inference Optimization:**
- Use ONNX Runtime for faster inference
- Use TensorRT for GPU optimization (NVIDIA GPUs)

### Error Handling

**1. Model Failures:**
- Fallback to rule-based systems if ML models fail
- Graceful degradation (show basic recommendations without AI)

**2. Data Quality:**
- Validate Analytics data before passing to Python AI
- Handle missing data gracefully (use defaults, flag low confidence)

**3. Service Availability:**
- Circuit breakers for Analytics/Python AI service calls
- Timeout handling (don't block user requests if AI is slow)

## Conclusion

The integration of **Analytics Service** (data science core) and **Python AI Service** (ML/AI layer) creates a powerful system that:

1. **Analytics Service** provides clean, structured data and statistical insights
2. **Python AI Service** adds intelligent predictions, content generation, and NLP capabilities
3. **Together**, they enable:
   - **Listings Service**: Optimize listings for maximum views and sales
   - **Shopping Service**: Help buyers make informed decisions and negotiate
   - **Social Service**: Intelligent negotiation chatbot with mood analysis
   - **Auction Monitor**: Advanced price analysis and recommendations

The separation of concerns ensures:
- **Analytics** focuses on data science (statistics, data processing)
- **Python AI** focuses on ML/AI (deep learning, NLP, content generation)
- **Clear data flow**: Raw Data → Analytics → Python AI → Insights

This architecture allows each service to evolve independently while maintaining clear boundaries and responsibilities.

## Data Pipeline Implementation Details

For comprehensive details on the data pipeline architecture, platform adapters, data quality engine, and implementation roadmap, see:

**[AUCTION_MONITOR_DATA_PIPELINE.md](./AUCTION_MONITOR_DATA_PIPELINE.md)**

This document covers:
- **Platform-Specific Implementation**: eBay, Discogs, Buyee, YahooJP, CarousellHK, RecordCity adapters
- **Unified Data Model**: Complete PostgreSQL schema with staging and normalized tables
- **Data Pipeline Architecture**: Extract → Transform → Load with quality controls
- **Data Quality Engine**: Deduplication, confidence scoring, enrichment
- **Analytics Integration**: How clean data flows to Analytics Service
- **Monitoring & Observability**: Quality metrics, platform health, alerting
- **Implementation Roadmap**: 20-week phased approach

## Key Design Principles

1. **Data Quality First**: Only high-confidence data (≥0.7) feeds into Analytics and Python AI
2. **Staging Layer**: Two-stage storage (raw → normalized) enables reprocessing and debugging
3. **Platform Abstraction**: Adapter pattern allows easy addition of new platforms
4. **Rate Limiting**: Platform-specific rate limiters prevent blocking and ToS violations
5. **Monitoring**: Comprehensive quality metrics and platform health tracking
6. **Incremental Rollout**: Start with official APIs (eBay, Discogs), then add scraping platforms

