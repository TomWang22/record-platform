# k6 Bottleneck Finder

## Overview

The bottleneck finder runs progressive load tests to identify:
- **Upper limit of virtual users** (VUs) before degradation
- **Bottlenecks** (error rates, latency spikes, timeouts)
- **Breaking points** where performance degrades significantly
- **Recommendations** for optimization

## Quick Start

```bash
# Find bottlenecks for shopping service
bash scripts/find-bottlenecks.sh shopping

# Custom configuration
BASE_URL=https://record.local:30443 \
MAX_VUS=1000 \
bash scripts/find-bottlenecks.sh shopping
```

## How It Works

### Progressive Load Testing

The script runs k6 with progressive stages:
1. **Baseline** (10 VUs) - Establish baseline performance
2. **Light Load** (25 VUs) - Test under light load
3. **Moderate Load** (50 VUs) - Test under moderate load
4. **High Load** (100 VUs) - Test under high load
5. **Very High Load** (200 VUs) - Test under very high load
6. **Extreme Load** (300-500 VUs) - Test near breaking point
7. **Hold at Max** - Sustain max load to identify sustained bottlenecks
8. **Ramp Down** - Graceful shutdown

### Bottleneck Detection

The script monitors and identifies:

#### 1. Error Rate Bottlenecks
- **Threshold**: > 5% error rate
- **Severity**: HIGH if > 5%, CRITICAL if > 10%
- **Indicates**: Server overload, database connection issues, resource exhaustion

#### 2. Latency Bottlenecks
- **P95 Threshold**: > 3000ms (3 seconds)
- **P99 Threshold**: > 5000ms (5 seconds)
- **Severity**: HIGH for P95, CRITICAL for P99
- **Indicates**: Slow database queries, network issues, CPU/memory constraints

#### 3. Timeout Bottlenecks
- **Threshold**: > 50 timeout errors
- **Severity**: HIGH
- **Indicates**: Requests taking too long, need to increase timeouts or optimize

#### 4. Server Error Bottlenecks
- **Threshold**: > 20 server errors (5xx)
- **Severity**: CRITICAL
- **Indicates**: Application crashes, database connection failures, resource exhaustion

#### 5. Client Error Bottlenecks
- **Threshold**: > 100 client errors (4xx)
- **Severity**: MEDIUM
- **Indicates**: Authentication issues, validation problems, rate limiting

#### 6. Throughput Bottlenecks
- **Threshold**: < 10 req/s with > 100 VUs
- **Severity**: HIGH
- **Indicates**: Request processing is too slow, need optimization or scaling

## Output

### Console Output

The script outputs a comprehensive bottleneck analysis:

```
🔍 BOTTLENECK ANALYSIS REPORT
================================

Test Configuration:
  Max VUs Reached: 500
  Total Requests: 125000
  Avg Throughput: 125.5 req/s

ERROR ANALYSIS:
  Error Rate: 7.2% ⚠️  BOTTLENECK
  Timeout Errors: 45 ✅
  Server Errors (5xx): 12 ✅
  Client Errors (4xx): 89 ✅

LATENCY ANALYSIS (ms):
  P95: 3200ms ⚠️  BOTTLENECK
  P99: 5800ms ⚠️  BOTTLENECK

BOTTLENECKS IDENTIFIED: 2
  1. [HIGH] ERROR_RATE
     Issue: Error rate is 7.20% (threshold: 5%)
     Recommendation: Check server logs, database connections, and resource limits
  2. [HIGH] LATENCY_P95
     Issue: P95 latency is 3200ms (threshold: 3000ms)
     Recommendation: Optimize database queries, add caching, or scale horizontally

UPPER BOUND ANALYSIS:
  Estimated Max VUs: 425
  ⚠️  Service can handle ~425 concurrent users (with 7.2% error rate)
```

### Files Generated

Results are saved in `scripts/load/results/bottleneck-{service}-{timestamp}/`:

- **`output.txt`** - Full k6 test output
- **`summary.json`** - k6 summary metrics (for graph generation)
- **`bottleneck-analysis.json`** - Structured bottleneck analysis
- **`bottleneck-latency-graph.html`** - Visual latency graphs

### JSON Analysis Format

```json
{
  "summary": {
    "maxVUs": 500,
    "currentVUs": 0,
    "totalRequests": 125000,
    "duration": 600,
    "avgThroughput": 125.5,
    "upperBoundVUs": 425
  },
  "errors": {
    "errorRate": 7.2,
    "timeoutErrors": 45,
    "serverErrors": 12,
    "clientErrors": 89
  },
  "latency": {
    "avg": 850,
    "p50": 450,
    "p95": 3200,
    "p99": 5800,
    "max": 15000
  },
  "bottlenecks": [
    {
      "type": "ERROR_RATE",
      "severity": "HIGH",
      "description": "Error rate is 7.20% (threshold: 5%)",
      "recommendation": "Check server logs, database connections, and resource limits"
    }
  ]
}
```

## Configuration

### Environment Variables

```bash
# Service URL
BASE_URL=https://record.local:30443
API_PATH=/api
HOST=record.local

# Test parameters
MIN_VUS=10          # Starting VUs
MAX_VUS=500         # Maximum VUs to test
STAGE_DURATION=1m   # Duration per stage

# Authentication
EMAIL=testuser@example.com
PASS=password123
TOKEN=<jwt-token>   # Optional: provide token directly

# Service-specific URLs
AUTH_URL=https://record.local:30443/api/auth
SHOPPING_URL=https://record.local:30443/api/cart
ORDERS_URL=https://record.local:30443/api/orders
LISTINGS_URL=https://record.local:30443/api/listings
```

### Custom Stages

You can customize the progressive stages by modifying the script or using k6 directly:

```bash
k6 run --stages "0s:10,30s:25,1m:50,2m:100,3m:200,4m:300,5m:400,6m:500,8m:500,9m:0" \
  scripts/load/k6-bottleneck-finder.js
```

## Interpreting Results

### Upper Bound VUs

The script calculates an estimated upper bound based on:
- **Error Rate**: If > 10%, upper bound is ~70% of max VUs tested
- **Error Rate 5-10%**: Upper bound is ~85% of max VUs tested
- **High Latency**: If P95 > 3000ms, upper bound is ~80% of max VUs tested
- **Good Performance**: If error rate < 5% and latency acceptable, can handle max VUs+

### Bottleneck Severity

- **CRITICAL**: Immediate action required (error rate > 10%, P99 > 5000ms, server errors)
- **HIGH**: Performance degradation (error rate 5-10%, P95 > 3000ms, timeouts)
- **MEDIUM**: Minor issues (client errors, moderate latency)

### Recommendations

The script provides specific recommendations for each bottleneck:
- **Error Rate**: Check logs, database connections, resource limits
- **Latency**: Optimize queries, add caching, scale horizontally
- **Timeouts**: Increase timeout values or optimize slow endpoints
- **Server Errors**: Check application logs, database connections, resource exhaustion
- **Throughput**: Optimize request processing or increase server capacity

## Examples

### Find Shopping Service Bottlenecks

```bash
bash scripts/find-bottlenecks.sh shopping
```

### Test with Higher Load

```bash
MAX_VUS=1000 bash scripts/find-bottlenecks.sh shopping
```

### Test Specific Service Endpoints

```bash
BASE_URL=https://record.local:30443 \
SHOPPING_URL=https://record.local:30443/api/cart \
bash scripts/find-bottlenecks.sh shopping
```

## Troubleshooting

### Test Fails to Start

1. Check authentication:
   ```bash
   curl -k -X POST https://record.local:30443/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","password":"password123"}'
   ```

2. Verify service is accessible:
   ```bash
   curl -k https://record.local:30443/api/cart \
     -H "Host: record.local" \
     -H "Authorization: Bearer <token>"
   ```

### No Bottlenecks Detected

If no bottlenecks are detected but performance is poor:
- Check if thresholds are too lenient
- Review latency percentiles (P99.9, P99.99)
- Check resource utilization (CPU, memory, database)

### High Error Rate

If error rate is high:
1. Check server logs: `kubectl logs -l app=shopping-service`
2. Check database connections: `kubectl exec -it postgres-shopping-1 -- psql -c "SELECT count(*) FROM pg_stat_activity"`
3. Check resource limits: `kubectl top pods -l app=shopping-service`

## Integration with Daily CronJob

You can integrate bottleneck finding into your daily CronJob:

```yaml
# Add to k6-shopping-daily.yaml
- name: RUN_BOTTLENECK_TEST
  value: "true"
```

Then modify the script to run bottleneck finder when this env var is set.

## Next Steps

After identifying bottlenecks:
1. **Optimize** based on recommendations
2. **Re-test** to verify improvements
3. **Monitor** in production with the same thresholds
4. **Scale** if needed (horizontal or vertical)

