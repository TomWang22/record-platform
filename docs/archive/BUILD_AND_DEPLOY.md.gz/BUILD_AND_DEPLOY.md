# Build and Deploy Guide

## Quick Start

### Build All Services
```bash
# Build all services and load into kind cluster
./scripts/build-all-services.sh

# Build without loading into kind (for CI/CD)
LOAD_INTO_KIND=false ./scripts/build-all-services.sh

# Build for specific platform (e.g., ARM64)
BUILD_PLATFORM=linux/arm64 ./scripts/build-all-services.sh
```

### Deploy All Services
```bash
# Deploy to default namespace (record-platform) with dev overlay
./scripts/deploy-all-services.sh

# Deploy with custom namespace
NAMESPACE=my-namespace ./scripts/deploy-all-services.sh

# Deploy without waiting for ready
WAIT_FOR_READY=false ./scripts/deploy-all-services.sh
```

## Services Built

1. **api-gateway** - API Gateway service
2. **auth-service** - Authentication service (bcrypt concurrency 8, connection pool updates)
3. **analytics-service** - Analytics service
4. **social-service** - Social/forum service
5. **listings-service** - Listings/marketplace service
6. **shopping-service** - Shopping cart and orders service
7. **auction-monitor** - Auction monitoring service
8. **python-ai-service** - Python AI/ML service
9. **cron-jobs** - Scheduled jobs
10. **webapp** - Next.js webapp (standalone, not in k8s)

## Webapp Dockerfile Optimizations

The webapp Dockerfile has been optimized for fast builds:

- **Multi-stage build** with separate deps/build/runtime stages
- **BuildKit cache mounts** for pnpm store and Next.js cache
- **Parallel builds** with `--ignore-scripts` for faster install
- **Standalone output** for smaller runtime image
- **Source map removal** to reduce image size
- **Non-root user** for security
- **Next.js telemetry disabled** for faster builds

## k6 Test Suite

### Shopping Service Comprehensive Test

Created: `scripts/load/k6-shopping-comprehensive.js`

**Features:**
- Uses auth service for user registration/login
- Tests all shopping endpoints:
  - Cart operations (add, get, update, remove, clear)
  - Checkout flow
  - Order management
  - Purchase history
  - Watchlist operations
  - Wishlist operations
  - Recently viewed items
  - Search history tracking
- Database validation (external PostgreSQL on port 5436)
- Redis cache validation (external Redis on port 6379)
- Lua script validation (herd stampede prevention)

**Usage:**
```bash
# Standard test
k6 run --vus 50 --duration 10m scripts/load/k6-shopping-comprehensive.js

# Ramp-up test
k6 run --stages 0s:10,30s:50,2m:100,5m:200,8m:300,10m:0 scripts/load/k6-shopping-comprehensive.js

# Custom configuration
SHOPPING_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
AUTH_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
HOST=record.local \
SETUP_USERS=50 \
k6 run --vus 100 --duration 15m scripts/load/k6-shopping-comprehensive.js
```

## External Infrastructure

All databases and Redis are externalized (running in Docker Compose, not k8s):

- **PostgreSQL instances** (8 dedicated databases):
  - Main DB (5433) - records schema
  - Auth DB (5437) - auth schema
  - Social DB (5434) - social schema
  - Listings DB (5435) - listings schema
  - Shopping DB (5436) - shopping schema
  - Auction Monitor DB (5438) - auction_monitor schema
  - Analytics DB (5439) - analytics schema
  - Python AI DB (5440) - python_ai schema

- **Redis** (6379) - Caching, JWT revocation, Lua scripting for herd stampede prevention

- **Kafka** (29092) - Event streaming
- **Zookeeper** (2181) - Kafka coordination

## Auth Service Updates

The auth service has been updated with:
- **bcrypt concurrency increased from 4 to 8** for better throughput under high load
- **Connection pool updates** for better database connection handling
- **Redis caching** with Lua scripts to prevent herd stampede

## Caddyfile and gRPC/HTTP2/3

The Caddyfile is configured for:
- **HTTP/2 and HTTP/3 (QUIC)** support
- **gRPC routing** with proper protocol handling
- **Strict TLS** (TLS 1.2/1.3 only)
- **Health check endpoints** (gRPC and HTTP)
- **Service routing** for all microservices

## Next Steps

1. **Build services:**
   ```bash
   ./scripts/build-all-services.sh
   ```

2. **Deploy to cluster:**
   ```bash
   ./scripts/deploy-all-services.sh
   ```

3. **Verify deployment:**
   ```bash
   kubectl -n record-platform get pods
   kubectl -n record-platform get services
   ```

4. **Run k6 tests:**
   ```bash
   k6 run --vus 50 --duration 10m scripts/load/k6-shopping-comprehensive.js
   ```

5. **Check service health:**
   ```bash
   kubectl -n record-platform logs -f deployment/auth-service
   kubectl -n record-platform logs -f deployment/shopping-service
   ```

## Troubleshooting

### Build Issues
- Ensure Docker BuildKit is enabled: `export DOCKER_BUILDKIT=1`
- Check Docker has enough disk space: `docker system df`
- Clear build cache if needed: `docker builder prune -af`

### Deployment Issues
- Verify cluster connection: `kubectl cluster-info`
- Check namespace exists: `kubectl get namespace record-platform`
- View pod logs: `kubectl -n record-platform logs <pod-name>`

### k6 Test Issues
- Verify auth service is running: `kubectl -n record-platform get pods -l app=auth-service`
- Check service endpoints: `kubectl -n record-platform get endpoints`
- Verify external databases are running: `docker ps | grep postgres`
