# CA Rotation Test - Ready Status

## ✅ All Prerequisites Verified

### Prerequisites Check Results:
1. ✅ **mkcert installed and CA found** - Certificate generation ready
2. ✅ **Caddy pods: 2/2 ready** - High availability with RollingUpdate
3. ✅ **Caddy NodePort: 30443** - Service exposed correctly
4. ✅ **Caddy health check works via port-forward** - Connectivity verified
5. ✅ **TLS secrets exist in both namespaces** - ingress-nginx and record-platform
6. ✅ **CA secret exists** - dev-root-ca configured
7. ✅ **curl with HTTP/2 support** - Test script requirements met

### Caddy Configuration:
- **Strategy**: RollingUpdate (zero-downtime)
- **Replicas**: 2 (high availability)
- **maxUnavailable**: 0 (ensures at least one pod always serving)
- **Service Type**: NodePort (30443)

### Service Status:
- **Auction Monitor**: Starting (database exists, schema applied)
- **Social Service**: Starting (database exists, schema applied, network connectivity issue may resolve)

## Running the Test

The CA rotation test is ready to run:

```bash
./scripts/test-full-chain-with-rotation.sh
```

### What the Test Does:
1. **Pre-rotation health check** - Verifies Caddy is healthy
2. **Continuous requests** - 15,000 requests during rotation (production-grade stress test)
3. **CA rotation** - Rotates certificates with zero-downtime
4. **Success rate validation** - Verifies 100% success rate
5. **Post-rotation verification** - Confirms new certificate is active

### Expected Results:
- **Rotation time**: 1-2 seconds (optimized)
- **Success rate**: 100% (15000/15000 requests)
- **Throughput**: ~120 req/s average (100-150 req/s observed)
- **Zero downtime**: Confirmed with RollingUpdate strategy

## Notes

- **Port-forward**: Test uses port-forward (8443) to bypass macOS/Kind NodePort TLS issues
- **HTTP/2 multiplexing**: Enabled via port-forward for maximum throughput
- **Concurrent requests**: 20 concurrent requests for production-grade testing
- **Timeout**: 3.0s per request to ensure 100% success during rotation

## Troubleshooting

If the test fails:
1. Check Caddy pods: `kubectl -n ingress-nginx get pods -l app=caddy-h3`
2. Check Caddy logs: `kubectl -n ingress-nginx logs -l app=caddy-h3 --tail=50`
3. Verify port-forward: `kubectl -n ingress-nginx port-forward svc/caddy-h3 8443:443`
4. Test health: `curl -k -I --http2 -H "Host: record.local" "https://127.0.0.1:8443/_caddy/healthz"`

## Verification Script

Run the prerequisites check anytime:
```bash
./scripts/verify-rotation-prerequisites.sh
```

