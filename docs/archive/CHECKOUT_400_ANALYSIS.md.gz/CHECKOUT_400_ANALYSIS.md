# Checkout 400 Error Analysis

**Generated:** $(date)

---

## 🔍 Root Cause Analysis

### Issue
Checkout endpoint is returning 400 errors during E2E test.

### Possible Causes

1. **Items Not in Cart** (Most Likely)
   - k6 script calls checkout with `otherListingId`
   - Item may not have been added to cart before checkout
   - Race condition: item added but not yet committed
   - Item was removed from cart (sold out, cleaned up)

2. **Empty Items Array**
   - k6 script sends empty items array
   - Items array is null or undefined

3. **Missing Required Fields**
   - Item missing `item_id` or `item_type`
   - Item structure is incorrect

4. **Cart Query Timeout**
   - Cart query times out (3s limit)
   - Returns 400 with "No items found in cart"

---

## 📊 Checkout Validation Flow

The checkout endpoint validates in this order:

1. ✅ Items array exists and is not empty
2. ✅ Each item has `item_id` and `item_type`
3. ✅ Query cart for items (with 3s timeout)
4. ✅ Verify items exist in cart
5. ✅ Verify all requested items are in cart

**400 Errors Returned:**
- `"Items array required"` - items is null/undefined/empty
- `"Each item must have item_id and item_type"` - missing fields
- `"No items found in cart"` - cart query returned 0 items
- `"Some requested items are not in cart"` - partial match

---

## 🔧 k6 Script Behavior

From `k6-shopping-service-comprehensive.js`:

```javascript
// Try to checkout with other user's listing (should succeed)
if (otherListingId) {
  const res = http.post(
    `${BASE_URL}${API_PREFIX}/cart/checkout`,
    JSON.stringify({
      items: [{
        item_type: 'listing',
        item_id: otherListingId,
        listing_id: otherListingId,
        quantity: 1,
      }],
      payment_method: 'simulated',
    }),
    opts
  );
}
```

**Issue**: The script assumes `otherListingId` is in the cart, but:
- Item may not have been added to cart
- Item may have been removed (sold out, cleaned up)
- Race condition between add-to-cart and checkout

---

## 💡 Recommendations

1. **Fix k6 Script**:
   - Add item to cart BEFORE calling checkout
   - Verify item is in cart before checkout
   - Add retry logic if checkout fails with 400

2. **Improve Checkout Error Messages**:
   - Return more detailed error about why checkout failed
   - Include which items are missing from cart

3. **Add Logging**:
   - Log when items are not in cart
   - Log cart contents before checkout
   - Log which items were requested vs. found

4. **Handle Race Conditions**:
   - Add retry logic in k6 script
   - Add delay between add-to-cart and checkout

---

## 📁 Related Files

- `/Users/tom/.cursor/worktrees/record-platform/oxy/services/shopping-service/src/routes/cart.ts`
- `/Users/tom/.cursor/worktrees/record-platform/oxy/scripts/load/k6-shopping-service-comprehensive.js`

