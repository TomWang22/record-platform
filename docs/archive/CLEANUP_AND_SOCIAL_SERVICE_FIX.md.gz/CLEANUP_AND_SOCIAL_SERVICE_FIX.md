# Cleanup and Social Service Investigation

## ✅ Cleanup Completed

### 1. Removed pgbouncer ✅
- **Deleted**: `kubectl delete deploy pgbouncer`
- **Removed from**: `infra/k8s/overlays/dev/kustomization.yaml`
- **Reason**: Postgres is externalized, pgbouncer not needed

### 2. Removed pg-backup CronJobs ✅
- **Deleted**: 
  - `pg-backup-pvc`
  - `pg-basebackup-weekly`
  - `pg-dump-nightly`
- **Removed from**: `infra/k8s/overlays/dev/kustomization.yaml`
- **Reason**: Postgres is externalized, backups handled externally

## 🔍 Social Service Investigation

### Current Status
- **Pods**: 2 pods in CrashLoopBackOff
- **Issue**: Health check returning HTTP 503
- **Symptoms**: 
  - Service starts successfully (HTTP server on 4006, gRPC on 50056)
  - Health check fails with 503
  - Kubernetes kills pod (liveness probe failure)
  - Pod restarts in CrashLoopBackOff

### Root Cause Analysis

**From Logs**:
```
[social] HTTP server listening on port 4006
[social] gRPC server listening on port 50056
[social] received SIGTERM, shutting down gracefully
[social] DB pool closed
```

**From Events**:
```
Readiness probe failed: HTTP probe failed with statuscode: 503
Liveness probe failed: HTTP probe failed with statuscode: 503
Container app failed liveness probe, will be restarted
```

**Database Configuration**:
```
POSTGRES_URL_SOCIAL: postgresql://postgres:postgres@host.docker.internal:5434/records?connect_timeout=5
```

### Likely Issues

1. **Database Connection Failure**: Health check queries database, connection fails, returns 503
2. **Health Check Too Strict**: Old health check code requires both DB and Redis to be healthy
3. **Service Not Rebuilt**: Health check fix in code not yet deployed (needs rebuild)

### Health Check Fix Applied

**File**: `services/social-service/src/server.ts`

**Changes**:
- Database check: Critical (503 if down)
- Redis check: Non-critical (doesn't fail health check if down)
- Better error logging

**Status**: ✅ Code fixed, but service needs to be rebuilt and redeployed

## 🔧 Fix Steps

### Step 1: Rebuild Services with Health Check Fixes
```bash
# Rebuild social-service and auction-monitor with fixed health checks
./scripts/build-and-load.sh h3
```

### Step 2: Restart Deployments
```bash
# Restart social-service to pick up new image
kubectl -n record-platform rollout restart deploy/social-service
kubectl -n record-platform rollout restart deploy/auction-monitor

# Wait for rollout
kubectl -n record-platform rollout status deploy/social-service
kubectl -n record-platform rollout status deploy/auction-monitor
```

### Step 3: Verify Health Checks
```bash
# Check pod status
kubectl -n record-platform get pods -l app=social-service

# Test health endpoint
kubectl -n record-platform run curl-test --rm -i --restart=Never \
  --image=curlimages/curl -- \
  curl -sS http://social-service.record-platform.svc.cluster.local:4006/healthz

# Check endpoints
kubectl -n record-platform get endpoints social-service
```

### Step 4: Verify Database Connectivity
```bash
# Test database connection from pod
kubectl -n record-platform run db-test --rm -i --restart=Never \
  --image=postgres:16 -- \
  sh -c "PGHOST=host.docker.internal PGPORT=5434 nc -zv \$PGHOST \$GPORT"
```

## 📊 Current Service Status

### ✅ Working Services
- api-gateway: ✅ Running, health check OK
- auth-service: ✅ Running, health check OK
- listings-service: ✅ Running, health check OK
- analytics-service: ✅ Running, health check OK
- shopping-service: ✅ Running, health check OK
- python-ai-service: ✅ Running, health check OK
- webapp: ✅ Running (newly deployed)
- nginx: ✅ Running, health check OK

### ⚠️ Services Needing Attention
- **social-service**: ❌ CrashLoopBackOff (health check 503, needs rebuild)
- **auction-monitor**: ⚠️ Running but no endpoints (health check likely failing, needs rebuild)
- **records-service**: ⚠️ Health check returns 500 (needs investigation)

### 🗑️ Removed Services
- **pgbouncer**: ✅ Removed (postgres externalized)
- **pg-backup cronjobs**: ✅ Removed (postgres externalized)

## 🧪 Testing Status

### ✅ Webapp (Port 3001)
- **Status**: ✅ Deployed and running
- **Endpoint**: `http://webapp.record-platform.svc.cluster.local:3001`
- **Test**: Returns HTML (200 OK)

### ✅ Nginx (Port 8080)
- **Status**: ✅ Running
- **Endpoint**: `http://nginx.record-platform.svc.cluster.local:8080`
- **Health Check**: ✅ HTTP 200

### ⚠️ k6 Tests
- **Status**: Scripts ready, but services need to be healthy first
- **Next**: Rebuild services, then run k6 tests

## 📝 Next Steps

1. **Rebuild Services**:
   ```bash
   ./scripts/build-and-load.sh h3
   ```

2. **Restart Deployments**:
   ```bash
   kubectl -n record-platform rollout restart deploy/social-service deploy/auction-monitor
   ```

3. **Verify Services**:
   ```bash
   ./scripts/test-all-services.sh
   ```

4. **Run k6 Tests** (after services are healthy):
   ```bash
   ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
   ./scripts/load/run-analytics-tests.sh
   ```

5. **Test Webapp**:
   ```bash
   kubectl -n record-platform port-forward svc/webapp 3001:3001
   # Open http://localhost:3001
   ```

6. **Test Nginx**:
   ```bash
   kubectl -n record-platform port-forward svc/nginx 8080:8080
   # Open http://localhost:8080
   ```

## 🔍 Investigation Script

Use the investigation script to debug social service:
```bash
./scripts/investigate-social-service.sh
```

This will show:
- Pod status and events
- Recent logs
- Environment variables
- Database configuration
- Health endpoint test

