# Kubernetes Cluster Fix Summary

## Date: 2025-11-26

## Issues Identified

1. **CoreDNS Unhealthy**
   - One CoreDNS pod was failing health checks (0/1 READY, 18 restarts)
   - Causing DNS resolution issues across the cluster

2. **Linkerd Control Plane Issues**
   - `linkerd-identity`: 0/2 READY (18 restarts)
   - `linkerd-proxy-injector`: 0/2 READY (21 restarts)
   - `linkerd-destination`: 0/4 READY (32 restarts)
   - Proxies couldn't connect to control plane due to DNS resolution failures
   - **Missing**: `linkerd-policy` controller pod (service exists but no pod)

3. **Auth Service Crashes**
   - Pod was 0/2 READY with 24 restarts
   - Linkerd proxy sidecar failing health checks
   - Pods stuck in Pending/ContainerCreating state

## Fixes Applied

### 1. CoreDNS Fix
```bash
kubectl delete pod -n kube-system coredns-66bc5c9577-76489
```
- **Result**: ✅ CoreDNS now healthy (2/2 Running)

### 2. Linkerd Components Restart
```bash
kubectl rollout restart deployment/linkerd-identity -n linkerd
kubectl rollout restart deployment/linkerd-proxy-injector -n linkerd
kubectl rollout restart deployment/linkerd-destination -n linkerd
```
- **Result**: ⚠️ Components restarting, but still have DNS resolution issues due to missing policy controller

### 3. Auth Service Fix
```bash
kubectl delete deployment auth-service -n record-platform
kubectl apply -f infra/k8s/base/auth-service/deploy.yaml
kubectl annotate deployment auth-service -n record-platform linkerd.io/inject=disabled --overwrite
kubectl delete pod -n record-platform -l app=auth-service
```
- **Result**: ✅ Auth service now running (1/1 READY)
- **Note**: Linkerd injection temporarily disabled to bypass proxy connectivity issues

## Current Status

### ✅ Healthy Components
- **Kubernetes Node**: Ready
- **CoreDNS**: 2/2 Running
- **Auth Service**: 1/1 Running (without Linkerd proxy)

### ⚠️ Known Issues
- **Linkerd Policy Controller**: Missing pod (service exists but no deployment/pod)
  - This causes DNS resolution failures for `linkerd-policy.linkerd.svc.cluster.local`
  - Also affects `linkerd-dst-headless.linkerd.svc.cluster.local`
- **Linkerd Components**: Some pods still initializing or not fully ready
  - `linkerd-identity`: Mixed status (old pod 1/2, new pod 0/2)
  - `linkerd-proxy-injector`: 0/2 READY
  - `linkerd-destination`: 1/4 READY (old pod), 0/4 PodInitializing (new pod)

## Recommendations

### Immediate (For Testing)
1. ✅ **Auth service is ready** - Can run tests now:
   ```bash
   ./scripts/test-auth-service.sh
   ```

### Short-term (Fix Linkerd)
1. **Install Linkerd Policy Controller**:
   ```bash
   # Check if policy controller needs to be installed
   linkerd install --components=policy-controller | kubectl apply -f -
   # OR check existing Linkerd installation scripts
   ```

2. **Alternative**: If policy controller isn't needed, consider:
   - Removing Linkerd entirely for development
   - Or fixing the DNS resolution issues

### Long-term
1. **Monitor Linkerd health**: Set up alerts for Linkerd control plane components
2. **Document Linkerd setup**: Ensure policy controller is included in installation
3. **Health checks**: Add automated checks for CoreDNS and Linkerd components

## Testing

The auth service is now ready for testing:

```bash
# Run auth service tests
./scripts/test-auth-service.sh

# Check service health
kubectl get pods -n record-platform -l app=auth-service
kubectl logs -n record-platform -l app=auth-service -c app --tail=20
```

## Notes

- Auth service is running **without Linkerd proxy** (injection disabled)
- This is fine for testing, but production should have Linkerd enabled
- Linkerd policy controller needs to be installed for full Linkerd functionality
- CoreDNS issues were resolved by restarting the unhealthy pod

