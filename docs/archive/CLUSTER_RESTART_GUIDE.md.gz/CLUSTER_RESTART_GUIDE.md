# Cluster Restart and Redeploy Guide

## Quick Start

To completely restart the cluster and redeploy everything:

```bash
./scripts/restart-cluster-and-redeploy.sh h3
```

This script will:
1. ✅ Delete the existing Kind cluster
2. ✅ Create a new cluster with proper port mappings
3. ✅ Install ingress-nginx
4. ✅ Build and load all service images
5. ✅ Deploy Caddy with proper configuration
6. ✅ Set up TLS certificates
7. ✅ Deploy all services
8. ✅ Restart services that need rebuilding (social-service, auction-monitor)

## What Gets Rebuilt

The script uses `scripts/build-and-load.sh` which builds these services:
- api-gateway
- auth-service
- records-service
- listings-service
- analytics-service
- python-ai-service
- social-service
- shopping-service
- auction-monitor
- cron-jobs
- pgbouncer

## Certificate Setup

The script automatically:
- Generates new certificates using `mkcert`
- Creates `record-local-tls` secret in both `ingress-nginx` and `record-platform` namespaces
- Creates `dev-root-ca` secret for CA trust

**Prerequisites**: `mkcert` must be installed and initialized:
```bash
brew install mkcert
mkcert -install
```

## After Restart

1. **Verify Caddy is working**:
   ```bash
   ./scripts/test-full-chain-with-rotation.sh
   ```

2. **Check service health**:
   ```bash
   kubectl -n record-platform get pods
   kubectl -n ingress-nginx get pods -l app=caddy-h3
   ```

3. **View logs if issues**:
   ```bash
   kubectl -n record-platform logs -f deployment/social-service
   kubectl -n record-platform logs -f deployment/auction-monitor
   ```

## Manual Steps (if script fails)

If the script fails at any step, you can run steps manually:

### 1. Delete and recreate cluster
```bash
kind delete cluster --name h3
kind create cluster --name h3 --config kind-h3.yaml
```

### 2. Install ingress-nginx
```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx --create-namespace \
  --set controller.allowSnippetAnnotations=true \
  --set controller.service.type=ClusterIP
```

### 3. Build and load images
```bash
./scripts/build-and-load.sh h3
```

### 4. Deploy Caddy
```bash
kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-configmap.yaml
kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-deploy.yaml
kubectl -n ingress-nginx apply -f infra/k8s/caddy-h3-svc.yaml
```

### 5. Set up certificates
```bash
./scripts/rotate-ca-and-fix-tls.sh
```

### 6. Deploy services
```bash
kubectl apply -k infra/k8s/overlays/dev
```

### 7. Restart services
```bash
kubectl -n record-platform rollout restart deploy/social-service deploy/auction-monitor
```

## Troubleshooting

### Cluster creation fails
- Check Docker is running
- Check if port 30443 or 8443 are already in use
- Try: `docker ps` to see if old containers exist

### Images fail to build
- Check Docker has enough resources
- Try building one service at a time
- Check Dockerfile paths are correct

### Caddy fails to start
- Check certificates are created: `kubectl -n ingress-nginx get secret record-local-tls`
- Check Caddyfile is valid: `kubectl -n ingress-nginx get configmap caddy-h3 -o yaml`
- Check logs: `kubectl -n ingress-nginx logs -l app=caddy-h3`

### Services fail to start
- Check database connections (if using external DBs)
- Check ConfigMaps and Secrets exist
- Check resource limits aren't too restrictive

## Expected Results

After successful restart:
- ✅ Caddy pods: 2/2 Ready
- ✅ All service pods: Running
- ✅ Test script: All tests passing
- ✅ Certificate: Valid and trusted
- ✅ NodePort: Working on port 30443

## Performance

After restart, the test script should:
- Complete in reasonable time (not hang)
- Achieve 120+ req/s throughput
- Show 100% success rate for CA rotation

If performance is still slow, check:
1. Cluster resources (CPU/memory)
2. Network connectivity
3. Certificate validity
4. Caddy configuration

