# Connectivity and File Copy Issues - Investigation and Fixes

## Summary

Investigated and fixed both file copy and connectivity issues for the listings service k6 tests.

## Issues Found

### 1. File Copy Issue ✅ FIXED
**Problem**: Files were being created in pods but couldn't be copied because pods terminated too quickly.

**Root Cause**: 
- Pods complete and terminate immediately after k6 finishes
- `kubectl cp` requires the pod to be in a running state
- Files were created but not accessible once pod terminated

**Solution**:
- Added monitoring to detect when files are available while pod is still running
- Copy files immediately when detected, before pod terminates
- Added `sleep 5` in k6 container to keep it alive briefly after completion
- Use `kubectl exec` as fallback if `kubectl cp` fails
- Copy files as soon as job completes, before cleanup

**Files Modified**:
- `scripts/run-k6-listings-with-graphs.sh`: Added file monitoring and early copy logic

### 2. Connectivity Issue ⚠️ PARTIALLY FIXED
**Problem**: 100% error rate - all requests failing with authentication errors.

**Root Causes Identified**:
1. **hostAliases placement**: Initially placed incorrectly in YAML structure
2. **Connection pool exhaustion**: k6 may be exhausting connection pools with high VUs
3. **Network errors**: Status 0 responses indicate network-level failures

**Solutions Applied**:
1. ✅ Fixed hostAliases placement (moved to `spec.template.spec` level, not in containers)
2. ✅ Added `http.setResponseCallback` to handle expected status codes
3. ✅ Improved error handling in authentication function
4. ✅ Added connection keep-alive headers
5. ✅ Added HTTP timeout configuration

**Verification**:
- ✅ Direct curl test with hostAliases works (got 201 response with token)
- ✅ Files are now being copied successfully
- ⚠️ k6 still showing 100% error rate (needs further investigation)

**Remaining Issues**:
- k6 authentication still failing despite curl working
- May be related to k6's connection pooling or HTTP/2 handling
- Need to investigate k6-specific network configuration

## Files Modified

1. **`scripts/run-k6-listings-with-graphs.sh`**
   - Fixed hostAliases placement in YAML
   - Added file monitoring while pod is running
   - Improved file copy logic with multiple fallback methods
   - Added sleep in container to keep it alive briefly

2. **`scripts/load/k6-listings-service-comprehensive.js`**
   - Added `http.setResponseCallback` for expected status codes
   - Improved authentication error handling
   - Added connection keep-alive headers
   - Better handling of network errors (status 0)

## Testing Results

### File Copy ✅
```
✅ Copied k6-summary.json via kubectl cp
✅ Latency graphs generated successfully
✅ Report copied to project root
```

### Connectivity ⚠️
```
✅ curl test with hostAliases: SUCCESS (201 response)
⚠️ k6 test: Still showing 100% error rate
```

## Next Steps

1. **Investigate k6 Connection Issues**:
   - Check k6's HTTP/2 and connection pool settings
   - Test with lower VUs to see if it's a concurrency issue
   - Compare with working social service test configuration

2. **Alternative Approaches**:
   - Use API Gateway directly instead of Caddy
   - Test with HTTP/1.1 instead of HTTP/2
   - Add retry logic for failed connections

3. **Monitor Network**:
   - Check Caddy logs for connection errors
   - Monitor Kubernetes network policies
   - Check for rate limiting or connection limits

## Commands for Further Investigation

```bash
# Test connectivity with curl (works)
kubectl -n record-platform run test-curl --rm -i --restart=Never \
  --image=curlimages/curl:latest \
  --overrides='{"spec":{"hostAliases":[{"ip":"10.96.171.48","hostnames":["record.local"]}]}}' \
  -- curl -v https://record.local/api/auth/register -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123"}'

# Check k6 logs for specific errors
kubectl -n record-platform logs -l job-name=k6-listings-graphs | grep -E "error|Error|dial|connect"

# Test with minimal VUs
VUS=1 DURATION=10s ./scripts/run-k6-listings-with-graphs.sh
```

