# Docker Desktop Recovery - Immediate Actions

**Date**: January 6, 2026  
**Issue**: Docker Desktop VM Wedged - Docker.raw is 256GB (should be <40-60GB)  
**Status**: ⚠️ CRITICAL - Docker CLI commands hanging for 15+ hours

## Diagnosis Confirmed

✅ **Root Cause Identified**: Docker.raw is 256GB (5-6x normal size)
- Normal size: 40-60GB
- Current size: 256GB
- This is causing Docker Desktop VM to wedge (metadata traversal failures)

## Immediate Recovery Steps

### Step 1: Safe Shutdown (DO THIS FIRST)

```bash
# Use the recovery script
./scripts/docker-desktop-recovery.sh shutdown
```

This will:
1. Quit Docker Desktop application cleanly
2. Kill hung Docker VM processes
3. Verify all processes stopped

### Step 2: Reset Docker Desktop (RECOMMENDED)

**Option A - Use Recovery Script** (Easiest):
```bash
./scripts/docker-desktop-recovery.sh reset
```

**Option B - Manual Reset**:
1. Open Docker Desktop
2. Settings → Troubleshoot → Reset to factory defaults
3. Confirm reset

**What happens**:
- ✅ Docker.raw removed (recreated fresh on next start)
- ✅ VM metadata cleared and rebuilt
- ✅ All images/containers/volumes deleted (RP is reproducible, so safe)
- ✅ Docker CLI will be responsive again

### Step 3: Rebuild RP

After Docker Desktop resets and restarts:

```bash
# Recreate Kind cluster
kind delete cluster --name h3
kind create cluster --name h3 --config kind-h3.yaml

# Rebuild and load images
./scripts/build-and-load-images.sh

# Deploy services
kubectl apply -k infra/k8s/base
```

## Why This Happened

RP workload exceeds Docker Desktop's design limits:

- ✅ 8 Postgres databases
- ✅ Kafka + Zookeeper
- ✅ Kind clusters (nested Kubernetes)
- ✅ Frequent rebuilds
- ✅ k6 load tests
- ✅ Long-running containers
- ✅ Large logs accumulating

**This is not your fault** - RP simply outgrew Docker Desktop.

## Long-Term Solution

### Recommended: Migrate to OrbStack/Colima

**Why**:
- Real ext4 filesystem (no Docker.raw ballooning)
- Predictable I/O performance
- Stable under load
- Faster rebuilds
- Better kind support

**Migration Steps** (1 hour, done forever):
1. Install OrbStack or Colima
2. Export Kind cluster configs
3. Recreate cluster in new environment
4. Rebuild images
5. Deploy services

**After migration**: Docker will never wedge again with RP's workload.

### Alternative: Stay on Docker Desktop with Hygiene Rules

If you stay on Docker Desktop:

**Daily Cleanup**:
```bash
docker system prune -af --volumes
```

**Cap Resources** (Docker Desktop Settings):
- CPUs: ≤ 8
- Memory: ≤ 10GB
- Disk image size: Fixed limit (100GB), not unlimited

**Monitor Docker.raw Size**:
```bash
ls -lh ~/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw
# If >60GB, reset immediately
```

**Warning**: These only delay the failure. RP's workload will eventually trigger this again.

## Recovery Script Usage

```bash
# Check status (size, processes, responsiveness)
./scripts/docker-desktop-recovery.sh check

# Safe shutdown (before reset)
./scripts/docker-desktop-recovery.sh shutdown

# Reset Docker Desktop (nuclear option - deletes everything)
./scripts/docker-desktop-recovery.sh reset

# Try compact disk (may not work if too corrupted)
./scripts/docker-desktop-recovery.sh compact
```

## Summary

**Current Status**: Docker.raw is 256GB → Docker Desktop VM is wedged → CLI commands hang

**Immediate Fix**: Reset Docker Desktop (RP is reproducible, so losing images is fine)

**Long-Term Fix**: Migrate to OrbStack/Colima (1 hour, done forever)

**This is not failure - this is signal that you've outgrown Docker Desktop.**
