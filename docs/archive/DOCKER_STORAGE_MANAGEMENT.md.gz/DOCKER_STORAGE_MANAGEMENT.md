# Docker Storage Management Guide

## Current Situation

You have **8 PostgreSQL database instances** running in Docker, which is causing storage issues:

- **15 Docker volumes**: 48.54GB total
- **8 PostgreSQL volumes**: Each database has its own volume
- **Docker images**: 5.487GB
- **Build cache**: 4.524GB (can be cleaned)

## Immediate Actions (Do These First!)

### 1. Clean Up Docker Build Cache (Safest, Immediate Space Recovery)

```bash
# Clean build cache (reclaims ~4.5GB)
docker builder prune -a -f

# Clean unused images (reclaims ~3.5GB)
docker image prune -a -f

# Clean unused volumes (CAREFUL - only unused volumes)
docker volume prune -f
```

### 2. Check Current Storage Usage

```bash
# See detailed storage breakdown
docker system df -v

# Check disk space
df -h
```

## Expanding Docker Storage (macOS)

### Option 1: Increase Docker Desktop Disk Image Size (Recommended)

1. **Open Docker Desktop**
2. **Go to Settings → Resources → Advanced**
3. **Increase "Disk image size"**:
   - Current: Check your current setting
   - Recommended: **100GB minimum** for 8 databases
   - For production-like data: **200GB+**
4. **Click "Apply & Restart"**
5. **Wait for Docker to resize** (may take 5-10 minutes)

### Option 2: Move Docker Data to External Drive

If your main drive is full:

```bash
# Stop Docker Desktop
# Move Docker data directory to external drive
# Update Docker Desktop settings to use new location
```

### Option 3: Use Docker Desktop Storage Location Settings

1. **Docker Desktop → Settings → Resources → Advanced**
2. **Change "Disk image location"** to a drive with more space
3. **Apply & Restart**

## Long-Term Storage Management Strategy

### 1. Database Volume Optimization

#### Option A: Shared PostgreSQL Instance (Recommended for Development)

Instead of 8 separate PostgreSQL instances, use **1 PostgreSQL instance with 8 databases**:

**Benefits:**
- **90% storage reduction** (shared WAL, shared binaries)
- **Lower memory usage** (shared connection pool)
- **Easier backup/restore** (single instance)
- **Faster startup** (1 container vs 8)

**Implementation:**
- Use `POSTGRES_DB` environment variable or create databases in init scripts
- Each service connects to same PostgreSQL with different database name
- Still maintains data isolation (separate schemas/databases)

#### Option B: Keep Separate Instances but Optimize

If you need separate instances (for production-like isolation):

1. **Use smaller base images**: Already using `postgres:16-alpine` ✅
2. **Enable compression**: PostgreSQL compression for large tables
3. **Regular VACUUM**: Clean up dead tuples
4. **Archive old data**: Move historical data to cold storage

### 2. Volume Size Limits

Set explicit size limits on volumes to prevent runaway growth:

```yaml
# docker-compose.yml
services:
  postgres:
    volumes:
      - pgdata:/var/lib/postgresql/data
    # Add size limit (if supported by your Docker setup)
    deploy:
      resources:
        limits:
          storage: 20Gi  # Per database limit
```

### 3. Regular Cleanup Script

Create `scripts/cleanup-docker-storage.sh`:

```bash
#!/usr/bin/env bash
# Cleanup Docker storage safely

echo "🧹 Cleaning Docker storage..."

# 1. Clean build cache (safe)
echo "Cleaning build cache..."
docker builder prune -a -f

# 2. Clean unused images (safe)
echo "Cleaning unused images..."
docker image prune -a -f

# 3. Show current usage
echo ""
echo "📊 Current Docker storage usage:"
docker system df

# 4. Show volume sizes
echo ""
echo "📦 Database volume sizes:"
docker volume ls | grep pgdata
```

### 4. Database-Specific Cleanup

For each database, run periodic maintenance:

```bash
# Connect to each database and run VACUUM
docker exec -it record-platform-postgres-1 psql -U postgres -d records -c "VACUUM FULL;"
docker exec -it record-platform-postgres-analytics-1 psql -U postgres -d analytics -c "VACUUM FULL;"
# ... repeat for all 8 databases
```

### 5. Backup and Archive Strategy

**Regular Backups:**
- Keep only last 7 days of daily backups
- Weekly backups: Keep last 4 weeks
- Monthly backups: Keep last 6 months

**Archive Old Data:**
- Move old data to compressed archives
- Store archives outside Docker volumes
- Use `pg_dump` with compression

## Monitoring Storage Usage

### Create Storage Monitoring Script

```bash
#!/usr/bin/env bash
# scripts/check-docker-storage.sh

echo "📊 Docker Storage Report"
echo "========================"
echo ""

# Overall usage
echo "Overall Docker Storage:"
docker system df
echo ""

# Volume sizes
echo "Database Volume Sizes:"
for vol in $(docker volume ls -q | grep pgdata); do
  size=$(docker run --rm -v "$vol":/data alpine du -sh /data 2>/dev/null | cut -f1)
  echo "  $vol: $size"
done
echo ""

# Disk space
echo "System Disk Space:"
df -h | grep -E "Filesystem|/dev/"
```

## Recommended Configuration

### For Development (Current Setup)

**Minimum Requirements:**
- Docker disk image: **100GB**
- Each database volume: **10-20GB**
- Total for 8 databases: **80-160GB**

**Optimization:**
- Use single PostgreSQL instance with 8 databases
- Reduces storage to **~20-30GB** total

### For Production-Like Testing

**Requirements:**
- Docker disk image: **200GB+**
- Each database volume: **50-100GB** (depending on data)
- Regular cleanup and archiving

## Migration Path: Single PostgreSQL Instance

### Step 1: Create New docker-compose.yml Section

```yaml
# Single PostgreSQL with multiple databases
postgres-unified:
  image: postgres:16-alpine
  environment:
    POSTGRES_PASSWORD: postgres
    POSTGRES_MULTIPLE_DATABASES: records,social,listings,shopping,auth,auction_monitor,analytics,python_ai
  ports: ["5433:5432"]
  volumes:
    - pgdata-unified:/var/lib/postgresql/data
    - ./infra/postgres/init-multiple-databases.sh:/docker-entrypoint-initdb.d/init-multiple-databases.sh
  shm_size: 1g
```

### Step 2: Create Init Script

```bash
# infra/postgres/init-multiple-databases.sh
#!/bin/bash
set -e

for db in records social listings shopping auth auction_monitor analytics python_ai; do
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE DATABASE $db;
  EOSQL
done
```

### Step 3: Update Service Connection Strings

Change from:
```env
POSTGRES_URL=postgresql://postgres:postgres@postgres-auth:5432/auth
```

To:
```env
POSTGRES_URL=postgresql://postgres:postgres@postgres-unified:5432/auth
```

## Safety Checklist Before Expanding Storage

- [ ] **Backup all databases** before any changes
- [ ] **Stop all containers** before resizing
- [ ] **Check current disk space** on host
- [ ] **Verify backups are working** before cleanup
- [ ] **Test on one database first** before applying to all

## Emergency Recovery

If Docker storage is completely full:

1. **Stop all containers**:
   ```bash
   docker-compose down
   ```

2. **Clean build cache** (safest cleanup):
   ```bash
   docker builder prune -a -f
   ```

3. **Remove unused images**:
   ```bash
   docker image prune -a -f
   ```

4. **Expand Docker disk image** in Docker Desktop settings

5. **Restart containers**:
   ```bash
   docker-compose up -d
   ```

## Related Files

- `docker-compose.yml` - Database service definitions
- `infra/k8s/base/postgres/pvc.yaml` - Kubernetes storage (10Gi per database)
- `infra/k8s/base/postgres/pvc-big.yaml` - Large storage (100Gi)

