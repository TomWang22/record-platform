# E2E Test Failure Report

**Generated:** $(date)
**Status:** 3/4 pods failed

---

## 🔴 Critical Issue

3 out of 4 k6 test pods have failed immediately after starting.

---

## 📊 Pod Status

- k6-shopping-e2e-1: ❌ Failed
- k6-shopping-e2e-2: ❌ Failed  
- k6-shopping-e2e-3: ✅ Running
- k6-shopping-e2e-4: ❌ Failed

---

## 🔍 Investigation


### Failed Pod Logs:

          /\      |‾‾| /‾‾/   /‾‾/   
     /\  /  \     |  |/  /   /  /    
    /  \/    \    |     (   /   ‾‾\  
   /          \   |  |\  \ |  (‾)  | 
  / __________ \  |__| \__\ \_____/ .io

