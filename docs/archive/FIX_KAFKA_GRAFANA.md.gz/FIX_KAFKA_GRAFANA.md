# Fixing Kafka and Grafana Issues

## Kafka Fix (Cluster ID Mismatch)

### Problem
Kafka is using `emptyDir` for data storage. When the pod restarts, the data is lost but Zookeeper still has the old cluster ID metadata, causing a mismatch.

### Solution
Delete the Kafka pod to clear the `emptyDir` data and let it reconnect to Zookeeper with a fresh cluster ID.

```bash
# Delete Kafka pod
kubectl -n record-platform delete pod -l app=kafka

# Wait for recreation
kubectl -n record-platform wait --for=condition=ready pod -l app=kafka --timeout=120s

# Verify it's running
kubectl -n record-platform get pod -l app=kafka
```

### Better Long-term Solution
Use a PVC for Kafka data persistence:
- Create a PVC for Kafka data
- Update deployment to use PVC instead of emptyDir
- This prevents data loss on pod restarts

## Grafana (Helm) Fix (Permission Denied)

### Problem
Init container `init-chown-data` is failing with permission denied errors on:
- `/var/lib/grafana/pdf`
- `/var/lib/grafana/csv`
- `/var/lib/grafana/png`

### Solution Options

#### Option 1: Delete PVC (Loses Data)
```bash
# Get PVC name
PVC_NAME=$(kubectl -n monitoring get pvc -l app.kubernetes.io/name=grafana -o jsonpath='{.items[0].metadata.name}')

# Delete PVC
kubectl -n monitoring delete pvc "$PVC_NAME"

# Delete pods to force recreation
kubectl -n monitoring delete pod -l app.kubernetes.io/name=grafana

# Wait for recreation
kubectl -n monitoring wait --for=condition=ready pod -l app.kubernetes.io/name=grafana --timeout=120s
```

#### Option 2: Fix Permissions (Keep Data)
```bash
# Get Grafana pod
GRAFANA_POD=$(kubectl -n monitoring get pod -l app.kubernetes.io/name=grafana -o jsonpath='{.items[0].metadata.name}')

# Fix permissions manually
kubectl -n monitoring exec "$GRAFANA_POD" -c init-chown-data -- chown -R 472:472 /var/lib/grafana 2>/dev/null || \
kubectl -n monitoring exec "$GRAFANA_POD" -c grafana -- chown -R 472:472 /var/lib/grafana
```

#### Option 3: Use Standalone Grafana (Recommended)
The standalone Grafana works perfectly. You can ignore the Helm Grafana or delete it:
```bash
# Delete Helm Grafana deployment
kubectl -n monitoring delete deployment -l app.kubernetes.io/name=grafana
```

## ServiceMonitors Verification

### Check All ServiceMonitors
```bash
# List all ServiceMonitors
kubectl -n monitoring get servicemonitors

# Verify Prometheus is configured to scrape them
kubectl -n monitoring get prometheus -o yaml | grep -A 5 serviceMonitorSelector
```

### Verify Prometheus is Scraping
```bash
# Port forward Prometheus
kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090

# Check targets (in another terminal)
curl -s http://localhost:9090/api/v1/targets | jq '.data.activeTargets[] | select(.labels.namespace=="record-platform") | {job: .labels.job, health: .health}'
```

### Expected ServiceMonitors (17 total)
1. haproxy-exporter
2. ingress-nginx-controller
3. monitoring-grafana
4. monitoring-kube-prometheus-alertmanager
5. monitoring-kube-prometheus-apiserver
6. monitoring-kube-prometheus-coredns
7. monitoring-kube-prometheus-kube-controller-manager
8. monitoring-kube-prometheus-kube-etcd
9. monitoring-kube-prometheus-kube-proxy
10. monitoring-kube-prometheus-kube-scheduler
11. monitoring-kube-prometheus-kubelet
12. monitoring-kube-prometheus-operator
13. monitoring-kube-prometheus-prometheus
14. monitoring-kube-state-metrics
15. monitoring-prometheus-node-exporter
16. nginx-exporter
17. postgres-exporter

