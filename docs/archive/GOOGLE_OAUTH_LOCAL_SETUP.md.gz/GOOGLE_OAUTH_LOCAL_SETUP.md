# Google OAuth Setup for Local Development

## Problem
Google OAuth **does not accept `.local` domains** (like `record.local`). You need to use either:
- `localhost` (for local development)
- A real domain (for production)

## Solution: Use `localhost` for Development

### Step 1: Update Google Console OAuth Settings

Since you already created the OAuth client, you need to **edit it** and change the URIs:

1. Go back to: https://console.cloud.google.com/apis/credentials
2. Click on your OAuth client (the one you just created)
3. **Edit** the following:

**Authorized JavaScript origins:**
```
http://localhost:4001
https://localhost:8443
```

**Authorized redirect URIs:**
```
http://localhost:4001/auth/google/callback
https://localhost:8443/api/auth/google/callback
```

**Why both?**
- `http://localhost:4001` - Direct access to auth service (for testing)
- `https://localhost:8443` - Via API gateway (production-like setup)

4. Click **Save**

### Step 2: Update Kubernetes Configuration

We'll configure OAuth to work with `localhost`:

```yaml
GOOGLE_CALLBACK_URL: "http://localhost:4001/auth/google/callback"
FRONTEND_URL: "http://localhost:3001"
```

Or if accessing via gateway:
```yaml
GOOGLE_CALLBACK_URL: "https://localhost:8443/api/auth/google/callback"
FRONTEND_URL: "https://localhost:8443"
```

### Step 3: Access OAuth via localhost

When testing OAuth, access it via:
- `http://localhost:4001/auth/google` (direct to auth service)
- Or `https://localhost:8443/api/auth/google` (via gateway)

## Alternative: Use a Real Domain (Production)

If you have a real domain (e.g., `yourdomain.com`), use that instead:

**Authorized JavaScript origins:**
```
https://yourdomain.com
```

**Authorized redirect URIs:**
```
https://yourdomain.com/api/auth/google/callback
```

## Alternative: Use ngrok for Development (Recommended)

ngrok gives you a real HTTPS domain that tunnels to localhost:

1. **Install ngrok**: https://ngrok.com/download
2. **Start tunnel**:
   ```bash
   ngrok http 8443
   ```
3. **Copy the HTTPS URL** (e.g., `https://abc123.ngrok.io`)
4. **Use in Google Console**:
   - Authorized JavaScript origins: `https://abc123.ngrok.io`
   - Authorized redirect URIs: `https://abc123.ngrok.io/api/auth/google/callback`
5. **Update config**:
   ```yaml
   GOOGLE_CALLBACK_URL: "https://abc123.ngrok.io/api/auth/google/callback"
   FRONTEND_URL: "https://abc123.ngrok.io"
   ```

## Quick Fix: Use localhost Now

For immediate testing, let's use `localhost`:

1. **In Google Console**, edit your OAuth client:
   - Authorized JavaScript origins: `http://localhost:4001`
   - Authorized redirect URIs: `http://localhost:4001/auth/google/callback`

2. **Test OAuth**:
   ```bash
   # Port-forward to access auth service directly
   kubectl port-forward -n record-platform svc/auth-service 4001:4001
   
   # Then access:
   # http://localhost:4001/auth/google
   ```

## Summary

✅ **Easiest for now**: Use `localhost:4001` in Google Console  
✅ **Best for development**: Use ngrok for a real HTTPS domain  
✅ **Best for production**: Use your real domain

Let me know which approach you want to use, and I'll update the configuration!

