# Google OAuth - Publish for All Users

## Current Status: Testing Mode

Your OAuth app is currently in **Testing** mode, which means:
- ❌ Only test users can sign in
- ❌ You must manually add each user's email
- ✅ Good for development/testing

## Goal: Publish for All Users

To allow **ANY user with a Google email** to sign in:
- ✅ No need to add users manually
- ✅ Any Google account can sign in
- ✅ Production-ready

---

## Step 1: Add Test User (For Immediate Testing)

**While still in Testing mode**, add your email so you can test right away:

1. Go to: https://console.cloud.google.com/apis/credentials/consent
2. Scroll down to **"Test users"** section
3. Click **"+ ADD USERS"**
4. Enter: `tomwang04312@gmail.com`
5. Click **"ADD"**

✅ **Now you can test OAuth immediately!**

---

## Step 2: Publish OAuth Consent Screen (For All Users)

### Requirements Before Publishing:

1. **OAuth Consent Screen must be configured:**
   - ✅ App name: "Record Platform" (or your choice)
   - ✅ User support email: Your email
   - ✅ Developer contact: Your email
   - ✅ Scopes: `profile`, `email` (already set)

2. **Privacy Policy (Required for Publishing):**
   - You need a Privacy Policy URL
   - Can be a simple page on your website
   - Example: `https://record.local:8443/privacy` or `https://yourdomain.com/privacy`

3. **Terms of Service (Optional but Recommended):**
   - Recommended for production
   - Example: `https://record.local:8443/terms`

### Steps to Publish:

1. **Go to OAuth Consent Screen:**
   - Visit: https://console.cloud.google.com/apis/credentials/consent
   - Or: APIs & Services → OAuth consent screen

2. **Review Your Configuration:**
   - App name: "Record Platform"
   - User support email: [Your email]
   - Scopes: `.../auth/userinfo.email`, `.../auth/userinfo.profile`

3. **Add Privacy Policy (Required):**
   - Scroll to **"Authorized domains"** section
   - Under **"Application home page"**, add:
     ```
     https://record.local:8443
     ```
   - Under **"Privacy Policy link"**, add:
     ```
     https://record.local:8443/privacy
     ```
   - ⚠️ **Note**: If you don't have a privacy policy page yet, you can:
     - Create a simple HTML page
     - Host it on your domain
     - Or use a service like GitHub Pages

4. **Publish the App:**
   - Scroll to the top
   - Click **"PUBLISH APP"** button
   - Confirm the warning dialog
   - Status will change from "Testing" to "In production"

5. **Verification (May be Required):**
   - Google may require app verification if:
     - You request sensitive scopes
     - You have many users
     - You request restricted scopes
   - For basic `profile` and `email` scopes, verification is usually **NOT required**
   - You'll see a banner if verification is needed

---

## Step 3: Create Privacy Policy Page (If Needed)

If you don't have a privacy policy yet, create a simple one:

### Option 1: Simple HTML Page

Create `public/privacy.html`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy - Record Platform</title>
</head>
<body>
    <h1>Privacy Policy</h1>
    <p>Last updated: [Date]</p>
    <h2>Information We Collect</h2>
    <p>When you sign in with Google, we collect:</p>
    <ul>
        <li>Email address</li>
        <li>Name</li>
        <li>Profile picture (if available)</li>
    </ul>
    <h2>How We Use Your Information</h2>
    <p>We use this information to:</p>
    <ul>
        <li>Create and manage your account</li>
        <li>Provide our services</li>
    </ul>
    <h2>Contact Us</h2>
    <p>If you have questions, contact us at: [Your email]</p>
</body>
</html>
```

### Option 2: Add to Your Frontend

If you have a frontend, add a route:
- `/privacy` → Privacy Policy page
- `/terms` → Terms of Service page (optional)

---

## Step 4: Update Authorized Domains

In Google Console, under **"Authorized domains"**:

1. Click **"+ ADD DOMAIN"**
2. Add your domain (without `http://` or `https://`):
   - For local dev: `localhost` (already works)
   - For production: `yourdomain.com`

**Note**: `.local` domains won't work. For production, use a real domain.

---

## Quick Summary

### For Testing (Right Now):
1. ✅ Add `tomwang04312@gmail.com` as test user
2. ✅ Test OAuth immediately

### For Production (All Users):
1. ✅ Configure OAuth consent screen (already done)
2. ✅ Create Privacy Policy page
3. ✅ Add Privacy Policy URL to Google Console
4. ✅ Click "PUBLISH APP"
5. ✅ Any Google user can now sign in!

---

## After Publishing

- ✅ **Any Google user** can sign in (no need to add them manually)
- ✅ No more "This app isn't verified" warnings (for basic scopes)
- ✅ Production-ready OAuth

## Important Notes

- **Verification**: For basic scopes (`profile`, `email`), Google usually doesn't require verification
- **Sensitive Scopes**: If you add sensitive scopes later, verification may be required
- **Domain**: Make sure your Privacy Policy URL is accessible (even if it's a simple page)

---

## Troubleshooting

### "App verification required"
- **Cause**: You're using sensitive or restricted scopes
- **Fix**: For basic auth, you shouldn't need verification. If you see this, check your scopes.

### "Privacy Policy URL not accessible"
- **Cause**: The URL you provided isn't reachable
- **Fix**: Make sure the URL is publicly accessible (even if it's a simple HTML page)

### "Domain not verified"
- **Cause**: You're trying to use a domain you don't own
- **Fix**: Use `localhost` for dev, or verify your production domain in Google Search Console

---

## Current Configuration

- **App Name**: Record Platform
- **Client ID**: `969606486482-2kt1ku811jmulj9ndvhsrk1u5n8mvbjk.apps.googleusercontent.com`
- **Scopes**: `profile`, `email`
- **Status**: Testing (needs to be published)

Ready to publish! 🚀

