# Google OAuth Setup Status

## ✅ Current Status

### Implementation: **COMPLETE** ✅
- ✅ OAuth routes implemented (`/auth/google`, `/auth/google/callback`)
- ✅ Passport.js Google OAuth strategy configured
- ✅ User creation/linking logic implemented
- ✅ JWT token generation after OAuth
- ✅ Database schema supports OAuth (`oauth_providers` table)
- ✅ Error handling and redirects configured

### Configuration: **NEEDS SETUP** ❌
- ❌ `GOOGLE_CLIENT_ID`: **Not configured** (empty in secrets)
- ❌ `GOOGLE_CLIENT_SECRET`: **Not configured** (empty in secrets)
- ✅ `GOOGLE_CALLBACK_URL`: Set to `https://record.local:8443/api/auth/google/callback`
- ✅ `FRONTEND_URL`: Set to `https://record.local:8443`

## 🚀 Quick Setup Guide

### Step 1: Get Google OAuth Credentials

1. **Go to Google Cloud Console:**
   - Visit: https://console.cloud.google.com/
   - Sign in with your Google account

2. **Create or Select Project:**
   - Click project dropdown → "New Project"
   - Name: "Record Platform" (or your choice)
   - Click "Create"

3. **Enable Google+ API:**
   - Go to **APIs & Services** → **Library**
   - Search: "Google+ API"
   - Click **Enable**

4. **Configure OAuth Consent Screen:**
   - Go to **APIs & Services** → **OAuth consent screen**
   - User Type: **External** (for public use)
   - App name: "Record Platform"
   - User support email: [Your email]
   - Developer contact: [Your email]
   - Click **Save and Continue**
   - Scopes: Click **Add or Remove Scopes**
     - Select: `.../auth/userinfo.email`
     - Select: `.../auth/userinfo.profile`
   - Click **Save and Continue**
   - Test users: Add your email (if in testing mode)
   - Click **Save and Continue**

5. **Create OAuth Client:**
   - Go to **APIs & Services** → **Credentials**
   - Click **+ Create Credentials** → **OAuth client ID**
   - Application type: **Web application**
   - Name: "Record Platform Auth"
   - **Authorized JavaScript origins:**
     ```
     https://record.local:8443
     ```
   - **Authorized redirect URIs:**
     ```
     https://record.local:8443/api/auth/google/callback
     ```
   - Click **Create**
   - **Copy the Client ID and Client Secret** (you'll need these!)

### Step 2: Add Credentials to Kubernetes

Edit `infra/k8s/base/config/app-secrets.yaml`:

```yaml
GOOGLE_CLIENT_ID: "your_client_id.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET: "your_client_secret_here"
GOOGLE_CALLBACK_URL: "https://record.local:8443/api/auth/google/callback"
FRONTEND_URL: "https://record.local:8443"
```

### Step 3: Apply and Restart

```bash
# Apply secrets
kubectl apply -f infra/k8s/base/config/app-secrets.yaml

# Restart auth service
kubectl rollout restart deployment/auth-service -n record-platform

# Wait for restart
kubectl wait --for=condition=ready pod -n record-platform -l app=auth-service --timeout=60s
```

### Step 4: Test OAuth

1. **Initiate OAuth:**
   ```bash
   # Open in browser or use curl
   curl -L "https://record.local:8443/api/auth/google"
   ```
   This will redirect to Google login.

2. **After login**, you'll be redirected to:
   ```
   https://record.local:8443/auth/callback?token=...&newUser=true/false
   ```

3. **Check logs:**
   ```bash
   kubectl logs -n record-platform -l app=auth-service -c app | grep -i oauth
   ```

## 📋 OAuth Flow

```
User clicks "Sign in with Google"
  ↓
GET /api/auth/google
  ↓
Redirect to Google Login
  ↓
User authenticates with Google
  ↓
Google redirects to: /api/auth/google/callback?code=...
  ↓
Auth Service:
  1. Exchanges code for user profile
  2. Creates/finds user in database
  3. Links OAuth provider to user
  4. Generates JWT token
  5. Redirects to: FRONTEND_URL/auth/callback?token=...&newUser=...
```

## 🔍 Verification Checklist

- [ ] Google Cloud project created
- [ ] Google+ API enabled
- [ ] OAuth consent screen configured
- [ ] OAuth client ID created
- [ ] Authorized redirect URI matches: `https://record.local:8443/api/auth/google/callback`
- [ ] Client ID and Secret copied
- [ ] Credentials added to `app-secrets.yaml`
- [ ] Secrets applied to Kubernetes
- [ ] Auth service restarted
- [ ] OAuth initiation works (`/api/auth/google`)
- [ ] Google login page appears
- [ ] Callback receives code
- [ ] User created in database
- [ ] JWT token generated
- [ ] Redirect to frontend works

## 🐛 Troubleshooting

### Error: "redirect_uri_mismatch"
- **Fix**: Make sure the redirect URI in Google Console **exactly** matches:
  ```
  https://record.local:8443/api/auth/google/callback
  ```
  (including `https://`, no trailing slash)

### Error: "invalid_client"
- **Fix**: Double-check `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in `app-secrets.yaml`
- Make sure they're not empty strings

### Error: "access_denied"
- **Fix**: Configure OAuth consent screen in Google Cloud Console
- Add your email as a test user if in testing mode

### OAuth works but no user created
- **Check logs**: `kubectl logs -n record-platform -l app=auth-service -c app`
- **Verify database**: Check if `oauth_providers` table exists

## 📚 Files Reference

- **OAuth Routes**: `services/auth-service/src/routes/oauth.ts`
- **OAuth Logic**: `services/auth-service/src/lib/oauth.ts`
- **Setup Guide**: `OAUTH_SETUP_GUIDE.md`
- **Secrets Config**: `infra/k8s/base/config/app-secrets.yaml`

## 🎯 Next Steps

1. **Get Google OAuth credentials** (follow Step 1 above)
2. **Add credentials to `app-secrets.yaml`**
3. **Apply and restart** (follow Step 3 above)
4. **Test OAuth flow** (follow Step 4 above)

The code is **production-ready** - you just need the Google credentials! 🚀

