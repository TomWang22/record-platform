# gRPC Health Checks Implementation

## Overview

All services now support gRPC health checks using the standard `grpc.health.v1.Health` protocol. Health checks use **HTTP/2 (h2c) or HTTP/3 (QUIC)** - **NOT HTTP/1.1**.

## Protocol Stack

```
┌─────────────────────────────────────┐
│  gRPC Health Check                  │
│  grpc.health.v1.Health/Check       │
└──────────────┬──────────────────────┘
               │
       ┌───────┴────────┐
       │                │
   HTTP/2 (h2c)    HTTP/3 (QUIC)
   Port 50051+     Port 443
       │                │
       └───────┬────────┘
               │
    ┌──────────▼──────────┐
    │  Caddy (Routes)     │
    │  - HTTP/2/3 only    │
    │  - NOT HTTP/1.1     │
    └─────────────────────┘
```

## Services with gRPC Health Checks

1. **auth-service** (port 50051)
   - Service name: `auth.AuthService`
   - Health check: `grpc.health.v1.Health/Check`

2. **records-service** (port 50051)
   - Service name: `records.RecordsService`
   - Health check: `grpc.health.v1.Health/Check`

3. **social-service** (port 50051)
   - Service name: `social.SocialService`
   - Health check: `grpc.health.v1.Health/Check`

4. **shopping-service** (port 50058)
   - Service name: `shopping.ShoppingService`
   - Health check: `grpc.health.v1.Health/Check`
   - **Strict TLS enabled**

5. **listings-service** (port 50051)
6. **analytics-service** (port 50051)
7. **auction-monitor** (port 50059)
8. **python-ai-service** (port 50060)

## Usage

### Via Caddy (External)

```bash
# Check auth service health
grpcurl -plaintext -d '{"service":"auth.AuthService"}' \
  record.local:443 grpc.health.v1.Health/Check

# Check shopping service health (with strict TLS)
grpcurl -d '{"service":"shopping.ShoppingService"}' \
  record.local:443 grpc.health.v1.Health/Check
```

### Direct (In-Cluster)

```bash
# Check auth service health directly
grpcurl -plaintext -d '{"service":"auth.AuthService"}' \
  auth-service.record-platform.svc.cluster.local:50051 \
  grpc.health.v1.Health/Check
```

## Response Format

```json
{
  "status": "SERVING"  // or "NOT_SERVING", "SERVICE_UNKNOWN", "UNKNOWN"
}
```

## Caddyfile Configuration

The Caddyfile routes gRPC health checks to the appropriate service:

```caddy
@grpc_health {
  protocol grpc
  path_regexp ^/grpc\.health\.v1\.Health/
}
handle @grpc_health {
  reverse_proxy {
    to auth-service.record-platform.svc.cluster.local:50051
    to shopping-service.record-platform.svc.cluster.local:50058
    # ... other services
    transport http {
      versions h2c  # HTTP/2 cleartext - NOT HTTP/1.1
    }
  }
}
```

## Kubernetes Probes

Kubernetes probes still use HTTP/1.1 `/healthz` endpoints for simplicity:
- **Readiness**: `httpGet: { path: /healthz, port: http }`
- **Liveness**: `httpGet: { path: /healthz, port: http }`

gRPC health checks are available for:
- External monitoring
- Service mesh health checks
- Load balancer health checks
- Advanced monitoring tools

## Strict TLS

Shopping service and other services use **strict TLS verification**:
- CA certificate mounted at `/etc/ssl/certs/k6-ca.crt`
- `SSL_CERT_FILE` environment variable set
- No `--insecure-skip-tls-verify` flags
- Production-ready security

## Connection Pool

Auth service connection pool scaled to **100 connections**:
- `connection_limit=100`
- `pool_timeout=30`
- Single shared PrismaClient instance
- Optimized for high concurrent load

