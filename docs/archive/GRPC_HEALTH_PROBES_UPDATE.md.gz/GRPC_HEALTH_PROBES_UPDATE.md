# gRPC Health Probes Update

## Changes Made

### 1. ✅ Updated Auth Service Health Probes
- **Before**: HTTP/1.1 health checks (`httpGet: { path: /healthz }`)
- **After**: gRPC health checks (`exec: grpc-health-probe`)
- **Protocol**: HTTP/2 (h2c) and HTTP/3 (QUIC) - **NOT HTTP/1.1**

### 2. ✅ Added grpc-health-probe Binary
- Installed in auth-service Dockerfile
- Version: v0.4.24
- Location: `/usr/local/bin/grpc-health-probe`
- Uses standard `grpc.health.v1.Health/Check` protocol

### 3. ✅ Updated Kubernetes Probes
```yaml
readinessProbe:
  exec:
    command:
      - /usr/local/bin/grpc-health-probe
      - -addr=localhost:50051
      - -service=auth.AuthService
```

### 4. ✅ Started k6 Shopping Service Load Tests
- Bottleneck test: Running
- Ramp test: Running
- Tests use scaled auth service connection pool (100 connections)

## Why gRPC Health Checks?

1. **Protocol Alignment**: Matches our HTTP/2/3 architecture
2. **No HTTP/1.1**: Eliminates legacy protocol usage
3. **Standard Protocol**: Uses `grpc.health.v1.Health` standard
4. **Better Performance**: HTTP/2 multiplexing for health checks
5. **Production Ready**: Industry-standard health checking

## Connection Pool Scaling

- **Auth Service**: 100 connections (scaled up)
- **Reason**: Auth is the first service (login required)
- **Impact**: Handles high concurrent load from k6 tests
- **Result**: Better performance under load

## Test Status

- **Bottleneck Test**: Running (finding upper limits)
- **Ramp Test**: Running (gradual load increase)
- **Both tests**: Using strict TLS and gRPC health checks

