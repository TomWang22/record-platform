# Service Investigation Findings

**Date:** December 2, 2025  
**Investigation:** Auction Monitor and Social Service Crash Issues

## Executive Summary

After investigating the CrashLoopBackOff issues with Auction Monitor and Social Service, I've identified the root causes and provided recommendations for fixes.

---

## Issues Identified

### 1. Auction Monitor - Health Check Failures

**Status:** ⚠️ CrashLoopBackOff (2 pods)

**Symptoms:**
- Pods start successfully (HTTP server on port 4008, gRPC on 50059)
- Health checks fail with HTTP 503
- Startup probe fails: "HTTP probe failed with statuscode: 503"
- Pods restart repeatedly

**Root Cause:**
The health check endpoint (`/healthz`) queries **both databases**:
1. `listingsPool` (listings DB on port 5435)
2. `auctionPool` (auction-monitor DB on port 5438)

If either database connection fails, the health check returns HTTP 503, causing Kubernetes to restart the pod.

**Code Location:** `services/auction-monitor/src/server.ts:29-38`

```typescript
app.get('/healthz', async (_req, res) => {
  try {
    // Check both databases
    await listingsPool.query('SELECT 1');
    await auctionPool.query('SELECT 1');
    res.json({ ok: true, db: 'connected', listings: 'ok', auction_monitor: 'ok' });
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) });
  }
});
```

**Findings:**
- ✅ Server process is running (`node dist/server.js`)
- ✅ Ports are listening (4008, 50059)
- ⚠️ Health check endpoint returns 503 (database connection issue)
- ✅ Kafka connectivity works (port 9092 via service)
- ⚠️ Database connections may be failing

**Environment Variables:**
- `POSTGRES_URL_LISTINGS`: From ConfigMap
- `POSTGRES_URL_AUCTION_MONITOR`: From ConfigMap
- `KAFKA_BROKER`: `kafka-external.record-platform.svc.cluster.local:9092` ✅

**Recommendations:**
1. **Check database connectivity** - Verify both databases are accessible from pods
2. **Improve health check** - Make health check more resilient (check databases separately, don't fail on one)
3. **Increase startup probe timeout** - Give more time for database connections to establish
4. **Add connection retry logic** - Implement exponential backoff for database connections

### 2. Social Service - Mixed Status

**Status:** ⚠️ 1 Running, 1 CrashLoopBackOff

**Symptoms:**
- One pod running successfully (`social-service-5789584986-lmzgp`)
- One pod crashing repeatedly (`social-service-6c49795587-rbcc9`)
- Readiness probe fails: "HTTP probe failed with statuscode: 503"
- Liveness probe fails, causing restarts

**Root Cause:**
Similar to Auction Monitor - health check queries database and Redis. If either fails, returns 503.

**Code Location:** `services/social-service/src/server.ts:34-47`

```typescript
app.get('/healthz', async (_req: Request, res: Response) => {
  try {
    await pool.query('SELECT 1')
    let r = 'skipped'
    try {
      r = redis ? await redis.ping() : 'disabled'
    } catch {
      r = 'error'
    }
    res.json({ ok: true, db: 'connected', redis: r, cpu_cores: CPU_CORES })
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) })
  }
})
```

**Findings:**
- ✅ One pod running successfully
- ⚠️ One pod crashing due to health check failures
- ⚠️ Health check requires both DB and Redis to be healthy
- ⚠️ Service has NO endpoints (pods not passing health checks)

**Recommendations:**
1. **Check why one pod works and one doesn't** - May be resource constraints or timing
2. **Improve health check resilience** - Don't fail completely if Redis is down
3. **Review pod resource limits** - Ensure both pods have sufficient resources
4. **Check for race conditions** - Database/Redis connection timing

### 3. Kafka Configuration

**Status:** ✅ Working (with minor port note)

**Findings:**
- ✅ Kafka service exists: `kafka-external` (ClusterIP)
- ✅ Service port: 9092 (maps to targetPort 29092)
- ✅ Endpoint: `10.0.0.8:29092` (Docker Compose Kafka)
- ✅ Connectivity test from pod: Port 9092 works ✅
- ⚠️ ConfigMap uses port 9092 (correct, service handles mapping)

**Configuration:**
- **Service:** `kafka-external.record-platform.svc.cluster.local:9092`
- **Actual Kafka:** Docker Compose on `10.0.0.8:29092`
- **Service Mapping:** Port 9092 → TargetPort 29092 ✅

**Note:** The service correctly maps port 9092 (what services use) to targetPort 29092 (actual Kafka port). This is working correctly.

---

## Service Endpoints Status

**Services with NO endpoints (not passing health checks):**
- `auction-monitor` - No endpoints (pods failing health checks)
- `social-service` - No endpoints (one pod running but not passing health check)

**Services with endpoints:**
- `analytics-service` - ✅ `10.244.0.110:50054,10.244.0.110:4004`
- `kafka-external` - ✅ `10.0.0.8:29092`

---

## Database Connectivity

**Auction Monitor Databases:**
- `POSTGRES_URL_LISTINGS`: Should connect to `host.docker.internal:5435`
- `POSTGRES_URL_AUCTION_MONITOR`: Should connect to `host.docker.internal:5438`

**Note:** `host.docker.internal` from Kind cluster routes to local `Postgres.app` instance on macOS, not Docker Compose containers. This is a known limitation.

**Workaround:** Databases and schemas have been created in Postgres.app to match the expected structure.

---

## Health Check Configuration

### Auction Monitor

```yaml
startupProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 15
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 20

readinessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 5
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 10

livenessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 15
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 6
```

**Issue:** Health check fails if either database is unreachable, causing pod restarts.

### Social Service

```yaml
readinessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3

livenessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
```

**Issue:** Health check fails if database is unreachable, causing pod restarts.

---

## Recommendations

### Immediate Actions

1. **Fix Auction Monitor Health Check**
   - Make health check more resilient (check databases separately)
   - Don't return 503 if one database is temporarily unavailable
   - Add connection retry logic with exponential backoff

2. **Fix Social Service Health Check**
   - Similar resilience improvements
   - Don't fail completely if Redis is down (already partially handled)

3. **Verify Database Connectivity**
   - Test database connections from pods
   - Verify `host.docker.internal` routing is working
   - Check if databases exist and are accessible

4. **Increase Startup Probe Timeouts**
   - Give more time for database connections to establish
   - Especially important for dual-database services like Auction Monitor

### Code Changes Needed

#### Auction Monitor Health Check Improvement

```typescript
app.get('/healthz', async (_req, res) => {
  const status = {
    ok: true,
    listings: 'unknown',
    auction_monitor: 'unknown',
    timestamp: new Date().toISOString()
  };
  
  // Check listings DB (non-blocking)
  try {
    await listingsPool.query('SELECT 1');
    status.listings = 'ok';
  } catch (err) {
    status.listings = 'error';
    status.ok = false;
    console.error('[auction-monitor] listings DB check failed:', err);
  }
  
  // Check auction-monitor DB (non-blocking)
  try {
    await auctionPool.query('SELECT 1');
    status.auction_monitor = 'ok';
  } catch (err) {
    status.auction_monitor = 'error';
    status.ok = false;
    console.error('[auction-monitor] auction-monitor DB check failed:', err);
  }
  
  // Return 200 if at least one DB is working, 503 only if both fail
  const httpStatus = status.ok ? 200 : 503;
  res.status(httpStatus).json(status);
});
```

#### Social Service Health Check Improvement

```typescript
app.get('/healthz', async (_req: Request, res: Response) => {
  const status = {
    ok: true,
    db: 'unknown',
    redis: 'unknown',
    cpu_cores: CPU_CORES,
    timestamp: new Date().toISOString()
  };
  
  // Check database (critical)
  try {
    await pool.query('SELECT 1');
    status.db = 'connected';
  } catch (err) {
    status.db = 'disconnected';
    status.ok = false;
    console.error('[social] DB check failed:', err);
  }
  
  // Check Redis (non-critical)
  try {
    status.redis = redis ? await redis.ping() : 'disabled';
  } catch (err) {
    status.redis = 'error';
    // Don't fail health check if Redis is down (non-critical)
    console.warn('[social] Redis check failed:', err);
  }
  
  const httpStatus = status.ok ? 200 : 503;
  res.status(httpStatus).json(status);
});
```

### Configuration Changes

1. **Increase Startup Probe Timeouts**
   - Auction Monitor: `initialDelaySeconds: 30` (from 15)
   - Social Service: `initialDelaySeconds: 20` (from 10)

2. **Add Database Connection Retry Logic**
   - Implement exponential backoff in service startup
   - Don't start HTTP server until databases are connected
   - Add connection pool configuration with retries

3. **Review Resource Limits**
   - Ensure pods have sufficient CPU/memory
   - Check if resource constraints are causing failures

---

## Testing Recommendations

1. **Test Database Connectivity**
   ```bash
   kubectl exec -n record-platform <auction-monitor-pod> -- \
     sh -c "nc -zv host.docker.internal 5435 && nc -zv host.docker.internal 5438"
   ```

2. **Test Health Endpoint Manually**
   ```bash
   kubectl port-forward -n record-platform <auction-monitor-pod> 4008:4008
   curl http://localhost:4008/healthz
   ```

3. **Check Database Connections from Pod**
   ```bash
   kubectl exec -n record-platform <auction-monitor-pod> -- \
     env | grep POSTGRES_URL
   ```

4. **Monitor Pod Logs**
   ```bash
   kubectl logs -n record-platform -l app=auction-monitor --tail=100 -f
   ```

---

## Related Issues

1. **host.docker.internal Routing**
   - Kind cluster routes to local Postgres.app, not Docker Compose
   - Workaround: Created databases in Postgres.app
   - Long-term: Use Kubernetes Services for Postgres

2. **Dual-Database Architecture**
   - Auction Monitor uses two databases (listings + auction-monitor)
   - Both must be healthy for service to work
   - Consider making one optional or adding fallback logic

3. **Health Check Design**
   - Current design: All dependencies must be healthy
   - Better design: Degraded mode if non-critical dependencies fail
   - Critical dependencies (DB) should still cause 503

---

## Next Steps

1. ✅ **Investigation Complete** - Root causes identified
2. ⏳ **Code Changes** - Implement resilient health checks
3. ⏳ **Configuration Updates** - Increase timeouts, add retries
4. ⏳ **Testing** - Verify fixes work
5. ⏳ **Deployment** - Roll out fixes

---

**Last Updated:** December 2, 2025  
**Status:** Investigation Complete, Awaiting Fixes

