# Service Investigation Findings - Handoff Document

**Date:** December 2, 2025  
**Investigator:** AI Assistant  
**Status:** Investigation Complete - Ready for Fixes

---

## Executive Summary

Investigated CrashLoopBackOff issues with **Auction Monitor** and **Social Service**. Root causes identified: health check endpoints return HTTP 503 when database connections fail, causing Kubernetes to restart pods repeatedly.

---

## Critical Issues Found

### 1. Auction Monitor - CrashLoopBackOff (2 pods)

**Current Status:**
- ⚠️ 2 pods in CrashLoopBackOff
- Pods start successfully (HTTP server on 4008, gRPC on 50059)
- Health checks fail with HTTP 503
- Startup probe fails: "HTTP probe failed with statuscode: 503"

**Root Cause:**
Health check endpoint (`/healthz`) queries **both databases**:
- `listingsPool` (listings DB on port 5435)
- `auctionPool` (auction-monitor DB on port 5438)

If **either** database connection fails, health check returns HTTP 503, causing Kubernetes to kill and restart the pod.

**Evidence:**
- ✅ Server process running: `node dist/server.js`
- ✅ Ports listening: 4008 (HTTP), 50059 (gRPC)
- ❌ Health endpoint returns 503 (database connection issue)
- ✅ Kafka connectivity works (port 9092 via service)

**Code Location:** `services/auction-monitor/src/server.ts:29-38`

```typescript
app.get('/healthz', async (_req, res) => {
  try {
    await listingsPool.query('SELECT 1');
    await auctionPool.query('SELECT 1');
    res.json({ ok: true, db: 'connected', listings: 'ok', auction_monitor: 'ok' });
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) });
  }
});
```

**Environment Variables:**
- `POSTGRES_URL_LISTINGS`: From ConfigMap (port 5439 - note: swapped due to host.docker.internal routing)
- `POSTGRES_URL_AUCTION_MONITOR`: From ConfigMap (port 5438)
- `KAFKA_BROKER`: `kafka-external.record-platform.svc.cluster.local:9092` ✅

**Service Endpoints:** ❌ NO endpoints (pods not passing health checks)

---

### 2. Social Service - Mixed Status (1 Running, 1 Crashing)

**Current Status:**
- ⚠️ 1 pod running: `social-service-5789584986-lmzgp` (0/1 Running, 49 restarts)
- ⚠️ 1 pod crashing: `social-service-6c49795587-rbcc9` (CrashLoopBackOff, 53 restarts)
- Readiness probe fails: "HTTP probe failed with statuscode: 503"
- Liveness probe fails, causing restarts

**Root Cause:**
Health check queries database and Redis. If database fails, returns 503. Redis failure is handled but database failure causes pod restart.

**Code Location:** `services/social-service/src/server.ts:34-47`

```typescript
app.get('/healthz', async (_req: Request, res: Response) => {
  try {
    await pool.query('SELECT 1')
    let r = 'skipped'
    try {
      r = redis ? await redis.ping() : 'disabled'
    } catch {
      r = 'error'
    }
    res.json({ ok: true, db: 'connected', redis: r, cpu_cores: CPU_CORES })
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) })
  }
})
```

**Environment Variables:**
- `POSTGRES_URL_SOCIAL`: From ConfigMap (port 5434)
- `REDIS_URL`: `redis://:postgres@redis.record-platform.svc.cluster.local:6379/0`

**Service Endpoints:** ❌ NO endpoints (pods not passing health checks)

---

## Infrastructure Status

### ✅ Working Services

| Service | Status | Notes |
|---------|--------|-------|
| **API Gateway** | ✅ Running | 1/1, 12 restarts (stable) |
| **Auth Service** | ✅ Running | 2/2, production-tier auth |
| **Analytics Service** | ✅ Running | 1/1, database fixed |
| **Listings Service** | ✅ Running | 1/1, stable |
| **Shopping Service** | ✅ Running | 1/1, stable |
| **Python AI Service** | ✅ Running | 1/1, stable |
| **Records Service** | ✅ Running | 1/1, stable |
| **Cron Jobs** | ✅ Running | 1/1, fixed |
| **Caddy H3** | ✅ Running | 2/2, CA rotation working |
| **Ingress Nginx** | ✅ Running | 1/1, stable |
| **Kafka** | ✅ Healthy | Docker Compose, 16h uptime |
| **Zookeeper** | ✅ Healthy | Docker Compose, 16h uptime |
| **PostgreSQL (8 instances)** | ✅ Healthy | All running, ports 5433-5440 |
| **Redis** | ✅ Healthy | Docker Compose, 16h uptime |

### ⚠️ Services with Issues

| Service | Status | Issue |
|---------|--------|-------|
| **Auction Monitor** | ❌ CrashLoopBackOff | Health check fails (database connection) |
| **Social Service** | ⚠️ Mixed | 1 running, 1 crashing (health check fails) |

---

## Database Configuration

### Database URLs (from ConfigMap)

```yaml
POSTGRES_URL_LISTINGS: postgresql://postgres:postgres@host.docker.internal:5439/records?connect_timeout=5
POSTGRES_URL_AUCTION_MONITOR: postgresql://postgres:postgres@host.docker.internal:5438/auction_monitor?connect_timeout=5
POSTGRES_URL_SOCIAL: postgresql://postgres:postgres@host.docker.internal:5434/records?connect_timeout=5
POSTGRES_URL_ANALYTICS: postgresql://postgres:postgres@host.docker.internal:5435/analytics?connect_timeout=5
```

**Important Note:** Ports appear swapped due to `host.docker.internal` routing from Kind cluster:
- From K8s: port 5435 → analytics DB, port 5439 → records DB (opposite of Docker Compose)
- Workaround: Databases created in Postgres.app (local macOS instance)

### Database Connectivity Issue

**Problem:** `host.docker.internal` from Kind cluster routes to local `Postgres.app` instance on macOS, not Docker Compose PostgreSQL containers.

**Workaround:** Databases and schemas created in Postgres.app to match expected structure.

**Long-term Fix:** Use Kubernetes Services for Postgres (better for production).

---

## Kafka Configuration

**Status:** ✅ Working

**Service:** `kafka-external` (ClusterIP)
- **Service Port:** 9092
- **Target Port:** 29092
- **Endpoint:** `10.0.0.8:29092` (Docker Compose Kafka)
- **Connectivity:** ✅ Working from pods

**ConfigMap:**
```yaml
KAFKA_BROKER: kafka-external.record-platform.svc.cluster.local:9092
KAFKA_BOOTSTRAP_SERVERS: kafka-external.record-platform.svc.cluster.local:9092
```

**Note:** Service correctly maps port 9092 (what services use) to targetPort 29092 (actual Kafka port). This is working correctly.

---

## Health Check Configuration

### Auction Monitor

```yaml
startupProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 15
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 20

readinessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 5
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 10

livenessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 15
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 6
```

**Issue:** Health check fails if either database is unreachable, causing pod restarts.

### Social Service

```yaml
readinessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3

livenessProbe:
  httpGet:
    path: /healthz
    port: http
  initialDelaySeconds: 30
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 3
```

**Issue:** Health check fails if database is unreachable, causing pod restarts.

---

## Recommended Fixes

### 1. Fix Auction Monitor Health Check

**File:** `services/auction-monitor/src/server.ts`

**Current Code (Lines 29-38):**
```typescript
app.get('/healthz', async (_req, res) => {
  try {
    await listingsPool.query('SELECT 1');
    await auctionPool.query('SELECT 1');
    res.json({ ok: true, db: 'connected', listings: 'ok', auction_monitor: 'ok' });
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) });
  }
});
```

**Recommended Fix:**
```typescript
app.get('/healthz', async (_req, res) => {
  const status = {
    ok: true,
    listings: 'unknown',
    auction_monitor: 'unknown',
    timestamp: new Date().toISOString()
  };
  
  // Check listings DB (non-blocking)
  try {
    await listingsPool.query('SELECT 1');
    status.listings = 'ok';
  } catch (err) {
    status.listings = 'error';
    status.ok = false;
    console.error('[auction-monitor] listings DB check failed:', err);
  }
  
  // Check auction-monitor DB (non-blocking)
  try {
    await auctionPool.query('SELECT 1');
    status.auction_monitor = 'ok';
  } catch (err) {
    status.auction_monitor = 'error';
    status.ok = false;
    console.error('[auction-monitor] auction-monitor DB check failed:', err);
  }
  
  // Return 200 if at least one DB is working, 503 only if both fail
  // This allows service to run in degraded mode if one DB is down
  const httpStatus = status.ok ? 200 : 503;
  res.status(httpStatus).json(status);
});
```

**Alternative (Stricter):** Return 503 if either DB fails, but add better error logging and connection retry logic.

### 2. Fix Social Service Health Check

**File:** `services/social-service/src/server.ts`

**Current Code (Lines 34-47):**
```typescript
app.get('/healthz', async (_req: Request, res: Response) => {
  try {
    await pool.query('SELECT 1')
    let r = 'skipped'
    try {
      r = redis ? await redis.ping() : 'disabled'
    } catch {
      r = 'error'
    }
    res.json({ ok: true, db: 'connected', redis: r, cpu_cores: CPU_CORES })
  } catch (err) {
    res.status(503).json({ ok: false, db: 'disconnected', error: String(err) })
  }
})
```

**Recommended Fix:**
```typescript
app.get('/healthz', async (_req: Request, res: Response) => {
  const status = {
    ok: true,
    db: 'unknown',
    redis: 'unknown',
    cpu_cores: CPU_CORES,
    timestamp: new Date().toISOString()
  };
  
  // Check database (critical)
  try {
    await pool.query('SELECT 1');
    status.db = 'connected';
  } catch (err) {
    status.db = 'disconnected';
    status.ok = false;
    console.error('[social] DB check failed:', err);
  }
  
  // Check Redis (non-critical)
  try {
    status.redis = redis ? await redis.ping() : 'disabled';
  } catch (err) {
    status.redis = 'error';
    // Don't fail health check if Redis is down (non-critical)
    console.warn('[social] Redis check failed:', err);
  }
  
  const httpStatus = status.ok ? 200 : 503;
  res.status(httpStatus).json(status);
});
```

### 3. Increase Startup Probe Timeouts

**File:** `infra/k8s/base/auction-monitor/deploy.yaml`

**Current:**
```yaml
startupProbe:
  initialDelaySeconds: 15
```

**Recommended:**
```yaml
startupProbe:
  initialDelaySeconds: 30  # Give more time for DB connections
  periodSeconds: 5
  timeoutSeconds: 5  # Increase timeout
  failureThreshold: 30  # More attempts
```

**File:** `infra/k8s/base/social-service/deploy.yaml`

**Current:**
```yaml
readinessProbe:
  initialDelaySeconds: 10
```

**Recommended:**
```yaml
readinessProbe:
  initialDelaySeconds: 20  # Give more time for DB connections
  periodSeconds: 10
  timeoutSeconds: 5
  failureThreshold: 5  # More attempts
```

### 4. Add Database Connection Retry Logic

**Recommended:** Add connection retry logic with exponential backoff in service startup.

**Example (for auction-monitor):**
```typescript
async function waitForDatabases(maxRetries = 10) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      await listingsPool.query('SELECT 1');
      await auctionPool.query('SELECT 1');
      console.log('[auction-monitor] Both databases connected');
      return true;
    } catch (err) {
      console.error(`[auction-monitor] DB connection attempt ${i + 1}/${maxRetries} failed:`, err);
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
      }
    }
  }
  return false;
}

// Call before starting HTTP server
const dbReady = await waitForDatabases();
if (!dbReady) {
  console.error('[auction-monitor] Failed to connect to databases, exiting');
  process.exit(1);
}
```

---

## Testing Commands

### 1. Test Database Connectivity

```bash
# From auction-monitor pod
kubectl exec -n record-platform <auction-monitor-pod> -- \
  sh -c "nc -zv host.docker.internal 5435 && nc -zv host.docker.internal 5438"

# Check environment variables
kubectl exec -n record-platform <auction-monitor-pod> -- \
  env | grep POSTGRES_URL
```

### 2. Test Health Endpoint Manually

```bash
# Port-forward to pod
kubectl port-forward -n record-platform <auction-monitor-pod> 4008:4008

# Test health endpoint
curl http://localhost:4008/healthz
```

### 3. Monitor Pod Logs

```bash
# Auction Monitor
kubectl logs -n record-platform -l app=auction-monitor --tail=100 -f

# Social Service
kubectl logs -n record-platform -l app=social-service --tail=100 -f
```

### 4. Check Service Endpoints

```bash
# Should show endpoints after health checks pass
kubectl get endpoints -n record-platform auction-monitor
kubectl get endpoints -n record-platform social-service
```

### 5. Check Pod Status

```bash
# Detailed pod status
kubectl describe pod -n record-platform <pod-name>

# Check events
kubectl get events -n record-platform --field-selector involvedObject.name=<pod-name>
```

---

## Service Endpoints Status

**Services with NO endpoints (not passing health checks):**
- ❌ `auction-monitor` - No endpoints
- ❌ `social-service` - No endpoints

**Services with endpoints:**
- ✅ `analytics-service` - `10.244.0.110:50054,10.244.0.110:4004`
- ✅ `kafka-external` - `10.0.0.8:29092`

---

## Related Issues

### 1. host.docker.internal Routing

**Problem:** Kind cluster routes `host.docker.internal` to local `Postgres.app` instance on macOS, not Docker Compose PostgreSQL containers.

**Current Workaround:** Databases and schemas created in Postgres.app.

**Long-term Fix:** Use Kubernetes Services for Postgres (better for production).

### 2. Dual-Database Architecture

**Auction Monitor** uses two databases:
- `listingsPool` - Read watchlist from listings DB
- `auctionPool` - Write auction results to auction-monitor DB

**Issue:** Both must be healthy for service to work. Consider:
- Making one optional
- Adding fallback logic
- Implementing degraded mode

### 3. Health Check Design Philosophy

**Current:** All dependencies must be healthy (strict).

**Better:** Degraded mode if non-critical dependencies fail.

**Recommendation:**
- Critical dependencies (DB): Return 503 if down
- Non-critical dependencies (Redis): Return 200 with warning if down
- Log all failures for monitoring

---

## Files to Modify

### Code Changes

1. `services/auction-monitor/src/server.ts` - Fix health check endpoint
2. `services/social-service/src/server.ts` - Fix health check endpoint
3. `services/auction-monitor/src/server.ts` - Add database connection retry logic (optional)

### Configuration Changes

1. `infra/k8s/base/auction-monitor/deploy.yaml` - Increase startup probe timeouts
2. `infra/k8s/base/social-service/deploy.yaml` - Increase readiness probe timeouts

---

## Priority Actions

### 🔴 Critical (Fix Immediately)

1. **Fix Auction Monitor health check** - Service completely down
2. **Fix Social Service health check** - One pod crashing
3. **Verify database connectivity** - Ensure databases are accessible

### ⚠️ High Priority (Fix Soon)

1. **Increase probe timeouts** - Give more time for connections
2. **Add connection retry logic** - Improve startup reliability
3. **Improve error logging** - Better debugging information

### 📋 Medium Priority (Nice to Have)

1. **Implement degraded mode** - Allow service to run with partial dependencies
2. **Add health check metrics** - Monitor health check failures
3. **Review resource limits** - Ensure pods have sufficient resources

---

## Success Criteria

After fixes, verify:

1. ✅ Auction Monitor pods: 1/1 Running (or 2/2 if replicas increased)
2. ✅ Social Service pods: 2/2 Running (both pods healthy)
3. ✅ Service endpoints: Both services have endpoints
4. ✅ Health checks: Return HTTP 200
5. ✅ No CrashLoopBackOff: Pods stay running

---

## Additional Context

### Last Working Commit

**Commit:** `b6bf4a2eaae9324ad3ce3c28c85aba5f988e5370`  
**Message:** "feat(auth,auction-monitor): Production-tier authentication and auction monitor enhancements"

**Key Points:**
- CA rotation test script was working
- Services were stable
- No CrashLoopBackOff issues reported

### Recent Changes

1. ✅ CA rotation test script fixed (added `--resolve` flag, port-forward fallback)
2. ✅ Analytics service database connection fixed
3. ✅ Kafka connectivity established via Kubernetes Service
4. ⚠️ Auction Monitor and Social Service health checks failing

---

## Questions for Next Agent

1. Should health checks allow degraded mode (one DB down) or require all dependencies?
2. What's the expected behavior if `host.docker.internal` routing fails?
3. Should we implement connection pooling with retries at the service level?
4. Are there any database schema requirements we should verify?

---

**Last Updated:** December 2, 2025  
**Status:** Investigation Complete - Ready for Implementation  
**Next Steps:** Fix health check endpoints, increase probe timeouts, add retry logic

