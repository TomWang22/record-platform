# k6 Shopping Service Daily CronJob

## Overview

This CronJob runs daily k6 load tests on the shopping service to monitor performance and find the upper bound of concurrent users. The test runs automatically every day at 2:00 AM (America/New_York timezone).

## Features

- **Automatic Cleanup**: Pods and jobs are automatically deleted after 1 hour (`ttlSecondsAfterFinished: 3600`)
- **No Overlap**: Uses `concurrencyPolicy: Forbid` to prevent multiple runs
- **History Retention**: Keeps last 7 successful runs and 3 failed runs
- **Separate Results**: Results are saved in `scripts/load/results/shopping-ramp/` to avoid confusion
- **Database Ready**: Configured to use `postgres-shopping-1` on port 5436

## Setup

### 1. Create ConfigMap with Test Script

```bash
# Create namespace if needed
kubectl create ns k6-load

# Create ConfigMap with the k6 test script
kubectl -n k6-load create configmap k6-shopping-script \
  --from-file=k6-shopping-ramp.js=scripts/load/k6-shopping-ramp.js \
  --dry-run=client -o yaml | kubectl apply -f -
```

### 2. Apply CronJob

```bash
# Option 1: Use the setup script
bash scripts/setup-k6-shopping-cronjob.sh

# Option 2: Apply manually
kubectl apply -f infra/k8s/base/cron-jobs/k6-shopping-daily.yaml
```

## Configuration

The CronJob is configured with:

- **Schedule**: `0 2 * * *` (2:00 AM daily)
- **Timezone**: `America/New_York`
- **Test Type**: Ramp test (progressive load increase to 500 VUs)
- **Auto-cleanup**: Jobs and pods deleted after 1 hour
- **Database**: Uses `postgres-shopping-1:5436/records`

## Monitoring

### View CronJob Status

```bash
kubectl -n k6-load get cronjob k6-shopping-daily
```

### View Recent Jobs

```bash
kubectl -n k6-load get jobs -l app=k6-shopping-test
```

### View Job Logs

```bash
# Get latest job name
JOB=$(kubectl -n k6-load get jobs -l app=k6-shopping-test --sort-by=.metadata.creationTimestamp -o jsonpath='{.items[-1].metadata.name}')

# View logs
kubectl -n k6-load logs -l job-name=$JOB --tail=100
```

### View Test Results

Results are saved in the pod's `/results` directory. To retrieve:

```bash
# Get pod name
POD=$(kubectl -n k6-load get pods -l app=k6-shopping-test --sort-by=.metadata.creationTimestamp -o jsonpath='{.items[-1].metadata.name}')

# Copy results (before pod is deleted)
kubectl -n k6-load cp "${POD}:/results/final-summary.json" /tmp/shopping-test-summary.json
kubectl -n k6-load cp "${POD}:/results/output.txt" /tmp/shopping-test-output.txt
```

## Manual Test Run

To run the test manually (outside of CronJob schedule):

```bash
# Run the daily test script
bash scripts/run-k6-shopping-daily.sh

# Or run specific test type
TEST_TYPE=stress bash scripts/run-k6-shopping-daily.sh
TEST_TYPE=db-validation bash scripts/run-k6-shopping-daily.sh
```

## Cleanup

The CronJob automatically cleans up:
- **Jobs**: Deleted after 1 hour (`ttlSecondsAfterFinished: 3600`)
- **Pods**: Deleted with the job
- **Old Jobs**: Only last 7 successful and 3 failed jobs are kept

To manually clean up:

```bash
# Delete all completed jobs
kubectl -n k6-load delete jobs -l app=k6-shopping-test --field-selector status.successful=1

# Delete all failed jobs
kubectl -n k6-load delete jobs -l app=k6-shopping-test --field-selector status.failed=1

# Delete CronJob
kubectl -n k6-load delete cronjob k6-shopping-daily
```

## Customization

### Change Schedule

Edit `infra/k8s/base/cron-jobs/k6-shopping-daily.yaml`:

```yaml
spec:
  schedule: "0 3 * * *"  # Change to 3:00 AM
  timeZone: America/New_York
```

### Change Test Type

The CronJob currently runs the ramp test. To change:

1. Update the ConfigMap to include a different script
2. Update the CronJob args to use a different script file

### Update Test Script

When updating the test script:

```bash
# Update ConfigMap
kubectl -n k6-load create configmap k6-shopping-script \
  --from-file=k6-shopping-ramp.js=scripts/load/k6-shopping-ramp.js \
  --dry-run=client -o yaml | kubectl apply -f -

# Restart CronJob (optional - will use new script on next run)
kubectl -n k6-load delete cronjob k6-shopping-daily
kubectl apply -f infra/k8s/base/cron-jobs/k6-shopping-daily.yaml
```

## Troubleshooting

### CronJob Not Running

1. Check CronJob status:
   ```bash
   kubectl -n k6-load describe cronjob k6-shopping-daily
   ```

2. Check for schedule issues:
   ```bash
   kubectl -n k6-load get cronjob k6-shopping-daily -o yaml | grep -A 5 schedule
   ```

3. Check if previous job is still running:
   ```bash
   kubectl -n k6-load get jobs -l app=k6-shopping-test
   ```

### Pod Fails to Start

1. Check pod events:
   ```bash
   kubectl -n k6-load describe pod <pod-name>
   ```

2. Check ConfigMap exists:
   ```bash
   kubectl -n k6-load get configmap k6-shopping-script
   ```

3. Verify test script in ConfigMap:
   ```bash
   kubectl -n k6-load get configmap k6-shopping-script -o jsonpath='{.data.k6-shopping-ramp\.js}' | head -20
   ```

### Test Fails

1. Check job logs:
   ```bash
   kubectl -n k6-load logs -l app=k6-shopping-test --tail=200
   ```

2. Verify database connectivity:
   ```bash
   kubectl -n k6-load run test-db -it --rm --image=postgres:16 -- \
     psql -h postgres-shopping-1 -p 5436 -U postgres -d records -c "SELECT 1"
   ```

3. Verify service URLs:
   ```bash
   kubectl -n k6-load run test-curl -it --rm --image=curlimages/curl -- \
     curl -k https://caddy-h3.ingress-nginx.svc.cluster.local:443/_caddy/healthz
   ```

## Results Location

Test results are stored in:
- **Directory**: `scripts/load/results/shopping-ramp/`
- **Format**: `shopping-ramp-YYYYMMDD-HHMMSS.{json,txt,html}`
- **Graphs**: Automatically generated latency graphs in HTML format

## Notes

- The CronJob uses `--insecure-skip-tls-verify` for in-cluster testing
- Database connection uses the external `postgres-shopping-1` container
- Results are organized in separate folders per test type to avoid confusion
- Pods are automatically cleaned up after 1 hour to save resources

