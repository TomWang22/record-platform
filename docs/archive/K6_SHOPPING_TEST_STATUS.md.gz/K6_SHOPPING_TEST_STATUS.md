# Shopping Service k6 Load Test Status

## Current Status

**Test Running**: k6-shopping-ramp-1765149041
- **Job Name**: `k6-shopping-ramp-1765149041`
- **Namespace**: `k6-load`
- **Last Known Progress**: 264 VUs (34% complete)
- **Total Duration**: ~26 minutes
- **Target**: Ramp up to 500 VUs to find upper bound

## Test Configuration

- **Test Type**: Ramp-up (progressive load increase)
- **Stages**:
  - 30s: 10 VUs (warm-up)
  - 1m: 50 VUs
  - 2m: 100 VUs
  - 3m: 200 VUs
  - 4m: 300 VUs
  - 5m: 400 VUs
  - 6m: 500 VUs
  - 3m: Hold at 500 VUs
  - 2m: Ramp down

## Results Location

Results will be saved to:
- **Directory**: `scripts/load/results/shopping-shopping-ramp/`
- **Summary JSON**: `shopping-ramp-1765149041.json`
- **Output Log**: `shopping-ramp-1765149041.txt`
- **Latency Graph**: `shopping-ramp-1765149041-latency.html`

## Retrieving Results

When the test completes, run:

```bash
# Option 1: Use the retrieval script
bash scripts/wait-and-retrieve-k6-results.sh k6-shopping-ramp-1765149041 1765149041 shopping-ramp

# Option 2: Manual retrieval
POD=$(kubectl -n k6-load get pods -l job-name=k6-shopping-ramp-1765149041 -o jsonpath='{.items[0].metadata.name}')
kubectl -n k6-load cp "${POD}:/results/final-summary.json" scripts/load/results/shopping-shopping-ramp/shopping-ramp-1765149041.json
kubectl -n k6-load cp "${POD}:/results/output.txt" scripts/load/results/shopping-shopping-ramp/shopping-ramp-1765149041.txt

# Generate graph
python3 scripts/load/generate-latency-graph.py \
  scripts/load/results/shopping-shopping-ramp/shopping-ramp-1765149041.json \
  scripts/load/results/shopping-shopping-ramp/shopping-ramp-1765149041-latency.html
```

## Cleanup

The test script includes automatic cleanup via trap. To manually clean up:

```bash
kubectl -n k6-load delete job k6-shopping-ramp-1765149041
kubectl -n k6-load delete pod -l job-name=k6-shopping-ramp-1765149041
```

## Notes

- Test uses `--insecure-skip-tls-verify` for in-cluster testing
- Results are organized in separate folders per test type to avoid confusion
- Latency graphs are generated automatically when summary JSON is available

