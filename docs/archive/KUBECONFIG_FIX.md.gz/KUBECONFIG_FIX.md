# Kubeconfig Fix for TLS Handshake Timeouts

## Issue
The `~/.kube/config` file had incomplete configuration:
- `contexts: null`
- `users: null`
- This caused TLS handshake timeouts when trying to connect to the cluster

## Solution
The kubeconfig was regenerated from the Kind cluster:
```bash
kind get kubeconfig --name h3 > ~/.kube/config
```

## Prevention
If TLS timeouts occur again, regenerate the kubeconfig:
```bash
# Backup current config
cp ~/.kube/config ~/.kube/config.backup.$(date +%Y%m%d-%H%M%S)

# Get fresh kubeconfig from Kind
kind get kubeconfig --name h3 > ~/.kube/config

# Verify
kubectl cluster-info
```

## Root Cause
The kubeconfig file can become corrupted or incomplete, especially after:
- Kind cluster restarts
- Docker Desktop restarts
- Network configuration changes
- Manual edits to the kubeconfig file

## Verification
After fixing, verify cluster connectivity:
```bash
kubectl cluster-info
kubectl get nodes
kubectl get pods -A
```

