# Linkerd Observability Setup

## Current Status
- Linkerd is currently **disabled** at the namespace level to prevent 502 errors
- Linkerd control plane is running but proxies can't resolve control plane services
- This is a DNS resolution issue, not a fundamental Linkerd problem

## To Re-enable Linkerd for Observability

### Option 1: Fix DNS Resolution (Recommended)
1. Check CoreDNS health:
   ```bash
   kubectl -n kube-system get pods -l k8s-app=kube-dns
   kubectl -n kube-system logs -l k8s-app=kube-dns --tail=50
   ```

2. Restart CoreDNS if needed:
   ```bash
   kubectl -n kube-system rollout restart deployment/coredns
   ```

3. Re-enable Linkerd injection:
   ```bash
   kubectl -n record-platform annotate namespace record-platform linkerd.io/inject=enabled --overwrite
   kubectl -n record-platform rollout restart deployment/api-gateway deployment/social-service deployment/listings-service deployment/auth-service deployment/shopping-service
   ```

### Option 2: Use Linkerd Without Policy Controller (If DNS Issues Persist)
The policy controller is optional. You can configure Linkerd to work without it by:
1. Ensuring `linkerd-policy` service points to a working endpoint
2. Or configuring proxies to not require policy controller

### Option 3: Use Linkerd Only for Specific Services
Enable Linkerd only for services that need observability:
```bash
# Enable for specific deployments only
kubectl -n record-platform annotate deployment api-gateway linkerd.io/inject=enabled --overwrite
kubectl -n record-platform annotate deployment social-service linkerd.io/inject=enabled --overwrite
# Keep others disabled
```

## Verification
After re-enabling, verify Linkerd is working:
```bash
# Check proxy status
kubectl -n record-platform get pods -o wide | grep -E "api-gateway|social-service"

# Check Linkerd dashboard (if installed)
linkerd viz dashboard

# Check metrics
kubectl -n record-platform port-forward svc/api-gateway 4000:4000
curl http://localhost:4000/metrics | grep linkerd
```

## Current Workaround
For now, services run without Linkerd to ensure functionality. Observability features (tracing, metrics, mTLS) are disabled but services are stable.

