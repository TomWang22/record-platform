# macOS NodePort Permanent Solution

## Problem

NodePort 30443 has TLS handshake issues on macOS with Kind clusters. The TLS connection fails with errors like:
- `TLS connect error: error:0A000126:SSL routines::unexpected eof while reading`
- `Connection reset`

This is a known limitation of how Kind proxies NodePort traffic on macOS.

## Solution

Similar to how `scripts/lib/http3.sh` bypasses macOS/Docker UDP QUIC limitations by using the Kind node's network namespace, we've created `scripts/lib/nodeport.sh` to bypass TLS handshake issues.

### How It Works

The solution uses Docker's `--network container:` feature to run curl inside the Kind control-plane node's network namespace. This allows:

1. **Direct network access**: Bypasses macOS/Kind TLS forwarding issues
2. **No port-forward needed**: Works directly with NodePort
3. **Automatic fallback**: Tries direct connection first, falls back to Docker if TLS fails

### Implementation

**File**: `scripts/lib/nodeport.sh`

Key features:
- Detects Kind node automatically
- Pre-pulls curl image for faster execution
- Rewrites URLs to use `127.0.0.1:30443` inside the node
- Removes `--resolve` flags (not needed inside node)
- Filters Docker pull messages from output

### Usage

The helper is automatically loaded in `scripts/test-full-chain-with-rotation.sh`:

```bash
# Source the library
. "$SCRIPT_DIR/lib/nodeport.sh"

# Use nodeport_curl instead of regular curl
nodeport_curl -k -sS --http2 \
  --resolve "$HOST:${PORT}:127.0.0.1" \
  -H "Host: $HOST" "https://$HOST:${PORT}/_caddy/healthz"
```

The function automatically:
1. Tries direct connection first (fast path)
2. Detects TLS errors
3. Falls back to Docker container network if needed

### Environment Variables

- `NODEPORT_KIND_NODE`: Override Kind node name (auto-detected if not set)
- `NODEPORT_KIND_CLUSTER`: Override cluster name (default: `h3`)
- `NODEPORT_IMAGE`: Override curl image (default: `curlimages/curl:latest`)
- `NODEPORT_PORT`: Override port (default: `30443`)

### Integration

The test script has been updated to use the library function:

```bash
# Old (inline function)
nodeport_curl() { ... }

# New (library function)
. "$SCRIPT_DIR/lib/nodeport.sh"
# nodeport_curl is now available from library
```

### Benefits

1. **Permanent solution**: Works reliably on macOS without workarounds
2. **No port-forward needed**: Uses NodePort directly
3. **Automatic fallback**: Tries fast path first, falls back if needed
4. **Consistent with HTTP/3**: Uses same pattern as `http3.sh`
5. **Reusable**: Can be used in any script that needs NodePort access

### Testing

Test the solution:

```bash
# Test direct connection (should work or fallback automatically)
./scripts/test-full-chain-with-rotation.sh

# Or test manually
source scripts/lib/nodeport.sh
nodeport_curl -k -sS --http2 \
  --resolve "record.local:30443:127.0.0.1" \
  -H "Host: record.local" \
  "https://record.local:30443/_caddy/healthz"
```

### Comparison with HTTP/3 Solution

| Feature | HTTP/3 (`http3.sh`) | NodePort (`nodeport.sh`) |
|---------|---------------------|--------------------------|
| **Purpose** | Bypass UDP/QUIC limitations | Bypass TLS handshake issues |
| **Method** | Docker container network | Docker container network |
| **Protocol** | HTTP/3 (QUIC) | HTTP/2 (TLS) |
| **Port** | 443 (UDP) | 30443 (TCP) |
| **Image** | `alpine/curl-http3` | `curlimages/curl` |

Both use the same pattern: run curl inside the Kind node's network namespace to bypass macOS limitations.

## Python AI Database Setup

### Database Configuration

The Python AI service uses PostgreSQL for:
- **Prediction cache**: Store AI predictions to avoid redundant API calls
- **Inference logging**: Track all AI inferences for analytics
- **Analytics cache**: Cache enriched data from analytics service
- **Event logging**: Store events for audit and replay
- **Model metrics**: Track AI model performance

### Database: `python_ai`

**Connection**: `postgresql://postgres:postgres@host.docker.internal:5440/python_ai`

**Schema**: `ai`

**Tables**:
- `ai.predictions` - Prediction cache with TTL
- `ai.inference_log` - Inference tracking
- `ai.analytics_cache` - Analytics data cache
- `ai.events` - Event log
- `ai.model_metrics` - Model performance metrics

### Initialization

Run the initialization script:

```bash
./scripts/init-python-ai-db.sh
```

This will:
1. Create the `python_ai` database if it doesn't exist
2. Apply the schema from `infra/db/python-ai-schema.sql`
3. Create all tables, indexes, and functions

### Database Functions

- `ai.get_prediction()` - Get cached prediction
- `ai.store_prediction()` - Store prediction in cache
- `ai.cleanup_expired_cache()` - Clean up expired entries

### Integration with Python AI Service

The service automatically:
- Uses database cache as fallback if Redis is unavailable
- Logs all inferences to database
- Stores analytics data in database cache
- Tracks events for audit

**File**: `services/python-ai-service/app/db.py`

### Configuration

The database URL is configured in `infra/k8s/base/config/app-config.yaml`:

```yaml
POSTGRES_URL_PYTHON_AI: postgresql://postgres:postgres@host.docker.internal:5440/python_ai?connect_timeout=5
```

### Benefits

1. **Persistent cache**: Survives Redis restarts
2. **Analytics**: Track all AI inferences
3. **Performance**: Reduce redundant API calls
4. **Audit trail**: Complete event log
5. **Model improvement**: Track metrics for ML model training

## Summary

### NodePort Solution
- ✅ Permanent solution for macOS TLS issues
- ✅ Uses Docker container network (like HTTP/3)
- ✅ Automatic fallback
- ✅ Integrated into test scripts

### Python AI Database
- ✅ Complete schema for AI service
- ✅ Prediction caching
- ✅ Inference logging
- ✅ Analytics cache
- ✅ Event tracking
- ✅ Model metrics

Both solutions are production-ready and work reliably on macOS with Kind clusters.

