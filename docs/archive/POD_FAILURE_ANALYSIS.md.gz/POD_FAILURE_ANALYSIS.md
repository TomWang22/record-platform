# Pod Failure Analysis - 3/4 Pods Failed

**Generated:** $(date)
**Status:** 3 out of 4 k6 pods failed immediately

---

## 🔴 Critical Issue

3 pods failed immediately after starting:
- k6-shopping-e2e-1: ❌ Failed
- k6-shopping-e2e-2: ✅ Running
- k6-shopping-e2e-3: ❌ Failed
- k6-shopping-e2e-4: ❌ Failed

---

## 🔍 Investigation


### Failed Pod Logs:

running (02m48.1s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m48.9s/33m00.0s

running (02m49.9s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m50.4s/33m00.0s

running (02m51.0s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m52.3s/33m00.0s

running (02m52.7s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m53.2s/33m00.0s

running (02m53.5s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m53.9s/33m00.0s

running (02m54.3s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m55.1s/33m00.0s

running (02m55.1s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m55.4s/33m00.0s

running (02m56.0s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m56.5s/33m00.0s

running (02m57.0s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m57.6s/33m00.0s

running (02m58.0s), 02/15 VUs, 0 complete and 0 interrupted iterations
default   [   9% ] 02/15 VUs  02m58.4s/33m00.0s

### Pod Exit Status:
{"terminated":{"containerID":"containerd://afca05c4c56194970397648ce331c6acfaf1868f6248dd64663df50605df8aed","exitCode":137,"finishedAt":"2025-12-16T00:15:30Z","reason":"OOMKilled","startedAt":"2025-12-16T00:10:29Z"}}