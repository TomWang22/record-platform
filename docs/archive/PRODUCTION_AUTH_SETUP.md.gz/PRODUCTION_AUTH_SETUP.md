# Production-Tier Authentication Setup Guide

This guide configures the auth service for production-tier authentication matching Auth0-level quality.

## Overview

The auth service supports:
- **MFA/TOTP**: ✅ Production-ready (otplib)
- **Email Verification**: ✅ Production-ready (SMTP)
- **Phone/SMS Verification**: ⚠️ Requires Twilio credentials
- **Passkey/WebAuthn**: ✅ Production-ready (@simplewebauthn/server)
- **OAuth**: ⚠️ Requires Google credentials

## 1. Phone Verification (SMS) - Production Setup

### Supported Providers

The auth service supports multiple SMS providers with automatic fallback:

1. **Mock Provider** (Free - Development/Testing)
   - Like MailHog for email
   - Logs messages to console
   - Accessible via `/api/auth/sms/mock/messages`
   - Perfect for development and testing

2. **AWS SNS** (Very Cheap - ~$0.00645 per SMS)
   - Pay-as-you-go pricing
   - No free tier, but very affordable
   - Great for production at scale

3. **Vonage** (Free Tier Available)
   - Free tier: 10,000 messages/month
   - Good for small to medium scale

4. **MessageBird** (Free Tier Available)
   - Free tier: 1,000 messages/month
   - Good for testing and small projects

5. **Twilio** (Free Trial Available)
   - Free trial credits
   - Most popular, but can be expensive at scale

### Configuration

#### Option 1: Mock Provider (Development/Testing - FREE)

```bash
# Set in Kubernetes ConfigMap (app-config)
SMS_USE_MOCK: "true"
# or
SMS_PROVIDER: "mock"
```

Access sent messages: `GET /api/auth/sms/mock/messages`

#### Option 2: AWS SNS (Very Cheap - Recommended for Production)

```bash
# Set in Kubernetes Secret (app-secrets)
AWS_ACCESS_KEY_ID: "your_access_key"
AWS_SECRET_ACCESS_KEY: "your_secret_key"
AWS_REGION: "us-east-1"  # Optional, defaults to us-east-1

# Set in Kubernetes ConfigMap (app-config)
SMS_PROVIDER: "aws-sns"
```

**Cost**: ~$0.00645 per SMS (very affordable)

#### Option 3: Vonage (Free Tier - 10,000 messages/month)

```bash
# Set in Kubernetes Secret (app-secrets)
VONAGE_API_KEY: "your_api_key"
VONAGE_API_SECRET: "your_api_secret"
VONAGE_FROM_NUMBER: "+1234567890"  # Your Vonage number

# Set in Kubernetes ConfigMap (app-config)
SMS_PROVIDER: "vonage"
```

**Sign up**: https://www.vonage.com/communications-apis/sms/

#### Option 4: MessageBird (Free Tier - 1,000 messages/month)

```bash
# Set in Kubernetes Secret (app-secrets)
MESSAGEBIRD_API_KEY: "your_api_key"
MESSAGEBIRD_ORIGINATOR: "+1234567890"  # Your MessageBird number

# Set in Kubernetes ConfigMap (app-config)
SMS_PROVIDER: "messagebird"
```

**Sign up**: https://www.messagebird.com/

#### Option 5: Twilio (Free Trial Available)

```bash
# Set in Kubernetes Secret (app-secrets)
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_FROM_NUMBER=+1234567890  # Your Twilio phone number

# Set in Kubernetes ConfigMap (app-config)
SMS_PROVIDER: "twilio"  # Optional, auto-detects if credentials are set
```

### Implementation Details
- **Code Generation**: 6-digit random code
- **Expiry**: 15 minutes
- **Rate Limiting**: Implemented at database level (one code per phone per 15min)
- **Security**: Codes are bcrypt hashed before storage
- **Error Handling**: Returns 503 if service not configured (graceful degradation)

### Testing

#### With Mock Provider (Development)
```bash
# Send verification code (uses mock provider)
curl -X POST https://your-domain/api/auth/verification/phone/send \
  -H "Content-Type: application/json" \
  -d '{"phone": "+1234567890"}'

# View sent messages (mock provider only)
curl https://your-domain/api/auth/sms/mock/messages

# Verify code (extract from mock messages endpoint)
curl -X POST https://your-domain/api/auth/verification/phone/verify \
  -H "Content-Type: application/json" \
  -d '{"phone": "+1234567890", "code": "123456"}'
```

#### With Real Provider (Production)
```bash
# Send verification code
curl -X POST https://your-domain/api/auth/verification/phone/send \
  -H "Content-Type: application/json" \
  -d '{"phone": "+1234567890"}'

# Verify code (received via SMS)
curl -X POST https://your-domain/api/auth/verification/phone/verify \
  -H "Content-Type: application/json" \
  -d '{"phone": "+1234567890", "code": "123456"}'
```

## 2. Passkey/WebAuthn - Production Setup

### Requirements
- Valid domain (for RP_ID)
- HTTPS (required for WebAuthn)
- Browser WebAuthn API support

### Configuration

```bash
# Set in Kubernetes ConfigMap (app-config)
ALLOW_MOCK_PASSKEY_DATA: "false"  # Production mode - no mock data
WEBAUTHN_RP_ID: "yourdomain.com"  # Your domain (without protocol)
WEBAUTHN_ORIGIN: "https://yourdomain.com"  # Full origin URL
```

### Implementation Details
- **Validation**: Uses @simplewebauthn/server for production-grade validation
- **Attestation**: Validates attestationObject and clientDataJSON
- **Challenge**: Server-generated, time-limited challenges
- **Security**: Public key stored, private key never leaves device
- **Device Tracking**: Device name and type stored for user management

### Testing
```bash
# Start registration (returns challenge)
curl -X POST https://your-domain/api/auth/passkeys/register/start \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json"

# Finish registration (requires real WebAuthn data from browser)
# Must use browser WebAuthn API or @simplewebauthn/browser
```

## 3. Email Verification - Production Setup

### Requirements
- SMTP Server (SendGrid, AWS SES, Mailgun, etc.)
- SMTP credentials

### Configuration

```bash
# Set in Kubernetes Secret (app-secrets)
SMTP_HOST: "smtp.sendgrid.net"  # Your SMTP server
SMTP_PORT: "587"  # TLS port (465 for SSL)
SMTP_USER: "apikey"  # SMTP username
SMTP_PASSWORD: "your_smtp_password"  # SMTP password
SMTP_FROM: "noreply@yourdomain.com"  # From address
```

### Implementation Details
- **Code Generation**: 6-digit random code
- **Expiry**: 15 minutes
- **Templates**: HTML email templates with branding
- **Security**: Codes are bcrypt hashed before storage
- **Fallback**: Returns 503 if service not configured

## 4. MFA/TOTP - Production Ready

### Implementation Details
- **Library**: otplib (industry standard)
- **Algorithm**: TOTP (RFC 6238)
- **Window**: 90-second window (1 step before/after) for clock skew
- **Backup Codes**: 10 single-use backup codes generated
- **QR Code**: OTPAuth URL for easy setup

### Security Features
- Secret stored in database (encrypted at rest)
- Backup codes hashed with bcrypt
- Rate limiting on verification attempts
- Time-based codes (30-second intervals)

## 5. OAuth - Production Setup

### Requirements
- Google OAuth Client ID
- Google OAuth Client Secret
- OAuth Callback URL

### Configuration

```bash
# Set in Kubernetes Secret (app-secrets)
GOOGLE_CLIENT_ID: "your_google_client_id"
GOOGLE_CLIENT_SECRET: "your_google_client_secret"
GOOGLE_CALLBACK_URL: "https://yourdomain.com/api/auth/google/callback"
FRONTEND_URL: "https://yourdomain.com"
```

## Production Deployment Checklist

### Environment Variables

**ConfigMap (app-config):**
- [ ] `ALLOW_MOCK_PASSKEY_DATA: "false"` (production mode)
- [ ] `WEBAUTHN_RP_ID: "yourdomain.com"`
- [ ] `WEBAUTHN_ORIGIN: "https://yourdomain.com"`
- [ ] `NODE_ENV: "production"`

**Secret (app-secrets):**
- [ ] `TWILIO_ACCOUNT_SID` (for SMS)
- [ ] `TWILIO_AUTH_TOKEN` (for SMS)
- [ ] `TWILIO_FROM_NUMBER` (for SMS)
- [ ] `SMTP_HOST` (for email)
- [ ] `SMTP_PORT` (for email)
- [ ] `SMTP_USER` (for email)
- [ ] `SMTP_PASSWORD` (for email)
- [ ] `SMTP_FROM` (for email)
- [ ] `GOOGLE_CLIENT_ID` (for OAuth)
- [ ] `GOOGLE_CLIENT_SECRET` (for OAuth)
- [ ] `JWT_SECRET` (strong random secret)

### Security Hardening

- [ ] Use strong JWT secret (32+ characters, random)
- [ ] Enable HTTPS/TLS everywhere
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Enable audit logging
- [ ] Configure proper session timeouts
- [ ] Set up monitoring and alerting

### Testing

- [ ] Test MFA setup and verification
- [ ] Test email verification flow
- [ ] Test SMS verification flow (with real Twilio)
- [ ] Test passkey registration (with real browser)
- [ ] Test passkey authentication
- [ ] Test OAuth flow (if enabled)
- [ ] Test token refresh
- [ ] Test logout and token revocation

## Auth0-Level Features Comparison

| Feature | Auth0 | Our Implementation | Status |
|---------|-------|-------------------|--------|
| MFA/TOTP | ✅ | ✅ otplib | ✅ Production-ready |
| SMS Verification | ✅ | ✅ Twilio | ⚠️ Needs credentials |
| Email Verification | ✅ | ✅ SMTP | ✅ Production-ready |
| Passkey/WebAuthn | ✅ | ✅ @simplewebauthn/server | ✅ Production-ready |
| OAuth | ✅ | ✅ passport-google-oauth20 | ⚠️ Needs credentials |
| Social Login | ✅ | ✅ OAuth providers | ⚠️ Needs credentials |
| Password Reset | ✅ | ✅ Via email/SMS | ✅ Production-ready |
| Session Management | ✅ | ✅ JWT + Redis | ✅ Production-ready |
| Rate Limiting | ✅ | ✅ express-rate-limit | ✅ Production-ready |
| Audit Logging | ✅ | ⚠️ Basic logging | ⚠️ Needs enhancement |

## Migration from Dev to Production

1. **Update ConfigMap:**
   ```bash
   kubectl patch configmap app-config -n record-platform --type merge -p '{
     "data": {
       "ALLOW_MOCK_PASSKEY_DATA": "false",
       "NODE_ENV": "production",
       "WEBAUTHN_RP_ID": "yourdomain.com",
       "WEBAUTHN_ORIGIN": "https://yourdomain.com"
     }
   }'
   ```

2. **Update Secrets:**
   ```bash
   kubectl patch secret app-secrets -n record-platform --type merge -p '{
     "stringData": {
       "TWILIO_ACCOUNT_SID": "AC...",
       "TWILIO_AUTH_TOKEN": "...",
       "TWILIO_FROM_NUMBER": "+1234567890",
       "SMTP_HOST": "smtp.sendgrid.net",
       "SMTP_USER": "...",
       "SMTP_PASSWORD": "...",
       "SMTP_FROM": "noreply@yourdomain.com"
     }
   }'
   ```

3. **Restart Services:**
   ```bash
   kubectl rollout restart deployment/auth-service -n record-platform
   ```

4. **Verify:**
   ```bash
   ./scripts/test-auth-service.sh
   ```

## Troubleshooting

### SMS Not Working
- Check Twilio credentials are correct
- Verify phone number is verified in Twilio
- Check Twilio account has sufficient credits
- Review Twilio logs in dashboard

### Email Not Working
- Check SMTP credentials
- Verify SMTP server allows connections
- Check firewall rules
- Review SMTP server logs

### Passkey Not Working
- Ensure HTTPS is enabled
- Verify RP_ID matches domain
- Check browser console for WebAuthn errors
- Ensure browser supports WebAuthn

### OAuth Not Working
- Verify callback URL matches Google OAuth config
- Check Google OAuth credentials
- Verify redirect URIs are whitelisted
- Review OAuth consent screen settings

