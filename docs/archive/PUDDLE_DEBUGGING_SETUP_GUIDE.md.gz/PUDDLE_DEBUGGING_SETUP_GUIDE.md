# Puddle Debugging & Setup Guide

This document provides comprehensive debugging and setup instructions for **Puddle** (distributed computing broker) with gRPC, HTTP/2, HTTP/3, and Caddy 2.8. This guide contains all the working configurations and troubleshooting techniques that have been proven to work.

---

## Table of Contents

1. [Quick Start Checklist](#1-quick-start-checklist)
2. [Caddy 2.8 Setup & Configuration](#2-caddy-28-setup--configuration)
3. [Health Check Debugging](#3-health-check-debugging)
4. [gRPC Debugging](#4-grpc-debugging)
5. [HTTP/2 & HTTP/3 Debugging](#5-http2--http3-debugging)
6. [Common Issues & Fixes](#6-common-issues--fixes)
7. [Diagnostic Scripts](#7-diagnostic-scripts)
8. [Working Configurations](#8-working-configurations)

---

## 1. Quick Start Checklist

### Prerequisites
- [ ] Kubernetes cluster (kind, minikube, or cloud)
- [ ] `kubectl` configured
- [ ] `curl` with HTTP/2 and HTTP/3 support (`brew install curl` on macOS)
- [ ] `grpcurl` installed (`brew install grpcurl` or `go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest`)
- [ ] Docker running (for external databases if using Docker Compose)

### Initial Setup
```bash
# 1. Deploy Caddy 2.8
kubectl apply -f infra/k8s/caddy-h3-deploy.yaml

# 2. Create ConfigMap with Caddyfile
kubectl create configmap caddy-h3 \
  --from-file=Caddyfile=./Caddyfile \
  -n ingress-nginx

# 3. Create TLS secrets (if not already created)
# See section 2.3 for certificate setup

# 4. Verify Caddy is running
kubectl -n ingress-nginx get pods -l app=caddy-h3

# 5. Test health check
curl -k -I --http2 https://record.local:8443/_caddy/healthz
```

---

## 2. Caddy 2.8 Setup & Configuration

### 2.1 Caddyfile Configuration

**File**: `Caddyfile`

```caddyfile
{
  admin localhost:2019
}

# Primary vhost
https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  # Health check endpoint
  handle_path /_caddy/healthz {
    respond "ok" 200
  }

  # gRPC matchers - route by service name in path
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_compute {
    protocol grpc
    path_regexp ^/compute\.
  }

  # Route auth-service gRPC requests
  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route compute-broker gRPC requests
  handle @grpc_compute {
    reverse_proxy compute-broker.record-platform.svc.cluster.local:50061 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # REST API requests: route through ingress
  handle {
    reverse_proxy https://ingress-nginx-controller.ingress-nginx.svc.cluster.local:443 {
      header_up Host {http.request.host}
      transport http {
        tls
        tls_server_name record.local
        tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
        versions h2 h1
      }
    }
  }
}

# Internal h2c port for gRPC tests (bypasses TLS)
:5000 {
  # gRPC matchers
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_compute {
    protocol grpc
    path_regexp ^/compute\.
  }

  # Route auth-service gRPC requests
  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route compute-broker gRPC requests
  handle @grpc_compute {
    reverse_proxy compute-broker.record-platform.svc.cluster.local:50061 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }
}

# Catch-all for probes without SNI
https://:443 {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }
  # Health check endpoint for probes without SNI
  handle_path /_caddy/healthz {
    respond "ok" 200
  }
}
```

**Key Points**:
- `admin localhost:2019` - Enables zero-downtime reloads via admin API
- Port 5000 - Internal h2c (HTTP/2 cleartext) for gRPC testing
- `protocol grpc` matcher - Detects gRPC requests
- `transport http { versions h2c }` - Forces HTTP/2 for gRPC

---

### 2.2 Caddy Kubernetes Deployment

**File**: `infra/k8s/caddy-h3-deploy.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: caddy-h3
  namespace: ingress-nginx
spec:
  strategy: { type: Recreate }
  replicas: 1
  selector: { matchLabels: { app: caddy-h3 } }
  template:
    metadata:
      labels: { app: caddy-h3 }
    spec:
      hostNetwork: true
      dnsPolicy: ClusterFirstWithHostNet
      terminationGracePeriodSeconds: 5
      containers:
      - name: caddy
        image: caddy:2.8
        securityContext:
          runAsNonRoot: false
          capabilities: { add: ["NET_BIND_SERVICE"] }
        ports:
        - { name: https, containerPort: 443, protocol: TCP }
        - { name: https-udp, containerPort: 443, protocol: UDP }
        - { name: grpc-h2c, containerPort: 5000, protocol: TCP }
        volumeMounts:
        - { name: caddy-conf,  mountPath: /etc/caddy }
        - { name: caddy-certs, mountPath: /etc/caddy/certs, readOnly: true }
        - { name: caddy-ca,    mountPath: /etc/caddy/ca,    readOnly: true }
        readinessProbe:
          httpGet:
            scheme: HTTPS
            path: /_caddy/healthz
            port: 443
          periodSeconds: 5
          failureThreshold: 6
        livenessProbe:
          tcpSocket: { port: 443 }
          initialDelaySeconds: 3
          periodSeconds: 10
          failureThreshold: 3
      volumes:
      - name: caddy-conf
        configMap:
          name: caddy-h3
          items: [{ key: Caddyfile, path: Caddyfile }]
      - name: caddy-certs
        secret:
          secretName: record-local-tls
          items:
            - { key: tls.crt, path: tls.crt }
            - { key: tls.key, path: tls.key }
      - name: caddy-ca
        secret:
          secretName: dev-root-ca
          items:
            - { key: dev-root.pem, path: dev-root.pem }
```

**Key Features**:
- `hostNetwork: true` - Required for binding to host ports (443)
- `capabilities: ["NET_BIND_SERVICE"]` - Allows binding to port 443 without root
- UDP port 443 - Required for HTTP/3 (QUIC)
- Port 5000 - Internal h2c port for gRPC testing

---

### 2.3 Certificate Setup

**Create TLS certificates**:

```bash
# 1. Generate CA
openssl genrsa -out ca.key 4096
openssl req -new -x509 -days 365 -key ca.key -out ca.crt \
  -subj "/CN=dev-root-ca"

# 2. Generate server certificate
openssl genrsa -out tls.key 2048
openssl req -new -key tls.key -out tls.csr \
  -subj "/CN=record.local"
openssl x509 -req -days 365 -in tls.csr -CA ca.crt -CAkey ca.key \
  -CAcreateserial -out tls.crt

# 3. Create Kubernetes secrets
kubectl create secret tls record-local-tls \
  --cert=tls.crt \
  --key=tls.key \
  -n ingress-nginx

kubectl create secret generic dev-root-ca \
  --from-file=dev-root.pem=ca.crt \
  -n ingress-nginx
```

---

### 2.4 macOS Port Forwarding (Required for HTTP/3)

**macOS firewall blocks UDP 443**, so we need to forward:

```bash
# Add to /etc/pf.conf (requires sudo)
rdr on lo0 inet proto tcp from any to any port 443 -> 127.0.0.1 port 8443
rdr on lo0 inet proto udp from any to any port 443 -> 127.0.0.1 port 8443

# Reload pf
sudo pfctl -f /etc/pf.conf
sudo pfctl -e
```

**Alternative**: Use port 8443 directly (no forwarding needed):
```bash
curl -k -I --http2 https://record.local:8443/_caddy/healthz
curl -k -I --http3-only https://record.local:8443/_caddy/healthz
```

---

## 3. Health Check Debugging

### 3.1 Basic Health Check Test

```bash
# Test Caddy health check
curl -k -I --http2 https://record.local:8443/_caddy/healthz

# Expected: HTTP/2 200

# Test HTTP/3 health check
curl -k -I --http3-only https://record.local:8443/_caddy/healthz

# Expected: HTTP/3 200
```

### 3.2 Health Check Failure Diagnosis

**Script**: `scripts/diag-caddy-h3.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
NS=ingress-nginx

echo "== Pods =="
kubectl -n "$NS" get pods -l app=caddy-h3 -o wide

POD=$(kubectl -n "$NS" get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
if [[ -z "${POD}" ]]; then
  echo "No pod yet. Checking events…"
  kubectl -n "$NS" get events --sort-by=.lastTimestamp | tail -n 25
  exit 0
fi

echo "== Describe Pod =="
kubectl -n "$NS" describe pod "$POD" | sed -n '/Events:/,$p'

PHASE=$(kubectl -n "$NS" get pod "$POD" -o jsonpath='{.status.phase}')
if [[ "$PHASE" == "Running" ]]; then
  echo "== Caddy log tail =="
  kubectl -n "$NS" logs "$POD" --tail=200
fi

echo "== Node :443 in-use check =="
NODE=$(kubectl -n "$NS" get pod "$POD" -o jsonpath='{.spec.nodeName}')
kubectl debug node/"$NODE" -it --image=busybox -- chroot /host sh -c \
  'ss -nltp | grep ":443" || true; ss -nulp | grep ":443" || true' || true
```

**Usage**:
```bash
chmod +x scripts/diag-caddy-h3.sh
./scripts/diag-caddy-h3.sh
```

### 3.3 Extended Health Check Diagnostics

**Script**: `scripts/diag-caddy-h3-extended.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
NS=ingress-nginx
APP=app=caddy-h3

echo "== Pods =="
kubectl -n "$NS" get pods -l "$APP" -o wide || true

POD=$(kubectl -n "$NS" get pod -l "$APP" -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
[[ -z "${POD}" ]] && { 
  echo "No pod found. Recent events:"
  kubectl -n "$NS" get events --sort-by=.lastTimestamp | tail -n 40
  exit 1
}

echo; echo "== Pod conditions =="
kubectl -n "$NS" get pod "$POD" -o json | jq '.status | {phase,conditions,containerStatuses}'

echo; echo "== Pod events =="
kubectl -n "$NS" describe pod "$POD" | sed -n '/Events:/,$p'

echo; echo "== Container last state =="
kubectl -n "$NS" get pod "$POD" -o json | jq '.status.containerStatuses[0] | {ready,state,lastState,restartCount,image}'

echo; echo "== Full logs (latest) =="
kubectl -n "$NS" logs "$POD" --tail=500 || true

echo; echo "== Full logs (previous, if any) =="
kubectl -n "$NS" logs "$POD" --previous --tail=200 || true

echo; echo "== Node socket holders on 443 (TCP/UDP) =="
NODE=$(kubectl -n "$NS" get pod "$POD" -o jsonpath='{.spec.nodeName}')
kubectl debug node/"$NODE" -it --image=busybox -- chroot /host sh -c '
  echo "-- TCP :443 --"; ss -nltp | grep ":443" || true;
  echo "-- UDP :443 --"; ss -nulp | grep ":443" || true;
' || true

echo; echo "== In-pod Caddyfile validate (best-effort) =="
kubectl -n "$NS" exec "$POD" -- caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile || true
```

**Usage**:
```bash
chmod +x scripts/diag-caddy-h3-extended.sh
./scripts/diag-caddy-h3-extended.sh
```

### 3.4 Service Health Check Debugging

**Check if service endpoints exist**:

```bash
# Check service
kubectl -n record-platform get svc api-gateway -o wide

# Check endpoints
kubectl -n record-platform get endpoints api-gateway

# Check endpoint slices (Kubernetes 1.21+)
kubectl -n record-platform get endpointslices.discovery.k8s.io \
  -l kubernetes.io/service-name=api-gateway

# If endpoints are empty, check pod status
kubectl -n record-platform get pods -l app=api-gateway
```

**Common Issue**: Service has 0 endpoints → Pods not ready or selector mismatch

**Fix**:
```bash
# Check pod labels match service selector
kubectl -n record-platform get pods -l app=api-gateway --show-labels
kubectl -n record-platform get svc api-gateway -o yaml | grep selector

# Restart deployment if needed
kubectl -n record-platform rollout restart deployment/api-gateway
kubectl -n record-platform rollout status deployment/api-gateway
```

---

## 4. gRPC Debugging

### 4.1 Basic gRPC Health Check

**Using grpcurl**:

```bash
# Test via h2c port (port 5000, plaintext)
# First, port-forward Caddy pod
kubectl -n ingress-nginx port-forward pod/$(kubectl -n ingress-nginx get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}') 5000:5000 &

# Test gRPC health check
grpcurl -plaintext \
  -import-path ./proto \
  -proto proto/auth.proto \
  -d '{}' \
  127.0.0.1:5000 \
  auth.AuthService/HealthCheck

# Expected output:
# {
#   "healthy": true,
#   "version": "1.0.0"
# }
```

**Using grpcurl via TLS (port 8443)**:

```bash
grpcurl -insecure \
  -H "Host: record.local" \
  -authority "record.local" \
  -H "TE: trailers" \
  -H "Content-Type: application/grpc" \
  -import-path ./proto \
  -proto proto/auth.proto \
  -d '{}' \
  127.0.0.1:8443 \
  auth.AuthService/HealthCheck
```

### 4.2 gRPC Debugging Script

**Script**: `scripts/test-grpc-health.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-record.local}"
PROTO_DIR="${PROTO_DIR:-./proto}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
fail() { echo "❌ $*" >&2; exit 1; }

# Check if grpcurl is installed
if ! command -v grpcurl >/dev/null 2>&1; then
  fail "grpcurl not installed. Install with: brew install grpcurl"
fi

# Helper function with timeout
grpcurl_with_timeout() {
  local timeout_sec="${1:-10}"
  shift
  local cmd=("$@")
  
  if command -v timeout >/dev/null 2>&1; then
    timeout "$timeout_sec" "${cmd[@]}" 2>&1
  elif command -v gtimeout >/dev/null 2>&1; then
    gtimeout "$timeout_sec" "${cmd[@]}" 2>&1
  else
    local pid
    "${cmd[@]}" 2>&1 &
    pid=$!
    (
      sleep "$timeout_sec"
      kill "$pid" 2>/dev/null || true
    ) &
    wait "$pid" 2>/dev/null || echo "grpcurl timeout after ${timeout_sec}s"
  fi
}

# Test gRPC services
say "Testing gRPC Services"

# Test Auth Service
say "Test 1: Auth Service - HealthCheck"
CADDY_POD=$(kubectl -n ingress-nginx get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [[ -n "$CADDY_POD" ]]; then
  # Port forward in background
  kubectl -n ingress-nginx port-forward pod/$CADDY_POD 5000:5000 > /dev/null 2>&1 &
  PF_PID=$!
  sleep 2
  
  RESULT=$(grpcurl_with_timeout 5 grpcurl -plaintext \
    -import-path "$PROTO_DIR" \
    -proto "$PROTO_DIR/auth.proto" \
    -d '{}' \
    -max-time 5 \
    "127.0.0.1:5000" \
    "auth.AuthService/HealthCheck" 2>&1) || RESULT=""
  
  kill $PF_PID 2>/dev/null || true
  wait $PF_PID 2>/dev/null || true
  
  if echo "$RESULT" | grep -q "healthy"; then
    ok "Auth Service gRPC HealthCheck works"
  else
    warn "Auth Service gRPC HealthCheck failed"
    echo "Response: $RESULT" | head -5
  fi
else
  warn "Caddy pod not found"
fi

# Test Compute Broker Service
say "Test 2: Compute Broker Service - HealthCheck"
if [[ -n "$CADDY_POD" ]]; then
  kubectl -n ingress-nginx port-forward pod/$CADDY_POD 5000:5000 > /dev/null 2>&1 &
  PF_PID=$!
  sleep 2
  
  RESULT=$(grpcurl_with_timeout 5 grpcurl -plaintext \
    -import-path "$PROTO_DIR" \
    -proto "$PROTO_DIR/compute.proto" \
    -d '{}' \
    -max-time 5 \
    "127.0.0.1:5000" \
    "compute.ComputeService/HealthCheck" 2>&1) || RESULT=""
  
  kill $PF_PID 2>/dev/null || true
  wait $PF_PID 2>/dev/null || true
  
  if echo "$RESULT" | grep -q "healthy"; then
    ok "Compute Broker Service gRPC HealthCheck works"
  else
    warn "Compute Broker Service gRPC HealthCheck failed"
    echo "Response: $RESULT" | head -5
  fi
fi

say "gRPC Testing Complete"
```

**Usage**:
```bash
chmod +x scripts/test-grpc-health.sh
./scripts/test-grpc-health.sh
```

### 4.3 Common gRPC Issues

**Issue 1: "Connection refused"**

**Diagnosis**:
```bash
# Check if gRPC service is running
kubectl -n record-platform get pods -l app=compute-broker

# Check service port
kubectl -n record-platform get svc compute-broker -o yaml | grep -A 5 ports

# Test direct connection (from within cluster)
kubectl -n record-platform run grpc-test --rm -it --restart=Never \
  --image=fullstorydev/grpcurl -- \
  -- grpcurl -plaintext compute-broker:50061 compute.ComputeService/HealthCheck
```

**Fix**: Ensure service is running and port matches Caddyfile configuration.

**Issue 2: "Deadline exceeded" or timeout**

**Diagnosis**:
```bash
# Check service logs
kubectl -n record-platform logs -l app=compute-broker --tail=100

# Check if service is overloaded
kubectl -n record-platform top pods -l app=compute-broker
```

**Fix**: Increase timeout in Caddyfile or check service performance.

**Issue 3: "Protocol not available"**

**Diagnosis**:
```bash
# Check Caddyfile has correct gRPC matcher
kubectl -n ingress-nginx get configmap caddy-h3 -o yaml | grep -A 10 grpc

# Validate Caddyfile
kubectl -n ingress-nginx exec -it deploy/caddy-h3 -- \
  caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
```

**Fix**: Ensure `protocol grpc` matcher is present and `transport http { versions h2c }` is configured.

---

## 5. HTTP/2 & HTTP/3 Debugging

### 5.1 Basic HTTP/2 Test

```bash
# Test HTTP/2
curl -k -I --http2 \
  --resolve "record.local:8443:127.0.0.1" \
  -H "Host: record.local" \
  "https://record.local:8443/_caddy/healthz"

# Expected: HTTP/2 200
```

### 5.2 Basic HTTP/3 Test

**Note**: HTTP/3 requires QUIC (UDP), which may be blocked by macOS firewall.

```bash
# Test HTTP/3
curl -k -I --http3-only \
  --resolve "record.local:443:127.0.0.1" \
  -H "Host: record.local" \
  "https://record.local/_caddy/healthz"

# Expected: HTTP/3 200
# If fails: Check UDP port forwarding (see section 2.4)
```

### 5.3 HTTP/2 & HTTP/3 Matrix Test

**Script**: `scripts/test-h2-h3-matrix.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-record.local}"
CURL_BIN="${CURL_BIN:-/opt/homebrew/opt/curl/bin/curl}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }

say "=== HTTP/2 & HTTP/3 Matrix Test ==="

# Test 1: HTTP/2 to Caddy health check
say "Test 1: HTTP/2 → Caddy health check"
H2_CADDY=$($CURL_BIN -k -sS -w "\n%{http_code}" --http2 --max-time 10 \
  --resolve "$HOST:8443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST:8443/_caddy/healthz" 2>&1 | tail -1)
if [[ "$H2_CADDY" == "200" ]]; then
  ok "HTTP/2 → Caddy: OK"
else
  warn "HTTP/2 → Caddy: HTTP $H2_CADDY"
fi

# Test 2: HTTP/3 to Caddy health check
say "Test 2: HTTP/3 → Caddy health check"
H3_CADDY=$($CURL_BIN -k -sS -w "\n%{http_code}" --http3-only --max-time 10 \
  --resolve "$HOST:443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST/_caddy/healthz" 2>&1 | tail -1)
if [[ "$H3_CADDY" == "200" ]]; then
  ok "HTTP/3 → Caddy: OK"
else
  warn "HTTP/3 → Caddy: HTTP $H3_CADDY (may be blocked by macOS firewall)"
fi

# Test 3: HTTP/2 to API endpoint
say "Test 3: HTTP/2 → API endpoint"
H2_API=$($CURL_BIN -k -sS -w "\n%{http_code}" --http2 --max-time 10 \
  --resolve "$HOST:8443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST:8443/api/healthz" 2>&1 | tail -1)
if [[ "$H2_API" == "200" ]]; then
  ok "HTTP/2 → API: OK"
else
  warn "HTTP/2 → API: HTTP $H2_API"
fi

# Test 4: HTTP/3 to API endpoint
say "Test 4: HTTP/3 → API endpoint"
H3_API=$($CURL_BIN -k -sS -w "\n%{http_code}" --http3-only --max-time 10 \
  --resolve "$HOST:443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST/api/healthz" 2>&1 | tail -1)
if [[ "$H3_API" == "200" ]]; then
  ok "HTTP/3 → API: OK"
else
  warn "HTTP/3 → API: HTTP $H3_API"
fi

say "=== Matrix Test Complete ==="
```

**Usage**:
```bash
chmod +x scripts/test-h2-h3-matrix.sh
./scripts/test-h2-h3-matrix.sh
```

### 5.4 Common HTTP/2 & HTTP/3 Issues

**Issue 1: HTTP/2 works but HTTP/3 fails**

**Diagnosis**:
```bash
# Check if UDP port 443 is accessible
nc -u -v 127.0.0.1 443

# Check Caddy logs for QUIC errors
kubectl -n ingress-nginx logs -l app=caddy-h3 | grep -i quic
```

**Fix**: 
- macOS firewall blocks UDP 443 → Use port forwarding (section 2.4)
- Or use port 8443 directly for HTTP/3

**Issue 2: "Connection refused" on HTTP/2**

**Diagnosis**:
```bash
# Check if Caddy is listening on port 443
kubectl -n ingress-nginx exec -it deploy/caddy-h3 -- netstat -tlnp | grep 443

# Check Caddy logs
kubectl -n ingress-nginx logs -l app=caddy-h3 --tail=50
```

**Fix**: Restart Caddy deployment:
```bash
kubectl -n ingress-nginx rollout restart deploy/caddy-h3
kubectl -n ingress-nginx rollout status deploy/caddy-h3
```

**Issue 3: "502 Bad Gateway"**

**Diagnosis**:
```bash
# Check if upstream service is reachable
kubectl -n record-platform get svc api-gateway
kubectl -n record-platform get endpoints api-gateway

# Test direct connection to upstream
kubectl -n record-platform run curl-test --rm -it --restart=Never \
  --image=curlimages/curl -- \
  curl -sS http://api-gateway:4000/healthz
```

**Fix**: Ensure upstream service is running and endpoints exist.

---

## 6. Common Issues & Fixes

### 6.1 Caddy Pod Not Starting

**Symptoms**: Pod in `CrashLoopBackOff` or `Pending`

**Diagnosis**:
```bash
# Check pod events
kubectl -n ingress-nginx describe pod -l app=caddy-h3

# Check logs
kubectl -n ingress-nginx logs -l app=caddy-h3 --previous
```

**Common Causes**:
1. **Port 443 already in use**
   ```bash
   # Check what's using port 443
   kubectl debug node/$(kubectl -n ingress-nginx get pod -l app=caddy-h3 -o jsonpath='{.items[0].spec.nodeName}') \
     -it --image=busybox -- chroot /host sh -c 'ss -nltp | grep ":443"'
   ```
   **Fix**: Change Caddy to use port 8443 (see section 6.2)

2. **Missing certificates**
   ```bash
   # Check if secrets exist
   kubectl -n ingress-nginx get secret record-local-tls
   kubectl -n ingress-nginx get secret dev-root-ca
   ```
   **Fix**: Create secrets (see section 2.3)

3. **Invalid Caddyfile**
   ```bash
   # Validate Caddyfile
   kubectl -n ingress-nginx exec -it deploy/caddy-h3 -- \
     caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
   ```
   **Fix**: Fix Caddyfile syntax errors

---

### 6.2 Change Caddy Port (Avoid 443 Conflicts)

**If port 443 is already in use**, change Caddy to use port 8443:

**Step 1**: Update Caddyfile (if needed - Caddyfile already supports 8443 via port forwarding)

**Step 2**: Update deployment ports:
```bash
kubectl -n ingress-nginx patch deploy caddy-h3 --type='json' -p='[
  {"op":"replace","path":"/spec/template/spec/containers/0/ports/0/containerPort","value":8443},
  {"op":"replace","path":"/spec/template/spec/containers/0/ports/1/containerPort","value":8443},
  {"op":"replace","path":"/spec/template/spec/containers/0/readinessProbe/httpGet/port","value":8443}
]'
```

**Step 3**: Restart deployment:
```bash
kubectl -n ingress-nginx rollout restart deploy/caddy-h3
kubectl -n ingress-nginx rollout status deploy/caddy-h3
```

**Step 4**: Test:
```bash
curl -k -I --http2 https://record.local:8443/_caddy/healthz
```

---

### 6.3 Upstream TLS Trust Issues

**Symptoms**: 502 Bad Gateway, Caddy logs show "certificate verify failed"

**Diagnosis**:
```bash
# Check Caddy logs
kubectl -n ingress-nginx logs -l app=caddy-h3 | grep -i "certificate\|tls\|verify"
```

**Fix**: Use HTTP upstream in development (no TLS):

**Create temporary Caddyfile**:
```caddyfile
{
  admin localhost:2019
}

https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  handle_path /_caddy/healthz {
    respond "ok" 200
  }

  # DEV: HTTP to ingress (no upstream TLS)
  reverse_proxy http://ingress-nginx-controller.ingress-nginx.svc.cluster.local:80 {
    header_up Host {http.request.host}
  }
}
```

**Apply**:
```bash
kubectl -n ingress-nginx create configmap caddy-h3 \
  --from-file=Caddyfile=/tmp/Caddyfile.http-upstream \
  --dry-run=client -o yaml | kubectl apply -f -

kubectl -n ingress-nginx rollout restart deploy/caddy-h3
```

---

### 6.4 Service Endpoints Empty

**Symptoms**: Service exists but has 0 endpoints → 502 Bad Gateway

**Diagnosis**:
```bash
# Check service selector
kubectl -n record-platform get svc api-gateway -o yaml | grep -A 5 selector

# Check pod labels
kubectl -n record-platform get pods -l app=api-gateway --show-labels

# Check if pods are ready
kubectl -n record-platform get pods -l app=api-gateway
```

**Fix**:
1. **Selector mismatch**: Update service selector to match pod labels
2. **Pods not ready**: Check pod logs and fix issues
3. **Restart deployment**: `kubectl -n record-platform rollout restart deployment/api-gateway`

---

### 6.5 gRPC Reflection Not Working

**Symptoms**: `grpcurl list` fails with "server does not support the reflection API"

**Fix**: Enable gRPC reflection in service:

```typescript
// In gRPC server code
import { enableReflection } from '@common/utils/grpc-reflection'

if (process.env.ENABLE_GRPC_REFLECTION !== "false") {
  enableReflection(server, [PROTO_PATH], ["auth.AuthService"])
}
```

**Test**:
```bash
grpcurl -plaintext -import-path ./proto \
  127.0.0.1:5000 list
```

---

## 7. Diagnostic Scripts

### 7.1 Complete Health Check Script

**Script**: `scripts/health-check-complete.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-record.local}"
NS_ING=ingress-nginx
NS_APP=record-platform
CURL_BIN="${CURL_BIN:-/opt/homebrew/opt/curl/bin/curl}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
fail() { echo "❌ $*" >&2; }

say "=== Complete Health Check ==="

# 1. Check Caddy pod
say "1. Checking Caddy pod..."
CADDY_POD=$(kubectl -n "$NS_ING" get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [[ -n "$CADDY_POD" ]]; then
  PHASE=$(kubectl -n "$NS_ING" get pod "$CADDY_POD" -o jsonpath='{.status.phase}')
  if [[ "$PHASE" == "Running" ]]; then
    ok "Caddy pod is Running"
  else
    warn "Caddy pod is $PHASE"
  fi
else
  fail "Caddy pod not found"
fi

# 2. Check Caddy health endpoint
say "2. Checking Caddy health endpoint..."
H2_HEALTH=$($CURL_BIN -k -sS -w "\n%{http_code}" --http2 --max-time 5 \
  --resolve "$HOST:8443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST:8443/_caddy/healthz" 2>&1 | tail -1)
if [[ "$H2_HEALTH" == "200" ]]; then
  ok "Caddy HTTP/2 health check: OK"
else
  warn "Caddy HTTP/2 health check: HTTP $H2_HEALTH"
fi

# 3. Check API Gateway service
say "3. Checking API Gateway service..."
GATEWAY_ENDPOINTS=$(kubectl -n "$NS_APP" get endpoints api-gateway \
  -o jsonpath='{.subsets[0].addresses[*].ip}' 2>/dev/null | wc -w || echo "0")
if [[ "$GATEWAY_ENDPOINTS" -gt 0 ]]; then
  ok "API Gateway has $GATEWAY_ENDPOINTS endpoint(s)"
else
  warn "API Gateway has 0 endpoints"
fi

# 4. Check API Gateway health via Caddy
say "4. Checking API Gateway via Caddy..."
API_HEALTH=$($CURL_BIN -k -sS -w "\n%{http_code}" --http2 --max-time 10 \
  --resolve "$HOST:8443:127.0.0.1" \
  -H "Host: $HOST" \
  "https://$HOST:8443/api/healthz" 2>&1 | tail -1)
if [[ "$API_HEALTH" == "200" ]]; then
  ok "API Gateway via Caddy: OK"
else
  warn "API Gateway via Caddy: HTTP $API_HEALTH"
fi

# 5. Check gRPC services (if grpcurl available)
if command -v grpcurl >/dev/null 2>&1; then
  say "5. Checking gRPC services..."
  CADDY_POD=$(kubectl -n "$NS_ING" get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
  if [[ -n "$CADDY_POD" ]]; then
    kubectl -n "$NS_ING" port-forward pod/$CADDY_POD 5000:5000 > /dev/null 2>&1 &
    PF_PID=$!
    sleep 2
    
    GRPC_RESULT=$(grpcurl -plaintext -max-time 5 \
      -import-path ./proto \
      -proto proto/auth.proto \
      -d '{}' \
      127.0.0.1:5000 \
      auth.AuthService/HealthCheck 2>&1) || GRPC_RESULT=""
    
    kill $PF_PID 2>/dev/null || true
    wait $PF_PID 2>/dev/null || true
    
    if echo "$GRPC_RESULT" | grep -q "healthy"; then
      ok "gRPC Auth Service: OK"
    else
      warn "gRPC Auth Service: Failed"
    fi
  fi
else
  warn "grpcurl not installed - skipping gRPC checks"
fi

say "=== Health Check Complete ==="
```

**Usage**:
```bash
chmod +x scripts/health-check-complete.sh
./scripts/health-check-complete.sh
```

---

### 7.2 Service Connectivity Test

**Script**: `scripts/test-service-connectivity.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

NS="${NS:-record-platform}"
SERVICE="${SERVICE:-api-gateway}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }

say "=== Service Connectivity Test: $SERVICE ==="

# 1. Check service exists
if ! kubectl -n "$NS" get svc "$SERVICE" >/dev/null 2>&1; then
  warn "Service $SERVICE not found"
  exit 1
fi
ok "Service $SERVICE exists"

# 2. Check endpoints
ENDPOINTS=$(kubectl -n "$NS" get endpoints "$SERVICE" \
  -o jsonpath='{.subsets[0].addresses[*].ip}' 2>/dev/null | wc -w || echo "0")
if [[ "$ENDPOINTS" -gt 0 ]]; then
  ok "Service has $ENDPOINTS endpoint(s)"
else
  warn "Service has 0 endpoints"
fi

# 3. Check pods
PODS=$(kubectl -n "$NS" get pods -l app="$SERVICE" -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || echo "")
if [[ -n "$PODS" ]]; then
  ok "Found pods: $PODS"
  for pod in $PODS; do
    PHASE=$(kubectl -n "$NS" get pod "$pod" -o jsonpath='{.status.phase}')
    READY=$(kubectl -n "$NS" get pod "$pod" -o jsonpath='{.status.containerStatuses[0].ready}')
    if [[ "$PHASE" == "Running" ]] && [[ "$READY" == "true" ]]; then
      ok "Pod $pod: Running and Ready"
    else
      warn "Pod $pod: $PHASE (Ready: $READY)"
    fi
  done
else
  warn "No pods found for service $SERVICE"
fi

# 4. Test direct connection
say "Testing direct connection to service..."
kubectl -n "$NS" run connectivity-test --rm -it --restart=Never \
  --image=curlimages/curl -- \
  curl -sS -w "\nHTTP %{http_code}\n" \
  "http://${SERVICE}:4000/healthz" || warn "Direct connection test failed"

say "=== Connectivity Test Complete ==="
```

**Usage**:
```bash
chmod +x scripts/test-service-connectivity.sh
./scripts/test-service-connectivity.sh api-gateway
```

---

## 8. Working Configurations

### 8.1 Complete Working Caddyfile

This is the **proven working Caddyfile** that handles gRPC, HTTP/2, and HTTP/3:

```caddyfile
{
  admin localhost:2019
}

https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  handle_path /_caddy/healthz {
    respond "ok" 200
  }

  # gRPC routing
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_compute {
    protocol grpc
    path_regexp ^/compute\.
  }

  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  handle @grpc_compute {
    reverse_proxy compute-broker.record-platform.svc.cluster.local:50061 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # REST API
  handle {
    reverse_proxy https://ingress-nginx-controller.ingress-nginx.svc.cluster.local:443 {
      header_up Host {http.request.host}
      transport http {
        tls
        tls_server_name record.local
        tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
        versions h2 h1
      }
    }
  }
}

:5000 {
  # Internal h2c port for gRPC testing
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_compute {
    protocol grpc
    path_regexp ^/compute\.
  }

  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  handle @grpc_compute {
    reverse_proxy compute-broker.record-platform.svc.cluster.local:50061 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }
}

https://:443 {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }
  handle_path /_caddy/healthz {
    respond "ok" 200
  }
}
```

### 8.2 Working gRPC Test Command

**Proven working grpcurl command**:

```bash
# Via h2c port (most reliable)
kubectl -n ingress-nginx port-forward pod/$(kubectl -n ingress-nginx get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}') 5000:5000 &

grpcurl -plaintext \
  -import-path ./proto \
  -proto proto/compute.proto \
  -d '{}' \
  -max-time 10 \
  127.0.0.1:5000 \
  compute.ComputeService/HealthCheck

# Via TLS (if h2c fails)
grpcurl -insecure \
  -H "Host: record.local" \
  -authority "record.local" \
  -H "TE: trailers" \
  -H "Content-Type: application/grpc" \
  -import-path ./proto \
  -proto proto/compute.proto \
  -d '{}' \
  -max-time 10 \
  127.0.0.1:8443 \
  compute.ComputeService/HealthCheck
```

### 8.3 Working HTTP/2 & HTTP/3 Test Commands

**Proven working curl commands**:

```bash
# HTTP/2 test
curl -k -I --http2 \
  --resolve "record.local:8443:127.0.0.1" \
  -H "Host: record.local" \
  --max-time 10 \
  "https://record.local:8443/_caddy/healthz"

# HTTP/3 test (requires UDP port forwarding on macOS)
curl -k -I --http3-only \
  --resolve "record.local:443:127.0.0.1" \
  -H "Host: record.local" \
  --max-time 10 \
  "https://record.local/_caddy/healthz"
```

---

## Quick Reference

### Essential Commands

```bash
# Check Caddy status
kubectl -n ingress-nginx get pods -l app=caddy-h3

# Check Caddy logs
kubectl -n ingress-nginx logs -l app=caddy-h3 --tail=100

# Restart Caddy
kubectl -n ingress-nginx rollout restart deploy/caddy-h3

# Test health check
curl -k -I --http2 https://record.local:8443/_caddy/healthz

# Test gRPC (via port forward)
kubectl -n ingress-nginx port-forward pod/$(kubectl -n ingress-nginx get pod -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}') 5000:5000 &
grpcurl -plaintext -import-path ./proto -proto proto/compute.proto -d '{}' 127.0.0.1:5000 compute.ComputeService/HealthCheck

# Check service endpoints
kubectl -n record-platform get endpoints api-gateway

# Validate Caddyfile
kubectl -n ingress-nginx exec -it deploy/caddy-h3 -- caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
```

### Troubleshooting Flow

1. **Health check fails** → Run `scripts/diag-caddy-h3.sh`
2. **gRPC fails** → Check service is running, test via port 5000
3. **HTTP/2 works but HTTP/3 fails** → Check UDP port forwarding (macOS)
4. **502 Bad Gateway** → Check service endpoints, test direct connection
5. **Service not found** → Check service selector matches pod labels

---

## Notes

1. **macOS UDP Limitation**: HTTP/3 requires UDP port forwarding (see section 2.4) or use port 8443 directly

2. **Port Conflicts**: If port 443 is in use, Caddy can use port 8443 (see section 6.2)

3. **TLS Trust**: In development, use HTTP upstream to avoid CA trust issues (see section 6.3)

4. **gRPC Testing**: Always test via port 5000 (h2c) first, then fallback to port 8443 (TLS)

5. **Service Discovery**: All services use Kubernetes DNS (e.g., `compute-broker.record-platform.svc.cluster.local:50061`)

6. **Health Checks**: All services should implement `/healthz` endpoint for Kubernetes probes

7. **Timeout Handling**: Always use timeouts in test scripts to prevent hanging

8. **Graceful Degradation**: Services should continue working even if Caddy/Kafka/Redis is temporarily unavailable

