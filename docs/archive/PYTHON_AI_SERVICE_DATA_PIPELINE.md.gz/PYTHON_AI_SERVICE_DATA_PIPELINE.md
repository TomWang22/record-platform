# Python AI Service Data Pipeline Documentation

## Overview

The Python AI Service now includes a comprehensive data pipeline that ingests data from the analytics service and provides AI-powered recommendations for selling, buying, negotiation, and bidding.

## Architecture

```
┌─────────────────┐
│ Analytics       │
│ Service         │───┐
└─────────────────┘   │
                      │
┌─────────────────┐   │   ┌──────────────────┐
│ Kafka           │◄──┼───┤ Data Pipeline    │
│ (Events)        │   │   │ (Ingestion)      │
└─────────────────┘   │   └──────────────────┘
                      │           │
┌─────────────────┐   │           │
│ Redis            │◄──┼───────────┤
│ (Cache)          │   │           │
└─────────────────┘   │           │
                      │           ▼
                      │   ┌──────────────────┐
                      └───┤ Python AI        │
                          │ Service          │
                          │ (AI Advisors)    │
                          └──────────────────┘
                                  │
                                  ▼
                          ┌──────────────────┐
                          │ API Endpoints    │
                          │ - Selling       │
                          │ - Buying        │
                          │ - Negotiation   │
                          │ - Bidding       │
                          └──────────────────┘
```

## Data Pipeline Components

### 1. Data Ingestion (`data_pipeline.py`)

The data pipeline module handles:
- **Analytics Service Integration**: Fetches price trends, similar searches, user history
- **Kafka Consumer**: Listens to real-time analytics events
- **Redis Caching**: Caches enriched data for faster responses
- **Event Publishing**: Publishes AI events back to Kafka

#### Key Functions

- `ingest_analytics_data(query, user_id)`: Fetches comprehensive data from analytics service
- `fetch_price_trend(query, days)`: Gets price trend data
- `fetch_similar_searches(query, user_id, limit)`: Gets similar search recommendations
- `fetch_trending_searches(days, limit)`: Gets trending searches
- `predict_price_from_analytics(items)`: Gets price predictions

### 2. AI Advisors (`ai_advisor.py`)

Four specialized advisor classes:

#### SellingAdvisor
Provides advice for listing records:
- Recommended listing price
- Market analysis (demand level, price trend, competition)
- Pricing strategy (premium, market_price, competitive)
- Timing recommendations (sell now, wait, etc.)

#### BuyingAdvisor
Provides advice for purchasing records:
- Fair price estimate
- Deal assessment (is it a good deal?)
- Alternative recommendations
- Best time to buy

#### NegotiationAdvisor
Provides advice for negotiations (both buyer and seller):
- Negotiation strategy
- Price range recommendations
- Talking points based on market data
- Counter-offer suggestions

#### BiddingAdvisor
Provides advice for auction bidding:
- Should you bid? (yes/no/caution)
- Maximum recommended bid
- Bidding strategy (aggressive/moderate/patient)
- Risk assessment

## API Endpoints

### 1. Selling Advice

**Endpoint**: `POST /ai/selling-advice`

**Request Body**:
```json
{
  "query": "The Beatles Abbey Road",
  "record_grade": "NM",
  "sleeve_grade": "VG+",
  "user_id": "user123",
  "current_price": 25.00
}
```

**Response**:
```json
{
  "query": "The Beatles Abbey Road",
  "recommended_price": 28.50,
  "market_analysis": {
    "demand_level": "high",
    "price_trend": "increasing",
    "competition": "medium"
  },
  "pricing_strategy": "premium",
  "timing": {
    "best_time": "wait_1_2_weeks",
    "reason": "Prices are trending upward, consider waiting"
  },
  "confidence": "medium",
  "data_sources": {
    "price_trend": true,
    "similar_searches": true,
    "analytics_prediction": true
  }
}
```

### 2. Buying Advice

**Endpoint**: `POST /ai/buying-advice`

**Request Body**:
```json
{
  "query": "Pink Floyd Dark Side of the Moon",
  "max_budget": 30.00,
  "user_id": "user123",
  "urgency": "normal"
}
```

**Response**:
```json
{
  "query": "Pink Floyd Dark Side of the Moon",
  "fair_price": 25.00,
  "max_budget": 30.00,
  "deal_assessment": {
    "fair_price": 25.00,
    "is_good_deal": true,
    "price_vs_market": "fair"
  },
  "alternatives": [
    {
      "query": "Pink Floyd Wish You Were Here",
      "similarity": 0.85,
      "estimated_price": 22.00
    }
  ],
  "best_time": {
    "recommendation": "buy_now",
    "reason": "Prices are rising, buy soon"
  },
  "urgency": "normal",
  "confidence": "medium"
}
```

### 3. Negotiation Advice

**Endpoint**: `POST /ai/negotiation-advice`

**Request Body**:
```json
{
  "query": "Led Zeppelin IV",
  "role": "buyer",
  "current_price": 30.00,
  "target_price": 25.00,
  "user_id": "user123"
}
```

**Response**:
```json
{
  "query": "Led Zeppelin IV",
  "role": "buyer",
  "current_price": 30.00,
  "market_price": 25.00,
  "target_price": 25.00,
  "negotiation_range": {
    "min": 21.25,
    "max": 23.75,
    "ideal": 22.50
  },
  "negotiation_stance": "moderate",
  "strategy": "Negotiate for fair market price",
  "talking_points": [
    "Recent market prices have been trending upward"
  ],
  "counter_offers": [
    {
      "amount": 22.50,
      "reason": "10% below market price - fair starting point"
    },
    {
      "amount": 21.25,
      "reason": "15% below market price - aggressive but reasonable"
    }
  ],
  "confidence": "medium"
}
```

### 4. Bidding Advice

**Endpoint**: `POST /ai/bidding-advice`

**Request Body**:
```json
{
  "query": "The Rolling Stones Sticky Fingers",
  "current_bid": 20.00,
  "auction_end_time": "2025-12-05T18:00:00Z",
  "user_id": "user123",
  "max_budget": 30.00
}
```

**Response**:
```json
{
  "query": "The Rolling Stones Sticky Fingers",
  "current_bid": 20.00,
  "market_price": 25.00,
  "max_recommended_bid": 23.75,
  "max_budget": 30.00,
  "should_bid": {
    "recommendation": "yes",
    "reason": "Current bid ($20.00) is below market price ($25.00)",
    "confidence": "high"
  },
  "bidding_strategy": {
    "approach": "moderate",
    "increment": 0.48,
    "max_bid": 23.75,
    "tactics": [
      "Monitor auction closely",
      "Prepare final bid strategy"
    ]
  },
  "risk_assessment": {
    "level": "low",
    "factors": [
      "Good price opportunity"
    ]
  },
  "auction_end_time": "2025-12-05T18:00:00",
  "confidence": "medium"
}
```

## Integration with Services

### Listings Service (Selling)

The listings service can call `/ai/selling-advice` when a user creates a listing:

```python
# In listings service
response = await http_client.post(
    "http://python-ai-service:5005/ai/selling-advice",
    json={
        "query": listing.title,
        "record_grade": listing.record_grade,
        "sleeve_grade": listing.sleeve_grade,
        "user_id": user_id,
        "current_price": listing.price,
    }
)
advice = response.json()
# Use advice.recommended_price as suggested listing price
```

### Shopping Service (Buying)

The shopping service can call `/ai/buying-advice` when a user views a product:

```python
# In shopping service
response = await http_client.post(
    "http://python-ai-service:5005/ai/buying-advice",
    json={
        "query": product.title,
        "max_budget": user_budget,
        "user_id": user_id,
        "urgency": "normal",
    }
)
advice = response.json()
# Display advice.fair_price and advice.deal_assessment
```

### Social Service (Negotiation)

The social service can call `/ai/negotiation-advice` during messaging:

```python
# In social service
response = await http_client.post(
    "http://python-ai-service:5005/ai/negotiation-advice",
    json={
        "query": listing.title,
        "role": "buyer",  # or "seller"
        "current_price": current_offer,
        "target_price": desired_price,
        "user_id": user_id,
    }
)
advice = response.json()
# Show advice.counter_offers and advice.talking_points
```

### Auction Monitor (Bidding)

The auction monitor can call `/ai/bidding-advice` for each auction:

```python
# In auction monitor
response = await http_client.post(
    "http://python-ai-service:5005/ai/bidding-advice",
    json={
        "query": auction.title,
        "current_bid": auction.current_bid,
        "auction_end_time": auction.end_time.isoformat(),
        "user_id": user_id,
        "max_budget": user_max_budget,
    }
)
advice = response.json()
# Use advice.should_bid.recommendation and advice.max_recommended_bid
```

## Configuration

### Environment Variables

```bash
# Analytics service URL
ANALYTICS_URL=http://analytics-service.record-platform.svc.cluster.local:4004

# Kafka configuration
KAFKA_BROKER=kafka-external.record-platform.svc.cluster.local:9092
ENABLE_KAFKA=true

# Redis configuration
REDIS_URL=redis://redis.record-platform.svc.cluster.local:6379/0
```

### Kafka Topics

The service consumes from:
- `analytics-predictions`: Price prediction events
- `analytics-searches`: Search logging events

The service publishes to:
- `ai-events`: AI advisor events (selling, buying, negotiation, bidding)

## Caching Strategy

- **Ingested Data**: Cached for 10 minutes (600 seconds)
- **Price Trends**: Cached for 5 minutes (300 seconds)
- **Similar Searches**: Cached for 10 minutes (600 seconds)

Cache keys follow the pattern:
- `ai:ingest:{query}:{user_id}`
- `ai:trend:{query}`
- `ai:similar:{query}:{user_id}`

## Error Handling

All endpoints gracefully handle:
- Analytics service unavailability (returns partial data)
- Kafka connection failures (continues without event publishing)
- Redis connection failures (skips caching, continues processing)

## Performance Considerations

- **Parallel Data Fetching**: Uses `asyncio.gather()` to fetch multiple data sources concurrently
- **Caching**: Reduces analytics service load and improves response times
- **Kafka Async Processing**: Non-blocking event processing
- **Connection Pooling**: Reuses HTTP and Redis connections

## Monitoring

All endpoints expose Prometheus metrics:
- `ai_http_requests_total{route, code}`: Request counts by route and status code

Monitor:
- Response times
- Cache hit rates
- Analytics service availability
- Kafka event processing

## Future Enhancements

1. **Machine Learning Models**: Train models on historical data for better predictions
2. **Sentiment Analysis**: Analyze user messages for negotiation context
3. **Market Timing**: More sophisticated timing recommendations based on historical patterns
4. **Personalization**: User-specific recommendations based on purchase history
5. **A/B Testing**: Test different recommendation strategies

