# Reference Files for gRPC, HTTP/2, HTTP/3 Implementation

This document contains the **complete file contents** of key files from this project that demonstrate gRPC, HTTP/2, HTTP/3, Docker workarounds, and Caddyfile configuration. Use these as reference for implementing similar patterns in other projects.

---

## 1. Core Configuration Files

### Caddyfile (Primary Configuration)

**File**: `Caddyfile`

```caddyfile
{
  admin localhost:2019
}

# Primary vhost
https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  # Health check endpoint
  handle_path /_caddy/healthz {
    respond "ok" 200
  }

  # gRPC matchers - route by service name in path
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_records {
    protocol grpc
    path_regexp ^/records\.
  }
  @grpc_social {
    protocol grpc
    path_regexp ^/social\.
  }
  @grpc_listings {
    protocol grpc
    path_regexp ^/listings\.
  }
  @grpc_analytics {
    protocol grpc
    path_regexp ^/analytics\.
  }
  @grpc_shopping {
    protocol grpc
    path_regexp ^/shopping\.
  }
  @grpc_auction_monitor {
    protocol grpc
    path_regexp ^/auction_monitor\.|^/auction-monitor\.
  }
  @grpc_python_ai {
    protocol grpc
    path_regexp ^/python_ai\.|^/python-ai\.
  }

  # Route auth-service gRPC requests
  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route records-service gRPC requests
  handle @grpc_records {
    reverse_proxy records-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route social-service gRPC requests
  handle @grpc_social {
    reverse_proxy social-service.record-platform.svc.cluster.local:50056 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route listings-service gRPC requests
  handle @grpc_listings {
    reverse_proxy listings-service.record-platform.svc.cluster.local:50057 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route analytics-service gRPC requests
  handle @grpc_analytics {
    reverse_proxy analytics-service.record-platform.svc.cluster.local:50054 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route shopping-service gRPC requests
  handle @grpc_shopping {
    reverse_proxy shopping-service.record-platform.svc.cluster.local:50058 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route auction-monitor gRPC requests
  handle @grpc_auction_monitor {
    reverse_proxy auction-monitor.record-platform.svc.cluster.local:50059 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route python-ai-service gRPC requests
  handle @grpc_python_ai {
    reverse_proxy python-ai-service.record-platform.svc.cluster.local:50060 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # REST API requests: route through nginx ingress (as before)
  handle {
    reverse_proxy https://ingress-nginx-controller.ingress-nginx.svc.cluster.local:443 {
      header_up Host {http.request.host}
      transport http {
        tls
        tls_server_name record.local
        tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
        versions h2 h1
      }
    }
  }
}

# FIX #1: Internal h2c port for gRPC tests (bypasses TLS)
:5000 {
  # gRPC matchers - route by service name in path
  @grpc_auth {
    protocol grpc
    path_regexp ^/auth\.
  }
  @grpc_records {
    protocol grpc
    path_regexp ^/records\.
  }
  @grpc_social {
    protocol grpc
    path_regexp ^/social\.
  }
  @grpc_listings {
    protocol grpc
    path_regexp ^/listings\.
  }
  @grpc_analytics {
    protocol grpc
    path_regexp ^/analytics\.
  }
  @grpc_shopping {
    protocol grpc
    path_regexp ^/shopping\.
  }
  @grpc_auction_monitor {
    protocol grpc
    path_regexp ^/auction_monitor\.|^/auction-monitor\.
  }
  @grpc_python_ai {
    protocol grpc
    path_regexp ^/python_ai\.|^/python-ai\.
  }

  # Route auth-service gRPC requests
  handle @grpc_auth {
    reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route records-service gRPC requests
  handle @grpc_records {
    reverse_proxy records-service.record-platform.svc.cluster.local:50051 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route social-service gRPC requests
  handle @grpc_social {
    reverse_proxy social-service.record-platform.svc.cluster.local:50056 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route listings-service gRPC requests
  handle @grpc_listings {
    reverse_proxy listings-service.record-platform.svc.cluster.local:50057 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route analytics-service gRPC requests
  handle @grpc_analytics {
    reverse_proxy analytics-service.record-platform.svc.cluster.local:50054 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route shopping-service gRPC requests
  handle @grpc_shopping {
    reverse_proxy shopping-service.record-platform.svc.cluster.local:50058 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route auction-monitor gRPC requests
  handle @grpc_auction_monitor {
    reverse_proxy auction-monitor.record-platform.svc.cluster.local:50059 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }

  # Route python-ai-service gRPC requests
  handle @grpc_python_ai {
    reverse_proxy python-ai-service.record-platform.svc.cluster.local:50060 {
      header_up Host {http.request.host}
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      transport http {
        versions h2c
      }
    }
  }
}

# Catch-all for probes without SNI
https://:443 {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }
  # Health check endpoint for probes without SNI
  handle_path /_caddy/healthz {
    respond "ok" 200
  }
}
```

**Key Features**:
- `admin localhost:2019` - Enables zero-downtime CA rotation
- `protocol grpc` matcher - Detects gRPC requests
- `path_regexp` - Service-specific routing
- `transport http { versions h2c }` - gRPC over HTTP/2 cleartext
- `header_up TE trailers` - Required for gRPC trailers
- Port 5000 - Internal h2c port for testing (bypasses TLS)

---

### Caddy Kubernetes Deployment

**File**: `infra/k8s/caddy-h3-deploy.yaml`

```yaml
# FILE: k8s/caddy-h3-deploy.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: caddy-h3
  namespace: ingress-nginx
spec:
  strategy: { type: Recreate }
  replicas: 1
  selector: { matchLabels: { app: caddy-h3 } }
  template:
    metadata: { labels: { app: caddy-h3 } }
    spec:
      hostNetwork: true
      dnsPolicy: ClusterFirstWithHostNet
      terminationGracePeriodSeconds: 5
      containers:
      - name: caddy
        image: caddy:2.8
        # root needed to bind 443; only CAP_NET_BIND_SERVICE elevated
        securityContext:
          runAsNonRoot: false
          capabilities: { add: ["NET_BIND_SERVICE"] }
        ports:
        - { name: https, containerPort: 443, protocol: TCP }
        - { name: https-udp, containerPort: 443, protocol: UDP }
        - { name: grpc-h2c, containerPort: 5000, protocol: TCP }
        volumeMounts:
        - { name: caddy-conf,  mountPath: /etc/caddy }                       # Caddyfile
        - { name: caddy-certs, mountPath: /etc/caddy/certs, readOnly: true } # tls.crt,tls.key
        - { name: caddy-ca,    mountPath: /etc/caddy/ca,    readOnly: true } # dev-root.pem
        readinessProbe:
          httpGet:
            scheme: HTTPS
            path: /_caddy/healthz
            port: 443
          periodSeconds: 5
          failureThreshold: 6
        livenessProbe:
          tcpSocket: { port: 443 }
          initialDelaySeconds: 3
          periodSeconds: 10
          failureThreshold: 3
      volumes:
      - name: caddy-conf
        configMap:
          name: caddy-h3
          items: [{ key: Caddyfile, path: Caddyfile }]
      - name: caddy-certs
        secret:
          secretName: record-local-tls
          items:
            - { key: tls.crt, path: tls.crt }
            - { key: tls.key, path: tls.key }
      - name: caddy-ca
        secret:
          secretName: dev-root-ca
          items:
            - { key: dev-root.pem, path: dev-root.pem }
```

**Key Features**:
- `hostNetwork: true` - Required for binding to host ports (443)
- UDP port 443 - Required for HTTP/3 (QUIC)
- Port 5000 - Internal h2c port for gRPC testing
- Volume mounts for Caddyfile, certificates, and CA
- Health checks for readiness and liveness

---

## 2. gRPC Implementation Files

### gRPC Client Library

**File**: `services/common/src/grpc-clients.ts`

```typescript
/* cspell:ignore grpc */
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import * as fs from "fs";
import { resolveProtoPath } from "./proto.js";

function buildCredentials() {
  const caPath =
    process.env.GRPC_CA_CERT ||
    process.env.INTERNAL_CA_CERT ||
    process.env.SHARED_CA_CERT ||
    "";
  if (caPath && fs.existsSync(caPath)) {
    const rootCert = fs.readFileSync(caPath);
    return grpc.credentials.createSsl(rootCert);
  }

  if (process.env.NODE_ENV === "production") {
    return grpc.credentials.createSsl();
  }

  return grpc.credentials.createInsecure();
}

// Load auth proto
const AUTH_PROTO_PATH = resolveProtoPath("auth.proto");
const authPackageDefinition = protoLoader.loadSync(AUTH_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const authProto = grpc.loadPackageDefinition(authPackageDefinition) as any;

// Load records proto
const RECORDS_PROTO_PATH = resolveProtoPath("records.proto");
const recordsPackageDefinition = protoLoader.loadSync(RECORDS_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const recordsProto = grpc.loadPackageDefinition(recordsPackageDefinition) as any;

// Load social proto
const SOCIAL_PROTO_PATH = resolveProtoPath("social.proto");
const socialPackageDefinition = protoLoader.loadSync(SOCIAL_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const socialProto = grpc.loadPackageDefinition(socialPackageDefinition) as any;

// Load listings proto
const LISTINGS_PROTO_PATH = resolveProtoPath("listings.proto");
const listingsPackageDefinition = protoLoader.loadSync(LISTINGS_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const listingsProto = grpc.loadPackageDefinition(listingsPackageDefinition) as any;

// Load shopping proto
const SHOPPING_PROTO_PATH = resolveProtoPath("shopping.proto");
const shoppingPackageDefinition = protoLoader.loadSync(SHOPPING_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const shoppingProto = grpc.loadPackageDefinition(shoppingPackageDefinition) as any;

// Load auction-monitor proto
const AUCTION_MONITOR_PROTO_PATH = resolveProtoPath("auction-monitor.proto");
const auctionMonitorPackageDefinition = protoLoader.loadSync(AUCTION_MONITOR_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const auctionMonitorProto = grpc.loadPackageDefinition(auctionMonitorPackageDefinition) as any;

// Load python-ai proto
const PYTHON_AI_PROTO_PATH = resolveProtoPath("python-ai.proto");
const pythonAiPackageDefinition = protoLoader.loadSync(PYTHON_AI_PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const pythonAiProto = grpc.loadPackageDefinition(pythonAiPackageDefinition) as any;

// Create gRPC clients
export function createAuthClient(address: string = "auth-service:50051") {
  const AuthService = authProto.auth.AuthService;
  return new AuthService(
    address,
    buildCredentials()
  );
}

export function createRecordsClient(address: string = "records-service:50051") {
  const RecordsService = recordsProto.records.RecordsService;
  return new RecordsService(
    address,
    buildCredentials()
  );
}

export function createSocialClient(address: string = "social-service:50056") {
  const SocialService = socialProto.social.SocialService;
  return new SocialService(
    address,
    buildCredentials()
  );
}

export function createListingsClient(address: string = "listings-service:50057") {
  const ListingsService = listingsProto.listings.ListingsService;
  return new ListingsService(
    address,
    buildCredentials()
  );
}

export function createShoppingClient(address: string = "shopping-service:50058") {
  const ShoppingService = shoppingProto.shopping.ShoppingService;
  return new ShoppingService(
    address,
    buildCredentials()
  );
}

export function createAuctionMonitorClient(address: string = "auction-monitor:50059") {
  const AuctionMonitorService = auctionMonitorProto.auction_monitor.AuctionMonitorService;
  return new AuctionMonitorService(
    address,
    buildCredentials()
  );
}

export function createPythonAIClient(address: string = "python-ai-service:50060") {
  const PythonAIService = pythonAiProto.python_ai.PythonAIService;
  return new PythonAIService(
    address,
    buildCredentials()
  );
}

// Helper to promisify gRPC calls with timeout
export function promisifyGrpcCall<T>(
  client: any,
  method: string,
  request: any,
  timeoutMs: number = 10000 // Default 10 second timeout
): Promise<T> {
  return new Promise((resolve, reject) => {
    let completed = false;
    const timeout = setTimeout(() => {
      if (!completed) {
        completed = true;
        reject(new Error(`gRPC call ${method} timed out after ${timeoutMs}ms`));
      }
    }, timeoutMs);

    try {
      client[method](request, (error: any, response: T) => {
        if (completed) return;
        completed = true;
        clearTimeout(timeout);
        if (error) {
          reject(error);
        } else {
          resolve(response);
        }
      });
    } catch (err) {
      if (completed) return;
      completed = true;
      clearTimeout(timeout);
      reject(err);
    }
  });
}
```

**Key Patterns**:
- `protoLoader.loadSync()` - Loads proto files with options
- `grpc.loadPackageDefinition()` - Creates service stubs
- `buildCredentials()` - Environment-based TLS/insecure selection
- `promisifyGrpcCall()` - Wraps callback-based gRPC calls with timeout

---

### gRPC Server Implementation

**File**: `services/auth-service/src/grpc-server.ts` (excerpt - first 275 lines showing key patterns)

```typescript
/* cspell:ignore grpc */
import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import { PrismaClient } from "../prisma/generated/client";
import { signJwt, verifyJwt } from "@common/utils/auth";
import * as bcrypt from "bcryptjs";
import { randomUUID } from "node:crypto";
import * as fs from "fs";
import { resolveProtoPath } from "@common/utils/proto";

const prisma = new PrismaClient();

// Load proto file
const PROTO_PATH = resolveProtoPath("auth.proto");
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const authProto = grpc.loadPackageDefinition(packageDefinition) as any;

// gRPC logging middleware
function withLogging(handler: any, methodName: string) {
  return async (call: any, callback: any) => {
    const start = Date.now();
    console.log(`[gRPC] ${methodName} called`);
    try {
      await handler(call, callback);
      const duration = Date.now() - start;
      console.log(`[gRPC] ${methodName} completed in ${duration}ms`);
    } catch (err: any) {
      const duration = Date.now() - start;
      console.error(`[gRPC] ${methodName} failed after ${duration}ms:`, err);
      callback({
        code: grpc.status.INTERNAL,
        message: err.message || "internal error",
      });
    }
  };
}

// Implement AuthService
const authService = {
  async Register(call: any, callback: any) {
    try {
      const { email, password } = call.request;
      if (!email || !password) {
        return callback({
          code: grpc.status.INVALID_ARGUMENT,
          message: "email and password required",
        });
      }
      // ... implementation ...
      callback(null, { token, user: { ... } });
    } catch (error: any) {
      console.error("[gRPC] Register error:", error);
      callback({
        code: grpc.status.INTERNAL,
        message: error.message || "internal error",
      });
    }
  },
  // ... other methods ...
};

// Create and start gRPC server with HTTP/2 only
export function startGrpcServer(port: number = 50051) {
  const server = new grpc.Server({
    'grpc.keepalive_time_ms': 30000,
    'grpc.keepalive_timeout_ms': 5000,
    'grpc.keepalive_permit_without_calls': 1,
    'grpc.http2.max_pings_without_data': 0,
    'grpc.http2.min_time_between_pings_ms': 10000,
    'grpc.http2.min_ping_interval_without_data_ms': 300000,
  });
  
  server.addService(authProto.auth.AuthService.service, {
    Register: withLogging(authService.Register, "Register"),
    Authenticate: withLogging(authService.Authenticate, "Authenticate"),
    ValidateToken: withLogging(authService.ValidateToken, "ValidateToken"),
    RefreshToken: withLogging(authService.RefreshToken, "RefreshToken"),
    HealthCheck: withLogging(authService.HealthCheck, "HealthCheck"),
  });

  // Enable gRPC reflection for tooling (grpcurl, etc.)
  if (process.env.ENABLE_GRPC_REFLECTION !== "false") {
    try {
      const { enableReflection } = require("@common/utils/grpc-reflection");
      enableReflection(server, [PROTO_PATH], ["auth.AuthService"]);
    } catch (err) {
      console.warn("[gRPC] Failed to enable reflection:", err);
    }
  }

  // Try to load TLS certs (for production with ALPN = h2)
  let credentials: grpc.ServerCredentials;
  const keyPath = process.env.TLS_KEY_PATH || "/etc/certs/tls.key";
  const certPath = process.env.TLS_CERT_PATH || "/etc/certs/tls.crt";
  
  if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
    const key = fs.readFileSync(keyPath);
    const cert = fs.readFileSync(certPath);
    credentials = grpc.ServerCredentials.createSsl(
      null, // root certs (null = no client cert required)
      [{ private_key: key, cert_chain: cert }],
      false as any
    );
    console.log("[gRPC] Starting secure HTTP/2-only server with ALPN = h2");
  } else {
    console.warn("[gRPC] TLS certs not found, starting insecure server (dev only)");
    credentials = grpc.ServerCredentials.createInsecure();
  }

  server.bindAsync(
    `0.0.0.0:${port}`,
    credentials,
    (error, actualPort) => {
      if (error) {
        console.error("[gRPC] Server bind error:", error);
        return;
      }
      server.start();
      console.log(`[gRPC] Server started on port ${actualPort} (HTTP/2 only, no HTTP/1.1 fallback)`);
    }
  );

  return server;
}
```

**Key Patterns**:
- `grpc.Server()` - Creates server with HTTP/2 keepalive settings
- `server.addService()` - Registers service methods
- `server.bindAsync()` - Binds to port with credentials
- Error handling with `grpc.status` codes
- Logging middleware wrapper

---

### API Gateway gRPC Integration

**File**: `services/api-gateway/src/server.ts` (excerpt - key patterns)

```typescript
import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import * as grpc from "@grpc/grpc-js";
import { createProxyMiddleware } from "http-proxy-middleware";

import {
  createAuthClient,
  createRecordsClient,
  createSocialClient,
  createListingsClient,
  createShoppingClient,
  createAuctionMonitorClient,
  createPythonAIClient,
  promisifyGrpcCall,
} from "@common/utils/grpc-clients";

const AUTH_GRPC_TARGET = process.env.AUTH_GRPC_TARGET || "auth-service:50051";
const authGrpcClient = createAuthClient(AUTH_GRPC_TARGET);
const recordsGrpcClient = createRecordsClient(RECORDS_GRPC_TARGET);
// ... other clients ...

const grpcStatusToHttp: Record<number, number> = {
  [grpc.status.INVALID_ARGUMENT ?? 3]: 400,
  [grpc.status.UNAUTHENTICATED ?? 16]: 401,
  [grpc.status.PERMISSION_DENIED ?? 7]: 403,
  [grpc.status.NOT_FOUND ?? 5]: 404,
  [grpc.status.ALREADY_EXISTS ?? 6]: 409,
  [grpc.status.UNAVAILABLE ?? 14]: 503,
};

function handleGrpcError(res: Response, err: any) {
  const status = grpcStatusToHttp[err?.code ?? -1] ?? 500;
  const message = err?.details || err?.message || "grpc error";
  res.status(status).json({ error: message });
}

function mapHttpRecordToGrpcInput(body: Record<string, any> | undefined | null) {
  if (!body) return {};
  const out: Record<string, any> = {};
  for (const [key, value] of Object.entries(body)) {
    if (value === undefined) continue;
    const snake = key.includes("_")
      ? key
      : key.replace(/([A-Z])/g, "_$1").toLowerCase();
    out[snake] = value;
  }
  return out;
}

// Example: HTTP endpoint that calls gRPC
app.post("/api/auth/register", jsonParser, async (req: AuthedRequest, res: Response) => {
  try {
    const grpcRequest = mapHttpRecordToGrpcInput(req.body);
    const response = await promisifyGrpcCall(
      authGrpcClient,
      "Register",
      grpcRequest,
      20000 // 20 second timeout for registration
    );
    res.status(201).json({
      token: response.token,
      user: {
        id: response.user.id,
        email: response.user.email,
        created_at: response.user.created_at,
      },
    });
  } catch (err: any) {
    handleGrpcError(res, err);
  }
});
```

**Key Patterns**:
- Creating gRPC clients per service
- Converting HTTP request body to gRPC format (camelCase → snake_case)
- Mapping gRPC status codes to HTTP status codes
- Using `promisifyGrpcCall` with timeout
- Error handling with `handleGrpcError()`

---

## 3. Protocol Buffer Definitions

### Proto File Example

**File**: `proto/auth.proto`

```protobuf
syntax = "proto3";

package auth;

option go_package = "github.com/yourorg/record-platform/proto/auth";

// Auth service for gRPC
service AuthService {
  // Authenticate user
  rpc Authenticate(AuthenticateRequest) returns (AuthenticateResponse);
  // Register user
  rpc Register(RegisterRequest) returns (RegisterResponse);
  
  // Validate token
  rpc ValidateToken(ValidateTokenRequest) returns (ValidateTokenResponse);
  
  // Refresh token
  rpc RefreshToken(RefreshTokenRequest) returns (RefreshTokenResponse);
  
  // Health check
  rpc HealthCheck(HealthCheckRequest) returns (HealthCheckResponse);
}

message AuthenticateRequest {
  string email = 1;
  string password = 2;
}

message AuthenticateResponse {
  string token = 1;
  string refresh_token = 2;
  User user = 3;
}

message RegisterRequest {
  string email = 1;
  string password = 2;
}

message RegisterResponse {
  string token = 1;
  User user = 2;
}

message ValidateTokenRequest {
  string token = 1;
}

message ValidateTokenResponse {
  bool valid = 1;
  User user = 2;
}

message RefreshTokenRequest {
  string refresh_token = 1;
}

message RefreshTokenResponse {
  string token = 1;
  string refresh_token = 2;
}

message HealthCheckRequest {}

message HealthCheckResponse {
  bool healthy = 1;
  string version = 2;
}

message User {
  string id = 1;
  string email = 2;
  string created_at = 3;
}
```

**Key Patterns**:
- `syntax = "proto3"` - Use proto3 syntax
- `service ServiceName { rpc MethodName(...) returns (...); }` - Service definition
- `message MessageName { type field = number; }` - Message definition
- Field numbering (1, 2, 3...) - Must be unique and sequential

---

## 4. Testing & Validation

### HTTP/3 Helper Library (MUST-HAVE)

**File**: `scripts/lib/http3.sh`

```bash
#!/usr/bin/env bash

# Shared helpers for issuing HTTP/3 requests against the kind cluster by
# reusing the control-plane node's network namespace. This avoids macOS/Docker
# UDP limitations so QUIC traffic reliably reaches the in-cluster Caddy pod.

_http3_fail() {
  if declare -F fail >/dev/null 2>&1; then
    fail "$1"
  else
    echo "HTTP/3 helper error: $1" >&2
    exit 1
  fi
}

_http3_warn() {
  if declare -F warn >/dev/null 2>&1; then
    warn "$1"
  else
    echo "HTTP/3 helper warning: $1" >&2
  fi
}

_http3_detect_kind_node() {
  local cluster="${HTTP3_KIND_CLUSTER:-${KIND_CLUSTER:-h3}}"
  local node=""
  if command -v kind >/dev/null 2>&1; then
    node="$(kind get nodes --name "$cluster" 2>/dev/null | head -n1 || true)"
    if [[ -z "$node" ]]; then
      node="$(kind get nodes 2>/dev/null | head -n1 || true)"
    fi
  fi
  [[ -n "$node" ]] || return 1
  echo "$node"
}

_HTTP3_RUNNER_READY=""

_http3_ensure_runner() {
  if [[ "$_HTTP3_RUNNER_READY" == "yes" ]]; then
    return 0
  elif [[ "$_HTTP3_RUNNER_READY" == "no" ]]; then
    return 1
  fi

  command -v docker >/dev/null 2>&1 || {
    _HTTP3_RUNNER_READY="no"
    _http3_fail "Docker is required for HTTP/3 tests."
  }

  local node="${HTTP3_KIND_NODE:-}"
  if [[ -z "$node" ]]; then
    node="$(_http3_detect_kind_node)" || {
      _HTTP3_RUNNER_READY="no"
      _http3_fail "Unable to detect kind node; set HTTP3_KIND_NODE manually."
    }
    HTTP3_KIND_NODE="$node"
  fi

  HTTP3_IMAGE="${HTTP3_IMAGE:-alpine/curl-http3}"
  _HTTP3_RUNNER_READY="yes"
}

http3_curl() {
  _http3_ensure_runner || return 1
  # Use timeout to ensure the command doesn't hang indefinitely
  # Docker run with --rm will clean up automatically
  docker run --rm \
    --network "container:${HTTP3_KIND_NODE}" \
    "$HTTP3_IMAGE" \
    curl "$@" || {
    # If curl fails, return with exit code 1
    return 1
  }
}
```

**Key Features**:
- Works around macOS/Docker UDP limitations for QUIC
- Uses Kind node's network namespace
- Auto-detects Kind cluster
- Uses `alpine/curl-http3` Docker image
- Provides `http3_curl()` function for test scripts

**Usage in test scripts**:
```bash
source scripts/lib/http3.sh
http3_curl -k -sS --http3-only --max-time 15 \
  -H "Host: record.local" \
  --resolve "record.local:443:127.0.0.1" \
  "https://record.local/_caddy/healthz"
```

---

### HTTP/2 and HTTP/3 Test Script

**File**: `scripts/test-microservices-http2-http3.sh` (excerpt - key patterns)

```bash
#!/usr/bin/env bash
set -euo pipefail

NS="record-platform"
HOST="${HOST:-record.local}"
CURL_BIN="${CURL_BIN:-/opt/homebrew/opt/curl/bin/curl}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
fail() { echo "❌ $*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/http3.sh
. "$SCRIPT_DIR/lib/http3.sh"

HTTP3_RESOLVE="${HOST}:443:127.0.0.1"

# Test 1: Auth Service - Registration (HTTP/2)
say "Test 1: Auth Service - Registration via HTTP/2 (User 1)"
TEST_EMAIL="microservice-test-$(date +%s)@example.com"
REGISTER_RESPONSE=$("$CURL_BIN" -k -sS -w "\n%{http_code}" --http2 --max-time 15 \
  --resolve "$HOST:8443:127.0.0.1" \
  -H "Host: $HOST" \
  -H "Content-Type: application/json" \
  -X POST "https://$HOST:8443/api/auth/register" \
  -d "{\"email\":\"$TEST_EMAIL\",\"password\":\"test123\"}" 2>&1) || {
  warn "Registration curl command failed (exit code: $?)"
  REGISTER_RESPONSE=""
  REGISTER_CODE="000"
}
REGISTER_CODE=$(echo "$REGISTER_RESPONSE" | tail -1)
if [[ "$REGISTER_CODE" == "201" ]]; then
  TOKEN=$(echo "$REGISTER_RESPONSE" | sed '$d' | grep -o '"token":"[^"]*"' | cut -d'"' -f4 || echo "")
  ok "User 1 registration works via HTTP/2"
fi

# Test 2: Auth Service - Registration (HTTP/3)
say "Test 2: Auth Service - Registration via HTTP/3"
REGISTER_RESPONSE_H3=$(http3_curl -k -sS -w "\n%{http_code}" --http3-only --max-time 15 \
  -H "Host: $HOST" \
  -H "Content-Type: application/json" \
  --resolve "$HTTP3_RESOLVE" \
  -X POST "https://$HOST/api/auth/register" \
  -d "{\"email\":\"test-h3-$(date +%s)@example.com\",\"password\":\"test123\"}" 2>&1)
REGISTER_CODE_H3=$(echo "$REGISTER_RESPONSE_H3" | tail -1)
if [[ "$REGISTER_CODE_H3" == "201" ]]; then
  ok "User registration works via HTTP/3"
fi

# Test 15a: gRPC Health Check - Auth Service
say "Test 15a: gRPC Health Check - Auth Service"
if command -v grpcurl >/dev/null 2>&1; then
  GRPC_AUTH_HEALTH=$(grpcurl -plaintext -max-time 10 \
    -H "Host: $HOST" \
    -d '{}' \
    "$HOST:5000" /auth.AuthService/HealthCheck 2>&1) || GRPC_AUTH_HEALTH=""
  if echo "$GRPC_AUTH_HEALTH" | grep -q "healthy"; then
    ok "gRPC Auth HealthCheck works"
  else
    warn "gRPC Auth HealthCheck failed"
  fi
fi
```

**Key Patterns**:
- `curl --http2` for HTTP/2 testing
- `http3_curl --http3-only` for HTTP/3 testing (uses helper library)
- `grpcurl -plaintext` for gRPC testing
- Service readiness checks before testing
- Comprehensive error handling and reporting

---

### HTTP/2/HTTP/3 Strict TLS Test

**File**: `scripts/test-http2-http3-strict-tls.sh` (excerpt - key patterns)

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-record.local}"
PORT="${PORT:-8443}"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }
fail() { echo "❌ $*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$SCRIPT_DIR/lib/http3.sh"

HTTP3_RESOLVE="${HOST}:443:127.0.0.1"

say "=== Testing HTTP/2, HTTP/3, and Strict TLS ==="

# Test 1: HTTP/2 health check
say "Test 1: HTTP/2 health check"
H2_RESPONSE=$(/opt/homebrew/opt/curl/bin/curl -k -sS -I --http2 --max-time 10 \
  -H "Host: ${HOST}" "https://127.0.0.1:${PORT}/_caddy/healthz" 2>&1) || H2_RESPONSE=""
if echo "$H2_RESPONSE" | head -n1 | grep -qE "200|HTTP/2 200"; then
  ok "HTTP/2 health check works"
else
  fail "HTTP/2 health check failed"
fi

# Test 2: HTTP/3 health check
say "Test 2: HTTP/3 health check"
if http3_curl -k -sS -I --http3-only --max-time 15 \
  -H "Host: ${HOST}" \
  --resolve "$HTTP3_RESOLVE" \
  "https://${HOST}/_caddy/healthz" 2>&1 | head -n1 | grep -q "HTTP/3 200"; then
  ok "HTTP/3 health check works"
else
  warn "HTTP/3 health check failed (QUIC path unavailable)"
fi

# Test 5: Strict TLS - TLS 1.3
say "Test 5: Strict TLS - TLS 1.3"
TLS13_RESPONSE=$(/opt/homebrew/opt/curl/bin/curl -k -sS -I --tlsv1.3 --http2 \
  -H "Host: ${HOST}" "https://127.0.0.1:${PORT}/_caddy/healthz" 2>&1) || TLS13_RESPONSE=""
if echo "$TLS13_RESPONSE" | head -n1 | grep -qE "200|HTTP/2 200"; then
  ok "TLS 1.3 works"
fi

# Test 6: Strict TLS - TLS 1.2
say "Test 6: Strict TLS - TLS 1.2"
TLS12_RESPONSE=$(/opt/homebrew/opt/curl/bin/curl -k -sS -I --tlsv1.2 --http2 \
  -H "Host: ${HOST}" "https://127.0.0.1:${PORT}/_caddy/healthz" 2>&1) || TLS12_RESPONSE=""
if echo "$TLS12_RESPONSE" | head -n1 | grep -qE "200|HTTP/2 200"; then
  ok "TLS 1.2 works"
fi

# Test 7: Strict TLS - TLS 1.1 should fail
say "Test 7: Strict TLS - TLS 1.1 should be rejected"
TLS11_RESPONSE=$(/opt/homebrew/opt/curl/bin/curl -k -sS -I --tlsv1.1 --http2 \
  -H "Host: ${HOST}" "https://127.0.0.1:${PORT}/_caddy/healthz" 2>&1) || TLS11_RESPONSE=""
if echo "$TLS11_RESPONSE" | grep -qE "error|handshake|protocol|SSL.*error|TLS.*error|unsupported protocol"; then
  ok "TLS 1.1 correctly rejected"
else
  warn "TLS 1.1 was not rejected (strict TLS may not be working)"
fi
```

**Key Patterns**:
- `curl --tlsv1.3` / `curl --tlsv1.2` - Test TLS versions
- `curl --tlsv1.1` - Should fail (strict TLS)
- Validates TLS 1.2/1.3 acceptance and TLS 1.1 rejection

---

### gRPC Test Script

**File**: `scripts/test-grpc-http2-http3.sh` (excerpt - key patterns)

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST="${HOST:-record.local}"
NS="record-platform"

say() { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok() { echo "✅ $*"; }
warn() { echo "⚠️  $*"; }

# Check if grpcurl is available
if ! command -v grpcurl >/dev/null 2>&1; then
  warn "grpcurl not found - some gRPC tests will be skipped"
  SKIP_GRPC=1
else
  SKIP_GRPC=0
  ok "grpcurl found - gRPC tests will run"
fi

# Helper function to run grpcurl with timeout
grpcurl_with_timeout() {
  local timeout_sec="${1:-10}"
  shift
  local cmd=("$@")
  
  if command -v timeout >/dev/null 2>&1; then
    timeout "$timeout_sec" "${cmd[@]}" 2>&1
  elif command -v gtimeout >/dev/null 2>&1; then
    gtimeout "$timeout_sec" "${cmd[@]}" 2>&1
  else
    local pid
    "${cmd[@]}" 2>&1 &
    pid=$!
    (
      sleep "$timeout_sec"
      kill "$pid" 2>/dev/null || true
    ) &
    wait "$pid" 2>/dev/null || echo "grpcurl timeout after ${timeout_sec}s"
  fi
}

# Test gRPC services
if [[ "${SKIP_GRPC:-1}" == "0" ]]; then
  say "Step 10: Testing gRPC Services via HTTP/2..."
  
  # Test Auth Service gRPC
  say "Step 10a: gRPC Auth Service - HealthCheck"
  GRPC_AUTH_HEALTH=$(grpcurl_with_timeout 10 grpcurl -insecure -H "Host: $HOST" \
    -d '{}' \
    "$HOST:8443" /auth.AuthService/HealthCheck) || GRPC_AUTH_HEALTH=""
  if echo "$GRPC_AUTH_HEALTH" | grep -q "healthy"; then
    ok "gRPC Auth HealthCheck works"
  else
    warn "gRPC Auth HealthCheck failed"
  fi
fi
```

**Key Patterns**:
- `grpcurl -insecure` - For testing without TLS
- `grpcurl -plaintext` - For h2c (port 5000)
- Timeout wrapper function
- Service path format: `/package.ServiceName/MethodName`

---

## 5. Docker & Kubernetes Configuration

### Docker Compose (Database Workaround)

**File**: `docker-compose.yml` (excerpt - key patterns)

```yaml
services:
  postgres:
    image: postgres:16-alpine
    environment: { POSTGRES_PASSWORD: postgres }
    restart: unless-stopped
    ports: ["5433:5432"]  # Changed to 5433 to avoid conflict with Postgres.app
    volumes: ["pgdata:/var/lib/postgresql/data"]
    shm_size: 1g
    healthcheck:
      test: ["CMD-SHELL","pg_isready -U postgres"]
      interval: 5s
      timeout: 3s
      retries: 20
      start_period: 10s

  postgres-auth:
    image: postgres:16-alpine
    environment: { POSTGRES_PASSWORD: postgres }
    restart: unless-stopped
    ports: ["5437:5432"]
    volumes: ["pgdata-auth:/var/lib/postgresql/data"]
    healthcheck:
      test: ["CMD-SHELL","pg_isready -U postgres"]
      interval: 5s
      timeout: 3s
      retries: 20
      start_period: 10s

  postgres-social:
    image: postgres:16-alpine
    environment: { POSTGRES_PASSWORD: postgres }
    restart: unless-stopped
    ports: ["5434:5432"]
    volumes: ["pgdata-social:/var/lib/postgresql/data"]
    healthcheck:
      test: ["CMD-SHELL","pg_isready -U postgres"]
      interval: 5s
      timeout: 3s
      retries: 20
      start_period: 10s

  # ... more postgres instances on different ports ...

  redis:
    image: redis:7-alpine
    command: ["redis-server","--save","","--appendonly","no"]
    ports: ["6379:6379"]
    restart: unless-stopped
    healthcheck:
      test: ["CMD","redis-cli","ping"]
      interval: 5s
      timeout: 3s
      retries: 20
      start_period: 5s

  kafka:
    image: confluentinc/cp-kafka:7.5.0
    depends_on:
      zookeeper: { condition: service_healthy }
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_LISTENERS: PLAINTEXT://0.0.0.0:9092,PLAINTEXT_HOST://0.0.0.0:29092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092,PLAINTEXT_HOST://host.docker.internal:29092
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    ports: ["29092:29092"]
    restart: unless-stopped
```

**Key Pattern**: Services in Kubernetes connect to Docker Compose databases using `host.docker.internal:PORT`

**Example connection string**:
```
POSTGRES_URL=postgresql://postgres:postgres@host.docker.internal:5433/records
```

---

### Kubernetes Service Definition

**File**: `infra/k8s/base/auth-service/service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: auth-service
  namespace: record-platform
  labels: { app: auth-service }
spec:
  selector: { app: auth-service }
  ports:
    - name: http
      port: 4001
      targetPort: http
    - name: grpc
      port: 50051
      targetPort: grpc
```

**Key Features**:
- Named ports (`http`, `grpc`) for clarity
- Service discovery via DNS: `auth-service.record-platform.svc.cluster.local`
- Port 4001 for HTTP endpoints
- Port 50051 for gRPC endpoints

---

### Kubernetes Deployment

**File**: `infra/k8s/base/auth-service/deploy.yaml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: auth-service
  namespace: record-platform
  labels: { app: auth-service }
spec:
  replicas: 1
  selector: { matchLabels: { app: auth-service } }
  template:
    metadata:
      labels: { app: auth-service }
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "4001"
        prometheus.io/path: "/metrics"
        linkerd.io/inject: enabled  # Enable Linkerd sidecar injection
    spec:
      containers:
        - name: app
          image: auth-service:dev
          imagePullPolicy: Never
          ports:
            - name: http
              containerPort: 4001
            - name: grpc
              containerPort: 50051
          envFrom:
            - configMapRef: { name: app-config }
            - secretRef:    { name: app-secrets }
          env:
            - name: NODE_ENV
              value: "development"
            - name: GRPC_PORT
              value: "50051"
            - name: ENABLE_GRPC
              value: "true"
          volumeMounts:
            - name: proto-files
              mountPath: /app/proto
              readOnly: true
          readinessProbe:
            httpGet: { path: /healthz, port: http }
            initialDelaySeconds: 10
            periodSeconds: 10
            timeoutSeconds: 5
            failureThreshold: 3
          livenessProbe:
            httpGet: { path: /healthz, port: http }
            initialDelaySeconds: 30
            periodSeconds: 10
            timeoutSeconds: 5
            failureThreshold: 3
      volumes:
        - name: proto-files
          configMap:
            name: proto-files
```

**Key Features**:
- Named container ports matching service ports
- Volume mount for proto files from ConfigMap
- Environment variables for gRPC configuration
- Health checks for readiness and liveness
- Prometheus annotations for metrics scraping

---

## 6. Database Migration Example (MUST-HAVE)

**File**: `infra/db/04-social-schema-upload-type-migration.sql`

```sql
-- Migration: Add upload_type column to forum.posts
-- Run on PostgreSQL port 5434 (social database)

SET ROLE postgres;

-- Add upload_type column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                 WHERE table_schema = 'forum' AND table_name = 'posts' AND column_name = 'upload_type') THEN
    ALTER TABLE forum.posts ADD COLUMN upload_type VARCHAR(32) NOT NULL DEFAULT 'text';
    ALTER TABLE forum.posts ADD CONSTRAINT chk_upload_type CHECK (upload_type IN ('text', 'image', 'video', 'link', 'poll'));
  END IF;
END $$;

-- Add index for upload_type
CREATE INDEX IF NOT EXISTS idx_posts_upload_type ON forum.posts(upload_type);

COMMENT ON COLUMN forum.posts.upload_type IS 'Type of post: text, image, video, link, or poll';

-- GRANTS (ensure postgres user has privileges)
GRANT ALL PRIVILEGES ON SCHEMA forum TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA forum TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA forum TO postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA forum GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES IN SCHEMA forum GRANT ALL ON SEQUENCES TO postgres;
```

**Key Patterns**:
- Idempotent migrations using `IF NOT EXISTS`
- `DO $$ ... END $$` blocks for conditional logic
- Index creation for performance
- Column comments for documentation
- Grant statements for permissions

---

## Quick Reference Checklist

When implementing gRPC + HTTP/2/HTTP/3 in a new project:

### Setup Phase
- [ ] `Caddyfile` - Configure Caddy for gRPC routing and HTTP/2/HTTP/3
- [ ] `infra/k8s/caddy-h3-deploy.yaml` - Deploy Caddy in Kubernetes
- [ ] `proto/*.proto` - Define your gRPC services

### Implementation Phase
- [ ] `services/common/src/grpc-clients.ts` - Create gRPC clients
- [ ] `services/auth-service/src/grpc-server.ts` - Implement gRPC servers
- [ ] `services/api-gateway/src/server.ts` - Integrate gRPC in API Gateway

### Testing Phase
- [ ] `scripts/lib/http3.sh` - **MUST-HAVE** - HTTP/3 helper library
- [ ] `scripts/test-microservices-http2-http3.sh` - Test HTTP/2/HTTP/3
- [ ] `scripts/test-http2-http3-strict-tls.sh` - Validate TLS
- [ ] `scripts/test-grpc-http2-http3.sh` - Test gRPC

### Deployment Phase
- [ ] `infra/k8s/base/*/deploy.yaml` - Service deployments
- [ ] `infra/k8s/base/*/service.yaml` - Service definitions
- [ ] `docker-compose.yml` - External database setup (if needed)
- [ ] `infra/db/*-migration.sql` - Database migrations (idempotent pattern)

---

## Key Patterns Summary

### Caddyfile gRPC Routing
```caddyfile
@grpc_service {
  protocol grpc
  path_regexp ^/service\.
}
handle @grpc_service {
  reverse_proxy service:50051 {
    transport http { versions h2c }
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
  }
}
```

### gRPC Client Creation
```typescript
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const proto = grpc.loadPackageDefinition(packageDefinition);
const client = new proto.Service.ServiceName(address, credentials);
```

### gRPC Server Setup
```typescript
const server = new grpc.Server();
server.addService(proto.Service.ServiceName.service, {
  MethodName: (call, callback) => {
    callback(null, response);
  },
});
server.bindAsync('0.0.0.0:50051', credentials, (error, port) => {
  server.start();
});
```

### HTTP to gRPC Conversion
```typescript
app.post('/api/endpoint', async (req, res) => {
  try {
    const grpcRequest = mapHttpToGrpc(req.body);
    const response = await promisifyGrpcCall(
      grpcClient,
      'MethodName',
      grpcRequest,
      10000
    );
    res.json(grpcToHttp(response));
  } catch (err) {
    handleGrpcError(res, err);
  }
});
```

### HTTP/3 Testing
```bash
source scripts/lib/http3.sh
http3_curl -k -sS --http3-only --max-time 15 \
  -H "Host: domain.local" \
  --resolve "domain.local:443:127.0.0.1" \
  "https://domain.local/endpoint"
```

---

## Notes

1. **Docker Workaround**: Services in Kubernetes connect to Docker Compose databases via `host.docker.internal:PORT`

2. **HTTP/3 Helper**: `scripts/lib/http3.sh` is **MUST-HAVE** - works around macOS/Docker UDP limitations for QUIC

3. **Zero-Downtime CA Rotation**: Caddyfile includes `admin localhost:2019` for zero-downtime certificate rotation

4. **Internal h2c Port**: Port 5000 in Caddyfile provides plaintext HTTP/2 (h2c) for internal gRPC testing

5. **Service Discovery**: All services use Kubernetes DNS (e.g., `auth-service.record-platform.svc.cluster.local:50051`)

6. **Database Migrations**: Use idempotent pattern with `IF NOT EXISTS` checks for safe re-runs
