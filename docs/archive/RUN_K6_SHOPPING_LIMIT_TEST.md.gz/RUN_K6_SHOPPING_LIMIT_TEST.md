# Run k6 Shopping Service Limit Test

## Current Status

**Service Readiness Check:**
```bash
./scripts/check-services-ready.sh
```

## Issues Found

1. **Shopping Service**: Currently crashing due to missing dependencies (needs rebuild)
2. **Auth Service**: Running (warnings about health.proto are non-critical)
3. **Databases**: ✅ All 8 PostgreSQL instances healthy
4. **Redis**: ✅ Healthy and running

## Fix Shopping Service

The shopping service needs to be rebuilt with the fixed Dockerfile:

```bash
# Rebuild shopping service
cd /Users/tom/.cursor/worktrees/record-platform/bsl
docker build \
  --platform linux/amd64 \
  --tag shopping-service:dev \
  --file services/shopping-service/Dockerfile \
  .

# Load into kind cluster
kind load docker-image shopping-service:dev --name h3

# Restart deployment
kubectl -n record-platform rollout restart deployment/shopping-service
kubectl -n record-platform rollout status deployment/shopping-service
```

## k6 Limit Test

The test file is: `scripts/load/k6-shopping-ramp.js`

This test:
- **Finds the upper bound** of the shopping service
- Uses **auth service** for user registration/login
- Progressively ramps up from 10 to 500 VUs
- Tests all shopping endpoints (cart, checkout, orders, watchlist, wishlist, etc.)
- Monitors error rates and identifies breaking point

### Run the Test

```bash
# Standard ramp-up (10 -> 500 VUs over ~23 minutes)
k6 run scripts/load/k6-shopping-ramp.js

# Aggressive ramp-up (find absolute limit)
k6 run --stages \
  0s:10,30s:50,1m:100,2m:200,3m:300,4m:400,5m:500,6m:600,7m:700,8m:800,9m:900,10m:1000,12m:0 \
  scripts/load/k6-shopping-ramp.js

# Custom configuration
SHOPPING_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
AUTH_URL=https://caddy-h3.ingress-nginx.svc.cluster.local:443 \
HOST=record.local \
k6 run scripts/load/k6-shopping-ramp.js
```

### Test Configuration

The test uses these stages:
- **30s**: Warm-up to 10 VUs
- **1m**: Ramp to 50 VUs
- **2m**: Ramp to 100 VUs
- **3m**: Ramp to 200 VUs
- **4m**: Ramp to 300 VUs
- **5m**: Ramp to 400 VUs
- **6m**: Ramp to 500 VUs
- **3m**: Hold at 500 VUs (stress test)
- **2m**: Ramp down to 0

### What It Tests

1. **Cart Operations**:
   - Add items to cart
   - Get cart contents
   - Update quantities

2. **Checkout Flow**:
   - Simulate checkout with payment
   - Create orders

3. **Order Management**:
   - List orders
   - Get order details

4. **Purchase History**:
   - View purchase history
   - Resell items

5. **Search History**:
   - Track search queries
   - View search history

6. **Watchlist & Wishlist**:
   - Add/remove items
   - View lists

### Output

The test provides:
- **Upper bound estimate** (max concurrent users)
- **Error rate analysis**
- **Throughput metrics**
- **Per-operation success rates**
- **Recommendations** based on error rates

### Expected Results

- **Excellent**: Error rate < 5%, service handles 500+ VUs
- **Acceptable**: Error rate < 10%, service handles ~400 VUs
- **Degraded**: Error rate > 10%, upper bound identified

## After Fixing Shopping Service

Once shopping service is rebuilt and ready:

1. **Verify services are ready:**
   ```bash
   ./scripts/check-services-ready.sh
   ```

2. **Run the limit test:**
   ```bash
   k6 run scripts/load/k6-shopping-ramp.js
   ```

3. **Monitor services during test:**
   ```bash
   # Watch shopping service logs
   kubectl -n record-platform logs -f deployment/shopping-service
   
   # Watch auth service logs
   kubectl -n record-platform logs -f deployment/auth-service
   
   # Monitor pod resource usage
   kubectl -n record-platform top pods
   ```

4. **Check database connections:**
   ```bash
   # Shopping DB
   docker exec record-platform-postgres-shopping-1 psql -U postgres -d records -c "SELECT count(*) FROM shopping.shopping_cart;"
   ```

## Database & Redis Status

✅ **All databases are healthy:**
- Main DB (5433)
- Auth DB (5437) - Used by auth service
- Shopping DB (5436) - Used by shopping service
- Listings DB (5435)
- Social DB (5434)
- Analytics DB (5439)
- Auction Monitor DB (5438)
- Python AI DB (5440)

✅ **Redis is healthy** (port 6379)
- Used for caching and Lua scripts (herd stampede prevention)
