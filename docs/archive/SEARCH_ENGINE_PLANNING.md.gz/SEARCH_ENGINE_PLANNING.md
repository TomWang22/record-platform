# Search Engine Planning

## Overview
The platform needs a comprehensive search engine to handle searches across listings, records, users, forum posts, and more. This document outlines the options and recommendations.

## Current State
- **Listings Service**: Basic PostgreSQL search with `pg_trgm` (trigram matching)
- **Records Service**: PostgreSQL search with `pg_trgm`
- **Social Service**: Basic PostgreSQL search
- **Shopping Service**: Search history tracking, but no full-text search

## Requirements
1. **Multi-entity search**: Listings, records, users, forum posts, comments
2. **Full-text search**: Title, description, content fields
3. **Filtering**: Price range, condition, category, date ranges, etc.
4. **Fuzzy matching**: Handle typos and variations
5. **Relevance ranking**: Sort by relevance, not just date/price
6. **Faceted search**: Filter by multiple attributes simultaneously
7. **Performance**: Sub-100ms response times for most queries
8. **Scalability**: Handle millions of documents

## Options

### Option 1: Meilisearch (Recommended)
**Pros:**
- ✅ Fast and lightweight (Rust-based)
- ✅ Built-in typo tolerance and fuzzy matching
- ✅ Faceted search out of the box
- ✅ Easy to deploy (Docker, single binary)
- ✅ Good documentation and community
- ✅ Real-time indexing
- ✅ Multi-tenant support
- ✅ Free and open-source

**Cons:**
- ⚠️ Less mature than Elasticsearch
- ⚠️ Smaller ecosystem
- ⚠️ May need custom ranking for complex use cases

**Implementation:**
- Deploy as separate service (Docker/Kubernetes)
- Sync data from PostgreSQL via change streams or scheduled jobs
- Use Meilisearch SDKs for Node.js services
- Index: listings, records, users, forum posts, comments

**Deployment:**
```yaml
# Kubernetes deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: meilisearch
spec:
  replicas: 2
  template:
    spec:
      containers:
      - name: meilisearch
        image: getmeili/meilisearch:v1.5
        env:
        - name: MEILI_MASTER_KEY
          valueFrom:
            secretKeyRef:
              name: meilisearch-secret
              key: master-key
        ports:
        - containerPort: 7700
```

### Option 2: Custom Search Service (PostgreSQL + Elasticsearch-like features)
**Pros:**
- ✅ Full control over implementation
- ✅ No external dependencies
- ✅ Can use existing PostgreSQL infrastructure
- ✅ Tight integration with existing services

**Cons:**
- ❌ More development time
- ❌ Need to implement ranking, faceting, etc.
- ❌ PostgreSQL full-text search limitations
- ❌ May not scale as well as dedicated search engines

**Implementation:**
- Create `search-service` microservice
- Use PostgreSQL full-text search (`tsvector`, `tsquery`)
- Implement custom ranking algorithm
- Add Redis for caching
- Use materialized views for performance

### Option 3: Elasticsearch
**Pros:**
- ✅ Industry standard
- ✅ Very powerful and flexible
- ✅ Excellent for complex queries
- ✅ Large ecosystem and community
- ✅ Good monitoring tools (Kibana)

**Cons:**
- ❌ Resource-intensive (memory, CPU)
- ❌ More complex to deploy and maintain
- ❌ Overkill for many use cases
- ❌ Requires more operational expertise

**Implementation:**
- Deploy Elasticsearch cluster (3+ nodes for HA)
- Use Logstash or custom sync jobs
- Integrate with Kibana for monitoring
- Use Elasticsearch client libraries

## Recommendation: Meilisearch

### Why Meilisearch?
1. **Performance**: Fast enough for our needs (sub-100ms)
2. **Simplicity**: Easy to deploy and maintain
3. **Features**: Has all the features we need out of the box
4. **Cost**: Free and open-source
5. **Developer Experience**: Good SDKs and documentation

### Architecture

```
┌─────────────────┐
│  API Gateway    │
└────────┬────────┘
         │
         ├─────────────────┐
         │                 │
    ┌────▼────┐      ┌─────▼─────┐
    │ Services │      │ Meilisearch│
    │ (Listings,│      │  Service   │
    │  Records, │      │            │
    │  Social)  │      │            │
    └────┬────┘      └─────┬─────┘
         │                 │
         │                 │
    ┌────▼─────────────────▼────┐
    │   Search Service           │
    │   (Orchestrator)           │
    │                            │
    │  - Multi-entity search     │
    │  - Result aggregation      │
    │  - Ranking                 │
    └────────────────────────────┘
```

### Implementation Plan

#### Phase 1: Meilisearch Service
1. Deploy Meilisearch as separate service
2. Create indexes for:
   - `listings` (title, description, category, etc.)
   - `records` (artist, name, format, etc.)
   - `users` (username, email, bio)
   - `forum_posts` (title, content, flair)
   - `forum_comments` (content)

#### Phase 2: Search Service
1. Create `search-service` microservice
2. Implement endpoints:
   - `POST /search` - Unified search across all entities
   - `GET /search/listings` - Search listings only
   - `GET /search/records` - Search records only
   - `GET /search/users` - Search users only
   - `GET /search/forum` - Search forum posts/comments
3. Features:
   - Query parsing and normalization
   - Multi-entity result aggregation
   - Relevance ranking
   - Faceted filtering
   - Pagination

#### Phase 3: Data Synchronization
1. **Real-time sync** (for critical entities):
   - Use PostgreSQL change streams (logical replication)
   - Or use triggers + message queue (Kafka)
   - Update Meilisearch index on create/update/delete

2. **Batch sync** (for less critical entities):
   - Scheduled jobs (cron)
   - Full reindex periodically
   - Incremental updates

#### Phase 4: Integration
1. Update services to use search service:
   - Listings service: Use search service for `/listings/search`
   - Records service: Use search service for record search
   - Social service: Use search service for forum search
   - Shopping service: Use search service for product search

2. Frontend integration:
   - Update search UI to use unified search endpoint
   - Add faceted filters
   - Add autocomplete/suggestions

### Service Structure

```
services/search-service/
├── src/
│   ├── server.ts          # Express server
│   ├── routes/
│   │   └── search.ts      # Search endpoints
│   ├── lib/
│   │   ├── meilisearch.ts # Meilisearch client
│   │   ├── ranking.ts     # Relevance ranking
│   │   └── aggregator.ts  # Result aggregation
│   └── jobs/
│       └── sync.ts        # Data synchronization jobs
├── Dockerfile
└── package.json
```

### Database Schema

```sql
-- Search service metadata (optional, for tracking)
CREATE SCHEMA IF NOT EXISTS search;

CREATE TABLE IF NOT EXISTS search.index_status (
  index_name TEXT PRIMARY KEY,
  last_synced_at TIMESTAMPTZ,
  sync_status TEXT, -- 'syncing', 'completed', 'error'
  document_count BIGINT,
  metadata JSONB
);
```

### API Endpoints

```typescript
// Unified search
POST /api/search
{
  "query": "vinyl records",
  "entities": ["listings", "records", "users"], // Optional: search all if not specified
  "filters": {
    "price_min": 10,
    "price_max": 100,
    "category": "vinyl"
  },
  "limit": 20,
  "offset": 0
}

// Response
{
  "results": [
    {
      "entity": "listings",
      "id": "...",
      "title": "...",
      "relevance_score": 0.95
    },
    // ...
  ],
  "facets": {
    "category": { "vinyl": 50, "cd": 30 },
    "price_range": { "0-50": 40, "50-100": 30 }
  },
  "total": 80
}
```

### Migration Strategy

1. **Phase 1**: Deploy Meilisearch, keep existing PostgreSQL search
2. **Phase 2**: Deploy search service, use it for new features
3. **Phase 3**: Gradually migrate existing endpoints to use search service
4. **Phase 4**: Remove PostgreSQL full-text search (or keep as fallback)

### Monitoring

- **Meilisearch metrics**: Index size, query latency, error rate
- **Search service metrics**: Request rate, latency, error rate
- **Sync job metrics**: Sync frequency, success rate, lag

### Cost Considerations

- **Meilisearch**: Free (open-source)
- **Infrastructure**: Additional service (CPU, memory)
- **Storage**: Index storage (typically 10-20% of source data size)

### Alternative: Hybrid Approach

- Use PostgreSQL full-text search for simple queries
- Use Meilisearch for complex queries, faceted search, fuzzy matching
- Route queries based on complexity

## Decision

**Recommended: Meilisearch + Search Service**

This provides:
- ✅ Fast, relevant search results
- ✅ Easy to maintain and scale
- ✅ Good developer experience
- ✅ Separation of concerns (dedicated search service)
- ✅ Future-proof (can migrate to Elasticsearch if needed)

## Next Steps

1. **Deploy Meilisearch**:
   ```bash
   docker run -d -p 7700:7700 -v meilisearch_data:/meili_data getmeili/meilisearch:v1.5
   ```

2. **Create Search Service**:
   - Set up service structure
   - Implement Meilisearch client
   - Create search endpoints

3. **Data Sync**:
   - Implement sync jobs
   - Set up change streams or triggers

4. **Integration**:
   - Update services to use search service
   - Update frontend

5. **Testing**:
   - Performance testing
   - Relevance testing
   - Load testing

