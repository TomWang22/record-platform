# Services and k6 Testing - Ready Status

## ✅ All Fixes Applied

### 1. Auction Monitor Health Check ✅
**File**: `services/auction-monitor/src/server.ts`

**Status**: **FIXED** - Now requires BOTH databases (as required by service architecture)
- `listingsPool` - REQUIRED (reads watchlist)
- `auctionPool` - REQUIRED (writes auction results)
- Returns 503 if either database fails (both are critical)
- Better error logging for debugging

### 2. Social Service Health Check ✅
**File**: `services/social-service/src/server.ts`

**Status**: **FIXED** - More resilient health check
- Database: Critical (503 if down)
- Redis: Non-critical (doesn't fail health check if down)
- Better error logging

### 3. Probe Timeouts Updated ✅
- **Auction Monitor**: Startup probe 30s, timeout 5s, failure threshold 30
- **Social Service**: Readiness probe 20s, failure threshold 5

### 4. Webapp Kubernetes Deployment ✅
**Files Created**:
- `infra/k8s/base/webapp/deploy.yaml`
- `infra/k8s/base/webapp/service.yaml`
- `infra/k8s/base/webapp/kustomization.yaml`

**Configuration**:
- Port: 3001
- Gateway URL: `http://api-gateway.record-platform.svc.cluster.local:4000`
- Added to base kustomization

### 5. k6 Testing Suite ✅

**Scripts Created**:
- `scripts/run-k6-tests.sh` - Main test runner (local or in-cluster)
- `scripts/run-k6-in-cluster.sh` - Run k6 as Kubernetes Job
- `K6_TESTING_GUIDE.md` - Comprehensive testing guide

**Available Tests**:
- ✅ `all-in-one-k6.js` - Complete pipeline test
- ✅ `k6-analytics-ingestion.js` - Analytics ingestion
- ✅ `k6-analytics-real-data.js` - Real eBay/Discogs data
- ✅ `k6-analytics-load-ramp.js` - Load ramp (1K → 5K VU)
- ✅ `k6-analytics-read-heavy.js` - Read-heavy workload
- ✅ `k6-analytics-soak.js` - Soak test (memory leaks)
- ✅ `k6-analytics-stress.js` - Stress test
- ✅ `k6-mixed.js` - Mixed workload
- ✅ `k6-reads.js` - Read-only workload

## 🚀 Quick Start

### 1. Verify All Services
```bash
./scripts/test-all-services.sh
```

### 2. Run k6 Tests

**Option A: In-Cluster (Recommended)**
```bash
# Main pipeline test
./scripts/run-k6-in-cluster.sh all-in-one-k6.js

# Analytics pipeline tests
./scripts/load/run-analytics-tests.sh
```

**Option B: Local (with port-forward)**
```bash
# Start port-forward
kubectl -n record-platform port-forward svc/api-gateway 8080:4000 &

# Run test
BASE_URL=http://localhost:8080 ./scripts/run-k6-tests.sh
```

### 3. Test Webapp
```bash
# Port-forward webapp
kubectl -n record-platform port-forward svc/webapp 3001:3001

# Access at http://localhost:3001
```

### 4. Test Nginx (port 8080)
```bash
# Port-forward nginx
kubectl -n record-platform port-forward svc/nginx 8080:8080

# Access at http://localhost:8080
```

## 📊 Port Configuration

| Service | Port | Access |
|---------|------|--------|
| **Webapp** | 3001 | `http://webapp.record-platform.svc.cluster.local:3001` |
| **Nginx** | 8080 | `http://nginx.record-platform.svc.cluster.local:8080` |
| **API Gateway** | 4000 | `http://api-gateway.record-platform.svc.cluster.local:4000` |
| **Analytics** | 4004 | `http://analytics-service.record-platform.svc.cluster.local:4004` |
| **Auction Monitor** | 4008 | `http://auction-monitor.record-platform.svc.cluster.local:4008` |

## 🧪 k6 Test Scenarios

### Basic Pipeline Test
```bash
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```
Tests: Authentication, Records CRUD, Mixed workload

### Analytics Pipeline Test
```bash
./scripts/load/run-analytics-tests.sh
```
Tests: Ingestion, Data Quality, Load Ramp, Read-Heavy, Soak, Stress

### Custom Test
```bash
BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000 \
MODE=mixed \
RATE=100 \
DURATION=10m \
VUS=50 \
MAX_VUS=500 \
./scripts/run-k6-in-cluster.sh all-in-one-k6.js
```

## 📝 Next Steps

1. **Rebuild and Deploy**:
   ```bash
   ./scripts/build-and-load.sh h3
   kubectl apply -k infra/k8s/overlays/dev
   ```

2. **Verify Services**:
   ```bash
   ./scripts/test-all-services.sh
   ```

3. **Run k6 Tests**:
   ```bash
   ./scripts/run-k6-in-cluster.sh all-in-one-k6.js
   ./scripts/load/run-analytics-tests.sh
   ```

4. **Test Webapp**:
   ```bash
   kubectl -n record-platform port-forward svc/webapp 3001:3001
   # Open http://localhost:3001
   ```

5. **Test Nginx**:
   ```bash
   kubectl -n record-platform port-forward svc/nginx 8080:8080
   # Open http://localhost:8080
   ```

## 🔍 Troubleshooting

### Services Not Ready
```bash
# Check all services
./scripts/test-all-services.sh

# Check specific service
kubectl -n record-platform get pods -l app=<service-name>
kubectl -n record-platform logs -l app=<service-name> --tail=50
```

### Auction Monitor Issues
```bash
# Check both databases are accessible
kubectl -n record-platform exec -it <auction-monitor-pod> -- \
  env | grep POSTGRES_URL

# Check health endpoint
kubectl -n record-platform port-forward svc/auction-monitor 4008:4008
curl http://localhost:4008/healthz
```

### k6 Test Issues
```bash
# Check if services are ready
./scripts/load/check-services.sh

# Get auth token
./scripts/load/get-token.sh

# Check job logs
kubectl -n record-platform logs job/k6-test-<timestamp>
```

## 📚 Documentation

- **k6 Testing Guide**: `K6_TESTING_GUIDE.md`
- **Services Fix Summary**: `SERVICES_FIX_SUMMARY.md`
- **NodePort Fix**: `NODEPORT_30443_FIX.md`

## ✅ Status

- ✅ Auction Monitor: Requires both DBs (correct behavior)
- ✅ Social Service: Resilient health check
- ✅ Webapp: Kubernetes deployment ready (port 3001)
- ✅ Nginx: Service ready (port 8080)
- ✅ k6 Tests: All scripts ready and documented
- ✅ Test Runners: Created for in-cluster and local testing

**All services are ready for testing!** 🚀

