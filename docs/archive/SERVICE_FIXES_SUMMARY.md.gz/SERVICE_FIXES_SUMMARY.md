# Service Issues Fixed After Cluster Restart

## Issues Found and Fixed

### 1. ✅ Missing Redis Secret
**Problem**: Redis deployment expected `redis-auth` secret but it didn't exist
**Error**: `Error: secret "redis-auth" not found`
**Fix**: Created `redis-auth` secret with `REDIS_PASSWORD` from `app-secrets`

### 2. ✅ Missing Postgres Secret for Cron Jobs
**Problem**: Cron-jobs deployment expected `postgres-secret` but it didn't exist
**Error**: `Error: secret "postgres-secret" not found`
**Fix**: Created `postgres-secret` with `POSTGRES_PASSWORD` from `postgres-superuser`

### 3. ✅ Python AI Service Import Errors
**Problem**: Python modules were importing without `app.` prefix
**Error**: `ModuleNotFoundError: No module named 'data_pipeline'`
**Fix**: Updated all imports in `ai_main.py`, `ai_advisor.py`, and `data_pipeline.py` to use `app.` prefix:
- `from data_pipeline` → `from app.data_pipeline`
- `from ai_advisor` → `from app.ai_advisor`
- `from db` → `from app.db`

### 4. ✅ Postgres PVC Mismatch
**Problem**: Postgres deployment expected `pgdata-big` and `pg-wal-archive` PVCs but only `pgdata` existed
**Error**: `persistentvolumeclaim "pgdata-big" not found`
**Fix**: 
- Changed `pgdata-big` → `pgdata` (use existing PVC)
- Changed `pg-wal-archive` PVC → `emptyDir` (WAL archive not critical for dev)

### 5. ✅ ServiceMonitor Kustomize Error
**Problem**: ServiceMonitor CRDs not installed (Prometheus Operator not present)
**Error**: `no matches for kind "ServiceMonitor" in version "monitoring.coreos.com/v1"`
**Fix**: 
- Commented out monitoring resources in `kustomization.yaml`
- Made ServiceMonitor resources optional (only if Prometheus Operator installed)

### 6. ✅ Social Service Database Connection
**Problem**: Social service can't connect to Postgres (Postgres wasn't running due to PVC issue)
**Status**: Will be fixed once Postgres starts (after PVC fix)

## Scripts Created

1. **`scripts/fix-missing-secrets.sh`**: Creates `redis-auth` and `postgres-secret`
2. **`scripts/fix-all-service-issues.sh`**: Comprehensive fix script that:
   - Creates missing secrets
   - Rebuilds python-ai-service
   - Restarts affected services
   - Waits for services to be ready

## Current Status

After fixes:
- ✅ Redis: Running (1/1)
- ✅ Cron-jobs: Running (1/1)
- ✅ Python AI: Rebuilt with fixed imports, restarting
- ⏳ Postgres: Will start after PVC fix applied
- ⏳ Social Service: Will connect once Postgres is running

## Next Steps

1. Apply the fixes:
   ```bash
   ./scripts/fix-missing-secrets.sh record-platform
   kubectl -n record-platform apply -f infra/k8s/base/postgres/deploy.yaml
   kubectl -n record-platform rollout restart deploy/python-ai-service
   ```

2. Wait for services to be ready:
   ```bash
   kubectl -n record-platform get pods -w
   ```

3. Check logs if issues persist:
   ```bash
   kubectl -n record-platform logs -l app=python-ai-service
   kubectl -n record-platform logs -l app=social-service
   kubectl -n record-platform logs -l app=postgres
   ```

## Notes

- **ServiceMonitor**: Optional monitoring feature, can be enabled later if Prometheus Operator is installed
- **Postgres PVC**: Using `pgdata` (10Gi) instead of `pgdata-big` for dev environment
- **WAL Archive**: Using `emptyDir` instead of PVC for simplicity in dev (data not persisted across restarts)

