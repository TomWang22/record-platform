# Comprehensive Service Health Report

**Generated:** $(date)

---

## 🔍 Service Status Investigation

### Service Readiness:

### auth-service
- **Ready:** 4/4
- **Restarts:** 8
- **Pod Ready:** true

### shopping-service
- **Ready:** 1/1
- **Restarts:** 4
- **Pod Ready:** true

### records-service
- **Ready:** 1/1
- **Restarts:** 20
- **Pod Ready:** true

### social-service
- **Ready:** 1/1
- **Restarts:** 28
- **Pod Ready:** true

### analytics-service
- **Ready:** 1/1
- **Restarts:** 0
- **Pod Ready:** true

### listings-service
- **Ready:** 2/2
- **Restarts:** 11
- **Pod Ready:** true

### api-gateway
- **Ready:** 2/2
- **Restarts:** 44
- **Pod Ready:** true

---

## 🔍 Probe Configuration:

### auth-service
- ⚠️  No startupProbe
- ⚠️  No readinessProbe

### shopping-service
- ⚠️  No startupProbe
- ⚠️  No readinessProbe

### records-service
- ⚠️  No startupProbe
- ⚠️  No readinessProbe

### social-service
- ⚠️  No startupProbe
- ⚠️  No readinessProbe

### analytics-service
- ⚠️  No startupProbe
- ⚠️  No readinessProbe

