# Strict TLS Verification - Production Ready Testing

## Overview

All k6 load tests now use **strict TLS verification** to ensure production readiness. This means:
- ✅ TLS certificates are properly validated
- ✅ Certificate chain is verified
- ✅ No insecure connections are allowed
- ✅ Production-grade security testing

## Configuration

### CA Certificate Setup

The tests use mkcert CA certificate for strict TLS verification:

```bash
# Verify mkcert CA exists
mkcert -CAROOT

# The CA certificate is automatically mounted in k6 pods at:
# /etc/ssl/certs/k6-ca.crt
```

### Automatic Configuration

The test scripts automatically:
1. Check for mkcert CA certificate
2. Create ConfigMap with CA certificate
3. Mount CA certificate in k6 pods
4. Set `SSL_CERT_FILE` environment variable
5. Run k6 with strict TLS (no `--insecure-skip-tls-verify`)

## Scripts Updated

### ✅ Strict TLS Enabled

- `scripts/find-bottlenecks.sh` - Bottleneck finder with strict TLS
- `scripts/run-k6-shopping.sh` - Shopping service tests with strict TLS
- `scripts/run-k6-shopping-daily.sh` - Daily CronJob with strict TLS

### Error Handling

If mkcert CA is not found, scripts will **fail** with:
```
❌ mkcert CA not found at /path/to/rootCA.pem - strict TLS verification REQUIRED for production testing
```

This ensures tests cannot run without proper TLS verification.

## Bottleneck Analysis

### Automatic Analysis

After each test run, the `analyze-bottlenecks.sh` script automatically:
1. Parses k6 summary metrics
2. Identifies bottlenecks by severity (CRITICAL, HIGH, MEDIUM)
3. Provides specific optimization recommendations
4. Identifies which service components are causing issues

### Running Analysis Manually

```bash
# Analyze latest results
bash scripts/analyze-bottlenecks.sh

# Analyze specific results directory
bash scripts/analyze-bottlenecks.sh scripts/load/results/bottleneck-shopping-20251207-185559 shopping
```

### Analysis Output

The script provides:
- **Overall Performance Metrics**: VUs, requests, throughput, error rate
- **Latency Analysis**: P50, P95, P99, P99.9, max latency
- **Bottleneck Identification**: 
  - Error rate bottlenecks
  - Latency bottlenecks (P95, P99)
  - Throughput bottlenecks
  - Server error bottlenecks
  - Endpoint-specific issues
- **Optimization Recommendations**: Specific actions for each bottleneck
- **Action Plan**: Prioritized list of optimizations

### Example Output

```
🔴 BOTTLENECKS IDENTIFIED:

  [CRITICAL] Error Rate Bottleneck
    Issue: 7.2% error rate (threshold: 5%)
    Impact: 7.2% of requests are failing
    Component: Service-wide (affects all endpoints)
    Recommendations:
      - Check application logs: kubectl logs -l app=shopping-service --tail=100
      - Check database connections: kubectl exec -it postgres-shopping-1 -- psql -c 'SELECT count(*) FROM pg_stat_activity'
      - Review resource limits: kubectl top pods -l app=shopping-service
      - Check for connection pool exhaustion
      - Verify database query performance

  [HIGH] P95 Latency Bottleneck
    Issue: P95 latency is 3200ms (threshold: 3000ms)
    Impact: 5% of requests take longer than 3200ms
    Component: Service-wide latency issue
    Recommendations:
      - Optimize database queries (add indexes, review slow queries)
      - Implement caching for frequently accessed data
      - Review connection pool settings
      - Check for N+1 query problems
      - Consider horizontal scaling
```

## Production Readiness Checklist

Before deploying to production, ensure:

- [ ] All tests pass with strict TLS verification
- [ ] Error rate < 5% under expected load
- [ ] P95 latency < 3000ms
- [ ] P99 latency < 5000ms
- [ ] No server errors (5xx) under normal load
- [ ] Throughput meets requirements
- [ ] Bottleneck analysis shows no CRITICAL issues
- [ ] All optimization recommendations have been reviewed

## Troubleshooting

### TLS Verification Fails

If tests fail with TLS errors:
1. Verify mkcert CA exists: `mkcert -CAROOT`
2. Check CA certificate is in ConfigMap: `kubectl -n k6-load get configmap k6-ca-cert`
3. Verify certificate is mounted: `kubectl -n k6-load describe pod <pod-name> | grep -A 5 k6-ca-cert`
4. Check SSL_CERT_FILE is set: `kubectl -n k6-load exec <pod-name> -- env | grep SSL`

### Certificate Issues

```bash
# Regenerate certificates if needed
mkcert -install
mkcert record.local

# Update ConfigMap
kubectl -n k6-load create configmap k6-ca-cert \
  --from-file=ca.crt=$(mkcert -CAROOT)/rootCA.pem \
  --dry-run=client -o yaml | kubectl apply -f -
```

## Benefits

✅ **Production-Ready**: Tests match production security requirements
✅ **Security Validation**: Ensures TLS is properly configured
✅ **Early Detection**: Catches TLS misconfigurations before production
✅ **Compliance**: Meets security best practices
✅ **Confidence**: Tests run with same security as production

