# Strict TLS Setup for k6

## Current Status

✅ **Dockerfile created**: `Dockerfile.k6-strict-tls`
⚠️ **Build issue**: k6 image runs as non-root, can't install packages
✅ **Workaround**: Using `--insecure-skip-tls-verify` for dev (matches social service)

## Approach

### Option 1: Custom k6 Image (Recommended for Production)

**Dockerfile**: `Dockerfile.k6-strict-tls`
- Copies CA cert to `/tmp/dev-root.pem`
- k6 runs as non-root user (UID 1000)
- Go's TLS doesn't easily support custom CA via env vars

**Limitation**: k6 uses Go's TLS implementation which checks system CA store, but we can't modify it as non-root.

**Solution**: For production, build a custom k6 image based on a full OS image (not the minimal k6 image), or use a reverse proxy with proper certs.

### Option 2: Runtime CA Cert Mount (Current)

**Current Implementation**:
- Mount CA cert as Kubernetes secret
- Use `--insecure-skip-tls-verify` for dev
- HTTP/2/3 still works (flag only affects cert verification)

**Script**: `scripts/run-k6-listings-with-graphs.sh`
- Checks for custom k6 image
- Falls back to standard image with `--insecure-skip-tls-verify`

## Building Custom k6 Image

```bash
# Build custom k6 image (currently has limitations)
docker build -f Dockerfile.k6-strict-tls -t k6-strict-tls:dev .

# Load into Kind cluster
kind load docker-image k6-strict-tls:dev
```

## Usage

```bash
# Use custom image (if available)
K6_IMAGE=k6-strict-tls:dev ./scripts/run-k6-listings-with-graphs.sh

# Use standard image (fallback)
./scripts/run-k6-listings-with-graphs.sh
```

## Production Recommendation

For production strict TLS:
1. **Use proper CA-signed certificates** (not self-signed)
2. **Configure system trust store** at Kubernetes level
3. **Use service mesh** (e.g., Linkerd, Istio) for mTLS
4. **Or use reverse proxy** with proper certs

## HTTP/2/3 Support

✅ **Maintained**: `--insecure-skip-tls-verify` does NOT disable HTTP/2/3
- k6 automatically negotiates HTTP/2 or HTTP/3 via ALPN
- Flag only affects certificate verification
- Caddy supports HTTP/2 and HTTP/3 (QUIC)

