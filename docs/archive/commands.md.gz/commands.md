Usage examples
Standard run (warm only):
./scripts/run_pgbench_sweep.sh

OPTIMIZED RUN (Maximum TPS - Recommended for Performance Tuning):
# SQL function + no IO timing + no parallel workers + optimized candidate_cap
# Expected: 15-30% TPS gain vs gold run
SKIP_DISK_CHECK=true \
RUN_SMOKE_TESTS=false \
RUN_COLD_CACHE=false \
GENERATE_PLOTS=false \
RUN_DIFF_MODE=false \
CREATE_BENCH_BACKUP=false \
RUN_OPTIMIZE_DB=false \
USE_SQL_FUNCTION=true \
USE_AUTO_WRAPPER=false \
TRACK_IO_TIMING=off \
MODE=quick \
./scripts/run_pgbench_sweep.sh \
  --pgoptions "-c jit=off -c enable_seqscan=off -c random_page_cost=1.1 -c cpu_index_tuple_cost=0.0005 -c cpu_tuple_cost=0.01 -c effective_cache_size=4GB -c work_mem=32MB -c track_io_timing=off -c effective_io_concurrency=300 -c max_parallel_workers=1 -c max_parallel_workers_per_gather=0 -c maintenance_work_mem=512MB -c pg_trgm.similarity_threshold=0.40 -c synchronous_commit=off"

# See scripts/OPTIMIZED-BENCHMARK-RUN.md for detailed explanation

FULL TEST RUN (Comprehensive - Recommended for Production-Like Testing):
# Includes: plots, DB optimization, parallel workers 12/4, cold cache, aggressive SQL function tuning
# Tests harder: full client sweep (8-256), both cold and warm phases, all diagnostics
# Uses SQL function with aggressive tuning: candidate_cap=24, min_rank=0.55
# Parallel workers: 12/4 (matches gold run, tests production-like parallelism)
RUN_OPTIMIZE_DB=true \
USE_SQL_FUNCTION=true \
USE_AUTO_WRAPPER=false \
RUN_COLD_CACHE=true \
EFFECTIVE_IO_CONCURRENCY=300 \
MODE=deep \
./scripts/run_pgbench_sweep.sh

# Note: SE_SQL_FUNCTION typo is auto-detected and fixed (use USE_SQL_FUNCTION for clarity)

With cold cache phase:
RUN_COLD_CACHE=true ./scripts/run_pgbench_sweep.sh

With diff-mode:
BASELINE_CSV=/path/to/gold.csv RUN_DIFF_MODE=true ./scripts/run_pgbench_sweep.sh

Skip smoke tests:
RUN_SMOKE_TESTS=false ./scripts/run_pgbench_sweep.sh

Skip plots:
GENERATE_PLOTS=false ./scripts/run_pgbench_sweep.sh

USE_AUTO_WRAPPER=true MODE=deep RUN_COLD_CACHE=true ./scripts/run_pgbench_sweep.sh

USE_AUTO_WRAPPER=false MODE=deep RUN_COLD_CACHE=true ./scripts/run_pgbench_sweep.sh

# Standard run
./scripts/run_pgbench_sweep.sh

# With tmpfs temp tablespace
FAST_TEMP_TABLESPACE=fasttmp MODE=deep ./scripts/run_pgbench_sweep.sh

# Deep mode with cold cache
MODE=deep RUN_COLD_CACHE=true ./scripts/run_pgbench_sweep.sh

# FULL TEST RUN (Comprehensive - with plots, DB optimization, parallel workers 12/4, cold cache)
# Uses SQL function with aggressive tuning (candidate_cap=24, min_rank=0.55)
# Note: SE_SQL_FUNCTION typo is auto-detected and fixed (use USE_SQL_FUNCTION for clarity)
RUN_OPTIMIZE_DB=true \
USE_SQL_FUNCTION=true \
USE_AUTO_WRAPPER=false \
RUN_COLD_CACHE=true \
EFFECTIVE_IO_CONCURRENCY=300 \
MODE=deep \
./scripts/run_pgbench_sweep.sh

# Same as above but with typo (auto-fixed):
RUN_OPTIMIZE_DB=true \
SE_SQL_FUNCTION=true \
USE_AUTO_WRAPPER=false \
RUN_COLD_CACHE=true \
EFFECTIVE_IO_CONCURRENCY=300 \
MODE=deep \
./scripts/run_pgbench_sweep.sh


# Quick benchmark (default)
./scripts/run_social_pgbench_sweep.sh

# Deep mode (high client counts)
MODE=deep ./scripts/run_social_pgbench_sweep.sh

# With cold cache phase
RUN_COLD_CACHE=true ./scripts/run_social_pgbench_sweep.sh

# With fast temp tablespace
FAST_TEMP_TABLESPACE=fasttmp ./scripts/run_social_pgbench_sweep.sh

# Full integration tests
./scripts/test-microservices-http2-http3.sh

uick access
# Grafanakubectl -n monitoring port-forward svc/monitoring-grafana 3000:80# http://localhost:3000 (admin/Admin123!)# Prometheuskubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090# http://localhost:9090# Jaegerkubectl -n observability port-forward svc/jaeger 16686:16686# http://localhost:16686# Linkerd Vizlinkerd viz dashboard
Next steps
Instrument services with OpenTelemetry (see otel-instrumentation.md)
Enable Linkerd auto-injection:
   kubectl annotate namespace record-platform linkerd.io/inject=enabled
Set up New Relic (optional):
   kubectl create secret generic newrelic-secret \     --from-literal=license-key="YOUR_KEY" \     -n observability
Create custom Grafana dashboards for business metrics
Metrics collected
Service metrics: request rate, error rate, latency (p50, p95, p99)
Infrastructure: CPU, memory, pod status
Distributed tracing: full request flows across services
Linkerd: service mesh metrics, topology, traffic flow
The stack is ready to use. See infra/k8s/OBSERVABILITY.md for detailed documentation.


Toms-MacBook-Pro:record-platform tom$ bash infra/k8s/scripts/install-observability.sh

>>> Installing comprehensive observability stack...

>>> 1. Installing kube-prometheus-stack (Prometheus + Grafana)
Release "monitoring" has been upgraded. Happy Helming!
NAME: monitoring
LAST DEPLOYED: Fri Nov 21 23:47:38 2025
NAMESPACE: monitoring
STATUS: deployed
REVISION: 3
NOTES:
kube-prometheus-stack has been installed. Check its status by running:
  kubectl --namespace monitoring get pods -l "release=monitoring"

Get Grafana 'admin' user password by running:

  kubectl --namespace monitoring get secrets monitoring-grafana -o jsonpath="{.data.admin-password}" | base64 -d ; echo

Access Grafana local instance:

  export POD_NAME=$(kubectl --namespace monitoring get pod -l "app.kubernetes.io/name=grafana,app.kubernetes.io/instance=monitoring" -oname)
  kubectl --namespace monitoring port-forward $POD_NAME 3000

Get your grafana admin user password by running:

  kubectl get secret --namespace monitoring -l app.kubernetes.io/component=admin-secret -o jsonpath="{.items[0].data.admin-password}" | base64 --decode ; echo


Visit https://github.com/prometheus-operator/kube-prometheus for instructions on how to create & configure Alertmanager and Prometheus instances using the Operator.

>>> Waiting for Prometheus CRDs to be available...

>>> 2. Creating observability namespace and deploying components...
namespace/observability unchanged
configmap/grafana-dashboards unchanged
configmap/otel-collector-config unchanged
service/jaeger unchanged
service/otel-collector unchanged
deployment.apps/jaeger unchanged
deployment.apps/otel-collector configured
podmonitor.monitoring.coreos.com/infrastructure-components unchanged
podmonitor.monitoring.coreos.com/record-platform-services unchanged
servicemonitor.monitoring.coreos.com/jaeger unchanged
servicemonitor.monitoring.coreos.com/linkerd-prometheus unchanged
servicemonitor.monitoring.coreos.com/otel-collector unchanged

>>> 3. Waiting for observability components to be ready...
deployment.apps/otel-collector condition met
deployment.apps/jaeger condition met

>>> 4. Applying ServiceMonitors and PodMonitors...
servicemonitor.monitoring.coreos.com/node-services unchanged
servicemonitor.monitoring.coreos.com/edge-exporters unchanged
servicemonitor.monitoring.coreos.com/otel-collector unchanged
servicemonitor.monitoring.coreos.com/jaeger unchanged
Error from server (NotFound): error when creating "infra/k8s/base/observability/servicemonitors.yaml": namespaces "linkerd" not found
podmonitor.monitoring.coreos.com/record-platform-services unchanged
podmonitor.monitoring.coreos.com/infrastructure-components unchanged

>>> 5. Installing Linkerd service mesh...
Linkerd CLI not found. Install it to enable service mesh:
  curl -sL https://run.linkerd.io/install-edge | sh
  bash infra/k8s/scripts/install-linkerd.sh

>>> 6. Configuring New Relic integration...
NEW_RELIC_LICENSE_KEY not set. Skipping New Relic setup.
To enable New Relic, set the environment variable:
  export NEW_RELIC_LICENSE_KEY='your-key-here'
Then update the secret:
  kubectl create secret generic newrelic-secret --from-literal=license-key='your-key' -n observability

>>> Observability stack installation complete!

Port-forward access:
  Grafana:       kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
  Prometheus:    kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090
  Jaeger:        kubectl -n observability port-forward svc/jaeger 16686:16686
  Linkerd Viz:   linkerd viz dashboard

Grafana credentials:
  Username: admin
  Password: Admin123!

Access URLs (when port-forwarding):
  Grafana:       http://localhost:3000
  Prometheus:    http://localhost:9090
  Jaeger UI:     http://localhost:16686

Next steps:
  1. Enable Linkerd auto-injection for namespaces:
     kubectl annotate namespace record-platform linkerd.io/inject=enabled
  2. Add OpenTelemetry instrumentation to your services
  3. Configure Grafana dashboards for your metrics
  4. Set up alerting rules in Prometheus
Toms-MacBook-Pro:record-platform tom$ kubectl annotate namespace record-platform linkerd.io/inject=enabled
namespace/record-platform annotated
Toms-MacBook-Pro:record-platform tom$ kubectl create secret generic newrelic-secret \
     --from-literal=license-key="YOUR_KEY" \
     -n observability
secret/newrelic-secret created
Toms-MacBook-Pro:record-platform tom$ 


What you'll see
Pre-built dashboards:
Kubernetes / Compute Resources / Cluster
Kubernetes / Compute Resources / Namespace (Pods)
Kubernetes / Networking / Cluster
Node Exporter Full
Explore metrics:
Go to Explore (compass icon)
Try queries like:
     # Request rate by service     sum(rate(http_requests_total[5m])) by (service)          # CPU usage     rate(container_cpu_usage_seconds_total{namespace="record-platform"}[5m])          # Memory usage     container_memory_usage_bytes{namespace="record-platform"}
Access other tools
Prometheus:
kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090# http://localhost:9090
Jaeger (Tracing):
kubectl -n observability port-forward svc/jaeger 16686:16686# http://localhost:16686
Next steps
See infra/k8s/GRAFANA-GUIDE.md for:
Creating custom dashboards for your services
Setting up alerts
Importing popular dashboards
Troubleshooting tips
The observability stack is ready to use. Start with the access script to open Grafana and explore your metrics.