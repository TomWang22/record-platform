# Listings Service - Load Test Report

**Test Date:** 2025-12-08 12:05:27

## Executive Summary

| Metric | Value |
|--------|-------|
| **Total Requests** | 29 |
| **Test Duration** | 22.9s |
| **Success Rate** | 17.24% |
| **Error Rate** | 82.76% |
| **Average Latency** | 2276.90ms |
| **Median Latency** | 62.98ms |
| **Min Latency** | 3.83ms |
| **Max Latency** | 12620.84ms |

## HTTP Request Latency Percentiles

| Percentile | Latency (ms) | Description |
|------------|--------------|-------------|
| **p1 (1st)** | 4.16 | 1% of requests faster than this |
| **p5 (5th)** | 5.86 | 5% of requests faster than this |
| **p10 (10th)** | 9.11 | 10% of requests faster than this |
| **p25 (25th)** | 22.23 | 25% of requests faster than this |
| **p50 (median)** | 62.98 | 50% of requests faster than this |
| **p75 (75th)** | 406.07 | 75% of requests faster than this |
| **p90 (90th)** | 12619.06 | 90% of requests faster than this |
| **p95 (95th)** | 12619.32 | 95% of requests faster than this |
| **p99 (99th)** | 12620.42 | 99% of requests faster than this |
| **p99.9 (99.9th)** | 12620.80 | 99.9% of requests faster than this |
| **p99.99 (99.99th)** | 12620.84 | 99.99% of requests faster than this |
| **p99.999 (99.999th)** | 12620.84 | 99.999% of requests faster than this |
| **p99.9999 (99.9999th)** | 12620.84 | 99.9999% of requests faster than this |
| **p99.99999 (99.99999th)** | 12620.84 | 99.99999% of requests faster than this |
| **p99.999999 (99.999999th)** | 12620.84 | 99.999999% of requests faster than this |
| **p100 (max)** | 12620.84 | Maximum observed latency |

## Component Breakdown

### Search Listings
- **Average Latency:** 162.79ms
- **P95 Latency:** 412.05ms
- **P99 Latency:** 413.61ms

### Create Listing
- **Average Latency:** 107.60ms
- **P95 Latency:** 257.60ms
- **P99 Latency:** 293.12ms

### Place Bid
- **Average Latency:** 0.00ms (no bids placed)
- **P95 Latency:** 0.00ms
- **P99 Latency:** 0.00ms

### Watchlist Operations
- **Average Latency:** 0.00ms (no operations)
- **P95 Latency:** 0.00ms
- **P99 Latency:** 0.00ms

## Throughput Metrics

| Operation | Count |
|-----------|-------|
| Total Searches | 14 |
| Total Listings Created | 0 |
| Total Bids | 0 |
| Total Offers | 0 |
| Total Watchlist Adds | 0 |
| Total Ratings | 0 |

## Test Configuration

- **TLS:** Strict TLS (CA certificate verified)
- **Protocol:** HTTP/2 and HTTP/3 (QUIC) via ALPN negotiation
- **Test Type:** Comprehensive load test
- **Service:** Listings Service
- **VUs:** 5
- **Duration:** 20s

## Notes

- All latency values are in milliseconds (ms)
- Percentiles are calculated from actual request latencies
- Error rate includes all HTTP errors (4xx, 5xx)
- Success rate = 100% - Error rate
- Authentication failures are contributing to the high error rate
- Search operations are working (14 successful searches)

---

*Report generated automatically from k6 test results*
