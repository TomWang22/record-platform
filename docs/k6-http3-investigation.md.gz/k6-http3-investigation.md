# k6 HTTP/3 Support Investigation - Proof of Concept

**Date:** December 2024  
**Purpose:** Investigate feasibility of adding native HTTP/3 (QUIC) support to k6 for load testing  
**Status:** Research & Feasibility Analysis

---

## Executive Summary

k6 is a modern, developer-centric load testing tool written in Go. While k6 natively supports HTTP/1.1 and HTTP/2, **HTTP/3 (QUIC) support is not currently available in the official k6 distribution**. This document investigates the feasibility of adding HTTP/3 support to k6, either through:

1. **Custom xk6 extension** (recommended for PoC)
2. **Fork and patch approach** (more invasive, requires maintaining fork)
3. **Upstream contribution** (long-term, requires Grafana approval)

---

## Current State Analysis

### k6 HTTP Protocol Support

**What k6 supports natively:**
- ✅ HTTP/1.1 (via Go's `net/http` package)
- ✅ HTTP/2 (via Go's `golang.org/x/net/http2` package)
- ❌ HTTP/3 (QUIC) - **NOT supported**

### Evidence from Codebase

In `scripts/k6-chaos-test.js`, there's an attempt to use HTTP/3:
```javascript
const res = http.get(URL, {
  headers: { Host: HOST },
  timeout: "10s",
  httpVersion: "HTTP/3",  // ⚠️ This option may not actually work
  noConnectionReuse: false,
});
```

**However, this `httpVersion: "HTTP/3"` option is likely ignored** or may cause k6 to fall back to HTTP/2 or HTTP/1.1, as k6's HTTP module doesn't have HTTP/3 implementation.

### Comments in Codebase

Several comments in the codebase suggest HTTP/3 support, but these appear to be aspirational rather than factual:
- `// k6 supports HTTP/2 multiplexing and HTTP/3 (QUIC) natively` (likely incorrect)
- `// HTTP/2 and HTTP/3 will be negotiated automatically via ALPN` (partially correct - ALPN can negotiate, but k6 can't speak QUIC)

**Reality:** While ALPN can negotiate HTTP/3, k6 cannot actually establish a QUIC connection even if the server advertises HTTP/3 support.

---

## Technical Architecture

### k6 Architecture Overview

k6 is built using:
- **Go runtime** for the core engine and HTTP client
- **Goja** (Go implementation of JavaScript/ECMAScript) for executing test scripts
- **Go's standard library** `net/http` for HTTP/1.1
- **golang.org/x/net/http2** for HTTP/2 support

### HTTP/3 Requirements

HTTP/3 uses **QUIC** (Quick UDP Internet Connections) as its transport protocol, which is fundamentally different from TCP-based HTTP/1.1 and HTTP/2:

1. **UDP-based transport** (not TCP)
2. **Built-in encryption** (TLS 1.3 is integrated into QUIC)
3. **Connection migration** support
4. **Multiplexing without head-of-line blocking**

### Go HTTP/3 Libraries

**Primary option: `quic-go`**
- GitHub: https://github.com/quic-go/quic-go
- HTTP/3 implementation: https://github.com/quic-go/webtransport
- Mature, actively maintained
- Used by Caddy, Cloudflare, and other major projects
- **Note:** There's also `github.com/lucas-clemente/quic-go` (older fork, less maintained)

**HTTP/3 client library:**
- `github.com/quic-go/webtransport` or `github.com/quic-go/quic-go/http3`
- Provides HTTP/3 client/server implementation on top of quic-go

---

## Implementation Approaches

### Approach 1: xk6 Extension (Recommended for PoC)

**xk6** is k6's extension system that allows adding custom functionality without modifying the core k6 codebase.

#### Advantages:
- ✅ Non-invasive (doesn't require forking k6)
- ✅ Can be maintained independently
- ✅ Can be tested and validated separately
- ✅ Can be shared as a standalone extension
- ✅ Easier to iterate and experiment

#### Disadvantages:
- ⚠️ Requires users to build a custom k6 binary with `xk6 build`
- ⚠️ Slight performance overhead (extension boundary)
- ⚠️ May lag behind k6 updates (need to test compatibility)

#### Implementation Steps:

1. **Create xk6 extension structure:**
   ```bash
   mkdir xk6-http3
   cd xk6-http3
   go mod init github.com/your-org/xk6-http3
   ```

2. **Dependencies:**
   ```go
   require (
       github.com/grafana/xk6 v0.0.0-... // Latest xk6
       github.com/quic-go/quic-go v0.40.0 // QUIC library
       github.com/quic-go/webtransport v0.6.0 // HTTP/3 on quic-go
       go.k6.io/k6 v0.47.0 // k6 core
   )
   ```

3. **Extension interface:**
   ```go
   package http3
   
   import (
       "go.k6.io/k6/js/modules"
       "github.com/quic-go/quic-go/http3"
   )
   
   func init() {
       modules.Register("k6/x/http3", New())
   }
   
   type RootModule struct{}
   type ModuleInstance struct {
       vu modules.VU
   }
   
   func New() *RootModule {
       return &RootModule{}
   }
   
   func (r *RootModule) NewModuleInstance(vu modules.VU) *ModuleInstance {
       return &ModuleInstance{vu: vu}
   }
   ```

4. **HTTP/3 Client wrapper:**
   - Wrap `http3.RoundTripper` to match k6's HTTP API
   - Implement connection pooling/reuse
   - Handle TLS/QUIC handshake
   - Map to JavaScript API compatible with k6's `http` module

5. **JavaScript API (should match k6's http module):**
   ```javascript
   import http3 from 'k6/x/http3';
   
   export default function() {
     const res = http3.get('https://example.com/api', {
       headers: { 'X-Custom': 'value' },
       timeout: '30s',
     });
     console.log(res.status, res.body);
   }
   ```

#### Challenges:
- **API compatibility:** Should match k6's `http` module API as closely as possible
- **Connection pooling:** QUIC connections behave differently than TCP - need to handle connection reuse properly
- **TLS handling:** QUIC integrates TLS 1.3, need to ensure certificate validation works
- **Metrics:** Need to ensure HTTP/3 requests are properly tracked in k6 metrics

### Approach 2: Fork and Patch k6 Core

Modify k6's core HTTP module to add HTTP/3 support directly.

#### Advantages:
- ✅ Native integration (no extension overhead)
- ✅ Can use k6's existing HTTP module API
- ✅ Better performance (no extension boundary)
- ✅ Full control over implementation

#### Disadvantages:
- ❌ Requires maintaining a fork of k6
- ❌ Must merge/rebase with upstream k6 releases
- ❌ More complex to develop and test
- ❌ Harder to share with community

#### Implementation Steps:

1. **Fork k6 repository:**
   ```bash
   git clone https://github.com/grafana/k6.git
   cd k6
   git remote add fork https://github.com/your-org/k6.git
   ```

2. **Modify HTTP module:**
   - File: `lib/netext/httpext/client.go`
   - Add HTTP/3 client alongside HTTP/1.1 and HTTP/2
   - Modify protocol negotiation logic to support QUIC

3. **Update HTTP transport selection:**
   - Detect HTTP/3 support (via ALPN or explicit option)
   - Initialize QUIC client when HTTP/3 is requested
   - Fallback to HTTP/2/1.1 if QUIC fails

4. **Update metrics:**
   - Ensure HTTP/3 requests are tracked properly
   - Add protocol tag: `protocol: http3`

### Approach 3: Upstream Contribution

Contribute HTTP/3 support directly to k6's main repository.

#### Advantages:
- ✅ Benefits entire k6 community
- ✅ Official support and maintenance
- ✅ No fork maintenance burden

#### Disadvantages:
- ❌ Requires Grafana/k6 team approval
- ❌ Long development and review cycle
- ❌ Must align with k6's architecture decisions
- ❌ May require significant design discussions

#### Process:
1. Open GitHub issue in k6 repository proposing HTTP/3 support
2. Discuss design and implementation approach with maintainers
3. Get approval before starting implementation
4. Implement following k6's coding standards
5. Submit PR and iterate based on feedback

---

## Proof of Concept Plan

### Phase 1: Research & Validation (Current Phase)

- ✅ Verify current k6 HTTP/3 support status
- ✅ Research quic-go library and HTTP/3 implementation
- ✅ Review k6's HTTP module architecture
- ✅ Analyze xk6 extension system
- ✅ Document findings (this document)

### Phase 2: Minimal xk6 Extension

**Goal:** Get a basic HTTP/3 request working through an xk6 extension

**Steps:**
1. Set up xk6 extension skeleton
2. Integrate quic-go HTTP/3 client
3. Create minimal JavaScript API (`http3.get()`)
4. Test against Caddy server (which supports HTTP/3)
5. Validate basic connectivity and TLS

**Success Criteria:**
- Can make HTTP/3 GET request from k6 script
- Request completes successfully
- Response status and body accessible

**Estimated Time:** 2-3 days

### Phase 3: API Compatibility

**Goal:** Match k6's HTTP module API as closely as possible

**Steps:**
1. Implement `http3.get()`, `http3.post()`, `http3.put()`, `http3.del()`, etc.
2. Support request options (headers, timeout, tags, etc.)
3. Return response object matching k6's format
4. Implement connection pooling/reuse

**Success Criteria:**
- API matches k6's `http` module (with HTTP/3-specific options)
- Can drop-in replace `http` with `http3` in simple scripts
- Connection reuse works correctly

**Estimated Time:** 3-5 days

### Phase 4: Integration with k6 Metrics

**Goal:** Ensure HTTP/3 requests are properly tracked

**Steps:**
1. Integrate with k6's metrics system
2. Track HTTP/3-specific metrics (QUIC handshake time, etc.)
3. Add protocol tagging
4. Validate metrics appear in k6 output

**Success Criteria:**
- HTTP/3 requests appear in k6 metrics
- Protocol tag shows `http3`
- Custom metrics (handshake time, etc.) available

**Estimated Time:** 2-3 days

### Phase 5: Load Testing & Validation

**Goal:** Validate HTTP/3 extension under load

**Steps:**
1. Run load tests against Caddy (HTTP/3 enabled)
2. Compare HTTP/2 vs HTTP/3 performance
3. Test connection pooling under high concurrency
4. Validate ephemeral port usage (QUIC should use UDP, not TCP ports)
5. Test error handling and fallback scenarios

**Success Criteria:**
- Extension handles high load (50+ VUs)
- Metrics are accurate
- No connection leaks
- Performance is acceptable

**Estimated Time:** 2-3 days

### Phase 6: Production Readiness

**Goal:** Make extension robust and production-ready

**Steps:**
1. Error handling and edge cases
2. Documentation and examples
3. CI/CD setup for building custom k6 binaries
4. Performance optimization
5. Compatibility testing with different k6 versions

**Success Criteria:**
- Extension is stable and well-documented
- Can be easily integrated into existing k6 workflows
- Performance overhead is minimal

**Estimated Time:** 3-5 days

---

## Technical Implementation Details

### QUIC Connection Management

QUIC connections are stateful and must be properly managed:

```go
// Connection pool for QUIC connections
type QUICConnPool struct {
    mu       sync.RWMutex
    conns    map[string]*quic.Connection
    dialer   *quic.Dialer
}

// Get or create QUIC connection for a host
func (p *QUICConnPool) GetConnection(addr string) (*quic.Connection, error) {
    p.mu.RLock()
    conn, exists := p.conns[addr]
    p.mu.RUnlock()
    
    if exists && conn != nil {
        return conn, nil
    }
    
    // Create new connection
    p.mu.Lock()
    defer p.mu.Unlock()
    
    // Double-check after acquiring write lock
    if conn, exists := p.conns[addr]; exists {
        return conn, nil
    }
    
    conn, err := p.dialer.Dial(context.Background(), addr, &tls.Config{
        ServerName: addr,
        NextProtos: []string{"h3"}, // HTTP/3 ALPN
    }, &quic.Config{})
    
    if err != nil {
        return nil, err
    }
    
    p.conns[addr] = conn
    return conn, nil
}
```

### HTTP/3 RoundTripper Integration

```go
import (
    "github.com/quic-go/quic-go/http3"
    "net/http"
)

type HTTP3Client struct {
    rt *http3.RoundTripper
}

func NewHTTP3Client() *HTTP3Client {
    return &HTTP3Client{
        rt: &http3.RoundTripper{
            TLSClientConfig: &tls.Config{
                // TLS config for QUIC
            },
            QuicConfig: &quic.Config{
                // QUIC-specific config
            },
        },
    }
}

func (c *HTTP3Client) Do(req *http.Request) (*http.Response, error) {
    return c.rt.RoundTrip(req)
}
```

### JavaScript API Mapping

```javascript
// Extension exports
export default class HTTP3 {
  constructor(vu) {
    this.vu = vu;
    // Initialize Go HTTP3 client
  }
  
  get(url, params) {
    return this.request('GET', url, null, params);
  }
  
  post(url, body, params) {
    return this.request('POST', url, body, params);
  }
  
  request(method, url, body, params) {
    // Call Go implementation via Goja bindings
    // Return response object matching k6's http module format
  }
}
```

---

## Challenges & Considerations

### 1. QUIC vs TCP Differences

**Challenge:** QUIC is UDP-based and behaves differently than TCP:
- No TCP handshake (QUIC has its own handshake)
- Connection migration support
- Different error conditions
- Built-in encryption (TLS 1.3 integrated)

**Mitigation:**
- Abstract connection handling behind a common interface
- Handle QUIC-specific errors appropriately
- Document differences for users

### 2. Connection Pooling

**Challenge:** QUIC connections are multiplexed streams, not separate connections like HTTP/1.1.

**Considerations:**
- One QUIC connection can handle many concurrent requests (like HTTP/2)
- Need to balance connection reuse vs. connection limits
- QUIC supports connection migration (handling IP changes)

**Implementation:**
- Pool QUIC connections per host
- Limit concurrent streams per connection
- Implement connection lifecycle management

### 3. TLS/Encryption

**Challenge:** QUIC integrates TLS 1.3, so certificate validation must work correctly.

**Requirements:**
- Support custom CA certificates (like k6's current TLS support)
- Validate certificates properly
- Support client certificates if needed
- Handle certificate errors appropriately

### 4. Performance

**Challenge:** Extension boundary may add overhead compared to native implementation.

**Mitigation:**
- Profile and optimize hot paths
- Minimize data copying between Go and JavaScript
- Consider native implementation if performance is critical

### 5. Compatibility

**Challenge:** Ensure extension works with different k6 versions.

**Strategy:**
- Pin to specific k6 version initially
- Test compatibility matrix
- Document supported k6 versions
- Provide migration guide for breaking changes

### 6. Error Handling

**Challenge:** QUIC errors are different from TCP/HTTP errors.

**Examples:**
- Connection refused (UDP vs TCP semantics)
- Handshake failures
- Stream errors
- Connection migration failures

**Implementation:**
- Map QUIC errors to HTTP-like errors where possible
- Provide detailed error information
- Support retry logic

### 7. Metrics & Observability

**Challenge:** HTTP/3 has different characteristics than HTTP/2.

**Metrics to track:**
- QUIC handshake time
- Stream establishment time
- Connection migration events
- UDP packet loss (if available)
- Stream errors vs connection errors

**Implementation:**
- Integrate with k6's metrics system
- Add custom metrics for QUIC-specific events
- Tag metrics with protocol version

---

## Testing Strategy

### Unit Tests

1. **Connection Management:**
   - Test connection pooling
   - Test connection reuse
   - Test connection cleanup

2. **Request/Response:**
   - Test GET, POST, PUT, DELETE requests
   - Test headers
   - Test request/response bodies
   - Test timeouts

3. **Error Handling:**
   - Test connection failures
   - Test handshake failures
   - Test stream errors
   - Test timeout scenarios

### Integration Tests

1. **Against Caddy:**
   - Test HTTP/3 requests to Caddy server
   - Test protocol negotiation
   - Test TLS validation
   - Test connection reuse

2. **Against Cloudflare/Other HTTP/3 Servers:**
   - Validate compatibility with other HTTP/3 implementations
   - Test edge cases

### Load Tests

1. **Concurrent Requests:**
   - Test with 10, 50, 100, 500 VUs
   - Validate connection pooling under load
   - Measure performance vs HTTP/2

2. **Long-Running Tests:**
   - Test connection stability over time
   - Test connection migration (if applicable)
   - Test memory leaks

3. **Error Scenarios:**
   - Test with intermittent network issues
   - Test with server restarts
   - Test with connection timeouts

---

## Comparison: HTTP/2 vs HTTP/3

### Advantages of HTTP/3 for Load Testing

1. **No Head-of-Line Blocking:**
   - HTTP/2 can still experience HOL blocking at TCP level
   - HTTP/3 eliminates this completely

2. **Faster Connection Establishment:**
   - QUIC combines handshake + TLS, reducing latency
   - 0-RTT connection resumption

3. **Better Multiplexing:**
   - True multiplexing without TCP limitations
   - Better handling of packet loss

4. **Connection Migration:**
   - Handles network changes better
   - Useful for mobile/network testing scenarios

### When HTTP/3 May Not Help

1. **Low Latency Networks:**
   - Benefits are less pronounced on low-latency, reliable networks
   - HTTP/2 may be sufficient

2. **Simple Request Patterns:**
   - If not using multiplexing heavily, benefits are minimal

3. **Infrastructure Support:**
   - Requires HTTP/3-capable servers (Caddy, Cloudflare, etc.)
   - Not all infrastructure supports HTTP/3 yet

---

## Building Custom k6 with xk6 Extension

### Build Command

```bash
# Install xk6
go install go.k6.io/xk6/cmd/xk6@latest

# Build k6 with HTTP/3 extension
xk6 build --with github.com/your-org/xk6-http3@latest

# This creates a k6 binary with HTTP/3 support
./k6 run test.js
```

### Docker Image

```dockerfile
FROM golang:1.21-alpine AS builder

RUN apk add --no-cache git
RUN go install go.k6.io/xk6/cmd/xk6@latest

WORKDIR /build
RUN xk6 build --with github.com/your-org/xk6-http3@latest --output /k6

FROM alpine:latest
COPY --from=builder /k6 /usr/local/bin/k6
ENTRYPOINT ["k6"]
```

### Kubernetes Job Example

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: k6-http3-test
spec:
  template:
    spec:
      containers:
      - name: k6
        image: your-registry/k6-http3:latest
        command: ["k6", "run", "/scripts/test.js"]
        volumeMounts:
        - name: test-script
          mountPath: /scripts
      volumes:
      - name: test-script
        configMap:
          name: k6-test-script
```

---

## Success Metrics

### PoC Success Criteria

1. **Functionality:**
   - ✅ Can make HTTP/3 requests from k6 scripts
   - ✅ API is compatible with k6's HTTP module
   - ✅ Requests are tracked in k6 metrics

2. **Performance:**
   - ✅ Handles 50+ VUs without issues
   - ✅ Connection pooling works correctly
   - ✅ No connection leaks

3. **Reliability:**
   - ✅ Handles errors gracefully
   - ✅ Supports TLS/certificate validation
   - ✅ Compatible with Caddy HTTP/3 server

### Future Enhancements (Post-PoC)

1. **Advanced Features:**
   - 0-RTT connection resumption
   - Connection migration
   - Custom QUIC configuration options

2. **Observability:**
   - QUIC-specific metrics
   - Detailed handshake timing
   - Stream-level metrics

3. **Integration:**
   - Support in k6 Cloud (if applicable)
   - IDE extensions/autocomplete
   - Documentation and examples

---

## Resources & References

### k6 Documentation
- k6 Extensions: https://k6.io/docs/extensions/get-started/create/
- xk6 Documentation: https://github.com/grafana/xk6
- k6 HTTP Module API: https://k6.io/docs/javascript-api/k6-http/

### HTTP/3 & QUIC
- QUIC RFC 9000: https://www.rfc-editor.org/rfc/rfc9000.html
- HTTP/3 RFC 9114: https://www.rfc-editor.org/rfc/rfc9114.html
- quic-go Documentation: https://github.com/quic-go/quic-go

### Example Implementations
- Caddy HTTP/3: https://caddyserver.com/docs/automatic-https#http-3
- Cloudflare HTTP/3: https://developers.cloudflare.com/http3/
- curl HTTP/3: https://curl.se/docs/http3.html

### Related Projects
- xk6-browser: https://github.com/grafana/xk6-browser
- xk6-redis: https://github.com/grafana/xk6-redis
- xk6-kafka: https://github.com/grafana/xk6-kafka

---

## Conclusion

Adding HTTP/3 support to k6 is **technically feasible** and can be achieved through an xk6 extension. The recommended approach for a proof of concept is:

1. **Start with xk6 extension** - Non-invasive, easier to iterate
2. **Use quic-go library** - Mature, well-maintained
3. **Match k6's HTTP API** - Ensures compatibility and ease of use
4. **Test against Caddy** - We already have HTTP/3-capable infrastructure

**Estimated Timeline for PoC:**
- Phase 1 (Research): ✅ Complete (this document)
- Phase 2-3 (Basic Implementation): 5-8 days
- Phase 4-5 (Integration & Testing): 4-6 days
- Phase 6 (Polish): 3-5 days
- **Total: ~2-3 weeks for a working PoC**

**Next Steps:**
1. Review and approve this investigation
2. Set up xk6 extension skeleton
3. Begin Phase 2 implementation
4. Iterate based on findings

---

## Appendix: Code Snippets for Reference

### Basic xk6 Extension Structure

```go
// main.go
package main

import (
    "go.k6.io/k6/js/modules"
    "github.com/your-org/xk6-http3/http3"
)

func init() {
    modules.Register("k6/x/http3", http3.NewRootModule())
}
```

```go
// http3/module.go
package http3

import "go.k6.io/k6/js/modules"

type RootModule struct{}

func NewRootModule() *RootModule {
    return &RootModule{}
}

func (r *RootModule) NewModuleInstance(vu modules.VU) modules.Instance {
    return &ModuleInstance{vu: vu}
}
```

### QUIC Connection Example

```go
import (
    "context"
    "crypto/tls"
    "github.com/quic-go/quic-go"
    "github.com/quic-go/quic-go/http3"
)

func createHTTP3Client() *http.Client {
    roundTripper := &http3.RoundTripper{
        TLSClientConfig: &tls.Config{
            // Your TLS config
        },
    }
    defer roundTripper.Close()
    
    return &http.Client{
        Transport: roundTripper,
    }
}
```

---

**Document Version:** 1.0  
**Last Updated:** December 2024  
**Author:** Investigation Team  
**Status:** Ready for Review

