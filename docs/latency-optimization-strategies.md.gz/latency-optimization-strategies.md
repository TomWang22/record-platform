# Python AI Service Latency Optimization Strategies

**Last Updated:** 2025-12-08  
**Current P95 Latency:** 14.08s (HTTP), 20.76s (AI Advice)  
**Target P95 Latency:** <5s (HTTP), <10s (AI Advice)

---

## Current Latency Breakdown

### Test Results (2025-12-08)
- **P95 HTTP Latency:** 14.08s ⚠️
- **P95 AI Advice:** 20.76s ⚠️
- **P95 Analytics → AI:** 260ms ✅ (excellent)
- **P95 API Gateway:** 3.73s ⚠️
- **Average Latency:** 2.75s
- **Max Latency:** 60.26s

### Latency Sources (Estimated)
1. **External API Calls (Discogs, eBay):** ~8-12s (40-60% of total)
2. **Analytics Service Calls:** ~0.5-2s (5-10% of total)
3. **Database Queries:** ~0.1-0.5s (2-5% of total)
4. **Service Processing:** ~0.5-1s (5-10% of total)
5. **Network/Connection Overhead:** ~1-3s (10-20% of total)
6. **Timeouts/Retries:** ~5-10s (25-50% of total when errors occur)

---

## Optimization Strategies

### 1. External API Optimization (Highest Impact) 🎯

**Current Issues:**
- Discogs API: 60 req/min limit, ~2-5s per request
- eBay API: Rate limited, ~3-8s per request
- Sequential calls (no parallelization)
- No request batching

**Solutions:**

#### A. Aggressive Caching
- **Current:** 24-hour cache TTL
- **Improvement:** 
  - Increase cache TTL to 7 days for stable prices
  - Implement cache warming for popular queries
  - Pre-populate cache with common album queries
  - Use Redis with longer TTL (30 days for stable data)

#### B. Request Batching
- **Current:** One query = one API call
- **Improvement:**
  - Batch multiple queries into single API calls
  - Use eBay's batch API if available
  - Group similar queries together

#### C. Parallel External API Calls
- **Current:** Sequential calls to Discogs and eBay
- **Improvement:**
  - Call Discogs and eBay in parallel (already done)
  - Use `asyncio.gather()` for all external calls
  - Don't wait for both - use first successful response

#### D. Fallback Strategies
- **Current:** Returns empty on timeout
- **Improvement:**
  - Use cached data even if stale (graceful degradation)
  - Return partial results immediately
  - Don't block on external APIs - make them truly optional

#### E. Reduce External API Calls
- **Current:** Calls external APIs for every request
- **Improvement:**
  - Only call external APIs if cache miss AND query is new
  - Skip external APIs if analytics has good data
  - Use analytics predictions as primary source

**Expected Impact:** Reduce P95 latency by 50-70% (from 20.76s to 6-10s)

---

### 2. Analytics Service Optimization

**Current Issues:**
- Slow database queries (unoptimized)
- No connection pooling optimization
- Sequential processing

**Solutions:**

#### A. Database Query Optimization
- **Current:** Full table scans on `search_history`
- **Improvement:**
  - Add indexes on frequently queried columns
  - Use materialized views for common queries
  - Implement query result caching in analytics service

#### B. Response Time Optimization
- **Current:** 260ms P95 (good, but can be better)
- **Improvement:**
  - Reduce to <100ms P95 with better caching
  - Pre-compute common recommendations
  - Use Redis for hot data

**Expected Impact:** Reduce Analytics → AI latency by 30-50% (from 260ms to 130-180ms)

---

### 3. Service Processing Optimization

**Current Issues:**
- Sequential processing of advice endpoints
- Multiple database writes per request
- Synchronous operations blocking async flow

**Solutions:**

#### A. Parallelize Advice Generation
- **Current:** Sequential calls to 4 advice endpoints
- **Improvement:**
  - Generate all 4 advice types in parallel
  - Use `asyncio.gather()` for concurrent processing
  - Return results as they complete (streaming)

#### B. Async Database Operations
- **Current:** Some blocking database operations
- **Improvement:**
  - Make all DB operations fully async
  - Batch database writes
  - Use connection pooling effectively

#### C. Reduce Processing Time
- **Current:** Complex logic in advice generation
- **Improvement:**
  - Simplify advice algorithms
  - Cache computed results
  - Pre-compute common calculations

**Expected Impact:** Reduce processing time by 20-30% (from 0.5-1s to 0.3-0.7s)

---

### 4. Connection Pool & Network Optimization

**Current Issues:**
- Connection pool exhaustion under load
- HTTP/1.1 limitations (no multiplexing)
- Connection reset errors

**Solutions:**

#### A. Increase Connection Pools
- **Current:** 300 max connections
- **Improvement:**
  - Increase to 500-1000 for peak load
  - Monitor pool utilization
  - Auto-scale based on demand

#### B. HTTP/2 Support
- **Current:** HTTP/1.1 for analytics service
- **Improvement:**
  - Upgrade analytics service to support HTTP/2
  - Use HTTP/2 for all internal service calls
  - Enable multiplexing (multiple requests per connection)

#### C. Connection Reuse
- **Current:** Some connection churn
- **Improvement:**
  - Increase keepalive timeouts
  - Reuse connections more aggressively
  - Implement connection health checks

**Expected Impact:** Reduce connection overhead by 30-40% (from 1-3s to 0.6-1.8s)

---

### 5. Timeout & Retry Optimization

**Current Issues:**
- Long timeouts (15s) causing slow failures
- Too many retries (3 attempts)
- No circuit breaker

**Solutions:**

#### A. Reduce Timeouts
- **Current:** 15s timeout for analytics, 15s for external APIs
- **Improvement:**
  - Reduce to 5s for analytics (fail fast)
  - Reduce to 8s for external APIs (fail fast)
  - Use cached data on timeout

#### B. Circuit Breaker Pattern
- **Current:** Always retries on failure
- **Improvement:**
  - Implement circuit breaker for external APIs
  - Skip external APIs if circuit is open
  - Use cached data when circuit is open

#### C. Smarter Retry Logic
- **Current:** 3 retries with exponential backoff
- **Improvement:**
  - Reduce to 1-2 retries for external APIs
  - Don't retry on 4xx errors
  - Retry only on network errors, not timeouts

**Expected Impact:** Reduce timeout overhead by 50-70% (from 5-10s to 1.5-3s)

---

### 6. Caching Strategy Enhancement

**Current Issues:**
- Cache misses still trigger external API calls
- No cache warming
- Cache TTL may be too short for stable data

**Solutions:**

#### A. Multi-Layer Caching
- **Current:** Redis cache only
- **Improvement:**
  - L1: In-memory cache (fast, small)
  - L2: Redis cache (medium, larger)
  - L3: Database cache (slow, persistent)
  - Check L1 → L2 → L3 → External API

#### B. Cache Warming
- **Current:** No cache warming
- **Improvement:**
  - Pre-populate cache with popular queries
  - Warm cache on service startup
  - Background job to refresh cache

#### C. Smarter Cache TTL
- **Current:** 24 hours for all data
- **Improvement:**
  - 7-30 days for stable prices (rarely change)
  - 1 hour for trending data (changes frequently)
  - Adaptive TTL based on data volatility

**Expected Impact:** Increase cache hit rate from ~60% to ~90%, reducing external API calls by 75%

---

### 7. Service Capacity & Scaling

**Current Issues:**
- 2 replicas may not be enough for 50 VUs
- CPU/memory limits may be too low
- No auto-scaling

**Solutions:**

#### A. Increase Replicas
- **Current:** 2 replicas
- **Improvement:**
  - Increase to 3-4 replicas for better load distribution
  - Use HPA (Horizontal Pod Autoscaler) for auto-scaling
  - Scale based on CPU/memory/request rate

#### B. Resource Limits
- **Current:** 4 CPU, 4Gi memory
- **Improvement:**
  - Increase to 8 CPU, 8Gi memory for peak load
  - Monitor resource utilization
  - Right-size based on actual usage

#### C. Load Balancing
- **Current:** Kubernetes default load balancing
- **Improvement:**
  - Use least-connections load balancing
  - Implement health-based routing
  - Distribute load more evenly

**Expected Impact:** Reduce service overload errors by 50-70%, improve P95 latency by 20-30%

---

## Implementation Priority

### Phase 1: Quick Wins (1-2 days)
1. ✅ **Aggressive Caching** - Increase cache TTL to 7 days
2. ✅ **Reduce Timeouts** - 5s for analytics, 8s for external APIs
3. ✅ **Circuit Breaker** - Skip external APIs when circuit is open
4. ✅ **Parallel External Calls** - Already done, verify it's working

**Expected Impact:** Reduce P95 latency by 30-40% (from 20.76s to 12-14s)

### Phase 2: Medium Effort (3-5 days)
1. ✅ **Request Batching** - Batch multiple queries
2. ✅ **Multi-Layer Caching** - L1 (memory) + L2 (Redis) + L3 (DB)
3. ✅ **Cache Warming** - Pre-populate popular queries
4. ✅ **Increase Replicas** - 2 → 3-4 replicas

**Expected Impact:** Reduce P95 latency by additional 20-30% (from 12-14s to 8-10s)

### Phase 3: Long-term (1-2 weeks)
1. ✅ **Analytics Service HTTP/2** - Upgrade to HTTP/2
2. ✅ **Database Query Optimization** - Add indexes, materialized views
3. ✅ **Auto-Scaling** - HPA based on metrics
4. ✅ **Request Streaming** - Return results as they complete

**Expected Impact:** Reduce P95 latency by additional 20-30% (from 8-10s to 5-7s)

---

## Target Metrics

### Current (2025-12-08)
- P95 HTTP Latency: 14.08s
- P95 AI Advice: 20.76s
- P95 Analytics → AI: 260ms
- P95 API Gateway: 3.73s

### Target (After Optimizations)
- P95 HTTP Latency: <5s (64% reduction)
- P95 AI Advice: <10s (52% reduction)
- P95 Analytics → AI: <150ms (42% reduction)
- P95 API Gateway: <1s (73% reduction)

---

## Monitoring & Validation

### Key Metrics to Track
1. **Cache Hit Rate:** Target >90%
2. **External API Call Rate:** Target <10% of requests
3. **Timeout Rate:** Target <5%
4. **Connection Pool Utilization:** Target <80%
5. **Service CPU/Memory:** Target <70%

### Success Criteria
- ✅ P95 latency <5s (HTTP)
- ✅ P95 latency <10s (AI Advice)
- ✅ Error rate <10%
- ✅ Cache hit rate >90%
- ✅ 100% uptime under normal load

---

## Next Steps

1. **Immediate:** Implement Phase 1 optimizations (caching, timeouts, circuit breaker)
2. **Short-term:** Implement Phase 2 optimizations (batching, multi-layer cache, scaling)
3. **Long-term:** Implement Phase 3 optimizations (HTTP/2, DB optimization, auto-scaling)
4. **Continuous:** Monitor metrics and iterate based on results

