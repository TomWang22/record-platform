# Analytics → Python AI Pipeline Bottleneck Analysis

## Executive Summary

The pipeline shows **33-34% error rate** with timeouts and connection errors. Root causes identified:

1. **HTTP/1.1 Limitations**: No connection multiplexing (one request per connection)
2. **Database Connection Pool Exhaustion**: Analytics service has only 30 max connections
3. **Slow Analytics Queries**: Worker threads in predict-price endpoint can be slow
4. **Network Protocol Mismatch**: Python AI uses httpx (HTTP/1.1), Analytics uses Express (HTTP/1.1 only)

## Detailed Findings

### 1. HTTP Client Configuration

**Current Setup:**
- Python AI Service: `httpx.AsyncClient` (HTTP/1.1 by default)
- Analytics Service: Express.js (HTTP/1.1 only, no HTTP/2 support)
- Connection Pool: `max_connections=100, max_keepalive_connections=20`

**Issues:**
- HTTP/1.1 has no connection multiplexing (one request per connection)
- With 50 VUs, we need 50+ concurrent connections
- Connection reuse helps but still limited by HTTP/1.1 overhead

**Optimizations Applied:**
- Added explicit `keepalive_expiry=30.0` for better connection reuse
- Increased `max_keepalive_connections=20` to keep more connections alive
- Added retry logic with exponential backoff (0.5s, 1s, 2s)

### 2. Database Connection Pools

**Current Configuration:**
- Analytics Service: `max=30` connections (listings + analytics pools)
- Python AI Service: `max=50` connections

**Issues:**
- With 50 VUs, analytics service may exhaust its 30-connection pool
- Each request to analytics may need a DB connection
- Connection pool exhaustion causes "connection refused" errors

**Recommendations:**
1. Increase analytics pool to `max=50` (match Python AI)
2. Use PgBouncer for connection pooling (if not already)
3. Monitor active connections during load tests

### 3. Analytics Service Performance

**predict-price Endpoint:**
- Uses worker threads for parallel processing
- Queries historical price data (may be slow)
- No caching of prediction results

**Issues:**
- Worker thread overhead adds latency
- Database queries may be slow (need to check `pg_stat_statements`)
- No result caching means repeated queries for same items

**Recommendations:**
1. Add Redis caching for prediction results
2. Optimize database queries (add indexes, use EXPLAIN ANALYZE)
3. Consider async processing instead of worker threads

### 4. Network Protocols

**Current:**
- HTTP/1.1 only (no HTTP/2, HTTP/3, or gRPC)
- No connection multiplexing
- Higher latency due to connection overhead

**Recommendations:**
1. **Short-term**: Optimize HTTP/1.1 usage (connection pooling, keepalive)
2. **Medium-term**: Upgrade analytics service to support HTTP/2
3. **Long-term**: Consider gRPC for inter-service communication

## Error Rate Analysis

**Observed Errors:**
- `connection refused`: Database pool exhaustion or service unavailable
- `connection reset by peer`: Service overloaded or connection timeout
- `request timeout`: Slow analytics queries (>5s)
- `EOF`: Service closed connection prematurely

**Error Distribution:**
- ~33-34% HTTP error rate (timeouts, connection errors)
- ~96% pipeline success rate (business logic succeeds despite HTTP errors)
- Most errors occur during high load (50 VUs)

## Recommendations

### Immediate Actions (High Priority)

1. **Increase Analytics DB Pool**
   ```typescript
   // services/analytics-service/src/db.ts
   max: 50  // Increase from 30 to 50
   ```

2. **Add Connection Monitoring**
   - Monitor active DB connections during load tests
   - Alert when pool usage > 80%

3. **Optimize Analytics Queries**
   - Run `EXPLAIN ANALYZE` on slow queries
   - Add missing indexes
   - Cache frequently accessed data

### Medium-term Improvements

1. **Add Result Caching**
   - Cache prediction results in Redis (TTL: 5-10 minutes)
   - Cache similar searches and trending data

2. **Optimize Worker Threads**
   - Consider async/await instead of worker threads
   - Batch process multiple items together

3. **Increase Timeouts**
   - Analytics predict-price: Increase from 5s to 10s
   - Add circuit breaker pattern for fault tolerance

### Long-term Enhancements

1. **HTTP/2 Support**
   - Upgrade analytics service to support HTTP/2
   - Use httpx with HTTP/2 enabled (requires `httpx[http2]`)

2. **gRPC Migration**
   - Define protobuf schemas for analytics → Python AI communication
   - Use gRPC for better performance and multiplexing

3. **Service Mesh**
   - Consider Istio/Linkerd for advanced load balancing
   - Automatic retries and circuit breaking

## Monitoring & Investigation

Use the investigation script to check current state:

```bash
./scripts/investigate-pipeline-bottlenecks.sh
```

This script checks:
- Database connection pool usage
- Slow queries (pg_stat_statements)
- Network connectivity
- Recent connection errors in logs

## Testing

Run k6 tests with automatic pod cleanup:

```bash
./scripts/run-k6-python-ai-with-cleanup.sh
```

This ensures:
- Pod is cleaned up after test (even if `--rm` fails)
- Graph is generated automatically
- Exit code is preserved

## Next Steps

1. ✅ Add pod cleanup wrapper script
2. ✅ Optimize HTTP client with keepalive
3. ⏳ Increase analytics DB pool to 50
4. ⏳ Add result caching for predictions
5. ⏳ Run EXPLAIN ANALYZE on slow queries
6. ⏳ Consider HTTP/2 or gRPC migration

