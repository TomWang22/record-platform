# Moving PostgreSQL Outside Kubernetes

## Why This Makes Sense

You've been running Postgres in K8s without an operator - that's **hardcore mode**. Moving it outside is a **production-grade decision**, not a retreat.

### Current Pain Points (K8s Inside)
- ❌ Pod restarts = cold cache = slow queries
- ❌ PVC reclaim battles
- ❌ WAL archive filling disk
- ❌ Node failures = DB resets
- ❌ Storage I/O pressure from scheduler
- ❌ Disk space issues (100% full = no writes)

### Benefits (Outside K8s)
- ✅ Stable disk I/O
- ✅ Persistent cache across restarts
- ✅ Proper WAL management
- ✅ No PVC juggling
- ✅ Predictable performance
- ✅ Easier backups/restores
- ✅ No pod lifecycle issues

## Migration Options

### Option A: Local Development (Docker Compose)
**Best for**: Development, testing, local benchmarks

**Pros**:
- Already have `docker-compose.yml` with Postgres
- Fast iteration
- No network latency
- Easy to reset

**Cons**:
- Not production-ready
- Single machine only

### Option B: Dedicated VM/Server
**Best for**: Production, staging, performance-critical workloads

**Pros**:
- Full control over resources
- Stable I/O
- Can optimize OS-level settings
- Easy to scale vertically
- Standard Postgres ops

**Cons**:
- Need to manage the server
- Network setup required

### Option C: Managed Database (RDS, AlloyDB, etc.)
**Best for**: Production when you want managed ops

**Pros**:
- Fully managed
- Automatic backups
- High availability
- Monitoring built-in

**Cons**:
- Cost
- Less control
- Vendor lock-in

## Recommended: Option B (Dedicated VM/Server)

This gives you the best balance of control and stability.

## Migration Steps

### 1. Set Up Postgres Outside K8s

#### On a dedicated server/VM:

```bash
# Install Postgres 16
sudo apt-get update
sudo apt-get install -y postgresql-16 postgresql-contrib-16

# Configure Postgres
sudo -u postgres psql <<'SQL'
-- Create database
CREATE DATABASE records;

-- Create app user
CREATE USER record_app WITH PASSWORD 'SUPER_STRONG_APP_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE records TO record_app;

-- Create superuser for admin tasks
ALTER USER postgres WITH PASSWORD 'YOUR_SECURE_PASSWORD';
SQL

# Configure postgresql.conf for performance
sudo nano /etc/postgresql/16/main/postgresql.conf
```

**Key settings for performance:**
```ini
# Memory
shared_buffers = 2GB
effective_cache_size = 8GB
work_mem = 256MB
maintenance_work_mem = 512MB

# WAL
wal_level = replica
max_wal_size = 2GB
min_wal_size = 80MB

# Connections
max_connections = 200

# Performance
random_page_cost = 1.0
cpu_index_tuple_cost = 0.0005
cpu_tuple_cost = 0.01
effective_io_concurrency = 200

# Parallelism
max_worker_processes = 16
max_parallel_workers = 16
max_parallel_workers_per_gather = 4

# JIT
jit = off

# Extensions
shared_preload_libraries = 'pg_stat_statements,pg_trgm'

# Autovacuum
autovacuum_naptime = 10s
autovacuum_vacuum_scale_factor = 0.05
autovacuum_analyze_scale_factor = 0.02
```

**Configure pg_hba.conf for remote access:**
```bash
sudo nano /etc/postgresql/16/main/pg_hba.conf
```

Add:
```
# Allow connections from K8s cluster
host    all             all             10.0.0.0/8              md5
host    all             all             172.16.0.0/12           md5
```

**Configure postgresql.conf for network:**
```ini
listen_addresses = '*'
port = 5432
```

**Restart Postgres:**
```bash
sudo systemctl restart postgresql
sudo systemctl enable postgresql
```

### 2. Export Data from K8s

```bash
# From your local machine
NS="record-platform"
POD=$(kubectl -n "$NS" get pod -l app=postgres -o jsonpath='{.items[0].metadata.name}')

# Create backup
kubectl -n "$NS" exec "$POD" -c db -- \
  pg_dump -U postgres -d records -F c -f /tmp/records_backup.dump

# Copy to local
kubectl -n "$NS" cp "$POD:/tmp/records_backup.dump" ./records_backup.dump -c db
```

### 3. Import to External Postgres

```bash
# On external Postgres server
pg_restore -U postgres -d records -v records_backup.dump
```

Or from your local machine:
```bash
pg_restore -h YOUR_EXTERNAL_HOST -U postgres -d records -v records_backup.dump
```

### 4. Update K8s Config

Update connection strings in `infra/k8s/base/config/app-config.yaml`:

```yaml
DATABASE_URL: postgresql://record_app:SUPER_STRONG_APP_PASSWORD@YOUR_EXTERNAL_HOST:5432/records?connect_timeout=5
POSTGRES_URL: postgresql://record_app:SUPER_STRONG_APP_PASSWORD@YOUR_EXTERNAL_HOST:5432/records?connect_timeout=5
```

### 5. Update Service Discovery

If you want to keep using the service name, create an ExternalName service:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: record-platform
spec:
  type: ExternalName
  externalName: YOUR_EXTERNAL_HOST
  ports:
  - port: 5432
```

### 6. Test Connection

```bash
# From a pod in the cluster
kubectl -n record-platform run -it --rm test-pg --image=postgres:16-alpine --restart=Never -- \
  psql -h YOUR_EXTERNAL_HOST -U record_app -d records -c "SELECT 1;"
```

## Performance Optimization (External Postgres)

Once outside K8s, you can optimize at the OS level:

### 1. Tune Linux I/O Scheduler
```bash
# For SSDs
echo noop > /sys/block/sda/queue/scheduler
# or
echo deadline > /sys/block/sda/queue/scheduler
```

### 2. Increase File Descriptors
```bash
# /etc/security/limits.conf
postgres soft nofile 65536
postgres hard nofile 65536
```

### 3. Tune Kernel Parameters
```bash
# /etc/sysctl.conf
vm.swappiness = 1
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5
kernel.shmmax = 68719476736
kernel.shmall = 4294967296
```

### 4. Use ZFS or XFS for Better I/O
```bash
# XFS is great for Postgres
sudo mkfs.xfs /dev/sdb
sudo mount -t xfs /dev/sdb /var/lib/postgresql
```

## Monitoring

Set up monitoring for external Postgres:

```bash
# Install pg_stat_statements
sudo -u postgres psql -d records <<'SQL'
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
```

Use Prometheus + postgres_exporter or Grafana Cloud.

## Backup Strategy

```bash
# Daily backups
0 2 * * * pg_dump -U postgres -F c records > /backups/records_$(date +\%Y\%m\%d).dump

# WAL archiving (if using)
archive_mode = on
archive_command = 'cp %p /wal-archive/%f'
```

## Rollback Plan

If you need to rollback:

1. Keep the K8s Postgres deployment (just scale to 0)
2. Keep the PVCs (don't delete)
3. Can restore from backup if needed

## Next Steps

1. **Choose your option** (VM/Server recommended)
2. **Set up Postgres** on external host
3. **Export data** from K8s
4. **Import data** to external
5. **Update connection strings**
6. **Test thoroughly**
7. **Monitor performance**
8. **Scale down K8s Postgres** (keep for rollback)

## Scripts

See `scripts/migrate-postgres-outside-k8s.sh` for automated migration.

