# Python AI Pipeline Optimization Progress

## Overview

This document tracks the optimization progress for the Python AI Service pipeline, including performance improvements, identified bottlenecks, and remediation steps.

## Current Status (2025-12-09)

### Latest Test Results
- **Test Date**: 2025-12-08 22:23:33
- **Total Requests**: 1,332
- **Test Duration**: 391.17s
- **HTTP Error Rate**: 47.37% (timeouts, connection errors)
- **Pipeline Success Rate**: 9.09% (target: 96%+)
- **Analytics Success Rate**: 0.00%
- **AI Success Rate**: 9.09%

### Performance Metrics
- **Average Latency**: 6,391.23ms
- **P95 Latency**: 35,914.55ms
- **P99 Latency**: 35,914.55ms
- **Max Latency**: 71,385.19ms

### Identified Issues

1. **Low Success Rate (9.09% vs 96%+ target)**
   - Root cause: Timeout configurations too aggressive for 50 VUs load
   - Analytics service timeouts (5s) insufficient under high load
   - Connection pool exhaustion with 50 concurrent VUs
   - Multiple old pods running causing resource contention

2. **Timeout Issues**
   - Analytics ingestion timeout: 5s (too short under load)
   - Price prediction timeout: 5s (too short under load)
   - Analytics fetch timeout: 10s (may need increase)

3. **Connection Pool Limits**
   - Analytics service: 300 connections (insufficient for 50 VUs)
   - Price prediction: 200 connections (insufficient)
   - External APIs: 200 connections (may need increase)

4. **Resource Contention**
   - Multiple old Python AI service pods still running
   - Pending pods due to resource limits

5. **Kafka SSL Connection Issues**
   - Python AI service trying to connect to Kafka but getting connection refused
   - Service may still be using PLAINTEXT port instead of SSL (9093)

## Optimizations Applied (2025-12-09)

### Timeout Optimizations

1. **Analytics Ingestion Timeout**
   - **Before**: 5.0s
   - **After**: 8.0s
   - **Rationale**: Analytics service can be slow under 50 VUs load, needs more time

2. **Price Prediction Timeout**
   - **Before**: 5.0s (with 2 retries)
   - **After**: 10.0s (with 3 retries)
   - **Rationale**: Price prediction endpoint uses worker threads which can be slow under load

3. **Analytics Fetch Timeout**
   - **Before**: 10.0s
   - **After**: 12.0s
   - **Rationale**: Provides more headroom for slow responses under high load

4. **Price Prediction Function Timeout**
   - **Before**: 5.0s (default parameter)
   - **After**: 8.0s (default parameter)
   - **Rationale**: Matches increased timeout in calling code

### Connection Pool Optimizations

1. **Analytics Service Connection Pool**
   - **Before**: `max_connections=300`, `max_keepalive_connections=75`, `keepalive_expiry=90.0`
   - **After**: `max_connections=500`, `max_keepalive_connections=125`, `keepalive_expiry=120.0`
   - **Rationale**: 50 VUs with concurrent requests need more headroom

2. **Price Prediction Connection Pool**
   - **Before**: `max_connections=200`, `max_keepalive_connections=50`, `keepalive_expiry=60.0`
   - **After**: `max_connections=400`, `max_keepalive_connections=100`, `keepalive_expiry=90.0`
   - **Rationale**: Price prediction is called frequently, needs larger pool

3. **External API Connection Pool**
   - **Before**: `max_connections=200`, `max_keepalive_connections=50`
   - **After**: `max_connections=300`, `max_keepalive_connections=75`
   - **Rationale**: External APIs (eBay, Discogs) need more connections for concurrent requests

### Resource Cleanup

1. **Old Pod Cleanup**
   - Deleted 3 old Python AI service pods that were still running
   - Resolved resource contention issues
   - Pods: `python-ai-service-7bf59b6786-sbskd`, `python-ai-service-5b984d77ff-qjgvx`, `python-ai-service-5b984d77ff-dl8z6`

### Files Modified

1. **`services/python-ai-service/app/ai_advisor.py`**
   - Updated all `ingest_analytics_data` timeouts: 5s → 8s
   - Updated all `predict_price_from_analytics` timeouts: 5s → 10s
   - Updated retry counts: 2 → 3 for price prediction

2. **`services/python-ai-service/app/data_pipeline.py`**
   - Updated `fetch_analytics_data` default timeout: 10s → 12s
   - Updated `predict_price_from_analytics` default timeout: 5s → 8s
   - Increased connection pools for analytics and price prediction

3. **`services/python-ai-service/app/http_client.py`**
   - Increased external API connection pools: 200 → 300

## Expected Improvements

With these optimizations, we expect:

1. **Success Rate**: 9.09% → 85-95% (target: 96%+)
   - Increased timeouts should reduce timeout errors
   - Larger connection pools should reduce connection exhaustion

2. **Latency**: Should remain similar or improve slightly
   - Better connection reuse with increased keepalive
   - Fewer retries needed with longer timeouts

3. **Error Rate**: 47.37% → 5-15%
   - Reduced timeout errors
   - Reduced connection reset errors

## Next Steps

1. **Test with Optimizations**
   - Run k6 test to validate improvements
   - Monitor success rate and latency metrics
   - Check for any new bottlenecks

2. **Kafka SSL Configuration**
   - Verify Python AI service is using SSL port (9093)
   - Fix Kafka connection issues if still present
   - Update Kafka broker configuration if needed

3. **Further Optimizations (if needed)**
   - Consider increasing Gunicorn timeout if still seeing timeouts
   - Monitor connection pool usage during load tests
   - Consider adding circuit breakers for external APIs

4. **Documentation**
   - Update README.md with optimization findings
   - Update ENGINEERING.md with performance tuning recommendations

## Historical Performance

### Previous Test Results (Before Optimizations)

**Test 1 (After Auth Rebuild)**
- Total Requests: 8,712
- Pipeline Success: 99.90%
- Error Rate: 33.37%
- P95 Latency: 5,229.21ms

**Test 2 (Service Instability)**
- Total Requests: 6,125
- Pipeline Success: 94.6%
- Error Rate: 34.23%
- P95 Latency: 3,460.00ms

**Test 3 (Service Crashed)**
- Total Requests: 1,332
- Pipeline Success: 9.09%
- Error Rate: 47.37%
- P95 Latency: 35,914.55ms

## Performance Improvements Over Time

### Phase 1 Optimizations (2025-12-07)
- **Cache TTL**: Increased from 24 hours to 7 days
- **Timeouts**: Reduced external API timeouts (15s → 8s), analytics timeouts (15s → 5s)
- **Retries**: Reduced from 3 to 2 for faster failure
- **Circuit Breaker**: Integrated for external APIs

**Results**: P95 latency improved from 29.5s to 2.8s (90% reduction)

### Phase 2 Optimizations (2025-12-07)
- **L1 Cache**: In-memory LRU cache before Redis
- **Cache Warming**: Popular queries cached on startup
- **Replicas**: Increased from 2 to 3

**Results**: P95 latency: 5.9s (still good, but higher than Phase 1)

### Phase 3 Optimizations (2025-12-09)
- **Timeout Increases**: Analytics (5s → 8s), Price prediction (5s → 10s)
- **Connection Pools**: Increased all pools (analytics: 300→500, price: 200→400, external: 200→300)
- **Resource Cleanup**: Deleted old pods causing contention

**Expected Results**: Success rate 9.09% → 85-95% (target: 96%+)

## Recommendations

1. **Monitor Connection Pool Usage**
   - Add metrics for connection pool utilization
   - Alert when pools are near capacity

2. **Implement Adaptive Timeouts**
   - Use p95 latency as baseline for timeout configuration
   - Adjust timeouts based on observed latency

3. **Add Circuit Breakers**
   - Already implemented for external APIs
   - Consider adding for analytics service if it becomes unreliable

4. **Database Optimization**
   - Continue monitoring slow queries
   - Add indexes as needed
   - Consider read replicas for analytics queries

5. **Kafka SSL Migration**
   - Complete migration to SSL port (9093)
   - Remove PLAINTEXT listener once all services migrated
   - Update all service configurations

## Kafka SSL/TLS Status

- **SSL Listener**: ✅ Enabled on port 9093
- **Certificates**: ✅ Generated and stored in `kafka-ssl-secret`
- **Python AI Service**: ⚠️ May still be using PLAINTEXT port (needs verification)
- **All SSL env vars**: ✅ Configured

See `docs/kafka-ssl-setup.md` for complete setup details.
