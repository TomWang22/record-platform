# Python AI Service Pipeline - Performance & Success Metrics

**Last Updated:** $(date +"%Y-%m-%d %H:%M:%S")  
**Test Suite:** Python AI Service Pipeline Load Test  
**Status:** 🔄 Active Monitoring

## 📊 Executive Summary

The Python AI Service Pipeline is a critical component that provides price recommendations and AI-powered advice to users. This document tracks performance metrics, identifies bottlenecks, and documents optimization efforts.

### Pipeline Flow
```
User Request → API Gateway → Python AI Service → Analytics Service → AI Advisor → Response
```

### Key Services
- **API Gateway**: Entry point, routes requests
- **Python AI Service**: Core AI logic, advice generation
- **Analytics Service**: Price predictions, search history, recommendations
- **Databases**: 
  - Python AI DB (port 5440:5432)
  - Analytics DB (port 5439:5432)
  - Listings DB (port 5439:5432)

---

## 🎯 Success Metrics

### Target Metrics
- **Pipeline Success Rate**: ≥ 95%
- **AI Success Rate**: ≥ 90%
- **Analytics Success Rate**: ≥ 85%
- **P95 Latency**: < 5s
- **P99 Latency**: < 10s
- **Connection Errors**: < 5 per test
- **HTTP Error Rate**: < 20%

### Current Performance (Latest Test)

**Test Date:** 2025-12-08  
**Test Duration:** 361.30s  
**Total Requests:** 4971

| Metric | Target | Current | Status |
|--------|--------|---------|--------|
| Pipeline Success Rate | ≥ 95% | **97.60%** | ✅ Exceeds target |
| AI Success Rate | ≥ 90% | **97.60%** | ✅ Exceeds target |
| Analytics Success Rate | ≥ 85% | **0.00%** | ❌ Critical issue |
| HTTP Error Rate | < 20% | **33.86%** | ⚠️ Needs improvement |
| Connection Errors | < 5 | **0** | ✅ Meets target |
| P95 Latency | < 5s | **11.07s** | ⚠️ Needs improvement |
| P99 Latency | < 10s | **N/A (timeouts)** | ❌ Needs investigation |
| < 10s | **N/A (timeouts)** | ❌ Needs investigation |

---

## 📈 Latency Breakdown

### Component Latency (P95)
- **Analytics → AI**: 29ms ✅ (excellent)
- **AI Advice**: 10.88s ⚠️ (high - needs optimization)
- **API Gateway**: 356ms ✅ (good)
- **Total Pipeline**: 46.05s ❌ (very high - critical bottleneck)

### Percentile Analysis
- **P50 (Median)**: 48.60ms ✅
- **P90**: 2.45s ⚠️
- **P95**: 5.59s ⚠️
- **P99**: N/A (timeouts)
- **Max**: 60.04s ❌

---

## 🔍 Critical Issues

### 1. Analytics Success Rate: 0.00% ❌

**Root Cause:**
- Analytics recommendations endpoint returns empty arrays
- `search_history` table has no data
- k6 test checks for non-empty `recommendations` array

**Impact:**
- Users cannot get search recommendations
- Similar searches feature unavailable
- Trending searches feature unavailable

**Solution:**
- Populate `search_history` table with test data
- Or modify k6 test to accept empty recommendations as valid
- Or implement fallback recommendations when history is empty

**Status:** 🔄 Investigation in progress

### 2. High HTTP Error Rate: 33.37% ⚠️

**Root Cause:**
- Request timeouts (60s timeout)
- Connection errors (14 occurrences)
- Service overload under high load (50 VUs)

**Impact:**
- 1/3 of requests fail at HTTP level
- Poor user experience
- Potential revenue loss

**Solution:**
- Optimize slow queries
- Increase service replicas
- Implement better retry logic
- Optimize external API calls (Discogs, eBay)

**Status:** 🔄 Optimization in progress

### 3. High P95 Pipeline Latency: 46.05s ❌

**Root Cause:**
- AI Advice generation is slow (P95: 10.88s)
- External API calls (Discogs, eBay) are rate-limited
- Database queries may be slow

**Impact:**
- Very slow response times
- Poor user experience
- Timeouts

**Solution:**
- Implement better caching
- Optimize AI advice generation
- Batch external API calls
- Optimize database queries

**Status:** 🔄 Optimization in progress

### 4. Connection Errors: 14 ⚠️

**Root Cause:**
- Connection pool exhaustion
- Network issues
- Service restarts

**Impact:**
- Request failures
- Unreliable service

**Solution:**
- ✅ Increased connection pools to 100 (applied)
- Monitor pool usage
- Implement connection retry logic

**Status:** ✅ Partially resolved (reduced from 37 to 14)

---

## ✅ Optimizations Applied

### Database Configuration
- ✅ **Fixed Analytics DB port**: 5435 → 5439
- ✅ **Increased connection pools**: 50 → 100 (Analytics), 100 (Python AI)
- ✅ **Optimized connection settings**: Keepalive, recycling, timeouts

### Service Configuration
- ✅ **Increased replicas**: 2 replicas for high availability
- ✅ **Optimized health checks**: gRPC health checks working
- ✅ **Resource limits**: CPU/Memory limits to prevent OOM

### Caching & Performance
- ✅ **Redis singleflight**: Prevents cache stampede
- ✅ **Database caching**: Fallback when Redis unavailable
- ✅ **Connection pooling**: httpx with keepalive

---

## 📋 Test Results History

### Test #1 (2025-12-07 16:51:35)
- **Total Requests:** 6,777
- **Pipeline Success:** 93.7%
- **HTTP Error Rate:** 100% (timeouts)
- **P95 Latency:** 17.88s
- **Issues:** High timeout rate, connection errors

### Test #2 (2025-12-07 17:45:16)
- **Total Requests:** 6,125
- **Pipeline Success:** 94.6%
- **HTTP Error Rate:** 34.23%
- **P95 Latency:** 3.46s
- **Issues:** Analytics success 0%, connection errors

### Test #3 (2025-12-08 00:05:14)
- **Total Requests:** 4,218
- **Pipeline Success:** 95.14%
- **HTTP Error Rate:** 34.23%
- **P95 Latency:** 8.62s
- **Issues:** Analytics success 0%, 37 connection errors

### Test #4 (2025-12-08 00:18:14) - **Latest**
- **Total Requests:** 8,173 ✅ (83% increase)
- **Pipeline Success:** 99.45% ✅ (improved)
- **HTTP Error Rate:** 33.37% ⚠️ (slight improvement)
- **P95 Latency:** 5.59s ⚠️ (improved from 8.62s)
- **Connection Errors:** 14 ✅ (62% reduction from 37)
- **Issues:** Analytics success 0%, high P95 latency

---


### Test #5 (2025-12-08 00:27:29) - **Latest**
- **Total Requests:** 4971
- **Pipeline Success:** 97.60%
- **HTTP Error Rate:** 33.86%
- **P95 Latency:** 11065.91ms
- **Connection Errors:** 0
- **Issues:** Analytics success 0.00%, AI success 97.60%

## 🎯 Recommendations

### Immediate Actions (Priority 1)
1. **Fix Analytics Success Rate**
   - Populate `search_history` table with test data
   - Or modify k6 test to handle empty recommendations
   - Implement fallback recommendations

2. **Reduce HTTP Error Rate**
   - Optimize slow queries (run EXPLAIN ANALYZE)
   - Increase service replicas (3-4 replicas)
   - Implement better timeout handling

3. **Reduce Pipeline Latency**
   - Optimize AI advice generation
   - Implement better caching for external API calls
   - Batch external API requests

### Short-term Actions (Priority 2)
1. **Monitor Connection Pools**
   - Track pool usage metrics
   - Alert on pool exhaustion
   - Auto-scale based on pool usage

2. **Optimize Database Queries**
   - Run EXPLAIN ANALYZE on slow queries
   - Add missing indexes
   - Optimize query plans

3. **Improve External API Handling**
   - Implement better rate limiting
   - Cache external API responses longer
   - Use async batch requests

### Long-term Actions (Priority 3)
1. **Implement Circuit Breakers**
   - Prevent cascading failures
   - Graceful degradation
   - Automatic recovery

2. **Add Monitoring & Alerting**
   - Real-time metrics dashboard
   - Alert on performance degradation
   - SLA tracking

3. **Load Testing Automation**
   - Daily automated tests
   - Performance regression detection
   - Trend analysis

---

## 📊 Performance Trends

### Request Volume
- **Test #1:** 6,777 requests
- **Test #2:** 6,125 requests
- **Test #3:** 4,218 requests
- **Test #4:** 8,173 requests ✅ (highest)

### Pipeline Success Rate
- **Test #1:** 93.7%
- **Test #2:** 94.6%
- **Test #3:** 95.14%
- **Test #4:** 99.45% ✅ (trending up)

### Connection Errors
- **Test #1:** Unknown
- **Test #2:** Unknown
- **Test #3:** 37 errors
- **Test #4:** 14 errors ✅ (62% reduction)

### P95 Latency
- **Test #1:** 17.88s
- **Test #2:** 3.46s
- **Test #3:** 8.62s
- **Test #4:** 5.59s ✅ (improved)

---

## 🔗 Related Documentation

- [Pipeline Bottleneck Analysis](./pipeline-bottleneck-analysis.md)
- [Database Optimization Guide](../infra/db/README.md)
- [k6 Load Testing Scripts](../scripts/load/README.md)

---

## 📝 Notes

- Analytics success rate of 0% is expected when `search_history` table is empty
- Pipeline success rate (99.45%) is excellent despite HTTP errors
- Connection errors reduced significantly after pool optimization
- P95 latency improved but still needs optimization

---

**Generated by:** Python AI Pipeline Performance Monitor  
**Last Test:** 2025-12-08 00:18:14  
**Next Review:** 2025-12-09

---

## 🔄 Analytics Service Workflow Analysis

### Current Architecture

**Analytics Service Responsibilities:**
1. **Price Prediction** (`/analytics/predict-price`)
   - Uses worker threads for parallel processing
   - Queries historical price data from `analytics.price_snapshots`
   - Enriches items with historical averages
   - Caches results in Redis (10min TTL)
   - Publishes events to Kafka

2. **Recommendations** (`/analytics/recommendations/similar`)
   - Queries `listings.search_history` for similar searches
   - Uses PostgreSQL trigram similarity (`%` operator)
   - Returns empty array when no search history exists

3. **Search History Analysis**
   - Tracks user searches in `listings.search_history`
   - Provides trending searches
   - User-specific search history

**Python AI Service Responsibilities:**
1. **External API Calls**
   - Discogs API (rate-limited: 50 req/min)
   - eBay API (rate-limited: 50 req/min)
   - Uses Redis singleflight to prevent cache stampede
   - Implements rate limiting with token bucket algorithm

2. **AI Advice Generation**
   - Selling Advice
   - Buying Advice
   - Negotiation Advice
   - Bidding Advice

3. **Data Pipeline**
   - Fetches analytics data (price trends, recommendations)
   - Processes and normalizes data
   - Generates AI-powered recommendations

### Data Flow

```
User Request
    ↓
API Gateway
    ↓
Python AI Service
    ├─→ Analytics Service (price predictions, recommendations)
    │   ├─→ Listings DB (search_history)
    │   └─→ Analytics DB (price_snapshots)
    ├─→ Discogs API (external, rate-limited)
    ├─→ eBay API (external, rate-limited)
    └─→ Redis Cache (singleflight, prevents thundering herd)
    ↓
AI Advice Response
```

### Identified Bottlenecks

1. **External API Calls** (Discogs, eBay)
   - Rate-limited (50 req/min each)
   - Network latency
   - Timeout handling (5s timeout)
   - **Impact**: High P95 latency (10.88s for AI Advice)

2. **Analytics Service Price Prediction**
   - Worker thread processing (CPU-bound)
   - Database queries (price_snapshots)
   - **Impact**: Moderate latency (P95: 29ms for Analytics → AI)

3. **Database Queries**
   - `search_history` queries (trigram similarity)
   - `price_snapshots` queries
   - **Impact**: Low latency (good performance)

4. **Connection Pool Exhaustion**
   - Fixed: Increased pools to 100
   - **Impact**: Reduced connection errors (37 → 14)

### Optimization Opportunities

1. **External API Optimization**
   - ✅ Implemented: Rate limiting with token bucket
   - ✅ Implemented: Redis singleflight (prevents duplicate calls)
   - 🔄 TODO: Batch API requests
   - 🔄 TODO: Increase cache TTL for stable prices
   - 🔄 TODO: Implement request queuing for rate limits

2. **Analytics Service Optimization**
   - ✅ Implemented: Redis caching (10min TTL)
   - ✅ Implemented: Worker threads for parallel processing
   - 🔄 TODO: Optimize price_snapshots queries (add indexes)
   - 🔄 TODO: Pre-compute price trends

3. **Database Optimization**
   - ✅ Applied: GIN trigram indexes on search_history
   - ✅ Applied: Connection pools increased to 100
   - 🔄 TODO: Analyze slow queries with EXPLAIN ANALYZE
   - 🔄 TODO: Add composite indexes for common queries

4. **Pipeline Optimization**
   - ✅ Implemented: Async processing for DB writes
   - ✅ Implemented: Timeout handling (3s for analytics calls)
   - 🔄 TODO: Implement circuit breakers
   - 🔄 TODO: Add request queuing for high load

---

## 📊 Latency Graph Fixes

### Issue
- Graph showing 0.00ms for most percentiles
- Component breakdown showing 0.00ms

### Root Cause
- Percentile extraction regex not matching k6 handleSummary output format
- Component metrics extraction not handling formatted output

### Fix Applied
- Updated regex patterns to match handleSummary formatted output
- Added fallback extraction from k6 raw metrics
- Improved component metrics extraction (Analytics → AI, AI Advice, Gateway, Pipeline)

### Expected Results
- All percentiles (p1 to p100) correctly displayed
- Component latencies correctly extracted
- Success rates properly shown

---

**Last Updated:** $(date +"%Y-%m-%d %H:%M:%S")

---

## 🔄 Complete Pipeline Architecture

### Service Responsibilities

**Analytics Service:**
- **Price Predictions** (`/analytics/predict-price`)
  - Worker thread processing (parallel scoring)
  - Historical price data queries (`analytics.price_snapshots`)
  - Redis caching (10min TTL)
  - Kafka event publishing

- **Recommendations** (`/analytics/recommendations/similar`)
  - Search history queries (`listings.search_history`)
  - PostgreSQL trigram similarity matching
  - Returns empty array when no history exists (expected behavior)

- **Search History Analysis**
  - User search tracking
  - Trending searches
  - Similar searches

**Python AI Service:**
- **External API Calls**
  - Discogs API (rate-limited: 50 req/min)
  - eBay API (rate-limited: 50 req/min)
  - Redis singleflight (prevents duplicate calls)
  - Rate limiting with token bucket algorithm

- **AI Advice Generation**
  - Selling Advice (uses analytics + external APIs)
  - Buying Advice (uses analytics + external APIs)
  - Negotiation Advice
  - Bidding Advice

- **Data Processing**
  - Fetches analytics data (price trends, recommendations)
  - Calls external APIs (Discogs, eBay)
  - Processes and normalizes data
  - Generates AI-powered recommendations

**Auction Monitor Service (Separate):**
- **Web Scraping** (NOT part of Python AI pipeline)
  - Discogs price history scraping (browser automation)
  - Buyee, YahooJP, CarousellHK, RecordCity scraping
  - Price history data collection
  - Used for historical price analysis

### Data Flow Diagram

```
User Request
    ↓
API Gateway (port 4000)
    ↓
Python AI Service (port 5005)
    ├─→ Analytics Service (port 4004)
    │   ├─→ Listings DB (port 5439) - search_history
    │   └─→ Analytics DB (port 5439) - price_snapshots
    │
    ├─→ Discogs API (external, rate-limited: 50/min)
    ├─→ eBay API (external, rate-limited: 50/min)
    │
    └─→ Redis Cache (singleflight, prevents thundering herd)
    ↓
AI Advice Response
```

### External API Integration

**Discogs API:**
- Endpoint: `https://api.discogs.com/database/search`
- Rate Limit: 60 req/min (conservative: 50/min)
- Caching: 1 hour TTL (Redis)
- Singleflight: Prevents duplicate calls

**eBay API:**
- Finding API: `https://svcs.ebay.com/services/search/FindingService/v1`
- Browse API: `https://api.ebay.com/buy/browse/v1/item_summary/search` (fallback)
- Rate Limit: ~50 req/min (conservative)
- Caching: 1 hour TTL (Redis)
- Singleflight: Prevents duplicate calls

**Note:** Gripsweat scraping not found in current codebase. May be:
- Future feature
- Part of auction-monitor service (separate from Python AI pipeline)
- Typo/alternative name for existing scraping service

---

## 🔍 Bottleneck Analysis (Latest Test)

### Test Results (2025-12-08 00:43:18)
- **Total Requests:** 6,567
- **Pipeline Success:** 99.86% ✅
- **AI Success:** 99.86% ✅
- **Analytics Success:** 0.00% (expected - empty search_history)
- **HTTP Error Rate:** 33.30% ⚠️
- **Connection Errors:** 11 ✅ (improved from 14)

### Latency Breakdown
- **P90:** 4,695ms ⚠️
- **P95:** 7,171ms ⚠️ (target: <5s)
- **P100 (Max):** 45,945ms ❌

### Component Latencies
- **Analytics → AI:** P95: 45.40ms ✅ (excellent)
- **AI Advice:** P95: 10,913ms ⚠️ (high - external APIs)
- **API Gateway:** P95: 2,054ms ⚠️
- **Total Pipeline:** P95: 41,429ms ❌ (very high)

### Root Causes

1. **External API Latency** (Primary Bottleneck)
   - Discogs API: Network latency + rate limiting
   - eBay API: Network latency + rate limiting
   - **Impact:** AI Advice P95: 10.9s
   - **Solution:** 
     - ✅ Implemented: Rate limiting, caching, singleflight
     - 🔄 TODO: Batch API requests
     - 🔄 TODO: Increase cache TTL for stable prices
     - 🔄 TODO: Implement request queuing

2. **Request Timeouts**
   - 33.30% HTTP error rate (timeouts)
   - 60s timeout may be too short for slow external APIs
   - **Impact:** Many requests timeout before completion
   - **Solution:**
     - 🔄 TODO: Increase timeout or implement async processing
     - 🔄 TODO: Return partial results on timeout

3. **Pipeline Latency**
   - P95: 41.4s (very high)
   - Sequential processing of multiple AI endpoints
   - **Impact:** Poor user experience
   - **Solution:**
     - 🔄 TODO: Parallelize AI endpoint calls where possible
     - 🔄 TODO: Implement request queuing for high load

4. **Database Queries**
   - Analytics queries are fast (P95: 45ms)
   - **Status:** ✅ Optimized

5. **Connection Pool Exhaustion**
   - Reduced from 37 to 11 errors
   - **Status:** ✅ Improved (pools increased to 100)

---

## 🎯 Optimization Roadmap

### Immediate (Priority 1)
1. **Optimize External API Calls**
   - Batch requests where possible
   - Increase cache TTL for stable prices (24h instead of 1h)
   - Implement request queuing for rate limits
   - Use async processing for non-critical data

2. **Reduce Timeout Rate**
   - Implement partial results on timeout
   - Increase timeout for external APIs (10s → 15s)
   - Return cached data if available on timeout

3. **Optimize AI Advice Generation**
   - Parallelize independent API calls
   - Use cached data when external APIs are slow
   - Implement circuit breakers for external APIs

### Short-term (Priority 2)
1. **Database Query Optimization**
   - Run EXPLAIN ANALYZE on slow queries
   - Add missing indexes
   - Optimize price_snapshots queries

2. **Service Scaling**
   - Increase replicas (2 → 3-4)
   - Implement auto-scaling based on load
   - Add request queuing

3. **Monitoring & Alerting**
   - Real-time metrics dashboard
   - Alert on performance degradation
   - Track external API latency trends

### Long-term (Priority 3)
1. **Architecture Improvements**
   - Implement circuit breakers
   - Add request queuing system
   - Pre-compute price trends
   - Background job processing for external APIs

2. **Caching Strategy**
   - Multi-layer caching (Redis + DB)
   - Intelligent cache invalidation
   - Cache warming for popular queries

3. **Load Testing Automation**
   - Daily automated tests
   - Performance regression detection
   - Trend analysis

---

**Last Updated:** $(date +"%Y-%m-%d %H:%M:%S")
