# Auth Service gRPC Migration Runbook

**Date Created**: December 20, 2025  
**Last Updated**: December 20, 2025  
**Status**: Active

## Overview

This runbook documents the migration of auth-service `validate` and `refresh` endpoints from HTTP proxy to gRPC, and the reasons why this migration was necessary.

## Problem Statement

### Initial Issue
- **Validate endpoint**: 0% success rate under load
- **Refresh endpoint**: 0% success rate under load
- **Error**: `ECONNRESET` (socket hang up) through API Gateway
- **Root cause**: HTTP proxy connection handling issues between API Gateway and auth-service

### Symptoms
1. Endpoints worked when accessed directly on auth-service (bypassing API Gateway)
2. Endpoints failed when accessed through API Gateway proxy
3. Connection resets (`ECONNRESET`) occurred under load
4. P95/P99 latency = 30s (exactly proxy timeout)
5. Auth service logs showed "request aborted"

### Impact
- **Critical**: Auth service is the gatekeeper for all downstream services
- **Cascade failures**: 0% success rates for Records, Analytics, Python AI services
- **User experience**: Users unable to validate tokens or refresh sessions
- **E2E testing**: Blocked due to auth failures

## Root Cause Analysis

### Why HTTP Proxy Failed

1. **Connection Reuse Issues**
   - `http-proxy-middleware` with `keepAliveAgent` tried to reuse connections
   - Auth service was closing/resetting connections under load
   - Proxy tried to reuse closed connections → `ECONNRESET`

2. **Connection Pool Exhaustion**
   - Under load, connection pool got exhausted
   - New connections couldn't be established
   - Requests timed out at 30s (proxy timeout)

3. **HTTP/1.1 Limitations**
   - HTTP/1.1 doesn't support multiplexing
   - Each request needs a separate connection
   - Connection overhead under high concurrency

### Why gRPC Solves This

1. **HTTP/2 Multiplexing**
   - Multiple requests over single connection
   - Better connection reuse
   - Reduced connection overhead

2. **Better Connection Management**
   - gRPC handles connection lifecycle properly
   - Automatic connection pooling
   - Graceful connection handling

3. **Consistency**
   - Login/register already use gRPC
   - Same protocol for all auth operations
   - Unified error handling

4. **Performance**
   - Binary protocol (more efficient than JSON)
   - Lower latency
   - Better throughput

## Solution Implemented

### 1. Auth Service gRPC Server Updates

**File**: `services/auth-service/src/grpc-server.ts`

#### ValidateToken Enhancement
- Added Redis revocation check (validates token JTI is not revoked)
- Added connection logging (logs duration and user email)
- Proper error handling with gRPC status codes

#### RefreshToken Implementation
- **Previously**: Returned `UNIMPLEMENTED`
- **Now**: Full implementation with:
  - Redis revocation check
  - User verification
  - New JWT generation with new JTI
  - Connection logging

### 2. API Gateway Updates

**File**: `services/api-gateway/src/server.ts`

#### Removed HTTP Proxy Routes
- Removed all `createProxyMiddleware` routes for validate/refresh
- Removed connection reuse workarounds
- Removed no-keep-alive agent hacks

#### Added gRPC Handlers
- `validateTokenHandler`: Calls gRPC `ValidateToken` method
- `refreshTokenHandler`: Calls gRPC `RefreshToken` method
- Connection logging for debugging
- Proper error handling with `handleGrpcError`

#### Routes Updated
- `/auth/validate` → gRPC `ValidateToken`
- `/api/auth/validate` → gRPC `ValidateToken`
- `/auth/refresh` → gRPC `RefreshToken`
- `/api/auth/refresh` → gRPC `RefreshToken`

### 3. HTTP/2/3 and TLS Configuration

#### gRPC Server (HTTP/2)
- Uses HTTP/2 internally (no HTTP/1.1 fallback)
- TLS support via `grpc.ServerCredentials.createSsl()`
- Strict TLS with client cert verification (if CA cert provided)
- Falls back to insecure (h2c) in dev

#### Caddy (HTTP/2/3)
- HTTP/3 (QUIC) enabled automatically on port 443
- HTTP/2 supported via ALPN
- Strict TLS: `protocols tls1.2 tls1.3` in Caddyfile
- gRPC routing to appropriate services

### 4. Connection Logging

#### API Gateway Logging
- Request received timestamp
- gRPC call initiation
- Success/error with duration
- Error details (code, message, details)

#### Auth Service Logging
- Method called
- Request duration
- User email (for successful operations)
- Error details

## Deployment Procedure

### Prerequisites
- Docker installed
- Kind cluster running
- kubectl configured

### Steps

1. **Rebuild Services**
   ```bash
   # Build auth-service
   docker build -t auth-service:dev -f services/auth-service/Dockerfile .
   
   # Build api-gateway
   docker build -t api-gateway:dev -f services/api-gateway/Dockerfile .
   ```

2. **Load Images into Kind**
   ```bash
   export KUBECONFIG=$HOME/.kube/kind-h3.yaml
   kind load docker-image auth-service:dev api-gateway:dev --name h3
   ```

3. **Restart Deployments**
   ```bash
   kubectl rollout restart deployment/auth-service api-gateway -n record-platform
   ```

4. **Wait for Rollout**
   ```bash
   kubectl rollout status deployment/auth-service -n record-platform --timeout=5m
   kubectl rollout status deployment/api-gateway -n record-platform --timeout=5m
   ```

5. **Verify Services**
   ```bash
   kubectl get pods -n record-platform -l 'app in (auth-service,api-gateway)'
   ```

6. **Smoke Test**
   ```bash
   # Register
   curl -k -X POST https://record.local:30443/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","password":"test123"}'
   
   # Validate (use token from register)
   curl -k -X POST https://record.local:30443/api/auth/validate \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YOUR_TOKEN" \
     -d '{}'
   
   # Refresh
   curl -k -X POST https://record.local:30443/api/auth/refresh \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YOUR_TOKEN" \
     -d '{}'
   ```

## Testing

### Incremental Load Test

**Script**: `scripts/load/k6-auth-incremental-load.js`

**Purpose**: Find max capacity and verify high success rates

**Configuration**:
- Gradual ramp: 1 → 5 → 10 → 20 → 50 → 100 VUs
- Hold stages at each level
- Total duration: ~30 minutes

**Thresholds**:
- Register: 95%+ success rate, P95 < 2s
- Login: 99%+ success rate, P95 < 1s
- Validate: 99%+ success rate, P95 < 500ms
- Refresh: 99%+ success rate, P95 < 500ms

**Run**:
```bash
k6 run scripts/load/k6-auth-incremental-load.js
```

### Packet Capture (If Issues Persist)

**Script**: `scripts/load/capture-packets.sh`

**Purpose**: Debug connection issues at packet level

**Run**:
```bash
./scripts/load/capture-packets.sh
```

**Analysis**:
```bash
# View captured packets
tcpdump -r test-results/packet-capture/auth-connection-*.pcap -n

# Or use Wireshark
wireshark test-results/packet-capture/auth-connection-*.pcap
```

## Monitoring

### Logs

**API Gateway**:
```bash
kubectl logs -f -l app=api-gateway -n record-platform | grep -E "ValidateToken|RefreshToken"
```

**Auth Service**:
```bash
kubectl logs -f -l app=auth-service -n record-platform | grep -E "ValidateToken|RefreshToken"
```

### Metrics

**Success Rates**:
- Register: Should be 95%+
- Login: Should be 99%+
- Validate: Should be 99%+
- Refresh: Should be 99%+

**Latencies**:
- Register: P95 < 2s
- Login: P95 < 1s
- Validate: P95 < 500ms
- Refresh: P95 < 500ms

## Rollback Procedure

If issues occur after migration:

1. **Revert Code Changes**
   ```bash
   git revert <commit-hash>
   ```

2. **Rebuild and Redeploy**
   ```bash
   # Follow deployment procedure above
   ```

3. **Verify Rollback**
   ```bash
   # Run smoke test
   # Check logs
   # Monitor metrics
   ```

## Success Criteria

### Before Migration
- ❌ Validate: 0% success rate
- ❌ Refresh: 0% success rate
- ❌ Connection errors: `ECONNRESET`
- ❌ P95 latency: 30s (timeout)

### After Migration
- ✅ Validate: 99%+ success rate
- ✅ Refresh: 99%+ success rate
- ✅ Connection errors: Eliminated
- ✅ P95 latency: < 500ms

## Why This Was Necessary

### 1. Auth Service is the Gatekeeper
- All downstream services depend on auth
- Auth failures cascade to all services
- 0% success rates block E2E testing

### 2. HTTP Proxy Limitations
- Connection reuse issues under load
- Connection pool exhaustion
- HTTP/1.1 limitations (no multiplexing)

### 3. gRPC Benefits
- HTTP/2 multiplexing (better connection management)
- Consistent with other auth endpoints
- Better performance and reliability
- Proper connection lifecycle management

### 4. E2E Testing Requirements
- Need high 90s success rates for all endpoints
- Auth must be reliable for downstream services
- Connection issues block comprehensive testing

## Related Documentation

- `test-results/GRPC_MIGRATION_SUMMARY_tom_12-20.md` - Migration summary
- `test-results/ROOT_CAUSE_INVESTIGATION_tom_12-20.md` - Root cause analysis
- `test-results/AUTH_BLOCKING_ANALYSIS_tom_12-19.md` - Blocking issues analysis

## Maintenance

### Regular Checks
- Monitor success rates (should be 99%+)
- Monitor latencies (P95 should be < 500ms)
- Check logs for connection errors
- Run incremental load test monthly

### Updates
- Keep gRPC libraries updated
- Monitor for connection issues
- Review and optimize connection pools
- Update thresholds as needed

---

**Maintained by**: Platform Team  
**Last Reviewed**: December 20, 2025  
**Next Review**: January 20, 2026

