# k6 HTTP/3 Testing Runbook

**Date Created**: December 20, 2025  
**Last Updated**: December 20, 2025  
**Status**: Active

## Overview

This runbook documents how to test HTTP/3 (QUIC) with k6, including current limitations and workarounds.

## Current Status

### k6 Native HTTP/3 Support

**Status:** ❌ Not Available in k6 v1.4.2

- k6 v1.4.2 does not natively support HTTP/3 (QUIC)
- Standard k6 builds do not include QUIC support
- `httpVersion: 'HTTP/3'` is not supported

### HTTP/3 Testing Options

#### Option 1: Use curl with HTTP/3 (Recommended)

**Status:** ✅ Working

Use the `scripts/test-microservices-http2-http3.sh` script which uses curl with HTTP/3 support via the `http3.sh` helper:

```bash
bash scripts/test-microservices-http2-http3.sh
```

**How it works:**
- Uses `http3.sh` helper script (`scripts/lib/http3.sh`)
- Runs curl in Docker container with HTTP/3 support
- Connects via Kind cluster network namespace
- Fully functional and verified working

#### Option 2: Build k6 with xk6 (Future)

**Status:** ⚠️ Experimental

Use `xk6` to build a custom k6 binary with HTTP/3 support:

```bash
# Install xk6
go install go.k6.io/xk6/cmd/xk6@latest

# Build k6 with HTTP/3 extension
xk6 build --with github.com/grafana/xk6-http3

# Use the custom binary
./k6 run scripts/load/k6-http3-toolchain.js
```

**Note:** This is experimental and may not be stable. Verify HTTP/3 support works before using in production tests.

## Toolchain Script

### Location

`scripts/load/k6-http3-toolchain.js`

### Purpose

- Placeholder for future k6 HTTP/3 support
- Documents current limitations
- Ready to use when k6 adds native HTTP/3 support

### Current Behavior

- Attempts to use `httpVersion: 'HTTP/3'` (will fail in current k6)
- Logs warning that HTTP/3 is not supported
- Recommends using `test-microservices-http2-http3.sh` instead

## Verification

### Test HTTP/3 with curl

```bash
# Source the http3.sh helper
. scripts/lib/http3.sh

# Test HTTP/3 health check
http3_curl -k -sS -I --http3-only --max-time 10 \
  -H "Host: record.local" \
  --resolve "record.local:443:${CLUSTER_IP}" \
  "https://record.local/_caddy/healthz"
```

Expected output:
```
HTTP/3 200 
server: Caddy
```

### Test HTTP/3 with test script

```bash
bash scripts/test-microservices-http2-http3.sh
```

Look for:
- ✅ "Create record works via HTTP/3"
- ✅ "Create forum post works via HTTP/3"
- ✅ "Caddy health check works via HTTP/3"

## Troubleshooting

### Issue: k6 HTTP/3 test fails

**Symptom:**
```
Error: invalid build parameters: unknown dependency : k6/experimental/exec
```

**Cause:** k6 doesn't support HTTP/3 natively

**Fix:** Use `scripts/test-microservices-http2-http3.sh` instead

### Issue: HTTP/3 curl fails

**Symptom:**
```
curl: (1) Protocol "http/3" not supported
```

**Cause:** curl doesn't have HTTP/3 support

**Fix:**
1. Install Homebrew curl (has HTTP/3 support):
   ```bash
   brew install curl
   ```

2. Use the http3.sh helper which uses Docker image with HTTP/3:
   ```bash
   . scripts/lib/http3.sh
   http3_curl --http3-only ...
   ```

## Future Enhancements

1. **Monitor k6 Releases:**
   - Check k6 release notes for HTTP/3 support
   - Update toolchain when native support is available

2. **xk6 Extension:**
   - Evaluate xk6-http3 extension stability
   - Document build process if stable

3. **Alternative Tools:**
   - Consider other load testing tools with HTTP/3 support
   - Evaluate if needed for production testing

## Related Documentation

- [HTTP/2 and HTTP/3 Test Script](../../scripts/test-microservices-http2-http3.sh)
- [http3.sh Helper](../../scripts/lib/http3.sh)
- [k6 HTTP/3 Toolchain](../../scripts/load/k6-http3-toolchain.js)

---

**Last Verified:** December 20, 2025  
**Next Review:** January 20, 2026

