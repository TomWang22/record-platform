# Records Service TLS Configuration Runbook

**Date Created**: December 20, 2025  
**Last Updated**: December 20, 2025  
**Status**: Active

## Overview

This runbook documents the TLS configuration requirements for the Records Service gRPC server and how to troubleshoot TLS handshake issues.

## Problem Statement

### Issue: TLS Handshake Failure

**Error:** `SSL routines:ssl3_get_record:wrong version number`  
**Status:** 503 Service Unavailable  
**Impact:** All records service operations fail via API Gateway

### Root Cause

**TLS Protocol Mismatch:**
- Records Service gRPC server: No TLS certs → starts in **insecure mode** (plaintext)
- API Gateway gRPC client: Has TLS certs → uses **TLS credentials**
- Result: Client tries TLS handshake, server expects plaintext → protocol mismatch

## Configuration Requirements

### Records Service Deployment

The Records Service **must** have TLS certificates mounted to match the API Gateway's TLS configuration.

#### Required Volume Mounts

```yaml
# infra/k8s/base/records-service/deploy.yaml
volumeMounts:
  - name: tls-certs
    mountPath: /etc/certs
    readOnly: true

volumes:
  - name: tls-certs
    secret:
      secretName: service-tls
      items:
        - key: tls.key
          path: tls.key
        - key: tls.crt
          path: tls.crt
        - key: ca.crt
          path: ca.crt
```

#### Verification

After deployment, verify TLS certs are mounted:

```bash
kubectl exec -n record-platform -l app=records-service -- ls -la /etc/certs/
```

Expected output:
```
ca.crt -> ..data/ca.crt
tls.crt -> ..data/tls.crt
tls.key -> ..data/tls.key
```

### gRPC Server Configuration

The Records Service gRPC server automatically detects TLS certs:

- **If certs exist** (`/etc/certs/tls.key` and `/etc/certs/tls.crt`):
  - Starts in **secure mode** with TLS
  - Log: `[records gRPC] Starting secure server with ALPN h2`

- **If certs missing**:
  - Starts in **insecure mode** (plaintext)
  - Log: `[records gRPC] TLS certs missing – starting insecure (dev)`

### API Gateway gRPC Client Configuration

The API Gateway gRPC client uses `buildCredentials()` from `services/common/src/grpc-clients.ts`:

- **If certs exist** (`/etc/certs/ca.crt`, `/etc/certs/tls.crt`, `/etc/certs/tls.key`):
  - Uses **TLS credentials** with client certificate
  - Log: (no explicit log, but connection succeeds)

- **If certs missing**:
  - Falls back to **insecure credentials**
  - Log: (no explicit log, but connection may fail if server uses TLS)

## Troubleshooting

### Symptom: "SSL routines:ssl3_get_record:wrong version number"

**Diagnosis:**
1. Check Records Service logs:
   ```bash
   kubectl logs -n record-platform -l app=records-service | grep -i "grpc\|tls"
   ```
   - If you see "TLS certs missing – starting insecure": **Server is insecure**
   - If you see "Starting secure server with ALPN h2": **Server is secure**

2. Check API Gateway TLS certs:
   ```bash
   kubectl exec -n record-platform -l app=api-gateway -- ls -la /etc/certs/
   ```
   - If certs exist: **Client uses TLS**
   - If certs missing: **Client uses insecure**

3. **Mismatch Detection:**
   - Server insecure + Client TLS = **Protocol mismatch** ❌
   - Server secure + Client TLS = **Match** ✅
   - Server insecure + Client insecure = **Match** ✅ (dev only)
   - Server secure + Client insecure = **Protocol mismatch** ❌

**Fix:**
- Ensure both use the same protocol (TLS or insecure)
- For production: Both should use TLS
- Mount TLS certs on Records Service if missing

### Symptom: "connect ECONNREFUSED"

**Diagnosis:**
- Records Service gRPC server not running
- Port 50051 not accessible
- Network policy blocking connection

**Fix:**
1. Check Records Service pod status:
   ```bash
   kubectl get pods -n record-platform -l app=records-service
   ```

2. Check gRPC server logs:
   ```bash
   kubectl logs -n record-platform -l app=records-service | grep "grpc\|50051"
   ```

3. Verify service endpoint:
   ```bash
   kubectl get svc -n record-platform records-service
   ```

### Symptom: "certificate verify failed"

**Diagnosis:**
- TLS certificates don't match
- CA certificate mismatch
- Server name override needed

**Fix:**
1. Verify certificates are from the same CA
2. Check `GRPC_SERVER_NAME` environment variable
3. Ensure `grpc.ssl_target_name_override` is set correctly

## Prevention

### Pre-Deployment Checklist

- [ ] TLS certs mounted on Records Service (`/etc/certs/`)
- [ ] TLS certs mounted on API Gateway (`/etc/certs/`)
- [ ] Both services use the same TLS secret (`service-tls`)
- [ ] gRPC server logs show "Starting secure server with ALPN h2"
- [ ] Test gRPC connection from API Gateway to Records Service

### Validation Script

Create `scripts/validate-tls-config.sh`:

```bash
#!/bin/bash
# Validate TLS configuration for gRPC services

echo "=== Checking TLS Configuration ==="

# Check Records Service
echo "Records Service:"
kubectl exec -n record-platform -l app=records-service -- ls /etc/certs/ 2>/dev/null && echo "✅ TLS certs mounted" || echo "❌ TLS certs missing"

# Check API Gateway
echo "API Gateway:"
kubectl exec -n record-platform -l app=api-gateway -- ls /etc/certs/ 2>/dev/null && echo "✅ TLS certs mounted" || echo "❌ TLS certs missing"

# Check gRPC server mode
echo "Records Service gRPC Mode:"
kubectl logs -n record-platform -l app=records-service --tail=50 | grep -i "grpc.*starting\|grpc.*tls" | tail -1
```

## Related Documentation

- [Auth Service gRPC Migration Runbook](./auth-service-grpc-migration.md)
- [Postmortem: Records Service TLS Fix](../test-results/POSTMORTEM_RECORDS_TLS_FIX_12-20_tom.md)
- [Retrospective: Records Service TLS Fix](../test-results/RETROSPECTIVE_RECORDS_TLS_FIX_12-20_tom.md)

## Quick Reference

### Commands

```bash
# Check TLS certs
kubectl exec -n record-platform -l app=records-service -- ls -la /etc/certs/

# Check gRPC server mode
kubectl logs -n record-platform -l app=records-service | grep "grpc.*starting"

# Test gRPC connection
grpcurl -insecure -H "Host: record.local" 127.0.0.1:30443 records.RecordsService/HealthCheck

# Verify service-to-service connection
kubectl exec -n record-platform -l app=api-gateway -- node -e "const grpc = require('@grpc/grpc-js'); const client = new grpc.Client('records-service:50051', grpc.credentials.createInsecure()); console.log('Connected');"
```

---

**Last Verified:** December 20, 2025  
**Next Review:** January 20, 2026

