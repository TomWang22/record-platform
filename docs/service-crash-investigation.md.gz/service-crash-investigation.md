# Service Crash Investigation Report

**Date:** 2025-12-08  
**Services Affected:** Python AI Service, Analytics Service  
**Status:** 🔴 Critical - Services crashing under load

---

## Executive Summary

Both Python AI Service and Analytics Service are experiencing crashes during high-load k6 tests. The primary root cause is **health check timeouts** - services become so overloaded they cannot respond to Kubernetes health checks, causing Kubernetes to kill and restart pods. This creates a cascading failure pattern.

---

## Root Cause Analysis

### 🔴 PRIMARY ROOT CAUSE: Health Check Timeouts

**Symptoms:**
- Pods failing liveness/readiness probes
- Error: `timeout: health rpc did not complete within Xs`
- Error: `context deadline exceeded (Client.Timeout exceeded while awaiting headers)`
- Kubernetes killing pods: `Container app failed liveness probe, will be restarted`
- Multiple restarts per pod (10-13 restarts observed)

**Root Cause:**
1. Under high load (50 VUs in k6 tests), services become completely unresponsive
2. Services cannot respond to health checks within the configured timeout
3. Kubernetes interprets this as an unhealthy service and kills the pod
4. Remaining pods take on more load, causing them to also become unresponsive
5. Cascading failure pattern develops

**Evidence:**
```
Warning  Unhealthy  16m (x104 over 82m)   kubelet  Readiness probe failed: timeout: failed to connect service "10.244.0.144:50060" within 3s
Normal   Killing    14m (x9 over 64m)     kubelet  Container app failed liveness probe, will be restarted
```

---

### ⚠️ SECONDARY ISSUES

#### 1. Resource Limits May Be Insufficient

**Current Configuration:**
- **Python AI Service:**
  - Limits: CPU 2, Memory 2Gi
  - Requests: CPU 500m, Memory 512Mi
- **Analytics Service:**
  - Limits: CPU 2, Memory 2Gi
  - Requests: CPU 500m, Memory 512Mi

**Issue:**
- Under high load, services may be CPU/memory constrained
- No OOM kills detected, but services may be throttled
- Resource limits may need to be increased for sustained high load

#### 2. Too Many Gunicorn Workers

**Observation:**
- Up to 97 Gunicorn workers spawned in logs
- Each worker consumes memory (~50-100MB per worker)
- With 97 workers × 100MB = ~9.7GB memory (exceeds 2Gi limit!)
- Workers may be spawning faster than they can be cleaned up

**Evidence:**
```
[2025-12-08 21:28:53 +0000] [95] [INFO] Booting worker with pid: 95
[2025-12-08 21:28:55 +0000] [96] [INFO] Booting worker with pid: 96
[2025-12-08 21:29:08 +0000] [97] [INFO] Booting worker with pid: 97
```

**Root Cause:**
- Gunicorn configuration may allow unlimited workers
- Need to cap worker count based on CPU/memory limits

#### 3. Analytics Service Health Check Too Aggressive

**Current Configuration:**
- Readiness probe: 3s timeout ⚠️ (too short!)
- Liveness probe: 5s timeout ⚠️ (too short!)
- Period: 10s (readiness), 30s (liveness)

**Issue:**
- 3s timeout is too aggressive for a service under load
- Analytics service also timing out on health checks
- Should match Python AI service timeouts (10s readiness, 15s liveness)

#### 4. Kafka Connection Errors (Non-Critical)

**Observation:**
- Many Kafka connection refused errors in logs
- `ERROR:aiokafka:Unable connect to "kafka-external.record-platform.svc.cluster.local:9092": [Errno 111] Connection refused`

**Impact:**
- Non-critical (Kafka consumer is wrapped in try-except)
- Service should continue to function without Kafka
- However, errors may add to log noise and slight overhead

---

## Test Results Correlation

### Test 1 (Best Result - 53.54% success)
- Service was relatively stable
- Some health check timeouts but not cascading failures

### Test 2 (30.30% success)
- Service restarts observed during test
- Health check failures increasing

### Test 3 (Worst Result - 9.47% success)
- Service crashed multiple times
- Pods in CrashLoopBackOff
- Complete service unavailability during crashes

**Correlation:**
- As load increases and persists, health check failures increase
- Once health checks start failing, cascading failures occur
- Service becomes completely unavailable

---

## Recommended Fixes

### 🔧 Immediate Fixes (Priority 1)

1. **Increase Analytics Service Health Check Timeouts**
   - Readiness: 3s → 10s
   - Liveness: 5s → 15s
   - Period: 10s → 10s (readiness), 30s → 30s (liveness)
   - Failure threshold: 3 → 5

2. **Cap Gunicorn Workers**
   - Set maximum workers based on memory limits
   - Formula: `max_workers = (memory_limit_mb - overhead) / worker_memory_mb`
   - Example: `(2048MB - 200MB) / 100MB = ~18 workers max`
   - Update `gunicorn.conf.py` to enforce this limit

3. **Increase Resource Limits (if cluster capacity allows)**
   - Python AI: CPU 2 → 4, Memory 2Gi → 4Gi
   - Analytics: CPU 2 → 4, Memory 2Gi → 4Gi
   - This will allow more workers and better performance under load

### 🔧 Medium-Term Fixes (Priority 2)

4. **Implement Health Check Caching**
   - Cache health check results for 1-2 seconds
   - Reduce load on services during health checks
   - Already implemented for Analytics service, verify it's working

5. **Add Circuit Breaker for Health Checks**
   - If health checks fail repeatedly, temporarily reduce load
   - Implement backoff for health check requests

6. **Monitor Resource Usage**
   - Add metrics for CPU/memory usage
   - Alert when approaching limits
   - Use this data to tune resource limits

### 🔧 Long-Term Fixes (Priority 3)

7. **Implement Horizontal Pod Autoscaling (HPA)**
   - Automatically scale pods based on CPU/memory usage
   - Scale up before services become overloaded
   - Scale down during low load periods

8. **Optimize Service Performance**
   - Reduce latency to allow more throughput
   - Implement request queuing
   - Add rate limiting at ingress

9. **Kafka Service Availability**
   - Investigate why Kafka is unavailable
   - Ensure Kafka is running and accessible
   - Or make Kafka truly optional (remove connection attempts)

---

## Current Service Status

### Python AI Service
- **Pods:** 3 replicas (2 ready, 1 terminating, 1 creating)
- **Restarts:** 10-13 per pod
- **Health Checks:** Failing with 10s/15s timeouts (recently increased)
- **Resource Limits:** CPU 2, Memory 2Gi

### Analytics Service
- **Pods:** 2 replicas (both ready)
- **Restarts:** 0 (stable)
- **Health Checks:** Failing with 3s/5s timeouts (too aggressive!)
- **Resource Limits:** CPU 2, Memory 2Gi

---

## Next Steps

1. ✅ **COMPLETED:** Increased Python AI health check timeouts
2. ⏳ **TODO:** Increase Analytics health check timeouts
3. ⏳ **TODO:** Cap Gunicorn workers in `gunicorn.conf.py`
4. ⏳ **TODO:** Increase resource limits (if cluster allows)
5. ⏳ **TODO:** Monitor resource usage during next k6 test
6. ⏳ **TODO:** Investigate Gunicorn worker spawning behavior

---

## References

- [Kubernetes Health Checks](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/)
- [Gunicorn Configuration](https://docs.gunicorn.org/en/stable/settings.html)
- [Python AI Service Deployment](../infra/k8s/base/python-ai-service/deploy.yaml)
- [Analytics Service Deployment](../infra/k8s/base/analytics-service/deploy.yaml)

---

**Document Maintained By:** AI Assistant  
**Last Updated:** 2025-12-08

