# Infrastructure as Code (IAC) Setup Guide

This guide helps you set up and verify Terraform and Ansible for managing the Record Platform infrastructure.

## 🚀 One-Command Bootstrap (Recommended)

**Deploy the entire platform with a single command:**

```bash
./scripts/bootstrap-platform.sh
```

This script:
- ✅ Checks all prerequisites (Terraform, Ansible, kubectl, kind, docker)
- ✅ Creates/verifies Kind cluster
- ✅ Initializes and applies Terraform (creates namespace, base configs)
- ✅ Installs Ansible collections
- ✅ Deploys services with Ansible
- ✅ Builds and loads Docker images
- ✅ Applies Kubernetes resources via Kustomize
- ✅ Waits for all deployments to be ready
- ✅ Shows status and next steps

**Options:**
```bash
./scripts/bootstrap-platform.sh --dry-run      # Preview changes without applying
./scripts/bootstrap-platform.sh --skip-build   # Skip Docker image builds
./scripts/bootstrap-platform.sh --destroy      # Teardown all infrastructure
./scripts/bootstrap-platform.sh --cluster h3   # Use specific Kind cluster
./scripts/bootstrap-platform.sh --env prod      # Deploy to production environment
```

## Manual Setup (Step-by-Step)

If you prefer to run each step manually:

1. **Run the setup verification script:**
   ```bash
   cd infra
   chmod +x test-iac-setup.sh
   ./test-iac-setup.sh
   ```

2. **Or use the Makefile:**
   ```bash
   cd infra
   make help        # See all commands
   make test-setup  # Run verification
   ```

## Prerequisites

### Required
- **Terraform** (>= 1.0)
  - Install: `brew install terraform`
  - Or: https://developer.hashicorp.com/terraform/downloads

- **Ansible** (>= 2.9)
  - Install: `pip install ansible`
  - Or: `pip3 install ansible`

### Optional (but recommended)
- **kubectl** - For Kubernetes management
  - Install: `brew install kubectl`

- **jq** - For JSON parsing
  - Install: `brew install jq`

## Directory Structure

```
infra/
├── terraform/          # Terraform configuration
│   ├── main.tf        # Main Terraform configuration
│   ├── variables.tf   # Variable definitions
│   ├── outputs.tf     # Output definitions
│   └── kubernetes.tf  # Kubernetes resources
├── ansible/           # Ansible playbooks
│   ├── ansible.cfg    # Ansible configuration
│   ├── requirements.yml  # Ansible collection requirements
│   ├── inventory/     # Inventory files
│   │   └── hosts.yml  # Host definitions
│   └── playbooks/     # Ansible playbooks
│       └── deploy-services.yml
├── test-iac-setup.sh  # Setup verification script
└── Makefile           # Convenience commands
```

## Terraform Usage

### Initialize
```bash
cd infra/terraform
terraform init
```

### Validate Configuration
```bash
terraform validate
```

### Plan Changes (Dry-run)
```bash
terraform plan
```

### Apply Changes
```bash
terraform apply
```

### Using Makefile
```bash
cd infra
make terraform-init      # Initialize
make terraform-validate # Validate
make terraform-plan      # Plan
make terraform-apply     # Apply
```

## Ansible Usage

### Install Collections
```bash
cd infra/ansible
ansible-galaxy collection install -r requirements.yml
```

### Verify Inventory
```bash
ansible-inventory --list
```

### Dry-run Playbook
```bash
ansible-playbook playbooks/deploy-services.yml --check
```

### Deploy
```bash
ansible-playbook playbooks/deploy-services.yml
```

### Using Makefile
```bash
cd infra
make ansible-install    # Install collections
make ansible-check      # Dry-run
make ansible-deploy     # Deploy
```

## Important Notes

### Standalone Mode
All playbooks are configured with:
- `skip_cert_management: true` - Does not touch certificates
- `skip_caddy_config: true` - Does not modify Caddy configuration

### Safety Features
- **Terraform**: `terraform plan` is a dry-run (no changes made)
- **Ansible**: `--check` flag runs in dry-run mode
- **No CA Interference**: Does not touch certificates, Caddy config, or CA rotation

### Safe to Test
- `terraform plan` - Shows what would be created (no changes)
- `ansible-playbook --check` - Shows what would change (no changes)
- Both are safe to run repeatedly

## Troubleshooting

### Terraform Issues

**Error: "No valid credential sources found"**
- Ensure `kubectl` is configured: `kubectl config current-context`
- Or set `kubeconfig_path` variable in `terraform/variables.tf`

**Error: "Provider requirements"**
- Run `terraform init` to download providers

### Ansible Issues

**Error: "Collection not found"**
- Install collections: `ansible-galaxy collection install -r requirements.yml`

**Error: "Inventory not found"**
- Check `ansible.cfg` has correct `inventory` path
- Verify `inventory/hosts.yml` exists

**Error: "Python interpreter not found"**
- Ensure Python 3 is installed: `python3 --version`
- Ansible will use the system Python by default

### Missing Files
The `test-iac-setup.sh` script will automatically create any missing files:
- Terraform: `main.tf`, `variables.tf`, `outputs.tf`
- Ansible: `ansible.cfg`, `inventory/hosts.yml`, `requirements.yml`

## Makefile Commands

```bash
make help              # Show all available commands
make terraform-init    # Initialize Terraform
make terraform-validate # Validate Terraform config
make terraform-plan     # Show Terraform plan
make terraform-apply    # Apply Terraform changes
make ansible-install    # Install Ansible collections
make ansible-check      # Dry-run Ansible playbook
make ansible-deploy     # Deploy with Ansible
make test-setup        # Run verification script
make clean             # Clean temporary files
```

## Next Steps

1. **Verify setup:**
   ```bash
   cd infra
   ./test-iac-setup.sh
   ```

2. **Test Terraform:**
   ```bash
   cd infra/terraform
   terraform plan
   ```

3. **Test Ansible:**
   ```bash
   cd infra/ansible
   ansible-playbook playbooks/deploy-services.yml --check
   ```

4. **When ready to deploy:**
   ```bash
   # Terraform
   cd infra/terraform
   terraform apply
   
   # Ansible
   cd infra/ansible
   ansible-playbook playbooks/deploy-services.yml
   ```

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the test script output: `./test-iac-setup.sh`
3. Verify prerequisites are installed correctly

