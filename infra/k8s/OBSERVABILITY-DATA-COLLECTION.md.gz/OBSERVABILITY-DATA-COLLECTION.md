# Observability Stack Data Collection Status

## Current Status

### ✅ Working Components

1. **Prometheus** (Metrics Collection)
   - Status: Running (2/2 pods)
   - ServiceMonitors: 17 configured
   - Scraping: All services being scraped
   - Data: Metrics from all microservices, Linkerd, Istio

2. **Grafana** (Visualization)
   - Standalone: Running (1/1) ✅
   - Helm: CrashLoopBackOff (PVC issue - use standalone)
   - Dashboards: Available in standalone Grafana
   - Data Sources: Prometheus configured

3. **Jaeger** (Distributed Tracing)
   - Status: Running (2/2 pods)
   - Endpoints: OTLP gRPC (4317), OTLP HTTP (4318)
   - Data: Receiving traces from services

4. **Linkerd** (Service Mesh)
   - Control Plane: 3 pods running
   - Injection: Enabled for `record-platform` namespace
   - Metrics: Available via Linkerd Viz
   - Data: Service-level metrics, mTLS, traffic management

5. **Istio** (Service Mesh)
   - Control Plane: 6 pods running
   - Metrics: Available via Istio Prometheus
   - Data: Service-level metrics, traffic management

6. **New Relic** (APM)
   - Secret: Configured ✅
   - Status: Ready (waiting for OTel Collector)

### ⚠️ Issues

1. **OTel Collector**: Pending (needs fixing)
   - Impact: New Relic export not working
   - Workaround: Services can send traces directly to Jaeger

2. **Grafana (Helm)**: CrashLoopBackOff
   - Impact: None (standalone Grafana works)
   - Fix: Delete PVC if needed

## Data Collection Coverage

### Metrics ✅
- **Prometheus**: Scraping all services via 17 ServiceMonitors
- **Linkerd**: Service mesh metrics (request rate, latency, success rate)
- **Istio**: Service mesh metrics (traffic, errors, latency)
- **Infrastructure**: Node exporters, HAProxy, Nginx exporters

### Traces ✅
- **Jaeger**: Receiving traces via OTLP (ports 4317, 4318)
- **OTel Collector**: Pending (fix needed for New Relic export)
- **Services**: Can send traces directly to Jaeger or via OTel

### Logs ⚠️
- **Current**: No centralized logging (services log to stdout)
- **Recommendation**: Add Fluentd/Fluent Bit + Elasticsearch or Loki

### Service Mesh ✅
- **Linkerd**: Active, injecting sidecars, providing mTLS
- **Istio**: Active (may conflict with Linkerd - recommend using one)

## Configuration Files

- **ServiceMonitors**: `infra/k8s/base/monitoring/servicemonitors.yaml`
- **Observability ServiceMonitors**: `infra/k8s/base/observability/servicemonitors.yaml`
- **PodMonitors**: `infra/k8s/base/observability/podmonitors.yaml`
- **OTel Config**: `infra/k8s/base/observability/otel-collector-deploy.yaml`
- **Jaeger Config**: `infra/k8s/base/observability/jaeger-deploy.yaml`

## Verification Commands

```bash
# Check Prometheus targets
kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090
# Visit: http://localhost:9090/targets

# Check Grafana
kubectl -n observability port-forward svc/grafana 3000:3000
# Visit: http://localhost:3000 (admin/admin)

# Check Jaeger
kubectl -n observability port-forward svc/jaeger 16686:16686
# Visit: http://localhost:16686

# Check ServiceMonitors
kubectl -n monitoring get servicemonitors

# Check Linkerd metrics
linkerd viz dashboard  # (if linkerd CLI installed)

# Check Istio metrics
istioctl dashboard prometheus  # (if istioctl installed)
```

## Next Steps

1. ✅ **pgbouncer**: Removed from kustomization.yaml
2. ⚠️ **OTel Collector**: Fix pending pod issue
3. ⚠️ **Service Mesh**: Choose Linkerd OR Istio (not both)
4. 📊 **Logging**: Consider adding centralized logging stack

