# Production Observability Stack Setup Guide

This document provides comprehensive guidance for setting up and maintaining the production-ready observability stack for the Record Platform.

## Overview

The observability stack consists of:
- **Prometheus**: Metrics collection and storage
- **Grafana**: Metrics visualization and dashboards
- **Jaeger**: Distributed tracing
- **OpenTelemetry Collector**: OTLP receiver/processor/exporter
- **Linkerd** (optional): Service mesh with automatic mTLS and metrics
- **Istio** (optional): Service mesh with advanced routing and observability
- **New Relic** (optional): APM integration via OpenTelemetry

## Quick Fix Script

For automated fixes of common issues, run:

```bash
bash infra/k8s/scripts/fix-observability-production.sh
```

This script will:
1. Fix CoreDNS and DNS resolution issues
2. Fix Grafana CrashLoopBackOff (init container issues)
3. Fix Prometheus Helm chart status
4. Fix OpenTelemetry Collector duplicate/pending pods
5. Fix Linkerd control plane restarts
6. Fix Istio control plane issues
7. Fix sidecar injection issues
8. Verify Jaeger, New Relic, and ServiceMonitor configurations

## Component Setup

### 1. Prometheus

**Namespace**: `monitoring` (Helm chart) or `observability` (standalone)

**Helm Chart Installation**:
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace \
  --set grafana.adminPassword='Admin123!' \
  --set grafana.service.type=ClusterIP \
  --set grafana.persistence.enabled=true \
  --set grafana.persistence.size=10Gi \
  --set prometheus.prometheusSpec.retention=30d \
  --set prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.storageClassName=standard \
  --set prometheus.prometheusSpec.storageSpec.volumeClaimTemplate.spec.resources.requests.storage=50Gi \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false \
  --wait --timeout=5m
```

**Standalone Installation**:
```bash
kubectl apply -k infra/k8s/base/observability
```

**Common Issues**:
- **Helm chart status "failed"**: Run the fix script or upgrade the chart
- **PVC permissions**: Grafana init container may fail if PVC has wrong permissions
- **ServiceMonitors not discovered**: Ensure `serviceMonitorSelectorNilUsesHelmValues=false`

### 2. Grafana

**Access**:
```bash
# Helm chart Grafana
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80

# Standalone Grafana
kubectl -n observability port-forward svc/grafana 3001:3000
```

**Credentials**:
- Helm: `admin` / `Admin123!`
- Standalone: `admin` / `admin`

**Common Issues**:
- **CrashLoopBackOff (init-chown-data)**: PVC permissions issue
  - Fix: Delete the pod and let it recreate, or delete/recreate the PVC (data loss!)
  - Prevention: Ensure PVC has correct storage class and permissions
- **Dashboard not loading**: Check datasource configuration
- **No metrics**: Verify ServiceMonitors are applied and Prometheus is scraping

### 3. Jaeger

**Configuration**: `infra/k8s/base/observability/jaeger-deploy.yaml`

**Access**:
```bash
kubectl -n observability port-forward svc/jaeger 16686:16686
```

**Endpoints**:
- Query UI: `16686`
- OTLP gRPC: `4317`
- OTLP HTTP: `4318`
- HTTP Collector: `14268`
- gRPC Collector: `14250`

**Verification**:
```bash
# Check OTLP ports are configured
kubectl -n observability get svc jaeger -o jsonpath='{.spec.ports[?(@.name=="otlp-grpc")].port}'
# Should return: 4317
```

**Common Issues**:
- **OTLP ports missing**: Ensure service YAML includes `otlp-grpc` and `otlp-http` ports
- **Traces not appearing**: Check OTel Collector configuration and connectivity

### 4. OpenTelemetry Collector

**Configuration**: `infra/k8s/base/observability/otel-collector-deploy.yaml`

**Endpoints**:
- OTLP gRPC: `4317`
- OTLP HTTP: `4318`
- Prometheus metrics: `8889`

**Exporters**:
- Jaeger: `jaeger.observability.svc.cluster.local:4317`
- New Relic: `https://otlp.nr-data.net:4317` (if configured)
- Prometheus: `0.0.0.0:8889`

**Common Issues**:
- **Duplicate/pending pods**: Resource constraints or deployment replicas > 1
  - Fix: Delete pending pods, scale deployment to 1 replica
- **New Relic 403 errors**: Invalid license key
- **Traces not reaching Jaeger**: Check OTel Collector logs and Jaeger connectivity

### 5. Linkerd Service Mesh

**Installation**:
```bash
bash infra/k8s/scripts/install-linkerd.sh
```

**Verification**:
```bash
linkerd check
```

**Enable Auto-Injection**:
```bash
# For namespace
kubectl annotate namespace record-platform linkerd.io/inject=enabled --overwrite

# For specific deployment
kubectl get deployment api-gateway -n record-platform -o yaml | \
  linkerd inject - | kubectl apply -f -
```

**Common Issues**:
- **Control plane restarts**: DNS resolution issues
  - Fix: Restart CoreDNS, verify DNS resolution from Linkerd pods
  - Check: `kubectl -n linkerd exec <pod> -c linkerd-destination -- nslookup linkerd-policy.linkerd.svc.cluster.local`
- **Sidecar not injected**: Namespace annotation missing or deployment not restarted
- **502 Bad Gateway**: Linkerd proxy issues - temporarily disable injection if needed

**Disable Injection** (if causing issues):
```bash
kubectl annotate namespace record-platform linkerd.io/inject- --overwrite
kubectl -n record-platform rollout restart deployment --all
```

### 6. Istio Service Mesh

**Installation**:
```bash
bash infra/k8s/scripts/install-istio.sh
```

**Verification**:
```bash
istioctl verify-install
```

**Enable Auto-Injection**:
```bash
# For namespace
kubectl label namespace record-platform istio-injection=enabled --overwrite

# For specific deployment
kubectl get deployment api-gateway -n record-platform -o yaml | \
  istioctl kube-inject -f - | kubectl apply -f -
```

**Common Issues**:
- **Control plane not ready**: Check istiod logs
- **Sidecar not injected**: Namespace label missing or deployment not restarted
- **Conflicts with Linkerd**: Don't run both service meshes simultaneously

### 7. New Relic Integration

**Setup**:
```bash
# Create secret with license key
kubectl create secret generic newrelic-secret \
  --from-literal=license-key='YOUR_NEW_RELIC_LICENSE_KEY' \
  -n observability \
  --dry-run=client -o yaml | kubectl apply -f -

# Restart OTel Collector to pick up secret
kubectl rollout restart deployment/otel-collector -n observability
```

**Verification**:
```bash
# Check secret exists
kubectl get secret newrelic-secret -n observability

# Check OTel Collector logs for New Relic errors
kubectl logs -n observability -l app=otel-collector | grep -i newrelic
```

**Common Issues**:
- **403 errors**: Invalid license key
- **No data in New Relic**: Check OTel Collector configuration and network connectivity

## DNS Resolution Issues

### CoreDNS Problems

**Symptoms**:
- Service DNS names not resolving
- Linkerd/Istio control plane restarts
- Pods can't connect to services

**Diagnosis**:
```bash
# Check CoreDNS pods
kubectl -n kube-system get pods -l k8s-app=kube-dns

# Check CoreDNS logs
kubectl -n kube-system logs -l k8s-app=kube-dns

# Test DNS resolution
kubectl run -n kube-system --rm -i --restart=Never test-dns --image=busybox:1.35 -- \
  nslookup kubernetes.default.svc.cluster.local
```

**Fix**:
```bash
# Restart CoreDNS
kubectl -n kube-system rollout restart deployment/coredns

# Wait for CoreDNS to be ready
kubectl -n kube-system wait --for=condition=ready pod -l k8s-app=kube-dns --timeout=120s
```

**Prevention**:
- Monitor CoreDNS pod restarts
- Ensure sufficient resources for CoreDNS pods
- Check for DNS loop detection issues

### Service DNS Resolution

**Test from Pod**:
```bash
# From a pod in the cluster
kubectl exec -n record-platform <pod-name> -- nslookup api-gateway.record-platform.svc.cluster.local

# Test service connectivity
kubectl run -n record-platform --rm -i --restart=Never test-curl --image=curlimages/curl:latest -- \
  curl -s http://api-gateway:4000/healthz
```

## Sidecar Injection Issues

### Linkerd Sidecar Injection

**Check Injection Status**:
```bash
# Check namespace annotation
kubectl get namespace record-platform -o jsonpath='{.metadata.annotations.linkerd\.io/inject}'

# Check pod sidecars
kubectl get pods -n record-platform -o jsonpath='{.items[*].spec.containers[*].name}'
# Should include: linkerd-proxy

# Check Linkerd proxy status
linkerd check --proxy
```

**Fix Injection**:
```bash
# Enable namespace injection
kubectl annotate namespace record-platform linkerd.io/inject=enabled --overwrite

# Restart deployments to inject sidecars
kubectl -n record-platform rollout restart deployment --all

# Or inject manually
kubectl get deployment api-gateway -n record-platform -o yaml | \
  linkerd inject - | kubectl apply -f -
```

### Istio Sidecar Injection

**Check Injection Status**:
```bash
# Check namespace label
kubectl get namespace record-platform -o jsonpath='{.metadata.labels.istio-injection}'

# Check pod sidecars
kubectl get pods -n record-platform -o jsonpath='{.items[*].spec.containers[*].name}'
# Should include: istio-proxy
```

**Fix Injection**:
```bash
# Enable namespace injection
kubectl label namespace record-platform istio-injection=enabled --overwrite

# Restart deployments to inject sidecars
kubectl -n record-platform rollout restart deployment --all

# Or inject manually
kubectl get deployment api-gateway -n record-platform -o yaml | \
  istioctl kube-inject -f - | kubectl apply -f -
```

## ServiceMonitors and PodMonitors

**Apply ServiceMonitors**:
```bash
# Base monitoring ServiceMonitors
kubectl apply -f infra/k8s/base/monitoring/servicemonitors.yaml

# Observability ServiceMonitors
kubectl apply -f infra/k8s/base/observability/servicemonitors.yaml
```

**Apply PodMonitors**:
```bash
kubectl apply -f infra/k8s/base/observability/podmonitors.yaml
```

**Verify Discovery**:
```bash
# Check Prometheus targets
kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090
# Then visit: http://localhost:9090/targets
```

## Production Checklist

- [ ] Prometheus is running and scraping metrics
- [ ] Grafana is accessible and dashboards are loading
- [ ] Jaeger is receiving traces via OTLP
- [ ] OpenTelemetry Collector is running and exporting to Jaeger
- [ ] ServiceMonitors and PodMonitors are applied
- [ ] CoreDNS is healthy and DNS resolution works
- [ ] Linkerd/Istio control plane is stable (if using)
- [ ] Sidecar injection is working (if using service mesh)
- [ ] New Relic is configured (if using)
- [ ] All components have proper resource limits
- [ ] PVCs have correct storage classes and permissions
- [ ] Health checks are configured for all components
- [ ] Backup strategy for Prometheus data (if needed)

## Troubleshooting Commands

```bash
# Check all observability components
kubectl get pods -A | grep -E 'monitoring|observability|linkerd|istio'

# Check Prometheus targets
kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090
# Visit: http://localhost:9090/targets

# Check Grafana datasources
kubectl -n monitoring port-forward svc/monitoring-grafana 3000:80
# Visit: http://localhost:3000 -> Configuration -> Data Sources

# Check Jaeger traces
kubectl -n observability port-forward svc/jaeger 16686:16686
# Visit: http://localhost:16686

# Check OTel Collector logs
kubectl logs -n observability -l app=otel-collector --tail=100

# Check Linkerd status
linkerd check

# Check Istio status
istioctl verify-install

# Test DNS resolution
kubectl run -n kube-system --rm -i --restart=Never test-dns --image=busybox:1.35 -- \
  nslookup kubernetes.default.svc.cluster.local

# Test service connectivity
kubectl run -n record-platform --rm -i --restart=Never test-curl --image=curlimages/curl:latest -- \
  curl -s http://api-gateway:4000/healthz
```

## Recovery Procedures

### Grafana CrashLoopBackOff

1. Check init container logs:
   ```bash
   kubectl -n monitoring logs <grafana-pod> -c init-chown-data
   ```

2. If PVC permissions issue:
   ```bash
   # Delete pod to recreate
   kubectl -n monitoring delete pod <grafana-pod>
   
   # If still failing, delete and recreate PVC (data loss!)
   kubectl -n monitoring delete pvc <grafana-pvc>
   # Then restart Grafana deployment
   ```

### Prometheus Not Scraping

1. Check ServiceMonitors:
   ```bash
   kubectl get servicemonitors -A
   ```

2. Check Prometheus targets:
   ```bash
   kubectl -n monitoring port-forward svc/monitoring-kube-prom-prometheus 9090:9090
   # Visit: http://localhost:9090/targets
   ```

3. Verify service labels match ServiceMonitor selectors

### Linkerd Control Plane Restarts

1. Check DNS resolution:
   ```bash
   kubectl -n linkerd exec <pod> -c linkerd-destination -- \
     nslookup linkerd-policy.linkerd.svc.cluster.local
   ```

2. Restart CoreDNS:
   ```bash
   kubectl -n kube-system rollout restart deployment/coredns
   ```

3. Restart Linkerd control plane:
   ```bash
   kubectl -n linkerd rollout restart deployment --all
   ```

### OTel Collector Not Exporting Traces

1. Check OTel Collector logs:
   ```bash
   kubectl logs -n observability -l app=otel-collector --tail=100
   ```

2. Verify Jaeger connectivity:
   ```bash
   kubectl run -n observability --rm -i --restart=Never test-curl --image=curlimages/curl:latest -- \
     curl -s http://jaeger.observability.svc.cluster.local:4318/
   ```

3. Check OTel Collector configuration:
   ```bash
   kubectl get configmap -n observability otel-collector-config -o yaml
   ```

## Additional Resources

- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Jaeger Documentation](https://www.jaegertracing.io/docs/)
- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [Linkerd Documentation](https://linkerd.io/2/tasks/)
- [Istio Documentation](https://istio.io/latest/docs/)

