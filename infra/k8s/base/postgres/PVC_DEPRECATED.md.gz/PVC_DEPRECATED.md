# PostgreSQL PVCs - DEPRECATED

⚠️ **These PVC files are no longer needed** - PostgreSQL has been externalized.

The following files are kept for reference but should not be deployed:
- `pvc.yaml` - Main postgres data PVC
- `pvc-big.yaml` - Large postgres data PVC  
- `wal-archive-pvc.yaml` - WAL archive PVC

PostgreSQL is now running externally (managed service or separate instance).
Services connect directly to the external PostgreSQL instance.

## Migration Notes

If you were using these PVCs:
1. Data should be migrated to external PostgreSQL
2. These PVCs can be safely deleted from the cluster
3. Update service connection strings to point to external PostgreSQL

## Related Files (also deprecated)
- `infra/k8s/overlays/dev/jobs/postgres-restore-from-pvc.yaml`
- `infra/k8s/overlays/dev/cronjobs/pg-backup-pvc.yaml`
- `infra/k8s/overlays/dev/pvc/pgbackups-pvc.yaml`
