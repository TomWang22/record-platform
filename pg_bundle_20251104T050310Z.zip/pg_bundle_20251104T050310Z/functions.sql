Output format is unaligned.
pg_get_functiondef
CREATE OR REPLACE FUNCTION public._hot_user()
 RETURNS uuid
 LANGUAGE sql
 STABLE
AS $function$ SELECT id FROM auth.users ORDER BY email NULLS LAST, id LIMIT 1 $function$

CREATE OR REPLACE FUNCTION public.armor(bytea)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_armor$function$

CREATE OR REPLACE FUNCTION public.armor(bytea, text[], text[])
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_armor$function$

CREATE OR REPLACE FUNCTION public.autoprewarm_dump_now()
 RETURNS bigint
 LANGUAGE c
 STRICT
AS '$libdir/pg_prewarm', $function$autoprewarm_dump_now$function$

CREATE OR REPLACE FUNCTION public.autoprewarm_start_worker()
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/pg_prewarm', $function$autoprewarm_start_worker$function$

CREATE OR REPLACE FUNCTION public.cash_dist(money, money)
 RETURNS money
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$cash_dist$function$

CREATE OR REPLACE FUNCTION public.choice(anyarray)
 RETURNS anyelement
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
  SELECT $1[1 + floor(random()*array_length($1,1))::int]
$function$

CREATE OR REPLACE FUNCTION public.citext(inet)
 RETURNS citext
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$network_show$function$

CREATE OR REPLACE FUNCTION public.citext(character)
 RETURNS citext
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$rtrim1$function$

CREATE OR REPLACE FUNCTION public.citext(boolean)
 RETURNS citext
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$booltext$function$

CREATE OR REPLACE FUNCTION public.citext_cmp(citext, citext)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_cmp$function$

CREATE OR REPLACE FUNCTION public.citext_eq(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_eq$function$

CREATE OR REPLACE FUNCTION public.citext_ge(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_ge$function$

CREATE OR REPLACE FUNCTION public.citext_gt(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_gt$function$

CREATE OR REPLACE FUNCTION public.citext_hash(citext)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_hash$function$

CREATE OR REPLACE FUNCTION public.citext_hash_extended(citext, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_hash_extended$function$

CREATE OR REPLACE FUNCTION public.citext_larger(citext, citext)
 RETURNS citext
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_larger$function$

CREATE OR REPLACE FUNCTION public.citext_le(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_le$function$

CREATE OR REPLACE FUNCTION public.citext_lt(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_lt$function$

CREATE OR REPLACE FUNCTION public.citext_ne(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_ne$function$

CREATE OR REPLACE FUNCTION public.citext_pattern_cmp(citext, citext)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_pattern_cmp$function$

CREATE OR REPLACE FUNCTION public.citext_pattern_ge(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_pattern_ge$function$

CREATE OR REPLACE FUNCTION public.citext_pattern_gt(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_pattern_gt$function$

CREATE OR REPLACE FUNCTION public.citext_pattern_le(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_pattern_le$function$

CREATE OR REPLACE FUNCTION public.citext_pattern_lt(citext, citext)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_pattern_lt$function$

CREATE OR REPLACE FUNCTION public.citext_smaller(citext, citext)
 RETURNS citext
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/citext', $function$citext_smaller$function$

CREATE OR REPLACE FUNCTION public.citextin(cstring)
 RETURNS citext
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$textin$function$

CREATE OR REPLACE FUNCTION public.citextout(citext)
 RETURNS cstring
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$textout$function$

CREATE OR REPLACE FUNCTION public.citextrecv(internal)
 RETURNS citext
 LANGUAGE internal
 STABLE PARALLEL SAFE STRICT
AS $function$textrecv$function$

CREATE OR REPLACE FUNCTION public.citextsend(citext)
 RETURNS bytea
 LANGUAGE internal
 STABLE PARALLEL SAFE STRICT
AS $function$textsend$function$

CREATE OR REPLACE FUNCTION public.crypt(text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_crypt$function$

CREATE OR REPLACE FUNCTION public.date_dist(date, date)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$date_dist$function$

CREATE OR REPLACE FUNCTION public.dearmor(text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_dearmor$function$

CREATE OR REPLACE FUNCTION public.decrypt(bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_decrypt$function$

CREATE OR REPLACE FUNCTION public.decrypt_iv(bytea, bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_decrypt_iv$function$

CREATE OR REPLACE FUNCTION public.digest(text, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_digest$function$

CREATE OR REPLACE FUNCTION public.digest(bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_digest$function$

CREATE OR REPLACE FUNCTION public.encrypt(bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_encrypt$function$

CREATE OR REPLACE FUNCTION public.encrypt_iv(bytea, bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_encrypt_iv$function$

CREATE OR REPLACE FUNCTION public.float4_dist(real, real)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$float4_dist$function$

CREATE OR REPLACE FUNCTION public.float8_dist(double precision, double precision)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$float8_dist$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_consistent(internal, bit, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_same(gbtreekey_var, gbtreekey_var, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_same$function$

CREATE OR REPLACE FUNCTION public.gbt_bit_union(internal, internal)
 RETURNS gbtreekey_var
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bit_union$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_consistent(internal, boolean, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_same(gbtreekey2, gbtreekey2, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_same$function$

CREATE OR REPLACE FUNCTION public.gbt_bool_union(internal, internal)
 RETURNS gbtreekey2
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gist', $function$gbt_bool_union$function$

CREATE OR REPLACE FUNCTION public.gbt_bpchar_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bpchar_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_bpchar_consistent(internal, character, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bpchar_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_consistent(internal, bytea, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_same(gbtreekey_var, gbtreekey_var, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_same$function$

CREATE OR REPLACE FUNCTION public.gbt_bytea_union(internal, internal)
 RETURNS gbtreekey_var
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_bytea_union$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_consistent(internal, money, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_distance(internal, money, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_same$function$

CREATE OR REPLACE FUNCTION public.gbt_cash_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_cash_union$function$

CREATE OR REPLACE FUNCTION public.gbt_date_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_date_consistent(internal, date, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_date_distance(internal, date, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_date_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_date_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_date_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_date_same(gbtreekey8, gbtreekey8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_same$function$

CREATE OR REPLACE FUNCTION public.gbt_date_union(internal, internal)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_date_union$function$

CREATE OR REPLACE FUNCTION public.gbt_decompress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_decompress$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_consistent(internal, anyenum, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_same(gbtreekey8, gbtreekey8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_same$function$

CREATE OR REPLACE FUNCTION public.gbt_enum_union(internal, internal)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_enum_union$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_consistent(internal, real, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_distance(internal, real, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_same(gbtreekey8, gbtreekey8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_same$function$

CREATE OR REPLACE FUNCTION public.gbt_float4_union(internal, internal)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float4_union$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_consistent(internal, double precision, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_distance(internal, double precision, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_same$function$

CREATE OR REPLACE FUNCTION public.gbt_float8_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_float8_union$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_consistent(internal, inet, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_same$function$

CREATE OR REPLACE FUNCTION public.gbt_inet_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_inet_union$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_consistent(internal, smallint, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_distance(internal, smallint, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_same(gbtreekey4, gbtreekey4, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_same$function$

CREATE OR REPLACE FUNCTION public.gbt_int2_union(internal, internal)
 RETURNS gbtreekey4
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int2_union$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_consistent(internal, integer, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_distance(internal, integer, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_same(gbtreekey8, gbtreekey8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_same$function$

CREATE OR REPLACE FUNCTION public.gbt_int4_union(internal, internal)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int4_union$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_consistent(internal, bigint, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_distance(internal, bigint, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_same$function$

CREATE OR REPLACE FUNCTION public.gbt_int8_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_int8_union$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_consistent(internal, interval, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_decompress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_decompress$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_distance(internal, interval, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_same(gbtreekey32, gbtreekey32, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_same$function$

CREATE OR REPLACE FUNCTION public.gbt_intv_union(internal, internal)
 RETURNS gbtreekey32
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_intv_union$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_consistent(internal, macaddr8, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_same$function$

CREATE OR REPLACE FUNCTION public.gbt_macad8_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad8_union$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_consistent(internal, macaddr, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_same$function$

CREATE OR REPLACE FUNCTION public.gbt_macad_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_macad_union$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_consistent(internal, numeric, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_same(gbtreekey_var, gbtreekey_var, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_same$function$

CREATE OR REPLACE FUNCTION public.gbt_numeric_union(internal, internal)
 RETURNS gbtreekey_var
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_numeric_union$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_consistent(internal, oid, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_distance(internal, oid, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_same(gbtreekey8, gbtreekey8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_same$function$

CREATE OR REPLACE FUNCTION public.gbt_oid_union(internal, internal)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_oid_union$function$

CREATE OR REPLACE FUNCTION public.gbt_text_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_text_consistent(internal, text, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_text_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_text_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_text_same(gbtreekey_var, gbtreekey_var, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_same$function$

CREATE OR REPLACE FUNCTION public.gbt_text_union(internal, internal)
 RETURNS gbtreekey_var
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_text_union$function$

CREATE OR REPLACE FUNCTION public.gbt_time_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_time_consistent(internal, time without time zone, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_time_distance(internal, time without time zone, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_time_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_time_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_time_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_time_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_same$function$

CREATE OR REPLACE FUNCTION public.gbt_time_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_time_union$function$

CREATE OR REPLACE FUNCTION public.gbt_timetz_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_timetz_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_timetz_consistent(internal, time with time zone, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_timetz_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_consistent(internal, timestamp without time zone, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_distance(internal, timestamp without time zone, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_same(gbtreekey16, gbtreekey16, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_same$function$

CREATE OR REPLACE FUNCTION public.gbt_ts_union(internal, internal)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_ts_union$function$

CREATE OR REPLACE FUNCTION public.gbt_tstz_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_tstz_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_tstz_consistent(internal, timestamp with time zone, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_tstz_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_tstz_distance(internal, timestamp with time zone, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_tstz_distance$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_compress$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_consistent(internal, uuid, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_consistent$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_fetch$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_penalty$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_picksplit$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_same(gbtreekey32, gbtreekey32, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_same$function$

CREATE OR REPLACE FUNCTION public.gbt_uuid_union(internal, internal)
 RETURNS gbtreekey32
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_uuid_union$function$

CREATE OR REPLACE FUNCTION public.gbt_var_decompress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_var_decompress$function$

CREATE OR REPLACE FUNCTION public.gbt_var_fetch(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbt_var_fetch$function$

CREATE OR REPLACE FUNCTION public.gbtreekey16_in(cstring)
 RETURNS gbtreekey16
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey16_out(gbtreekey16)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gbtreekey2_in(cstring)
 RETURNS gbtreekey2
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey2_out(gbtreekey2)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gbtreekey32_in(cstring)
 RETURNS gbtreekey32
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey32_out(gbtreekey32)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gbtreekey4_in(cstring)
 RETURNS gbtreekey4
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey4_out(gbtreekey4)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gbtreekey8_in(cstring)
 RETURNS gbtreekey8
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey8_out(gbtreekey8)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gbtreekey_var_in(cstring)
 RETURNS gbtreekey_var
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_in$function$

CREATE OR REPLACE FUNCTION public.gbtreekey_var_out(gbtreekey_var)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$gbtreekey_out$function$

CREATE OR REPLACE FUNCTION public.gen_random_bytes(integer)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_random_bytes$function$

CREATE OR REPLACE FUNCTION public.gen_random_uuid()
 RETURNS uuid
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/pgcrypto', $function$pg_random_uuid$function$

CREATE OR REPLACE FUNCTION public.gen_salt(text)
 RETURNS text
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_gen_salt$function$

CREATE OR REPLACE FUNCTION public.gen_salt(text, integer)
 RETURNS text
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_gen_salt_rounds$function$

CREATE OR REPLACE FUNCTION public.gin_btree_consistent(internal, smallint, anyelement, integer, internal, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_btree_consistent$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_anyenum(anyenum, anyenum, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_anyenum$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_bit(bit, bit, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_bit$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_bool(boolean, boolean, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_bool$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_bpchar(character, character, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_bpchar$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_bytea(bytea, bytea, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_bytea$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_char("char", "char", smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_char$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_cidr(cidr, cidr, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_cidr$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_date(date, date, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_date$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_float4(real, real, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_float4$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_float8(double precision, double precision, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_float8$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_inet(inet, inet, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_inet$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_int2(smallint, smallint, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_int2$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_int4(integer, integer, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_int4$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_int8(bigint, bigint, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_int8$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_interval(interval, interval, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_interval$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_macaddr(macaddr, macaddr, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_macaddr$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_macaddr8(macaddr8, macaddr8, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_macaddr8$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_money(money, money, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_money$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_name(name, name, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_name$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_numeric(numeric, numeric, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_numeric$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_oid(oid, oid, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_oid$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_text(text, text, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_text$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_time(time without time zone, time without time zone, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_time$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_timestamp(timestamp without time zone, timestamp without time zone, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_timestamp$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_timestamptz(timestamp with time zone, timestamp with time zone, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_timestamptz$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_timetz(time with time zone, time with time zone, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_timetz$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_uuid(uuid, uuid, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_uuid$function$

CREATE OR REPLACE FUNCTION public.gin_compare_prefix_varbit(bit varying, bit varying, smallint, internal)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_compare_prefix_varbit$function$

CREATE OR REPLACE FUNCTION public.gin_enum_cmp(anyenum, anyenum)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_enum_cmp$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_anyenum(anyenum, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_anyenum$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_bit(bit, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_bit$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_bool(boolean, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_bool$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_bpchar(character, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_bpchar$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_bytea(bytea, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_bytea$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_char("char", internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_char$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_cidr(cidr, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_cidr$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_date(date, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_date$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_float4(real, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_float4$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_float8(double precision, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_float8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_inet(inet, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_inet$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_int2(smallint, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_int2$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_int4(integer, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_int4$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_int8(bigint, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_int8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_interval(interval, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_interval$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_macaddr(macaddr, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_macaddr$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_macaddr8(macaddr8, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_macaddr8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_money(money, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_money$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_name(name, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_name$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_numeric(numeric, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_numeric$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_oid(oid, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_oid$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_text(text, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_text$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_time(time without time zone, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_time$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_timestamp(timestamp without time zone, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_timestamp$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_timestamptz(timestamp with time zone, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_timestamptz$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_timetz(time with time zone, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_timetz$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gin_extract_query_trgm$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_uuid(uuid, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_uuid$function$

CREATE OR REPLACE FUNCTION public.gin_extract_query_varbit(bit varying, internal, smallint, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_query_varbit$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_anyenum(anyenum, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_anyenum$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_bit(bit, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_bit$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_bool(boolean, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_bool$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_bpchar(character, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_bpchar$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_bytea(bytea, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_bytea$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_char("char", internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_char$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_cidr(cidr, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_cidr$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_date(date, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_date$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_float4(real, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_float4$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_float8(double precision, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_float8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_inet(inet, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_inet$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_int2(smallint, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_int2$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_int4(integer, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_int4$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_int8(bigint, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_int8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_interval(interval, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_interval$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_macaddr(macaddr, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_macaddr$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_macaddr8(macaddr8, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_macaddr8$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_money(money, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_money$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_name(name, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_name$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_numeric(numeric, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_numeric$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_oid(oid, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_oid$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_text(text, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_text$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_time(time without time zone, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_time$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_timestamp(timestamp without time zone, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_timestamp$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_timestamptz(timestamp with time zone, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_timestamptz$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_timetz(time with time zone, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_timetz$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_trgm(text, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gin_extract_value_trgm$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_uuid(uuid, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_uuid$function$

CREATE OR REPLACE FUNCTION public.gin_extract_value_varbit(bit varying, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_extract_value_varbit$function$

CREATE OR REPLACE FUNCTION public.gin_numeric_cmp(numeric, numeric)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE STRICT
AS '$libdir/btree_gin', $function$gin_numeric_cmp$function$

CREATE OR REPLACE FUNCTION public.gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gin_trgm_consistent$function$

CREATE OR REPLACE FUNCTION public.gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal)
 RETURNS "char"
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gin_trgm_triconsistent$function$

CREATE OR REPLACE FUNCTION public.gtrgm_compress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_compress$function$

CREATE OR REPLACE FUNCTION public.gtrgm_consistent(internal, text, smallint, oid, internal)
 RETURNS boolean
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_consistent$function$

CREATE OR REPLACE FUNCTION public.gtrgm_decompress(internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_decompress$function$

CREATE OR REPLACE FUNCTION public.gtrgm_distance(internal, text, smallint, oid, internal)
 RETURNS double precision
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_distance$function$

CREATE OR REPLACE FUNCTION public.gtrgm_in(cstring)
 RETURNS gtrgm
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_in$function$

CREATE OR REPLACE FUNCTION public.gtrgm_options(internal)
 RETURNS void
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE
AS '$libdir/pg_trgm', $function$gtrgm_options$function$

CREATE OR REPLACE FUNCTION public.gtrgm_out(gtrgm)
 RETURNS cstring
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_out$function$

CREATE OR REPLACE FUNCTION public.gtrgm_penalty(internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_penalty$function$

CREATE OR REPLACE FUNCTION public.gtrgm_picksplit(internal, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_picksplit$function$

CREATE OR REPLACE FUNCTION public.gtrgm_same(gtrgm, gtrgm, internal)
 RETURNS internal
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_same$function$

CREATE OR REPLACE FUNCTION public.gtrgm_union(internal, internal)
 RETURNS gtrgm
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$gtrgm_union$function$

CREATE OR REPLACE FUNCTION public.hmac(text, text, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_hmac$function$

CREATE OR REPLACE FUNCTION public.hmac(bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pg_hmac$function$

CREATE OR REPLACE FUNCTION public.int2_dist(smallint, smallint)
 RETURNS smallint
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$int2_dist$function$

CREATE OR REPLACE FUNCTION public.int4_dist(integer, integer)
 RETURNS integer
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$int4_dist$function$

CREATE OR REPLACE FUNCTION public.int8_dist(bigint, bigint)
 RETURNS bigint
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$int8_dist$function$

CREATE OR REPLACE FUNCTION public.interval_dist(interval, interval)
 RETURNS interval
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$interval_dist$function$

CREATE OR REPLACE FUNCTION public.norm_text(t text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE
AS $function$
  SELECT regexp_replace(lower(unaccent(coalesce(t,''))), '\s+', ' ', 'g')
$function$

CREATE OR REPLACE FUNCTION public.oid_dist(oid, oid)
 RETURNS oid
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$oid_dist$function$

CREATE OR REPLACE FUNCTION public.pg_buffercache_pages()
 RETURNS SETOF record
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/pg_buffercache', $function$pg_buffercache_pages$function$

CREATE OR REPLACE FUNCTION public.pg_buffercache_summary(OUT buffers_used integer, OUT buffers_unused integer, OUT buffers_dirty integer, OUT buffers_pinned integer, OUT usagecount_avg double precision)
 RETURNS record
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/pg_buffercache', $function$pg_buffercache_summary$function$

CREATE OR REPLACE FUNCTION public.pg_buffercache_usage_counts(OUT usage_count integer, OUT buffers integer, OUT dirty integer, OUT pinned integer)
 RETURNS SETOF record
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/pg_buffercache', $function$pg_buffercache_usage_counts$function$

CREATE OR REPLACE FUNCTION public.pg_check_frozen(regclass, OUT t_ctid tid)
 RETURNS SETOF tid
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_check_frozen$function$

CREATE OR REPLACE FUNCTION public.pg_check_visible(regclass, OUT t_ctid tid)
 RETURNS SETOF tid
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_check_visible$function$

CREATE OR REPLACE FUNCTION public.pg_prewarm(regclass, mode text DEFAULT 'buffer'::text, fork text DEFAULT 'main'::text, first_block bigint DEFAULT NULL::bigint, last_block bigint DEFAULT NULL::bigint)
 RETURNS bigint
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/pg_prewarm', $function$pg_prewarm$function$

CREATE OR REPLACE FUNCTION public.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision)
 RETURNS SETOF record
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pg_stat_statements', $function$pg_stat_statements_1_10$function$

CREATE OR REPLACE FUNCTION public.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone)
 RETURNS record
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pg_stat_statements', $function$pg_stat_statements_info$function$

CREATE OR REPLACE FUNCTION public.pg_stat_statements_reset(userid oid DEFAULT 0, dbid oid DEFAULT 0, queryid bigint DEFAULT 0)
 RETURNS void
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pg_stat_statements', $function$pg_stat_statements_reset_1_7$function$

CREATE OR REPLACE FUNCTION public.pg_truncate_visibility_map(regclass)
 RETURNS void
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_truncate_visibility_map$function$

CREATE OR REPLACE FUNCTION public.pg_visibility(regclass, OUT blkno bigint, OUT all_visible boolean, OUT all_frozen boolean, OUT pd_all_visible boolean)
 RETURNS SETOF record
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_visibility_rel$function$

CREATE OR REPLACE FUNCTION public.pg_visibility(regclass, blkno bigint, OUT all_visible boolean, OUT all_frozen boolean, OUT pd_all_visible boolean)
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_visibility$function$

CREATE OR REPLACE FUNCTION public.pg_visibility_map(regclass, blkno bigint, OUT all_visible boolean, OUT all_frozen boolean)
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_visibility_map$function$

CREATE OR REPLACE FUNCTION public.pg_visibility_map(regclass, OUT blkno bigint, OUT all_visible boolean, OUT all_frozen boolean)
 RETURNS SETOF record
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_visibility_map_rel$function$

CREATE OR REPLACE FUNCTION public.pg_visibility_map_summary(regclass, OUT all_visible bigint, OUT all_frozen bigint)
 RETURNS record
 LANGUAGE c
 STRICT
AS '$libdir/pg_visibility', $function$pg_visibility_map_summary$function$

CREATE OR REPLACE FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text)
 RETURNS SETOF record
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_armor_headers$function$

CREATE OR REPLACE FUNCTION public.pgp_key_id(bytea)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_key_id_w$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt(bytea, bytea)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt(bytea, bytea, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_decrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_encrypt(text, bytea, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_encrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_encrypt(text, bytea)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_encrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_encrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_pub_encrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_decrypt(bytea, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_decrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_decrypt(bytea, text, text)
 RETURNS text
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_decrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_decrypt_bytea(bytea, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_decrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text)
 RETURNS bytea
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_decrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_encrypt(text, text, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_encrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_encrypt(text, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_encrypt_text$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_encrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.pgp_sym_encrypt_bytea(bytea, text)
 RETURNS bytea
 LANGUAGE c
 PARALLEL SAFE STRICT
AS '$libdir/pgcrypto', $function$pgp_sym_encrypt_bytea$function$

CREATE OR REPLACE FUNCTION public.records_recent(p_user uuid, p_limit integer DEFAULT 50)
 RETURNS SETOF records.records
 LANGUAGE sql
 STABLE PARALLEL SAFE
AS $function$
  SELECT *
  FROM records.records
  WHERE user_id = p_user
  ORDER BY updated_at DESC
  LIMIT GREATEST(1, LEAST(200, COALESCE(p_limit,50)));
$function$

CREATE OR REPLACE FUNCTION public.regexp_match(citext, citext)
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$function$

CREATE OR REPLACE FUNCTION public.regexp_match(citext, citext, text)
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_match( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN pg_catalog.strpos($3, 'c') = 0 THEN  $3 || 'i' ELSE $3 END );
$function$

CREATE OR REPLACE FUNCTION public.regexp_matches(citext, citext, text)
 RETURNS SETOF text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT ROWS 10
AS $function$
    SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN pg_catalog.strpos($3, 'c') = 0 THEN  $3 || 'i' ELSE $3 END );
$function$

CREATE OR REPLACE FUNCTION public.regexp_matches(citext, citext)
 RETURNS SETOF text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT ROWS 1
AS $function$
    SELECT pg_catalog.regexp_matches( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$function$

CREATE OR REPLACE FUNCTION public.regexp_replace(citext, citext, text, text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, CASE WHEN pg_catalog.strpos($4, 'c') = 0 THEN  $4 || 'i' ELSE $4 END);
$function$

CREATE OR REPLACE FUNCTION public.regexp_replace(citext, citext, text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, $2::pg_catalog.text, $3, 'i');
$function$

CREATE OR REPLACE FUNCTION public.regexp_split_to_array(citext, citext)
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_split_to_array( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$function$

CREATE OR REPLACE FUNCTION public.regexp_split_to_array(citext, citext, text)
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_split_to_array( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN pg_catalog.strpos($3, 'c') = 0 THEN  $3 || 'i' ELSE $3 END );
$function$

CREATE OR REPLACE FUNCTION public.regexp_split_to_table(citext, citext, text)
 RETURNS SETOF text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, CASE WHEN pg_catalog.strpos($3, 'c') = 0 THEN  $3 || 'i' ELSE $3 END );
$function$

CREATE OR REPLACE FUNCTION public.regexp_split_to_table(citext, citext)
 RETURNS SETOF text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$function$

CREATE OR REPLACE FUNCTION public.replace(citext, citext, citext)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.regexp_replace( $1::pg_catalog.text, pg_catalog.regexp_replace($2::pg_catalog.text, '([^a-zA-Z_0-9])', E'\\\\\\1', 'g'), $3::pg_catalog.text, 'gi' );
$function$

CREATE OR REPLACE FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer DEFAULT 10, p_field text DEFAULT 'artist'::text)
 RETURNS TABLE(term text, hits integer, dist real)
 LANGUAGE sql
 STABLE PARALLEL SAFE
AS $function$
  WITH p AS (
    SELECT norm_text(COALESCE(p_q,'')) AS qn,
           CASE WHEN p_field IN ('label','catalog') THEN p_field ELSE 'artist' END AS fld
  ),
  base AS (
    SELECT CASE
             WHEN (SELECT fld FROM p)='label'   THEN r.label
             WHEN (SELECT fld FROM p)='catalog' THEN r.catalog_number
             ELSE r.artist
           END AS term_raw,
           CASE
             WHEN (SELECT fld FROM p)='label'   THEN r.label_norm
             WHEN (SELECT fld FROM p)='catalog' THEN r.catalog_norm
             ELSE r.artist_norm
           END AS term_norm
    FROM records.records r
    WHERE r.user_id = p_user
  ),
  alias AS (
    SELECT NULL::text AS term_raw, a.alias_norm AS term_norm
    FROM records.aliases_mv a
    JOIN records.records r ON r.id = a.record_id
    WHERE r.user_id = p_user
  ),
  unioned AS (SELECT * FROM base UNION ALL SELECT * FROM alias)
  SELECT COALESCE(term_raw, term_norm) AS term,
         COUNT(*)::int AS hits,
         MIN(similarity(term_norm, (SELECT qn FROM p))) AS dist
  FROM unioned
  WHERE term_norm IS NOT NULL AND term_norm <> ''
    AND (
      (length((SELECT qn FROM p)) <= 2 AND term_norm LIKE (SELECT qn FROM p) || '%') OR
      (length((SELECT qn FROM p)) >  2 AND term_norm %   (SELECT qn FROM p))
    )
  GROUP BY 1
  ORDER BY dist DESC, hits DESC
  LIMIT LEAST(50, GREATEST(1, p_k));
$function$

CREATE OR REPLACE FUNCTION public.search_facets(p_user uuid, p_q text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE qn TEXT := norm_text(p_q);
BEGIN
  RETURN jsonb_build_object(
    'format', (
      SELECT jsonb_agg(jsonb_build_object('format',format,'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT format, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user
          AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.search_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    ),
    'label', (
      SELECT jsonb_agg(jsonb_build_object('label',label,'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT label, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user AND label IS NOT NULL AND label<>''
          AND ((length(qn)<=2 AND r.label_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.label_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    ),
    'year', (
      SELECT jsonb_agg(
               jsonb_build_object('bucket',
                 CASE
                   WHEN release_year BETWEEN 1970 AND 1979 THEN '70s'
                   WHEN release_year BETWEEN 1980 AND 1989 THEN '80s'
                   WHEN release_year BETWEEN 1990 AND 1999 THEN '90s'
                   WHEN release_year BETWEEN 2000 AND 2009 THEN '00s'
                   WHEN release_year BETWEEN 2010 AND 2019 THEN '10s'
                   WHEN release_year BETWEEN 2020 AND 2029 THEN '20s'
                   ELSE 'unknown'
                 END,
                 'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT release_year, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user AND release_year IS NOT NULL
          AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.search_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    )
  );
END;
$function$

CREATE OR REPLACE FUNCTION public.search_hot_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.20'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET random_page_cost TO '1.1'
 SET enable_seqscan TO 'on'
AS $function$
DECLARE u   uuid := public._hot_user();
DECLARE sql text;
BEGIN
  sql := format($f$
    WITH x AS (SELECT public.norm_text(coalesce(%L,'')) AS q)
    SELECT r.id,
           (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = %L::uuid
      AND r.search_norm %% x.q
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(2000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, u::text, p_limit, p_offset);
  RETURN QUERY EXECUTE sql;
END$function$

CREATE OR REPLACE FUNCTION public.search_hot_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET random_page_cost TO '1.1'
AS $function$
DECLARE u   uuid := public._hot_user();
DECLARE sql text;
BEGIN
  sql := format($f$
    WITH x AS (SELECT public.norm_text(coalesce(%L,'')) AS q)
    SELECT r.id,
           (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = %L::uuid
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(2000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, u::text, p_limit, p_offset);
  RETURN QUERY EXECUTE sql;
END$function$

CREATE OR REPLACE FUNCTION public.search_hot_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET enable_seqscan TO 'off'
 SET enable_bitmapscan TO 'on'
 SET random_page_cost TO '1.0'
 SET work_mem TO '64MB'
AS $function$
DECLARE
  gates numeric[] := ARRAY[0.60,0.58,0.56,0.54,0.52,0.50,0.48,0.46];
  gate  numeric;
  sql   text;
  body  text := $q$
    WITH x AS (
      SELECT set_limit($GATE$) AS _ , public.norm_text(coalesce($1,'')) AS q
    ),
    cand AS (
      SELECT h.id, (h.search_norm <-> x.q) AS dist
      FROM records_hot.records_hot h, x
      WHERE h.user_id = $USER$::uuid
        AND h.search_norm % x.q
        AND similarity(h.search_norm, x.q) >= $GATE$
      ORDER BY 1 ASC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;
BEGIN
  FOREACH gate IN ARRAY gates LOOP
    sql := replace(body, '$USER$', quote_literal(p_user));
    sql := replace(sql, '$GATE$', to_char(gate,'FM0.00'));
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
    IF FOUND THEN RETURN; END IF;
  END LOOP;

  -- Final fallback: your existing pure KNN wrapper (hot heap)
  RETURN QUERY
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT h.id, (1::real - (h.search_norm <-> x.q)::real) AS rank
  FROM records_hot.records_hot h, x
  WHERE h.user_id = p_user
  ORDER BY h.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
END
$function$

CREATE OR REPLACE FUNCTION public.search_hot_knn_only(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET enable_seqscan TO 'off'
 SET enable_bitmapscan TO 'off'
 SET jit TO 'off'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  use_hot boolean;
BEGIN
  use_hot := (to_regclass('records_hot.records_hot') IS NOT NULL)
             AND EXISTS (SELECT 1 FROM records_hot.records_hot WHERE user_id = p_user LIMIT 1);

  IF use_hot THEN
    RETURN QUERY
    WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
    SELECT h.id, (1::real - (h.search_norm <-> x.q)::real) AS rank
    FROM records_hot.records_hot h, x
    WHERE h.user_id = p_user
    ORDER BY h.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(1000, p_limit))
    OFFSET GREATEST(0, p_offset);
  ELSE
    RETURN QUERY
    WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
    SELECT r.id, (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = p_user
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(1000, p_limit))
    OFFSET GREATEST(0, p_offset);
  END IF;
END
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET random_page_cost TO '1.1'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
    AND r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s032_fast(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, similarity(r.search_norm, x.q) AS sim
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid     -- tenant-pinned
      AND r.search_norm % x.q                  -- hits GIN
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(100, p_limit*20))  -- shortlist ~20× limit
  )
  SELECT id, sim::real AS rank
  FROM cand
  ORDER BY sim DESC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s032_gin_then_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id,
           similarity(r.search_norm, x.q) AS sim,
           (r.search_norm <-> x.q)        AS dist
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(100, p_limit*20))
  )
  SELECT id, (1::real - dist::real) AS rank
  FROM cand
  ORDER BY dist ASC                  -- KNN tie-break over shortlist
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET random_page_cost TO '1.1'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s036_fast(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.36'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, similarity(r.search_norm, x.q) AS sim
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(300, p_limit*12))
  )
  SELECT id, sim::real AS rank
  FROM cand
  ORDER BY sim DESC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_main_c25_s036_gin_then_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.36'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, (r.search_norm <-> x.q) AS dist
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY 1 ASC
    LIMIT LEAST(1000, GREATEST(300, p_limit*12))
  )
  SELECT id, (1::real - dist::real) AS rank
  FROM cand
  ORDER BY dist ASC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_percent_then_knn(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET enable_seqscan TO 'off'
 SET enable_bitmapscan TO 'off'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  sql text;
BEGIN
  sql := $q$
    WITH x AS (SELECT public.norm_text(coalesce($1,'')) AS q),
    cand AS (
      SELECT r.id, (r.search_norm <-> x.q) AS dist
      FROM records.records r, x
      WHERE r.user_id = $USER_LIT$
        AND r.search_norm % x.q
      ORDER BY 1 ASC
      LIMIT LEAST(1000, GREATEST(300, $2*12))
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;

  sql := replace(sql, '$USER_LIT$', quote_literal(p_user) || '::uuid');

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
END
$function$

CREATE OR REPLACE FUNCTION public.search_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET enable_seqscan TO 'off'
 SET enable_bitmapscan TO 'off'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  gates real[] := ARRAY[0.60, 0.58, 0.56, 0.54, 0.52];
  gate  real;
  cap   int := 400;   -- cap shortlist
  base  int := 10;    -- shortlist ≈ base×limit
  tname text;
  use_hot boolean;
  sql   text;
BEGIN
  use_hot := (to_regclass('records_hot.records_hot') IS NOT NULL)
             AND EXISTS (SELECT 1 FROM records_hot.records_hot WHERE user_id = p_user LIMIT 1);
  tname := CASE WHEN use_hot THEN 'records_hot.records_hot' ELSE 'records.records' END;

  FOREACH gate IN ARRAY gates LOOP
    sql := 'WITH x AS (
              SELECT set_limit($4) AS _, public.norm_text(coalesce($1, '''')) AS q
            ),
            cand AS (
              SELECT h.id, (h.search_norm <-> x.q) AS dist
              FROM '||tname||' h, x
              WHERE h.user_id = $5
                AND h.search_norm % x.q
                AND similarity(h.search_norm, x.q) >= $4
              ORDER BY 1 ASC
              LIMIT LEAST($6, GREATEST(200, $2*$7))
            )
            SELECT id, (1::real - dist::real) AS rank
            FROM cand
            ORDER BY dist ASC
            LIMIT GREATEST(1, LEAST(1000, $2))
            OFFSET GREATEST(0, $3)';

    RETURN QUERY EXECUTE sql USING
      p_q,           -- $1
      p_limit,       -- $2
      p_offset,      -- $3
      gate,          -- $4 (set_limit & similarity gate)
      p_user,        -- $5
      cap,           -- $6
      base;          -- $7

    IF FOUND THEN
      RETURN;
    END IF;
  END LOOP;

  -- last resort
  RETURN QUERY SELECT * FROM public.search_hot_knn_only(p_user, p_q, p_limit, p_offset, p_strict);
END
$function$

CREATE OR REPLACE FUNCTION public.search_hot_percent_then_knn_safe(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  sql text;
  rows int;
BEGIN
  -- 1st pass: tighter shortlist
  sql := '
    WITH x AS (
      SELECT set_limit(0.52) AS _, public.norm_text(coalesce($1, '''')) AS q
    ),
    cand AS (
      SELECT r.id, (r.search_norm <-> x.q) AS dist
      FROM records.records r, x
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND r.search_norm % x.q
        AND similarity(r.search_norm, x.q) >= 0.52
      ORDER BY dist ASC
      LIMIT 400
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  ';
  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  GET DIAGNOSTICS rows = ROW_COUNT;

  IF rows = 0 THEN
    -- Fallback: slightly looser
    sql := replace(sql, '0.52', '0.50');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$function$

CREATE OR REPLACE FUNCTION public.search_hot_poc_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_hot_poc_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
AS $function$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
AS $function$
  SELECT * FROM public.search_records_fuzzy_ids_core(p_user, p_q, p_limit::bigint, p_offset::bigint)
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_core(p_user uuid, p_q text, p_limit bigint, p_offset bigint)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
AS $function$
  WITH q AS (
    -- set_limit() both sets pg_trgm’s threshold and returns a real so we can SELECT it
    SELECT public.norm_text(p_q) AS qn,
           set_limit(0.25)       AS lim
  ),

  -- Candidates from records fields (looser threshold to widen recall)
  cand_from_records AS (
    SELECT r.id
    FROM records.records r, q
    WHERE r.user_id = p_user
      AND (
           similarity(r.search_norm, q.qn) >= 0.10
        OR similarity(r.artist_norm,  q.qn) >= 0.10
        OR similarity(r.name_norm,    q.qn) >= 0.10
        OR similarity(r.label_norm,   q.qn) >= 0.10
        OR similarity(r.catalog_norm, q.qn) >= 0.10
      )
  ),

  -- Candidates from aliases_mv (catch non-Latin variants)
  cand_from_aliases AS (
    SELECT a.record_id AS id
    FROM records.aliases_mv a, q
    WHERE a.user_id = p_user
      AND similarity(a.alias_norm, q.qn) >= 0.20
  ),

  cand AS (
    SELECT id FROM cand_from_records
    UNION
    SELECT id FROM cand_from_aliases
  ),

  scored AS (
    SELECT r.id,
           GREATEST(
             similarity(r.search_norm, q.qn),
             similarity(r.artist_norm,  q.qn),
             similarity(r.name_norm,    q.qn),
             similarity(r.label_norm,   q.qn),
             similarity(r.catalog_norm, q.qn),
             COALESCE(al.alias_sim, 0)
           )::real AS rank,
           r.search_norm <-> q.qn AS dist
    FROM cand c
    JOIN records.records r ON r.id = c.id
    CROSS JOIN q
    -- best alias match per record (if any)
    LEFT JOIN LATERAL (
      SELECT similarity(a2.alias_norm, q.qn) AS alias_sim
      FROM records.aliases_mv a2
      WHERE a2.user_id = p_user
        AND a2.record_id = r.id
      ORDER BY a2.alias_norm <-> q.qn
      LIMIT 1
    ) al ON true
  )

  SELECT id, rank
  FROM scored
  ORDER BY dist
  LIMIT p_limit OFFSET p_offset
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_knn_bias(p_user uuid, p_q text, p_limit bigint, p_offset bigint)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
AS $function$
  SELECT * FROM public.search_records_fuzzy_ids_core(p_user, p_q, p_limit, p_offset)
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
AS $function$
  WITH x AS (
    SELECT norm_text(coalesce(p_q,'')) AS q,
           greatest(10, least(40, coalesce(current_setting('app.search.rec_cap', true)::int, 25))) AS cap,
           coalesce(current_setting('app.search.dist_cutoff', true)::float, 0.86) AS dcut
  ),
  base AS (
    SELECT r.id::uuid AS id,
           (r.search_norm <-> x.q) AS d
    FROM records_poc.records r, x
    WHERE r.user_id = p_user
      AND r.search_norm % x.q
    ORDER BY d
    LIMIT (SELECT cap FROM x)
  )
  SELECT b.id, (1::real - b.d::real) AS rank
  FROM base b, x
  WHERE b.d <= x.dcut
  ORDER BY b.d
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c20_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '20'
 SET "pg_trgm.similarity_threshold" TO '0.30'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c20_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '20'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c20_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '20'
 SET "pg_trgm.similarity_threshold" TO '0.34'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c25_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.30'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c25_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET enable_partition_pruning TO 'on'
AS $function$
  SELECT * FROM public.search_records_fuzzy_ids_poc($1,$2,$3,$4,$5);
$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c25_s032_dyn(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
AS $function$
BEGIN
  RETURN QUERY EXECUTE format($f$
    WITH x AS (
      SELECT norm_text(%L) AS q,
             25            AS cap,
             0.86::float8  AS dcut
    ),
    base AS (
      SELECT r.id::uuid AS id,
             (r.search_norm <-> x.q) AS d
      FROM records_poc.records r, x
      WHERE r.user_id = %L::uuid
        AND r.search_norm %% x.q       -- escape trigram operator for format()
      ORDER BY d
      LIMIT (SELECT cap FROM x)
    )
    SELECT b.id, (1::real - b.d::real) AS rank
    FROM base b, x
    WHERE b.d <= x.dcut
    ORDER BY b.d
    LIMIT GREATEST(1, LEAST(1000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, p_user::text, p_limit, p_offset);
END$function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c25_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.34'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c30_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '30'
 SET "pg_trgm.similarity_threshold" TO '0.30'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c30_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '30'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_c30_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '30'
 SET "pg_trgm.similarity_threshold" TO '0.34'
 SET plan_cache_mode TO 'force_custom_plan'
AS $function$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $function$

CREATE OR REPLACE FUNCTION public.search_records_fuzzy_ids_poc_locked(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
  cap  int    := GREATEST(10, LEAST(40, COALESCE(current_setting('app.search.rec_cap', true)::int, 25)));
  dcut float8 := COALESCE(current_setting('app.search.dist_cutoff', true)::float, 0.86);
  sql  text;
BEGIN
  sql := format($f$
    WITH x AS (
      SELECT %L::text    AS q,
             %L::int     AS cap,
             %L::float8  AS dcut
    ),
    base AS (
      SELECT r.id::uuid AS id,
             (r.search_norm <-> x.q) AS d,
             x.dcut
      FROM records_poc.records r, x
      WHERE r.user_id = %L::uuid
        AND r.search_norm %% x.q
      ORDER BY d
      LIMIT (SELECT cap FROM x)
    )
    SELECT b.id, (1::real - b.d::real) AS rank
    FROM base b, x
    WHERE b.d <= x.dcut
    ORDER BY b.d
    LIMIT GREATEST(1, LEAST(1000, %L::int))
    OFFSET GREATEST(0, %L::int)
  $f$, p_q, cap, dcut, p_user, p_limit, p_offset);

  RETURN QUERY EXECUTE sql;
END$function$

CREATE OR REPLACE FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
AS $function$
  WITH x AS (SELECT norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id::uuid AS id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
    AND r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$function$

CREATE OR REPLACE FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032_kn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE sql
 STABLE
 SET "app.search.rec_cap" TO '25'
 SET "pg_trgm.similarity_threshold" TO '0.32'
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
AS $function$
  WITH x AS (SELECT norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id::uuid AS id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$function$

CREATE OR REPLACE FUNCTION public.search_records_super(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  sql text;
BEGIN
  /*
    Strategy:
    1) Build normalized text qn and tsquery qvec.
    2) Shortlist from MV by FTS if qvec has lexemes.
    3) UNION candidates from trigram on records + aliases (threshold tuned).
    4) Score: max(similarities, ts_rank), tie-break by <-> KNN distance.
    5) If result empty, auto-fallback to a looser trigram threshold.
  */
  sql := '
    WITH params AS (
      SELECT public.norm_text(coalesce($1, '''')) AS qn
    ),
    qts AS (
      -- tsquery from normalized text; websearch_to_tsquery handles quotes/phrases/operators
      SELECT websearch_to_tsquery(''simple'', p.qn) AS qvec, p.qn
      FROM params p
    ),

    -- 1) FTS shortlist from MV (very fast). Use only if qvec has any lexemes.
    fts AS (
      SELECT m.id
      FROM records.search_doc_mv m
      JOIN qts ON true
      WHERE m.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND qts.qvec <> ''''::tsquery
        AND m.sv @@ qts.qvec
      ORDER BY ts_rank_cd(m.sv, qts.qvec) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- 2) Trigram candidates from records (percent operator)
    trgm_rec AS (
      SELECT r.id
      FROM records.records r
      JOIN params p ON true
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND r.search_norm % p.qn
        AND similarity(r.search_norm, p.qn) >= 0.50  -- start at 0.50; auto-fallback below if empty
      ORDER BY similarity(r.search_norm, p.qn) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- 3) Trigram from aliases (maps to record_id)
    trgm_alias AS (
      SELECT a.record_id AS id
      FROM records.aliases_mv a
      JOIN params p ON true
      WHERE a.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND a.alias_norm % p.qn
        AND similarity(a.alias_norm, p.qn) >= 0.50
      ORDER BY similarity(a.alias_norm, p.qn) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- UNION all candidates (dedup)
    cand AS (
      SELECT id FROM fts
      UNION
      SELECT id FROM trgm_rec
      UNION
      SELECT id FROM trgm_alias
    ),

    -- Score candidates: combine trigram sims, alias sim, and ts_rank if available
    scored AS (
      SELECT r.id,
             GREATEST(
               similarity(r.search_norm, p.qn),
               similarity(r.artist_norm,  p.qn),
               similarity(r.name_norm,    p.qn),
               similarity(r.label_norm,   p.qn),
               similarity(r.catalog_norm, p.qn),
               COALESCE(al.alias_sim, 0)
             )                               AS sim,
             COALESCE(ts.ts_rank, 0)         AS ts_score,
             (r.search_norm <-> p.qn)        AS dist
      FROM cand c
      JOIN records.records r ON r.id = c.id
      JOIN params p          ON true
      LEFT JOIN LATERAL (
        SELECT MAX(similarity(a2.alias_norm, p.qn)) AS alias_sim
        FROM records.aliases_mv a2
        WHERE a2.user_id = r.user_id AND a2.record_id = r.id
      ) al ON true
      LEFT JOIN LATERAL (
        SELECT ts_rank_cd(m.sv, q.qvec) AS ts_rank
        FROM records.search_doc_mv m
        JOIN (SELECT * FROM qts) q ON true
        WHERE m.id = r.id AND m.user_id = r.user_id
      ) ts ON true
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
    ),

    ranked AS (
      SELECT id,
             -- blend FTS and trigram (weight FTS slightly if present)
             (0.6*sim + 0.4*ts_score)::real AS rank,
             dist
      FROM scored
    ),

    final AS (
      SELECT id, rank
      FROM ranked
      ORDER BY rank DESC, dist ASC
      LIMIT GREATEST(1, LEAST(1000, $2))
      OFFSET GREATEST(0, $3)
    )

    SELECT * FROM final
  ';

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;

  -- Fallback: if we returned nothing, loosen trigram gates (0.48)
  IF NOT FOUND THEN
    sql := replace(sql, '>= 0.50', '>= 0.48');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$function$

CREATE OR REPLACE FUNCTION public.search_records_super2(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false)
 RETURNS TABLE(id uuid, rank real)
 LANGUAGE plpgsql
 STABLE
 SET plan_cache_mode TO 'force_custom_plan'
 SET jit TO 'off'
 SET work_mem TO '64MB'
 SET random_page_cost TO '1.0'
AS $function$
DECLARE
  sql text;

  function_sql CONSTANT text := $q$
    WITH p AS (
      SELECT public.norm_text(coalesce($1,'')) AS qn
    ),
    latin AS (
      SELECT regexp_replace(p.qn, '[^[:alnum:][:space:]]+', ' ', 'g') AS latin_raw
      FROM p
    ),
    toks AS (
      SELECT array_remove(regexp_split_to_array(lower(l.latin_raw), '\s+'), '') AS arr
      FROM latin l
    ),
    toks2 AS (
      SELECT array(SELECT t FROM unnest(arr) t WHERE length(t) >= 2 LIMIT 8) AS arr
      FROM toks
    ),
    ts AS (
      SELECT CASE WHEN cardinality(arr) > 0
                  THEN to_tsquery('simple',
                         array_to_string(
                           (SELECT array_agg(t || ':*') FROM unnest(arr) t),
                           ' & '
                         ))
                  ELSE NULL::tsquery
             END AS qvec
      FROM toks2
    ),
    caps AS (
      SELECT LEAST(300, GREATEST(150, $2*10)) AS cap
    ),
    -- FTS + trigram prune on doc
    fts AS (
      SELECT m.id, ts_rank_cd(m.sv, ts.qvec) AS ts_rank
      FROM records.search_doc_mv m
      JOIN ts ON ts.qvec IS NOT NULL
      JOIN p  ON true
      JOIN caps c ON true
      WHERE m.user_id = $U$USER$U::uuid
        AND m.sv @@ ts.qvec
        AND m.doc % p.qn
        AND similarity(m.doc, p.qn) >= 0.30
      ORDER BY ts_rank DESC
      LIMIT (SELECT cap FROM caps)
    ),
    gate AS (
      SELECT set_limit(0.52) AS _
    ),
    rec_trgm AS (
      SELECT r.id, similarity(r.search_norm, p.qn) AS sim
      FROM records.records r, p, gate, caps
      WHERE r.user_id = $U$USER$U::uuid
        AND r.search_norm % p.qn
        AND similarity(r.search_norm, p.qn) >= 0.52
      ORDER BY sim DESC
      LIMIT (SELECT cap FROM caps)
    ),
    alias_hits AS (
      SELECT a.record_id AS id, similarity(a.alias_norm, p.qn) AS sim
      FROM records.aliases_mv a, p, gate, caps
      WHERE a.user_id = $U$USER$U::uuid
        AND a.alias_norm % p.qn
        AND similarity(a.alias_norm, p.qn) >= 0.52
      ORDER BY sim DESC
      LIMIT (SELECT cap FROM caps)
    ),
    alias_sim AS (
      SELECT id, MAX(sim) AS alias_sim
      FROM alias_hits
      GROUP BY id
    ),
    cand AS (
      SELECT id FROM fts
      UNION
      SELECT id FROM rec_trgm
      UNION
      SELECT id FROM alias_hits
    ),
    scored AS (
      SELECT r.id,
             GREATEST(
               similarity(r.search_norm, p.qn),
               similarity(r.artist_norm,  p.qn),
               similarity(r.name_norm,    p.qn),
               similarity(r.label_norm,   p.qn),
               similarity(r.catalog_norm, p.qn),
               COALESCE(a.alias_sim, 0)
             ) AS sim,
             COALESCE(f.ts_rank, 0) AS ts_rank,
             (r.search_norm <-> p.qn) AS dist
      FROM cand c
      JOIN records.records r ON r.id = c.id
      JOIN p ON true
      LEFT JOIN alias_sim a ON a.id = r.id
      LEFT JOIN fts f       ON f.id = r.id
      WHERE r.user_id = $U$USER$U::uuid
    ),
    ranked AS (
      SELECT id, (0.70*sim + 0.30*ts_rank)::real AS rank, dist
      FROM scored
    )
    SELECT id, rank
    FROM ranked
    ORDER BY rank DESC, dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;

BEGIN
  sql := replace(function_sql, '$U$USER$U', quote_literal(p_user));

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;

  IF NOT FOUND THEN
    sql := replace(sql, '>= 0.52', '>= 0.50');
    sql := replace(sql, 'set_limit(0.52)', 'set_limit(0.50)');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$function$

CREATE OR REPLACE FUNCTION public.set_limit(real)
 RETURNS real
 LANGUAGE c
 STRICT
AS '$libdir/pg_trgm', $function$set_limit$function$

CREATE OR REPLACE FUNCTION public.show_limit()
 RETURNS real
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$show_limit$function$

CREATE OR REPLACE FUNCTION public.show_trgm(text)
 RETURNS text[]
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$show_trgm$function$

CREATE OR REPLACE FUNCTION public.similarity(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$similarity$function$

CREATE OR REPLACE FUNCTION public.similarity_dist(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$similarity_dist$function$

CREATE OR REPLACE FUNCTION public.similarity_op(text, text)
 RETURNS boolean
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$similarity_op$function$

CREATE OR REPLACE FUNCTION public.split_part(citext, citext, integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT (pg_catalog.regexp_split_to_array( $1::pg_catalog.text, pg_catalog.regexp_replace($2::pg_catalog.text, '([^a-zA-Z_0-9])', E'\\\\\\1', 'g'), 'i'))[$3];
$function$

CREATE OR REPLACE FUNCTION public.strict_word_similarity(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$strict_word_similarity$function$

CREATE OR REPLACE FUNCTION public.strict_word_similarity_commutator_op(text, text)
 RETURNS boolean
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$strict_word_similarity_commutator_op$function$

CREATE OR REPLACE FUNCTION public.strict_word_similarity_dist_commutator_op(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$strict_word_similarity_dist_commutator_op$function$

CREATE OR REPLACE FUNCTION public.strict_word_similarity_dist_op(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$strict_word_similarity_dist_op$function$

CREATE OR REPLACE FUNCTION public.strict_word_similarity_op(text, text)
 RETURNS boolean
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$strict_word_similarity_op$function$

CREATE OR REPLACE FUNCTION public.strpos(citext, citext)
 RETURNS integer
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.strpos( pg_catalog.lower( $1::pg_catalog.text ), pg_catalog.lower( $2::pg_catalog.text ) );
$function$

CREATE OR REPLACE FUNCTION public.texticlike(citext, citext)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticlike$function$

CREATE OR REPLACE FUNCTION public.texticlike(citext, text)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticlike$function$

CREATE OR REPLACE FUNCTION public.texticnlike(citext, citext)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticnlike$function$

CREATE OR REPLACE FUNCTION public.texticnlike(citext, text)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticnlike$function$

CREATE OR REPLACE FUNCTION public.texticregexeq(citext, text)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticregexeq$function$

CREATE OR REPLACE FUNCTION public.texticregexeq(citext, citext)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticregexeq$function$

CREATE OR REPLACE FUNCTION public.texticregexne(citext, citext)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticregexne$function$

CREATE OR REPLACE FUNCTION public.texticregexne(citext, text)
 RETURNS boolean
 LANGUAGE internal
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$texticregexne$function$

CREATE OR REPLACE FUNCTION public.time_dist(time without time zone, time without time zone)
 RETURNS interval
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$time_dist$function$

CREATE OR REPLACE FUNCTION public.translate(citext, citext, text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
    SELECT pg_catalog.translate( pg_catalog.translate( $1::pg_catalog.text, pg_catalog.lower($2::pg_catalog.text), $3), pg_catalog.upper($2::pg_catalog.text), $3);
$function$

CREATE OR REPLACE FUNCTION public.ts_dist(timestamp without time zone, timestamp without time zone)
 RETURNS interval
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$ts_dist$function$

CREATE OR REPLACE FUNCTION public.tstz_dist(timestamp with time zone, timestamp with time zone)
 RETURNS interval
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/btree_gist', $function$tstz_dist$function$

CREATE OR REPLACE FUNCTION public.unaccent(text)
 RETURNS text
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/unaccent', $function$unaccent_dict$function$

CREATE OR REPLACE FUNCTION public.unaccent(regdictionary, text)
 RETURNS text
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/unaccent', $function$unaccent_dict$function$

CREATE OR REPLACE FUNCTION public.unaccent_init(internal)
 RETURNS internal
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/unaccent', $function$unaccent_init$function$

CREATE OR REPLACE FUNCTION public.unaccent_lexize(internal, internal, internal, internal)
 RETURNS internal
 LANGUAGE c
 PARALLEL SAFE
AS '$libdir/unaccent', $function$unaccent_lexize$function$

CREATE OR REPLACE FUNCTION public.word_similarity(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$word_similarity$function$

CREATE OR REPLACE FUNCTION public.word_similarity_commutator_op(text, text)
 RETURNS boolean
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$word_similarity_commutator_op$function$

CREATE OR REPLACE FUNCTION public.word_similarity_dist_commutator_op(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$word_similarity_dist_commutator_op$function$

CREATE OR REPLACE FUNCTION public.word_similarity_dist_op(text, text)
 RETURNS real
 LANGUAGE c
 IMMUTABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$word_similarity_dist_op$function$

CREATE OR REPLACE FUNCTION public.word_similarity_op(text, text)
 RETURNS boolean
 LANGUAGE c
 STABLE PARALLEL SAFE STRICT
AS '$libdir/pg_trgm', $function$word_similarity_op$function$

CREATE OR REPLACE FUNCTION records.make_search_norm(a text, n text, l text, c text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$
  SELECT public.norm_text(coalesce(a,'')||' '||coalesce(n,'')||' '||coalesce(l,'')||' '||coalesce(c,''));
$function$

CREATE OR REPLACE FUNCTION records.seed_aliases_for_user(p_user uuid)
 RETURNS bigint
 LANGUAGE plpgsql
AS $function$
DECLARE
  n bigint := 0;
BEGIN
  WITH tgt AS (
    SELECT id, artist_norm
    FROM records.records
    WHERE user_id = p_user
  )
  SELECT COALESCE(sum(records.upsert_aliases(
           id,
           CASE
             WHEN artist_norm LIKE '%teresa%'  OR artist_norm LIKE '%鄧麗君%' OR artist_norm LIKE '%邓丽君%' THEN ARRAY['Teresa Teng','鄧麗君','邓丽君','テレサ・テン']
             WHEN artist_norm LIKE '%anita%'   OR artist_norm LIKE '%梅艷芳%' OR artist_norm LIKE '%梅艳芳%' THEN ARRAY['Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ']
             WHEN artist_norm LIKE '%faye%'    OR artist_norm LIKE '%王菲%'                                  THEN ARRAY['Faye Wong','王菲','ワン・フェイ']
             WHEN artist_norm LIKE '%leslie%'  OR artist_norm LIKE '%張國榮%' OR artist_norm LIKE '%张国荣%' THEN ARRAY['Leslie Cheung','張國榮','张国荣','レスリー・チャン']
             ELSE ARRAY[]::text[]
           END
         )), 0)
    INTO n
  FROM tgt;
  RETURN n;
END
$function$

CREATE OR REPLACE FUNCTION records.seed_demo(p_user uuid, p_n integer)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
  i int;
  artists text[] := ARRAY[
    'Teresa Teng','鄧麗君','邓丽君','テレサ・テン',
    'Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ',
    'Faye Wong','王菲','ワン・フェイ',
    'Leslie Cheung','張國榮','张国荣','レスリー・チャン'
  ];
  formats text[] := ARRAY['LP','EP','12in','7in','CD'];
  labels  text[] := ARRAY['Polydor','PolyGram','Trio','CBS','Warner','EMI'];
  grades  text[] := ARRAY['NM','EX','VG+','VG'];
BEGIN
  INSERT INTO records.records(
    user_id, artist, name, format, catalog_number, notes,
    purchased_at, price_paid, record_grade, sleeve_grade,
    release_year, release_date, pressing_year, label, label_code
  )
  SELECT
    p_user,
    choice(artists) AS artist,
    'Album '||gs AS name,
    choice(formats) AS format,
    (choice(ARRAY['HK','TW','JP','CN','US'])||'-'||to_char((random()*999+1)::int,'FM000'))::text AS catalog_number,
    choice(ARRAY['','great','first press','promo']) AS notes,
    date '2018-01-01' + ((random()*((date '2024-12-31' - date '2018-01-01')))::int) AS purchased_at,
    round((random()*35+5)::numeric,2) AS price_paid,
    choice(grades) AS record_grade,
    choice(grades) AS sleeve_grade,
    (1970 + (random()*45)::int) AS release_year,
    (date '1970-01-01' + ((random()*18250)::int)) AS release_date,
    (1970 + (random()*45)::int) AS pressing_year,
    choice(labels) AS label,
    upper(substr(choice(labels),1,2)) || '-' || to_char((random()*999+1)::int,'FM000') AS label_code
  FROM generate_series(1,p_n) gs;

  -- make sure MV exists and populated
  PERFORM 1 FROM pg_matviews
    WHERE schemaname='records' AND matviewname='aliases_mv';
  IF FOUND THEN
    -- first run: non-concurrent is fine
    REFRESH MATERIALIZED VIEW records.aliases_mv;
  END IF;

  ANALYZE;
END
$function$

CREATE OR REPLACE FUNCTION records.set_norm_cols()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.artist_norm  := norm_text(NEW.artist);
  NEW.name_norm    := norm_text(NEW.name);
  NEW.label_norm   := norm_text(NEW.label);
  NEW.catalog_norm := norm_text(NEW.catalog_number);
  NEW.search_norm  := btrim(concat_ws(' ', NEW.artist_norm, NEW.name_norm,
                                      coalesce(NEW.catalog_norm,''), coalesce(NEW.label_norm,'')));
  RETURN NEW;
END
$function$

CREATE OR REPLACE FUNCTION records.touch_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END
$function$

CREATE OR REPLACE FUNCTION records.upsert_alias(p_record uuid, p_alias text)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
BEGIN
  IF p_alias IS NULL OR btrim(p_alias) = '' THEN
    RETURN;
  END IF;
  INSERT INTO records.aliases(record_id, alias)
  VALUES (p_record, btrim(p_alias))
  ON CONFLICT DO NOTHING;
END
$function$

CREATE OR REPLACE FUNCTION records.upsert_aliases(p_record uuid, p_terms text[])
 RETURNS bigint
 LANGUAGE plpgsql
AS $function$
DECLARE
  t text;
  n bigint := 0;
BEGIN
  IF p_terms IS NULL THEN RETURN 0; END IF;
  FOREACH t IN ARRAY p_terms LOOP
    BEGIN
      INSERT INTO records.aliases(record_id, alias)
      VALUES (p_record, btrim(t))
      ON CONFLICT DO NOTHING;
      IF FOUND THEN n := n + 1; END IF;
    EXCEPTION WHEN unique_violation THEN
      NULL;
    END;
  END LOOP;
  RETURN n;
END
$function$

CREATE OR REPLACE FUNCTION records_hot.sync_hot()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM records_hot.records_hot WHERE id = OLD.id;
    RETURN NULL;
  END IF;

  IF EXISTS (SELECT 1 FROM records_hot.config c WHERE c.user_id = COALESCE(NEW.user_id, OLD.user_id)) THEN
    INSERT INTO records_hot.records_hot(id, user_id, search_norm)
    VALUES (NEW.id, NEW.user_id, NEW.search_norm)
    ON CONFLICT (id) DO UPDATE
      SET user_id = EXCLUDED.user_id,
          search_norm = EXCLUDED.search_norm;
  END IF;
  RETURN NULL;
END$function$

(456 rows)
