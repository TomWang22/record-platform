--
-- PostgreSQL database cluster dump
--

\restrict YqGBWiG8uIsUmgjXvpjgamT4oY5FMMu3DELSQmfq0c6aVK69AYq0ggEd6c2B2J9

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:OMWvN1Y37wn9/AUM355trA==$RV1l8rnpoNtrIf1bChUKuIJ9miSgXXHRttthkr6qoaE=:NasuKiYBKmom26BgP3atqKhLSv1Tls4AOtfSSCKqh2g=';
CREATE ROLE record_app;
ALTER ROLE record_app WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:YBM7UjEgVvNvtkOyRCWhRA==$ddwDqraHBLAwXbdA+PmOjndrJdgjDPpDYhNRiechV8w=:29YCiTaX5+YmduSUYpIPMwyVw6DDs4wXkuHFu54lsTg=';
CREATE ROLE record_owner;
ALTER ROLE record_owner WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB NOLOGIN NOREPLICATION NOBYPASSRLS;

--
-- User Configurations
--








\unrestrict YqGBWiG8uIsUmgjXvpjgamT4oY5FMMu3DELSQmfq0c6aVK69AYq0ggEd6c2B2J9

--
-- PostgreSQL database cluster dump complete
--

