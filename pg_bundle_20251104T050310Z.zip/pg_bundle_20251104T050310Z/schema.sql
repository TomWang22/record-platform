--
-- PostgreSQL database dump
--

\restrict wUQgmvGfG6pnmGCq9rcd3exXeogbGoughXpdNxJHTsgouFPaXZpedoekLsqgr7h

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: record_owner
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO record_owner;

--
-- Name: bench; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA bench;


ALTER SCHEMA bench OWNER TO postgres;

--
-- Name: records; Type: SCHEMA; Schema: -; Owner: record_owner
--

CREATE SCHEMA records;


ALTER SCHEMA records OWNER TO record_owner;

--
-- Name: records_hot; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA records_hot;


ALTER SCHEMA records_hot OWNER TO postgres;

--
-- Name: records_poc; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA records_poc;


ALTER SCHEMA records_poc OWNER TO postgres;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_buffercache; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_buffercache WITH SCHEMA public;


--
-- Name: EXTENSION pg_buffercache; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_buffercache IS 'examine the shared buffer cache';


--
-- Name: pg_prewarm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_prewarm WITH SCHEMA public;


--
-- Name: EXTENSION pg_prewarm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_prewarm IS 'prewarm relation data';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pg_visibility; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_visibility WITH SCHEMA public;


--
-- Name: EXTENSION pg_visibility; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_visibility IS 'examine the visibility map (VM) and page-level visibility info';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: _hot_user(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public._hot_user() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$ SELECT id FROM auth.users ORDER BY email NULLS LAST, id LIMIT 1 $$;


ALTER FUNCTION public._hot_user() OWNER TO postgres;

--
-- Name: choice(anyarray); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.choice(anyarray) RETURNS anyelement
    LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
    AS $_$
  SELECT $1[1 + floor(random()*array_length($1,1))::int]
$_$;


ALTER FUNCTION public.choice(anyarray) OWNER TO postgres;

--
-- Name: norm_text(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.norm_text(t text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  SELECT regexp_replace(lower(unaccent(coalesce(t,''))), '\s+', ' ', 'g')
$$;


ALTER FUNCTION public.norm_text(t text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: records; Type: TABLE; Schema: records; Owner: record_owner
--

CREATE TABLE records.records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    artist text NOT NULL,
    name text NOT NULL,
    format text NOT NULL,
    catalog_number text,
    record_grade text,
    sleeve_grade text,
    has_insert boolean DEFAULT false,
    has_booklet boolean DEFAULT false,
    has_obi_strip boolean DEFAULT false,
    has_factory_sleeve boolean DEFAULT false,
    is_promo boolean DEFAULT false,
    notes text,
    purchased_at date,
    price_paid numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    insert_grade text,
    booklet_grade text,
    obi_strip_grade text,
    factory_sleeve_grade text,
    release_year integer,
    release_date date,
    pressing_year integer,
    label text,
    label_code text,
    artist_norm text,
    name_norm text,
    label_norm text,
    catalog_norm text,
    search_norm text
)
WITH (autovacuum_vacuum_scale_factor='0.01', autovacuum_vacuum_threshold='1000', autovacuum_analyze_scale_factor='0.005', autovacuum_analyze_threshold='1000', autovacuum_vacuum_cost_limit='2000', autovacuum_vacuum_cost_delay='2', toast.autovacuum_vacuum_scale_factor='0.01', toast.autovacuum_vacuum_threshold='1000', toast.autovacuum_vacuum_cost_limit='2000', toast.autovacuum_vacuum_cost_delay='2');


ALTER TABLE records.records OWNER TO record_owner;

--
-- Name: records_recent(uuid, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.records_recent(p_user uuid, p_limit integer DEFAULT 50) RETURNS SETOF records.records
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  SELECT *
  FROM records.records
  WHERE user_id = p_user
  ORDER BY updated_at DESC
  LIMIT GREATEST(1, LEAST(200, COALESCE(p_limit,50)));
$$;


ALTER FUNCTION public.records_recent(p_user uuid, p_limit integer) OWNER TO postgres;

--
-- Name: search_autocomplete(uuid, text, integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer DEFAULT 10, p_field text DEFAULT 'artist'::text) RETURNS TABLE(term text, hits integer, dist real)
    LANGUAGE sql STABLE PARALLEL SAFE
    AS $$
  WITH p AS (
    SELECT norm_text(COALESCE(p_q,'')) AS qn,
           CASE WHEN p_field IN ('label','catalog') THEN p_field ELSE 'artist' END AS fld
  ),
  base AS (
    SELECT CASE
             WHEN (SELECT fld FROM p)='label'   THEN r.label
             WHEN (SELECT fld FROM p)='catalog' THEN r.catalog_number
             ELSE r.artist
           END AS term_raw,
           CASE
             WHEN (SELECT fld FROM p)='label'   THEN r.label_norm
             WHEN (SELECT fld FROM p)='catalog' THEN r.catalog_norm
             ELSE r.artist_norm
           END AS term_norm
    FROM records.records r
    WHERE r.user_id = p_user
  ),
  alias AS (
    SELECT NULL::text AS term_raw, a.alias_norm AS term_norm
    FROM records.aliases_mv a
    JOIN records.records r ON r.id = a.record_id
    WHERE r.user_id = p_user
  ),
  unioned AS (SELECT * FROM base UNION ALL SELECT * FROM alias)
  SELECT COALESCE(term_raw, term_norm) AS term,
         COUNT(*)::int AS hits,
         MIN(similarity(term_norm, (SELECT qn FROM p))) AS dist
  FROM unioned
  WHERE term_norm IS NOT NULL AND term_norm <> ''
    AND (
      (length((SELECT qn FROM p)) <= 2 AND term_norm LIKE (SELECT qn FROM p) || '%') OR
      (length((SELECT qn FROM p)) >  2 AND term_norm %   (SELECT qn FROM p))
    )
  GROUP BY 1
  ORDER BY dist DESC, hits DESC
  LIMIT LEAST(50, GREATEST(1, p_k));
$$;


ALTER FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text) OWNER TO postgres;

--
-- Name: search_facets(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_facets(p_user uuid, p_q text) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE qn TEXT := norm_text(p_q);
BEGIN
  RETURN jsonb_build_object(
    'format', (
      SELECT jsonb_agg(jsonb_build_object('format',format,'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT format, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user
          AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.search_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    ),
    'label', (
      SELECT jsonb_agg(jsonb_build_object('label',label,'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT label, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user AND label IS NOT NULL AND label<>''
          AND ((length(qn)<=2 AND r.label_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.label_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    ),
    'year', (
      SELECT jsonb_agg(
               jsonb_build_object('bucket',
                 CASE
                   WHEN release_year BETWEEN 1970 AND 1979 THEN '70s'
                   WHEN release_year BETWEEN 1980 AND 1989 THEN '80s'
                   WHEN release_year BETWEEN 1990 AND 1999 THEN '90s'
                   WHEN release_year BETWEEN 2000 AND 2009 THEN '00s'
                   WHEN release_year BETWEEN 2010 AND 2019 THEN '10s'
                   WHEN release_year BETWEEN 2020 AND 2029 THEN '20s'
                   ELSE 'unknown'
                 END,
                 'count',cnt) ORDER BY cnt DESC)
      FROM (
        SELECT release_year, COUNT(*) AS cnt
        FROM records.records r
        WHERE r.user_id=p_user AND release_year IS NOT NULL
          AND ((length(qn)<=2 AND r.search_norm LIKE qn||'%')
            OR (length(qn)>2  AND r.search_norm % qn))
        GROUP BY 1 ORDER BY 2 DESC LIMIT 20
      ) t
    )
  );
END;
$$;


ALTER FUNCTION public.search_facets(p_user uuid, p_q text) OWNER TO postgres;

--
-- Name: search_hot_c25_s032(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.20'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET random_page_cost TO '1.1'
    SET enable_seqscan TO 'on'
    AS $_$
DECLARE u   uuid := public._hot_user();
DECLARE sql text;
BEGIN
  sql := format($f$
    WITH x AS (SELECT public.norm_text(coalesce(%L,'')) AS q)
    SELECT r.id,
           (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = %L::uuid
      AND r.search_norm %% x.q
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(2000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, u::text, p_limit, p_offset);
  RETURN QUERY EXECUTE sql;
END$_$;


ALTER FUNCTION public.search_hot_c25_s032(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_c25_s032_knn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET random_page_cost TO '1.1'
    AS $_$
DECLARE u   uuid := public._hot_user();
DECLARE sql text;
BEGIN
  sql := format($f$
    WITH x AS (SELECT public.norm_text(coalesce(%L,'')) AS q)
    SELECT r.id,
           (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = %L::uuid
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(2000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, u::text, p_limit, p_offset);
  RETURN QUERY EXECUTE sql;
END$_$;


ALTER FUNCTION public.search_hot_c25_s032_knn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_hot_percent_then_knn_adapt(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET enable_seqscan TO 'off'
    SET enable_bitmapscan TO 'on'
    SET random_page_cost TO '1.0'
    SET work_mem TO '64MB'
    AS $_$
DECLARE
  gates numeric[] := ARRAY[0.60,0.58,0.56,0.54,0.52,0.50,0.48,0.46];
  gate  numeric;
  sql   text;
  body  text := $q$
    WITH x AS (
      SELECT set_limit($GATE$) AS _ , public.norm_text(coalesce($1,'')) AS q
    ),
    cand AS (
      SELECT h.id, (h.search_norm <-> x.q) AS dist
      FROM records_hot.records_hot h, x
      WHERE h.user_id = $USER$::uuid
        AND h.search_norm % x.q
        AND similarity(h.search_norm, x.q) >= $GATE$
      ORDER BY 1 ASC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;
BEGIN
  FOREACH gate IN ARRAY gates LOOP
    sql := replace(body, '$USER$', quote_literal(p_user));
    sql := replace(sql, '$GATE$', to_char(gate,'FM0.00'));
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
    IF FOUND THEN RETURN; END IF;
  END LOOP;

  -- Final fallback: your existing pure KNN wrapper (hot heap)
  RETURN QUERY
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT h.id, (1::real - (h.search_norm <-> x.q)::real) AS rank
  FROM records_hot.records_hot h, x
  WHERE h.user_id = p_user
  ORDER BY h.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
END
$_$;


ALTER FUNCTION public.search_hot_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_knn_only(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_knn_only(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET enable_seqscan TO 'off'
    SET enable_bitmapscan TO 'off'
    SET jit TO 'off'
    SET random_page_cost TO '1.0'
    AS $$
DECLARE
  use_hot boolean;
BEGIN
  use_hot := (to_regclass('records_hot.records_hot') IS NOT NULL)
             AND EXISTS (SELECT 1 FROM records_hot.records_hot WHERE user_id = p_user LIMIT 1);

  IF use_hot THEN
    RETURN QUERY
    WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
    SELECT h.id, (1::real - (h.search_norm <-> x.q)::real) AS rank
    FROM records_hot.records_hot h, x
    WHERE h.user_id = p_user
    ORDER BY h.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(1000, p_limit))
    OFFSET GREATEST(0, p_offset);
  ELSE
    RETURN QUERY
    WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
    SELECT r.id, (1::real - (r.search_norm <-> x.q)::real) AS rank
    FROM records.records r, x
    WHERE r.user_id = p_user
    ORDER BY r.search_norm <-> x.q
    LIMIT GREATEST(1, LEAST(1000, p_limit))
    OFFSET GREATEST(0, p_offset);
  END IF;
END
$$;


ALTER FUNCTION public.search_hot_knn_only(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s032(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET random_page_cost TO '1.1'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
    AND r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s032(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s032_fast(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s032_fast(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, similarity(r.search_norm, x.q) AS sim
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid     -- tenant-pinned
      AND r.search_norm % x.q                  -- hits GIN
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(100, p_limit*20))  -- shortlist ~20× limit
  )
  SELECT id, sim::real AS rank
  FROM cand
  ORDER BY sim DESC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s032_fast(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s032_gin_then_knn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s032_gin_then_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id,
           similarity(r.search_norm, x.q) AS sim,
           (r.search_norm <-> x.q)        AS dist
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(100, p_limit*20))
  )
  SELECT id, (1::real - dist::real) AS rank
  FROM cand
  ORDER BY dist ASC                  -- KNN tie-break over shortlist
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s032_gin_then_knn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s032_knn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET random_page_cost TO '1.1'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s032_knn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s036_fast(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s036_fast(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.36'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, similarity(r.search_norm, x.q) AS sim
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY sim DESC
    LIMIT LEAST(1000, GREATEST(300, p_limit*12))
  )
  SELECT id, sim::real AS rank
  FROM cand
  ORDER BY sim DESC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s036_fast(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_main_c25_s036_gin_then_knn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_main_c25_s036_gin_then_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.36'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q),
  cand AS (
    SELECT r.id, (r.search_norm <-> x.q) AS dist
    FROM records.records r, x
    WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
      AND r.search_norm % x.q
    ORDER BY 1 ASC
    LIMIT LEAST(1000, GREATEST(300, p_limit*12))
  )
  SELECT id, (1::real - dist::real) AS rank
  FROM cand
  ORDER BY dist ASC
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_main_c25_s036_gin_then_knn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_percent_then_knn(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_percent_then_knn(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET enable_seqscan TO 'off'
    SET enable_bitmapscan TO 'off'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $_$
DECLARE
  sql text;
BEGIN
  sql := $q$
    WITH x AS (SELECT public.norm_text(coalesce($1,'')) AS q),
    cand AS (
      SELECT r.id, (r.search_norm <-> x.q) AS dist
      FROM records.records r, x
      WHERE r.user_id = $USER_LIT$
        AND r.search_norm % x.q
      ORDER BY 1 ASC
      LIMIT LEAST(1000, GREATEST(300, $2*12))
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;

  sql := replace(sql, '$USER_LIT$', quote_literal(p_user) || '::uuid');

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
END
$_$;


ALTER FUNCTION public.search_hot_percent_then_knn(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_percent_then_knn_adapt(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET enable_seqscan TO 'off'
    SET enable_bitmapscan TO 'off'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $_$
DECLARE
  gates real[] := ARRAY[0.60, 0.58, 0.56, 0.54, 0.52];
  gate  real;
  cap   int := 400;   -- cap shortlist
  base  int := 10;    -- shortlist ≈ base×limit
  tname text;
  use_hot boolean;
  sql   text;
BEGIN
  use_hot := (to_regclass('records_hot.records_hot') IS NOT NULL)
             AND EXISTS (SELECT 1 FROM records_hot.records_hot WHERE user_id = p_user LIMIT 1);
  tname := CASE WHEN use_hot THEN 'records_hot.records_hot' ELSE 'records.records' END;

  FOREACH gate IN ARRAY gates LOOP
    sql := 'WITH x AS (
              SELECT set_limit($4) AS _, public.norm_text(coalesce($1, '''')) AS q
            ),
            cand AS (
              SELECT h.id, (h.search_norm <-> x.q) AS dist
              FROM '||tname||' h, x
              WHERE h.user_id = $5
                AND h.search_norm % x.q
                AND similarity(h.search_norm, x.q) >= $4
              ORDER BY 1 ASC
              LIMIT LEAST($6, GREATEST(200, $2*$7))
            )
            SELECT id, (1::real - dist::real) AS rank
            FROM cand
            ORDER BY dist ASC
            LIMIT GREATEST(1, LEAST(1000, $2))
            OFFSET GREATEST(0, $3)';

    RETURN QUERY EXECUTE sql USING
      p_q,           -- $1
      p_limit,       -- $2
      p_offset,      -- $3
      gate,          -- $4 (set_limit & similarity gate)
      p_user,        -- $5
      cap,           -- $6
      base;          -- $7

    IF FOUND THEN
      RETURN;
    END IF;
  END LOOP;

  -- last resort
  RETURN QUERY SELECT * FROM public.search_hot_knn_only(p_user, p_q, p_limit, p_offset, p_strict);
END
$_$;


ALTER FUNCTION public.search_hot_percent_then_knn_adapt(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_percent_then_knn_safe(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_percent_then_knn_safe(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $_$
DECLARE
  sql text;
  rows int;
BEGIN
  -- 1st pass: tighter shortlist
  sql := '
    WITH x AS (
      SELECT set_limit(0.52) AS _, public.norm_text(coalesce($1, '''')) AS q
    ),
    cand AS (
      SELECT r.id, (r.search_norm <-> x.q) AS dist
      FROM records.records r, x
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND r.search_norm % x.q
        AND similarity(r.search_norm, x.q) >= 0.52
      ORDER BY dist ASC
      LIMIT 400
    )
    SELECT id, (1::real - dist::real) AS rank
    FROM cand
    ORDER BY dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  ';
  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  GET DIAGNOSTICS rows = ROW_COUNT;

  IF rows = 0 THEN
    -- Fallback: slightly looser
    sql := replace(sql, '0.52', '0.50');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$_$;


ALTER FUNCTION public.search_hot_percent_then_knn_safe(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_poc_c25_s032(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_poc_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_poc_c25_s032(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_hot_poc_c25_s032_knn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_hot_poc_c25_s032_knn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    AS $$
  WITH x AS (SELECT public.norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset)
$$;


ALTER FUNCTION public.search_hot_poc_c25_s032_knn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    AS $$
  SELECT * FROM public.search_records_fuzzy_ids_core(p_user, p_q, p_limit::bigint, p_offset::bigint)
$$;


ALTER FUNCTION public.search_records_fuzzy_ids(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_core(uuid, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_core(p_user uuid, p_q text, p_limit bigint, p_offset bigint) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    AS $$
  WITH q AS (
    -- set_limit() both sets pg_trgm’s threshold and returns a real so we can SELECT it
    SELECT public.norm_text(p_q) AS qn,
           set_limit(0.25)       AS lim
  ),

  -- Candidates from records fields (looser threshold to widen recall)
  cand_from_records AS (
    SELECT r.id
    FROM records.records r, q
    WHERE r.user_id = p_user
      AND (
           similarity(r.search_norm, q.qn) >= 0.10
        OR similarity(r.artist_norm,  q.qn) >= 0.10
        OR similarity(r.name_norm,    q.qn) >= 0.10
        OR similarity(r.label_norm,   q.qn) >= 0.10
        OR similarity(r.catalog_norm, q.qn) >= 0.10
      )
  ),

  -- Candidates from aliases_mv (catch non-Latin variants)
  cand_from_aliases AS (
    SELECT a.record_id AS id
    FROM records.aliases_mv a, q
    WHERE a.user_id = p_user
      AND similarity(a.alias_norm, q.qn) >= 0.20
  ),

  cand AS (
    SELECT id FROM cand_from_records
    UNION
    SELECT id FROM cand_from_aliases
  ),

  scored AS (
    SELECT r.id,
           GREATEST(
             similarity(r.search_norm, q.qn),
             similarity(r.artist_norm,  q.qn),
             similarity(r.name_norm,    q.qn),
             similarity(r.label_norm,   q.qn),
             similarity(r.catalog_norm, q.qn),
             COALESCE(al.alias_sim, 0)
           )::real AS rank,
           r.search_norm <-> q.qn AS dist
    FROM cand c
    JOIN records.records r ON r.id = c.id
    CROSS JOIN q
    -- best alias match per record (if any)
    LEFT JOIN LATERAL (
      SELECT similarity(a2.alias_norm, q.qn) AS alias_sim
      FROM records.aliases_mv a2
      WHERE a2.user_id = p_user
        AND a2.record_id = r.id
      ORDER BY a2.alias_norm <-> q.qn
      LIMIT 1
    ) al ON true
  )

  SELECT id, rank
  FROM scored
  ORDER BY dist
  LIMIT p_limit OFFSET p_offset
$$;


ALTER FUNCTION public.search_records_fuzzy_ids_core(p_user uuid, p_q text, p_limit bigint, p_offset bigint) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_knn_bias(uuid, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_knn_bias(p_user uuid, p_q text, p_limit bigint, p_offset bigint) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    AS $$
  SELECT * FROM public.search_records_fuzzy_ids_core(p_user, p_q, p_limit, p_offset)
$$;


ALTER FUNCTION public.search_records_fuzzy_ids_knn_bias(p_user uuid, p_q text, p_limit bigint, p_offset bigint) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    AS $$
  WITH x AS (
    SELECT norm_text(coalesce(p_q,'')) AS q,
           greatest(10, least(40, coalesce(current_setting('app.search.rec_cap', true)::int, 25))) AS cap,
           coalesce(current_setting('app.search.dist_cutoff', true)::float, 0.86) AS dcut
  ),
  base AS (
    SELECT r.id::uuid AS id,
           (r.search_norm <-> x.q) AS d
    FROM records_poc.records r, x
    WHERE r.user_id = p_user
      AND r.search_norm % x.q
    ORDER BY d
    LIMIT (SELECT cap FROM x)
  )
  SELECT b.id, (1::real - b.d::real) AS rank
  FROM base b, x
  WHERE b.d <= x.dcut
  ORDER BY b.d
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c20_s030(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c20_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '20'
    SET "pg_trgm.similarity_threshold" TO '0.30'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c20_s030(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c20_s032(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c20_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '20'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c20_s032(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c20_s034(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c20_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '20'
    SET "pg_trgm.similarity_threshold" TO '0.34'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c20_s034(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c25_s030(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c25_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.30'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c25_s030(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c25_s032(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c25_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET enable_partition_pruning TO 'on'
    AS $_$
  SELECT * FROM public.search_records_fuzzy_ids_poc($1,$2,$3,$4,$5);
$_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c25_s032(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c25_s032_dyn(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c25_s032_dyn(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    AS $_$
BEGIN
  RETURN QUERY EXECUTE format($f$
    WITH x AS (
      SELECT norm_text(%L) AS q,
             25            AS cap,
             0.86::float8  AS dcut
    ),
    base AS (
      SELECT r.id::uuid AS id,
             (r.search_norm <-> x.q) AS d
      FROM records_poc.records r, x
      WHERE r.user_id = %L::uuid
        AND r.search_norm %% x.q       -- escape trigram operator for format()
      ORDER BY d
      LIMIT (SELECT cap FROM x)
    )
    SELECT b.id, (1::real - b.d::real) AS rank
    FROM base b, x
    WHERE b.d <= x.dcut
    ORDER BY b.d
    LIMIT GREATEST(1, LEAST(1000, %s))
    OFFSET GREATEST(0, %s)
  $f$, p_q, p_user::text, p_limit, p_offset);
END$_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c25_s032_dyn(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c25_s034(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c25_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.34'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c25_s034(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c30_s030(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c30_s030(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '30'
    SET "pg_trgm.similarity_threshold" TO '0.30'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c30_s030(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c30_s032(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c30_s032(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '30'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c30_s032(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_c30_s034(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_c30_s034(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '30'
    SET "pg_trgm.similarity_threshold" TO '0.34'
    SET plan_cache_mode TO 'force_custom_plan'
    AS $_$
          SELECT * FROM public.search_records_fuzzy_ids_poc_locked($1,$2,$3,$4,$5);
        $_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_c30_s034(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_fuzzy_ids_poc_locked(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_fuzzy_ids_poc_locked(p_user uuid, p_q text, p_limit integer DEFAULT 100, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
  cap  int    := GREATEST(10, LEAST(40, COALESCE(current_setting('app.search.rec_cap', true)::int, 25)));
  dcut float8 := COALESCE(current_setting('app.search.dist_cutoff', true)::float, 0.86);
  sql  text;
BEGIN
  sql := format($f$
    WITH x AS (
      SELECT %L::text    AS q,
             %L::int     AS cap,
             %L::float8  AS dcut
    ),
    base AS (
      SELECT r.id::uuid AS id,
             (r.search_norm <-> x.q) AS d,
             x.dcut
      FROM records_poc.records r, x
      WHERE r.user_id = %L::uuid
        AND r.search_norm %% x.q
      ORDER BY d
      LIMIT (SELECT cap FROM x)
    )
    SELECT b.id, (1::real - b.d::real) AS rank
    FROM base b, x
    WHERE b.d <= x.dcut
    ORDER BY b.d
    LIMIT GREATEST(1, LEAST(1000, %L::int))
    OFFSET GREATEST(0, %L::int)
  $f$, p_q, cap, dcut, p_user, p_limit, p_offset);

  RETURN QUERY EXECUTE sql;
END$_$;


ALTER FUNCTION public.search_records_fuzzy_ids_poc_locked(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    AS $$
  WITH x AS (SELECT norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id::uuid AS id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
    AND r.search_norm % x.q
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$$;


ALTER FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032_kn(text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032_kn(p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE sql STABLE
    SET "app.search.rec_cap" TO '25'
    SET "pg_trgm.similarity_threshold" TO '0.32'
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    AS $$
  WITH x AS (SELECT norm_text(coalesce(p_q,'')) AS q)
  SELECT r.id::uuid AS id,
         (1::real - (r.search_norm <-> x.q)::real) AS rank
  FROM records_poc.records r, x
  WHERE r.user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid
  ORDER BY r.search_norm <-> x.q
  LIMIT GREATEST(1, LEAST(1000, p_limit))
  OFFSET GREATEST(0, p_offset);
$$;


ALTER FUNCTION public.search_records_hot_0dc268d0a86f4e128d109db0f1b735e0_c25_s032_kn(p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_super(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_super(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $_$
DECLARE
  sql text;
BEGIN
  /*
    Strategy:
    1) Build normalized text qn and tsquery qvec.
    2) Shortlist from MV by FTS if qvec has lexemes.
    3) UNION candidates from trigram on records + aliases (threshold tuned).
    4) Score: max(similarities, ts_rank), tie-break by <-> KNN distance.
    5) If result empty, auto-fallback to a looser trigram threshold.
  */
  sql := '
    WITH params AS (
      SELECT public.norm_text(coalesce($1, '''')) AS qn
    ),
    qts AS (
      -- tsquery from normalized text; websearch_to_tsquery handles quotes/phrases/operators
      SELECT websearch_to_tsquery(''simple'', p.qn) AS qvec, p.qn
      FROM params p
    ),

    -- 1) FTS shortlist from MV (very fast). Use only if qvec has any lexemes.
    fts AS (
      SELECT m.id
      FROM records.search_doc_mv m
      JOIN qts ON true
      WHERE m.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND qts.qvec <> ''''::tsquery
        AND m.sv @@ qts.qvec
      ORDER BY ts_rank_cd(m.sv, qts.qvec) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- 2) Trigram candidates from records (percent operator)
    trgm_rec AS (
      SELECT r.id
      FROM records.records r
      JOIN params p ON true
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND r.search_norm % p.qn
        AND similarity(r.search_norm, p.qn) >= 0.50  -- start at 0.50; auto-fallback below if empty
      ORDER BY similarity(r.search_norm, p.qn) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- 3) Trigram from aliases (maps to record_id)
    trgm_alias AS (
      SELECT a.record_id AS id
      FROM records.aliases_mv a
      JOIN params p ON true
      WHERE a.user_id = ' || quote_literal(p_user)::text || '::uuid
        AND a.alias_norm % p.qn
        AND similarity(a.alias_norm, p.qn) >= 0.50
      ORDER BY similarity(a.alias_norm, p.qn) DESC
      LIMIT LEAST(600, GREATEST(200, $2*12))
    ),

    -- UNION all candidates (dedup)
    cand AS (
      SELECT id FROM fts
      UNION
      SELECT id FROM trgm_rec
      UNION
      SELECT id FROM trgm_alias
    ),

    -- Score candidates: combine trigram sims, alias sim, and ts_rank if available
    scored AS (
      SELECT r.id,
             GREATEST(
               similarity(r.search_norm, p.qn),
               similarity(r.artist_norm,  p.qn),
               similarity(r.name_norm,    p.qn),
               similarity(r.label_norm,   p.qn),
               similarity(r.catalog_norm, p.qn),
               COALESCE(al.alias_sim, 0)
             )                               AS sim,
             COALESCE(ts.ts_rank, 0)         AS ts_score,
             (r.search_norm <-> p.qn)        AS dist
      FROM cand c
      JOIN records.records r ON r.id = c.id
      JOIN params p          ON true
      LEFT JOIN LATERAL (
        SELECT MAX(similarity(a2.alias_norm, p.qn)) AS alias_sim
        FROM records.aliases_mv a2
        WHERE a2.user_id = r.user_id AND a2.record_id = r.id
      ) al ON true
      LEFT JOIN LATERAL (
        SELECT ts_rank_cd(m.sv, q.qvec) AS ts_rank
        FROM records.search_doc_mv m
        JOIN (SELECT * FROM qts) q ON true
        WHERE m.id = r.id AND m.user_id = r.user_id
      ) ts ON true
      WHERE r.user_id = ' || quote_literal(p_user)::text || '::uuid
    ),

    ranked AS (
      SELECT id,
             -- blend FTS and trigram (weight FTS slightly if present)
             (0.6*sim + 0.4*ts_score)::real AS rank,
             dist
      FROM scored
    ),

    final AS (
      SELECT id, rank
      FROM ranked
      ORDER BY rank DESC, dist ASC
      LIMIT GREATEST(1, LEAST(1000, $2))
      OFFSET GREATEST(0, $3)
    )

    SELECT * FROM final
  ';

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;

  -- Fallback: if we returned nothing, loosen trigram gates (0.48)
  IF NOT FOUND THEN
    sql := replace(sql, '>= 0.50', '>= 0.48');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$_$;


ALTER FUNCTION public.search_records_super(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: search_records_super2(uuid, text, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_records_super2(p_user uuid, p_q text, p_limit integer DEFAULT 50, p_offset integer DEFAULT 0, p_strict boolean DEFAULT false) RETURNS TABLE(id uuid, rank real)
    LANGUAGE plpgsql STABLE
    SET plan_cache_mode TO 'force_custom_plan'
    SET jit TO 'off'
    SET work_mem TO '64MB'
    SET random_page_cost TO '1.0'
    AS $_$
DECLARE
  sql text;

  function_sql CONSTANT text := $q$
    WITH p AS (
      SELECT public.norm_text(coalesce($1,'')) AS qn
    ),
    latin AS (
      SELECT regexp_replace(p.qn, '[^[:alnum:][:space:]]+', ' ', 'g') AS latin_raw
      FROM p
    ),
    toks AS (
      SELECT array_remove(regexp_split_to_array(lower(l.latin_raw), '\s+'), '') AS arr
      FROM latin l
    ),
    toks2 AS (
      SELECT array(SELECT t FROM unnest(arr) t WHERE length(t) >= 2 LIMIT 8) AS arr
      FROM toks
    ),
    ts AS (
      SELECT CASE WHEN cardinality(arr) > 0
                  THEN to_tsquery('simple',
                         array_to_string(
                           (SELECT array_agg(t || ':*') FROM unnest(arr) t),
                           ' & '
                         ))
                  ELSE NULL::tsquery
             END AS qvec
      FROM toks2
    ),
    caps AS (
      SELECT LEAST(300, GREATEST(150, $2*10)) AS cap
    ),
    -- FTS + trigram prune on doc
    fts AS (
      SELECT m.id, ts_rank_cd(m.sv, ts.qvec) AS ts_rank
      FROM records.search_doc_mv m
      JOIN ts ON ts.qvec IS NOT NULL
      JOIN p  ON true
      JOIN caps c ON true
      WHERE m.user_id = $U$USER$U::uuid
        AND m.sv @@ ts.qvec
        AND m.doc % p.qn
        AND similarity(m.doc, p.qn) >= 0.30
      ORDER BY ts_rank DESC
      LIMIT (SELECT cap FROM caps)
    ),
    gate AS (
      SELECT set_limit(0.52) AS _
    ),
    rec_trgm AS (
      SELECT r.id, similarity(r.search_norm, p.qn) AS sim
      FROM records.records r, p, gate, caps
      WHERE r.user_id = $U$USER$U::uuid
        AND r.search_norm % p.qn
        AND similarity(r.search_norm, p.qn) >= 0.52
      ORDER BY sim DESC
      LIMIT (SELECT cap FROM caps)
    ),
    alias_hits AS (
      SELECT a.record_id AS id, similarity(a.alias_norm, p.qn) AS sim
      FROM records.aliases_mv a, p, gate, caps
      WHERE a.user_id = $U$USER$U::uuid
        AND a.alias_norm % p.qn
        AND similarity(a.alias_norm, p.qn) >= 0.52
      ORDER BY sim DESC
      LIMIT (SELECT cap FROM caps)
    ),
    alias_sim AS (
      SELECT id, MAX(sim) AS alias_sim
      FROM alias_hits
      GROUP BY id
    ),
    cand AS (
      SELECT id FROM fts
      UNION
      SELECT id FROM rec_trgm
      UNION
      SELECT id FROM alias_hits
    ),
    scored AS (
      SELECT r.id,
             GREATEST(
               similarity(r.search_norm, p.qn),
               similarity(r.artist_norm,  p.qn),
               similarity(r.name_norm,    p.qn),
               similarity(r.label_norm,   p.qn),
               similarity(r.catalog_norm, p.qn),
               COALESCE(a.alias_sim, 0)
             ) AS sim,
             COALESCE(f.ts_rank, 0) AS ts_rank,
             (r.search_norm <-> p.qn) AS dist
      FROM cand c
      JOIN records.records r ON r.id = c.id
      JOIN p ON true
      LEFT JOIN alias_sim a ON a.id = r.id
      LEFT JOIN fts f       ON f.id = r.id
      WHERE r.user_id = $U$USER$U::uuid
    ),
    ranked AS (
      SELECT id, (0.70*sim + 0.30*ts_rank)::real AS rank, dist
      FROM scored
    )
    SELECT id, rank
    FROM ranked
    ORDER BY rank DESC, dist ASC
    LIMIT GREATEST(1, LEAST(1000, $2))
    OFFSET GREATEST(0, $3)
  $q$;

BEGIN
  sql := replace(function_sql, '$U$USER$U', quote_literal(p_user));

  RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;

  IF NOT FOUND THEN
    sql := replace(sql, '>= 0.52', '>= 0.50');
    sql := replace(sql, 'set_limit(0.52)', 'set_limit(0.50)');
    RETURN QUERY EXECUTE sql USING p_q, p_limit, p_offset;
  END IF;
END
$_$;


ALTER FUNCTION public.search_records_super2(p_user uuid, p_q text, p_limit integer, p_offset integer, p_strict boolean) OWNER TO postgres;

--
-- Name: make_search_norm(text, text, text, text); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.make_search_norm(a text, n text, l text, c text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  SELECT public.norm_text(coalesce(a,'')||' '||coalesce(n,'')||' '||coalesce(l,'')||' '||coalesce(c,''));
$$;


ALTER FUNCTION records.make_search_norm(a text, n text, l text, c text) OWNER TO postgres;

--
-- Name: seed_aliases_for_user(uuid); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.seed_aliases_for_user(p_user uuid) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
  n bigint := 0;
BEGIN
  WITH tgt AS (
    SELECT id, artist_norm
    FROM records.records
    WHERE user_id = p_user
  )
  SELECT COALESCE(sum(records.upsert_aliases(
           id,
           CASE
             WHEN artist_norm LIKE '%teresa%'  OR artist_norm LIKE '%鄧麗君%' OR artist_norm LIKE '%邓丽君%' THEN ARRAY['Teresa Teng','鄧麗君','邓丽君','テレサ・テン']
             WHEN artist_norm LIKE '%anita%'   OR artist_norm LIKE '%梅艷芳%' OR artist_norm LIKE '%梅艳芳%' THEN ARRAY['Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ']
             WHEN artist_norm LIKE '%faye%'    OR artist_norm LIKE '%王菲%'                                  THEN ARRAY['Faye Wong','王菲','ワン・フェイ']
             WHEN artist_norm LIKE '%leslie%'  OR artist_norm LIKE '%張國榮%' OR artist_norm LIKE '%张国荣%' THEN ARRAY['Leslie Cheung','張國榮','张国荣','レスリー・チャン']
             ELSE ARRAY[]::text[]
           END
         )), 0)
    INTO n
  FROM tgt;
  RETURN n;
END
$$;


ALTER FUNCTION records.seed_aliases_for_user(p_user uuid) OWNER TO postgres;

--
-- Name: seed_demo(uuid, integer); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.seed_demo(p_user uuid, p_n integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  i int;
  artists text[] := ARRAY[
    'Teresa Teng','鄧麗君','邓丽君','テレサ・テン',
    'Anita Mui','梅艷芳','梅艳芳','アニタ・ムイ',
    'Faye Wong','王菲','ワン・フェイ',
    'Leslie Cheung','張國榮','张国荣','レスリー・チャン'
  ];
  formats text[] := ARRAY['LP','EP','12in','7in','CD'];
  labels  text[] := ARRAY['Polydor','PolyGram','Trio','CBS','Warner','EMI'];
  grades  text[] := ARRAY['NM','EX','VG+','VG'];
BEGIN
  INSERT INTO records.records(
    user_id, artist, name, format, catalog_number, notes,
    purchased_at, price_paid, record_grade, sleeve_grade,
    release_year, release_date, pressing_year, label, label_code
  )
  SELECT
    p_user,
    choice(artists) AS artist,
    'Album '||gs AS name,
    choice(formats) AS format,
    (choice(ARRAY['HK','TW','JP','CN','US'])||'-'||to_char((random()*999+1)::int,'FM000'))::text AS catalog_number,
    choice(ARRAY['','great','first press','promo']) AS notes,
    date '2018-01-01' + ((random()*((date '2024-12-31' - date '2018-01-01')))::int) AS purchased_at,
    round((random()*35+5)::numeric,2) AS price_paid,
    choice(grades) AS record_grade,
    choice(grades) AS sleeve_grade,
    (1970 + (random()*45)::int) AS release_year,
    (date '1970-01-01' + ((random()*18250)::int)) AS release_date,
    (1970 + (random()*45)::int) AS pressing_year,
    choice(labels) AS label,
    upper(substr(choice(labels),1,2)) || '-' || to_char((random()*999+1)::int,'FM000') AS label_code
  FROM generate_series(1,p_n) gs;

  -- make sure MV exists and populated
  PERFORM 1 FROM pg_matviews
    WHERE schemaname='records' AND matviewname='aliases_mv';
  IF FOUND THEN
    -- first run: non-concurrent is fine
    REFRESH MATERIALIZED VIEW records.aliases_mv;
  END IF;

  ANALYZE;
END
$$;


ALTER FUNCTION records.seed_demo(p_user uuid, p_n integer) OWNER TO postgres;

--
-- Name: set_norm_cols(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.set_norm_cols() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.artist_norm  := norm_text(NEW.artist);
  NEW.name_norm    := norm_text(NEW.name);
  NEW.label_norm   := norm_text(NEW.label);
  NEW.catalog_norm := norm_text(NEW.catalog_number);
  NEW.search_norm  := btrim(concat_ws(' ', NEW.artist_norm, NEW.name_norm,
                                      coalesce(NEW.catalog_norm,''), coalesce(NEW.label_norm,'')));
  RETURN NEW;
END
$$;


ALTER FUNCTION records.set_norm_cols() OWNER TO postgres;

--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END
$$;


ALTER FUNCTION records.touch_updated_at() OWNER TO postgres;

--
-- Name: upsert_alias(uuid, text); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.upsert_alias(p_record uuid, p_alias text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF p_alias IS NULL OR btrim(p_alias) = '' THEN
    RETURN;
  END IF;
  INSERT INTO records.aliases(record_id, alias)
  VALUES (p_record, btrim(p_alias))
  ON CONFLICT DO NOTHING;
END
$$;


ALTER FUNCTION records.upsert_alias(p_record uuid, p_alias text) OWNER TO postgres;

--
-- Name: upsert_aliases(uuid, text[]); Type: FUNCTION; Schema: records; Owner: postgres
--

CREATE FUNCTION records.upsert_aliases(p_record uuid, p_terms text[]) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
  t text;
  n bigint := 0;
BEGIN
  IF p_terms IS NULL THEN RETURN 0; END IF;
  FOREACH t IN ARRAY p_terms LOOP
    BEGIN
      INSERT INTO records.aliases(record_id, alias)
      VALUES (p_record, btrim(t))
      ON CONFLICT DO NOTHING;
      IF FOUND THEN n := n + 1; END IF;
    EXCEPTION WHEN unique_violation THEN
      NULL;
    END;
  END LOOP;
  RETURN n;
END
$$;


ALTER FUNCTION records.upsert_aliases(p_record uuid, p_terms text[]) OWNER TO postgres;

--
-- Name: sync_hot(); Type: FUNCTION; Schema: records_hot; Owner: postgres
--

CREATE FUNCTION records_hot.sync_hot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    DELETE FROM records_hot.records_hot WHERE id = OLD.id;
    RETURN NULL;
  END IF;

  IF EXISTS (SELECT 1 FROM records_hot.config c WHERE c.user_id = COALESCE(NEW.user_id, OLD.user_id)) THEN
    INSERT INTO records_hot.records_hot(id, user_id, search_norm)
    VALUES (NEW.id, NEW.user_id, NEW.search_norm)
    ON CONFLICT (id) DO UPDATE
      SET user_id = EXCLUDED.user_id,
          search_norm = EXCLUDED.search_norm;
  END IF;
  RETURN NULL;
END$$;


ALTER FUNCTION records_hot.sync_hot() OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email public.citext NOT NULL,
    password_hash text,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE auth.users OWNER TO postgres;

--
-- Name: results; Type: TABLE; Schema: bench; Owner: postgres
--

CREATE TABLE bench.results (
    id bigint NOT NULL,
    ts_utc timestamp with time zone DEFAULT now() NOT NULL,
    variant text NOT NULL,
    clients integer NOT NULL,
    threads integer NOT NULL,
    duration_s integer NOT NULL,
    limit_rows integer NOT NULL,
    tps numeric,
    lat_avg_ms numeric,
    lat_std_ms numeric,
    p50_ms numeric,
    p95_ms numeric,
    p99_ms numeric,
    p999_ms numeric,
    p9999_ms numeric,
    p100_ms numeric,
    notes text,
    git_rev text,
    git_branch text,
    host text,
    server_version text,
    track_io boolean,
    delta_blks_hit bigint,
    delta_blks_read bigint,
    delta_blk_read_ms numeric,
    delta_blk_write_ms numeric,
    delta_xact_commit bigint,
    delta_tup_returned bigint,
    delta_tup_fetched bigint,
    delta_stmt_total_ms numeric,
    delta_stmt_shared_hit bigint,
    delta_stmt_shared_read bigint,
    delta_stmt_shared_dirtied bigint,
    delta_stmt_shared_written bigint,
    delta_stmt_temp_read bigint,
    delta_stmt_temp_written bigint,
    delta_io_read_ms numeric,
    delta_io_write_ms numeric,
    delta_io_extend_ms numeric,
    delta_io_fsync_ms numeric,
    io_total_ms numeric,
    active_sessions numeric,
    cpu_share_pct numeric,
    ok_xacts bigint,
    fail_xacts bigint,
    err_pct numeric
);


ALTER TABLE bench.results OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE; Schema: bench; Owner: postgres
--

CREATE SEQUENCE bench.results_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE bench.results_id_seq OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE OWNED BY; Schema: bench; Owner: postgres
--

ALTER SEQUENCE bench.results_id_seq OWNED BY bench.results.id;


--
-- Name: aliases; Type: TABLE; Schema: records; Owner: record_owner
--

CREATE TABLE records.aliases (
    record_id uuid NOT NULL,
    alias text NOT NULL
);


ALTER TABLE records.aliases OWNER TO record_owner;

--
-- Name: aliases_mv; Type: MATERIALIZED VIEW; Schema: records; Owner: postgres
--

CREATE MATERIALIZED VIEW records.aliases_mv AS
 SELECT r.user_id,
    a.record_id,
    public.norm_text(a.alias) AS alias_norm
   FROM (records.aliases a
     JOIN records.records r ON ((r.id = a.record_id)))
  WITH NO DATA;


ALTER MATERIALIZED VIEW records.aliases_mv OWNER TO postgres;

--
-- Name: record_aliases; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.record_aliases AS
 SELECT user_id,
    record_id,
    alias_norm
   FROM records.aliases_mv;


ALTER VIEW public.record_aliases OWNER TO postgres;

--
-- Name: artist_seed; Type: TABLE; Schema: records; Owner: postgres
--

CREATE TABLE records.artist_seed (
    canon text NOT NULL,
    aliases text[] NOT NULL
);


ALTER TABLE records.artist_seed OWNER TO postgres;

--
-- Name: autocomplete_terms_mv; Type: MATERIALIZED VIEW; Schema: records; Owner: postgres
--

CREATE MATERIALIZED VIEW records.autocomplete_terms_mv AS
 WITH base AS (
         SELECT r.user_id,
            a.alias AS term_raw
           FROM (records.aliases a
             JOIN records.records r ON ((r.id = a.record_id)))
        UNION ALL
         SELECT records.user_id,
            records.artist AS term_raw
           FROM records.records
        UNION ALL
         SELECT records.user_id,
            records.name AS term_raw
           FROM records.records
        UNION ALL
         SELECT records.user_id,
            records.label AS term_raw
           FROM records.records
        )
 SELECT user_id,
    term_raw,
    public.norm_text(term_raw) AS term_norm,
    (count(*))::integer AS hits
   FROM base
  WHERE ((term_raw IS NOT NULL) AND (btrim(term_raw) <> ''::text))
  GROUP BY user_id, term_raw, (public.norm_text(term_raw))
  WITH NO DATA;


ALTER MATERIALIZED VIEW records.autocomplete_terms_mv OWNER TO postgres;

--
-- Name: records_staging_v2; Type: TABLE; Schema: records; Owner: postgres
--

CREATE UNLOGGED TABLE records.records_staging_v2 (
    user_id uuid NOT NULL,
    artist text NOT NULL,
    name text NOT NULL,
    format text NOT NULL,
    catalog_number text NOT NULL,
    notes text,
    purchased_at date,
    price_paid numeric(8,2),
    record_grade text,
    sleeve_grade text,
    release_year integer,
    release_date date,
    pressing_year integer,
    label text,
    label_code text,
    artist_norm text,
    name_norm text,
    label_norm text,
    catalog_norm text,
    search_norm text
);


ALTER TABLE records.records_staging_v2 OWNER TO postgres;

--
-- Name: search_doc_mv; Type: MATERIALIZED VIEW; Schema: records; Owner: postgres
--

CREATE MATERIALIZED VIEW records.search_doc_mv AS
 SELECT r.id,
    r.user_id,
    concat_ws(' '::text, r.artist_norm, r.name_norm, r.label_norm, r.catalog_norm, COALESCE(a.aliases_text, ''::text)) AS doc,
    to_tsvector('simple'::regconfig, concat_ws(' '::text, r.artist_norm, r.name_norm, r.label_norm, r.catalog_norm, COALESCE(a.aliases_text, ''::text))) AS sv
   FROM (records.records r
     LEFT JOIN ( SELECT aliases_mv.record_id,
            aliases_mv.user_id,
            string_agg(aliases_mv.alias_norm, ' '::text ORDER BY aliases_mv.alias_norm) AS aliases_text
           FROM records.aliases_mv
          GROUP BY aliases_mv.record_id, aliases_mv.user_id) a ON (((a.record_id = r.id) AND (a.user_id = r.user_id))))
  WITH NO DATA;


ALTER MATERIALIZED VIEW records.search_doc_mv OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: records_hot; Owner: postgres
--

CREATE TABLE records_hot.config (
    user_id uuid NOT NULL
);


ALTER TABLE records_hot.config OWNER TO postgres;

--
-- Name: records_hot; Type: TABLE; Schema: records_hot; Owner: postgres
--

CREATE TABLE records_hot.records_hot (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    search_norm text NOT NULL
);


ALTER TABLE records_hot.records_hot OWNER TO postgres;

--
-- Name: records; Type: TABLE; Schema: records_poc; Owner: postgres
--

CREATE TABLE records_poc.records (
    id uuid,
    user_id uuid,
    artist text,
    name text,
    format text,
    catalog_number text,
    record_grade text,
    sleeve_grade text,
    has_insert boolean,
    has_booklet boolean,
    has_obi_strip boolean,
    has_factory_sleeve boolean,
    is_promo boolean,
    notes text,
    purchased_at date,
    price_paid numeric(10,2),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    insert_grade text,
    booklet_grade text,
    obi_strip_grade text,
    factory_sleeve_grade text,
    release_year integer,
    release_date date,
    pressing_year integer,
    label text,
    label_code text,
    artist_norm text,
    name_norm text,
    label_norm text,
    catalog_norm text,
    search_norm text
);


ALTER TABLE records_poc.records OWNER TO postgres;

--
-- Name: results id; Type: DEFAULT; Schema: bench; Owner: postgres
--

ALTER TABLE ONLY bench.results ALTER COLUMN id SET DEFAULT nextval('bench.results_id_seq'::regclass);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: bench; Owner: postgres
--

ALTER TABLE ONLY bench.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: aliases aliases_pkey; Type: CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.aliases
    ADD CONSTRAINT aliases_pkey PRIMARY KEY (record_id, alias);


--
-- Name: artist_seed artist_seed_pkey; Type: CONSTRAINT; Schema: records; Owner: postgres
--

ALTER TABLE ONLY records.artist_seed
    ADD CONSTRAINT artist_seed_pkey PRIMARY KEY (canon);


--
-- Name: records records_pkey; Type: CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: records_hot; Owner: postgres
--

ALTER TABLE ONLY records_hot.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (user_id);


--
-- Name: records_hot records_hot_pkey; Type: CONSTRAINT; Schema: records_hot; Owner: postgres
--

ALTER TABLE ONLY records_hot.records_hot
    ADD CONSTRAINT records_hot_pkey PRIMARY KEY (id);


--
-- Name: bench_results_uq; Type: INDEX; Schema: bench; Owner: postgres
--

CREATE UNIQUE INDEX bench_results_uq ON bench.results USING btree (ts_utc, variant, clients, threads, duration_s, limit_rows);


--
-- Name: ac_terms_mv_uid_term_uq; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX ac_terms_mv_uid_term_uq ON records.autocomplete_terms_mv USING btree (user_id, term_raw, term_norm);


--
-- Name: ac_terms_user_hits; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX ac_terms_user_hits ON records.autocomplete_terms_mv USING btree (user_id, hits DESC);


--
-- Name: ac_terms_user_term_gist; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX ac_terms_user_term_gist ON records.autocomplete_terms_mv USING gist (user_id, term_norm public.gist_trgm_ops);


--
-- Name: aliases_mv_uniq_btree; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX aliases_mv_uniq_btree ON records.aliases_mv USING btree (user_id, record_id, alias_norm);


--
-- Name: aliases_mv_user_alias_gist; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX aliases_mv_user_alias_gist ON records.aliases_mv USING gist (user_id, alias_norm public.gist_trgm_ops);


--
-- Name: idx_records_artist_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_artist_gist_trgm ON records.records USING gist (artist_norm public.gist_trgm_ops);


--
-- Name: idx_records_artist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_artist_trgm ON records.records USING gin (artist public.gin_trgm_ops);


--
-- Name: idx_records_catalog_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_catalog_gist_trgm ON records.records USING gist (catalog_norm public.gist_trgm_ops);


--
-- Name: idx_records_id_inc_user; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_id_inc_user ON records.records USING btree (id) INCLUDE (user_id);


--
-- Name: idx_records_label_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_label_gist_trgm ON records.records USING gist (label_norm public.gist_trgm_ops);


--
-- Name: idx_records_name_gist_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_name_gist_trgm ON records.records USING gist (name_norm public.gist_trgm_ops);


--
-- Name: idx_records_name_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_name_trgm ON records.records USING gin (name public.gin_trgm_ops);


--
-- Name: idx_records_search_gin_trgm; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_search_gin_trgm ON records.records USING gin (search_norm public.gin_trgm_ops);


--
-- Name: idx_records_user; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user ON records.records USING btree (user_id);


--
-- Name: idx_records_user_updated; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX idx_records_user_updated ON records.records USING btree (user_id, updated_at DESC);


--
-- Name: rec_alias_0dc268d0a86f4e12_alias_trgm_gin; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX rec_alias_0dc268d0a86f4e12_alias_trgm_gin ON records.aliases_mv USING gin (alias_norm public.gin_trgm_ops) WITH (fastupdate=off) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: rec_hot_0dc268d0a86f4e128d109db0f1b735e0_searchnorm_trgm_gin; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX rec_hot_0dc268d0a86f4e128d109db0f1b735e0_searchnorm_trgm_gin ON records.records USING gin (search_norm public.gin_trgm_ops) WITH (fastupdate=off) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: rec_hot_0dc268d0a86f4e12_searchnorm_trgm_gin; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX rec_hot_0dc268d0a86f4e12_searchnorm_trgm_gin ON records.records USING gin (search_norm public.gin_trgm_ops) WITH (fastupdate=off) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: rec_hot_0dc268d0a86f4e12_trgm_knn_cov; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX rec_hot_0dc268d0a86f4e12_trgm_knn_cov ON records.records USING gist (search_norm public.gist_trgm_ops) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: records_hot_000000000000000000000000000000aa_trgm_knn; Type: INDEX; Schema: records; Owner: record_owner
--

CREATE INDEX records_hot_000000000000000000000000000000aa_trgm_knn ON records.records USING gist (search_norm public.gist_trgm_ops) WHERE (user_id = '00000000-0000-0000-0000-0000000000aa'::uuid);


--
-- Name: records_staging_v2_artist_name_format_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_artist_name_format_idx ON records.records_staging_v2 USING btree (artist, name, format);


--
-- Name: records_staging_v2_catalog_number_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_catalog_number_idx ON records.records_staging_v2 USING btree (catalog_number);


--
-- Name: records_staging_v2_user_id_idx; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX records_staging_v2_user_id_idx ON records.records_staging_v2 USING btree (user_id);


--
-- Name: search_doc_mv_doc_trgm_gin; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX search_doc_mv_doc_trgm_gin ON records.search_doc_mv USING gin (doc public.gin_trgm_ops);


--
-- Name: search_doc_mv_pk; Type: INDEX; Schema: records; Owner: postgres
--

CREATE UNIQUE INDEX search_doc_mv_pk ON records.search_doc_mv USING btree (id);


--
-- Name: search_doc_mv_sv_gin; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX search_doc_mv_sv_gin ON records.search_doc_mv USING gin (sv);


--
-- Name: search_doc_mv_user; Type: INDEX; Schema: records; Owner: postgres
--

CREATE INDEX search_doc_mv_user ON records.search_doc_mv USING btree (user_id);


--
-- Name: records_hot_knn; Type: INDEX; Schema: records_hot; Owner: postgres
--

CREATE INDEX records_hot_knn ON records_hot.records_hot USING gist (search_norm public.gist_trgm_ops) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: records_hot_search_trgm_gin; Type: INDEX; Schema: records_hot; Owner: postgres
--

CREATE INDEX records_hot_search_trgm_gin ON records_hot.records_hot USING gin (search_norm public.gin_trgm_ops) WITH (fastupdate=off) WHERE (user_id = '0dc268d0-a86f-4e12-8d10-9db0f1b735e0'::uuid);


--
-- Name: records_poc_hot_trgm_knn_cov; Type: INDEX; Schema: records_poc; Owner: postgres
--

CREATE INDEX records_poc_hot_trgm_knn_cov ON records_poc.records USING gist (search_norm public.gist_trgm_ops) INCLUDE (id);


--
-- Name: records records_hot_sync_del; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER records_hot_sync_del AFTER DELETE ON records.records FOR EACH ROW EXECUTE FUNCTION records_hot.sync_hot();


--
-- Name: records records_hot_sync_ins; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER records_hot_sync_ins AFTER INSERT ON records.records FOR EACH ROW EXECUTE FUNCTION records_hot.sync_hot();


--
-- Name: records records_hot_sync_upd; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER records_hot_sync_upd AFTER UPDATE OF user_id, search_norm ON records.records FOR EACH ROW EXECUTE FUNCTION records_hot.sync_hot();


--
-- Name: records trg_records_norm; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_records_norm BEFORE INSERT OR UPDATE ON records.records FOR EACH ROW EXECUTE FUNCTION records.set_norm_cols();


--
-- Name: records trg_records_touch; Type: TRIGGER; Schema: records; Owner: record_owner
--

CREATE TRIGGER trg_records_touch BEFORE UPDATE ON records.records FOR EACH ROW EXECUTE FUNCTION records.touch_updated_at();


--
-- Name: aliases aliases_record_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.aliases
    ADD CONSTRAINT aliases_record_id_fkey FOREIGN KEY (record_id) REFERENCES records.records(id) ON DELETE CASCADE;


--
-- Name: records records_user_id_fkey; Type: FK CONSTRAINT; Schema: records; Owner: record_owner
--

ALTER TABLE ONLY records.records
    ADD CONSTRAINT records_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: record_owner
--

GRANT USAGE ON SCHEMA auth TO record_app;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO record_app;


--
-- Name: SCHEMA records; Type: ACL; Schema: -; Owner: record_owner
--

GRANT USAGE ON SCHEMA records TO record_app;


--
-- Name: FUNCTION citextin(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextin(cstring) TO record_app;


--
-- Name: FUNCTION citextout(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextout(public.citext) TO record_app;


--
-- Name: FUNCTION citextrecv(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextrecv(internal) TO record_app;


--
-- Name: FUNCTION citextsend(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citextsend(public.citext) TO record_app;


--
-- Name: FUNCTION gbtreekey16_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey16_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey16_out(public.gbtreekey16); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey16_out(public.gbtreekey16) TO record_app;


--
-- Name: FUNCTION gbtreekey2_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey2_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey2_out(public.gbtreekey2); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey2_out(public.gbtreekey2) TO record_app;


--
-- Name: FUNCTION gbtreekey32_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey32_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey32_out(public.gbtreekey32); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey32_out(public.gbtreekey32) TO record_app;


--
-- Name: FUNCTION gbtreekey4_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey4_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey4_out(public.gbtreekey4); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey4_out(public.gbtreekey4) TO record_app;


--
-- Name: FUNCTION gbtreekey8_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey8_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey8_out(public.gbtreekey8); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey8_out(public.gbtreekey8) TO record_app;


--
-- Name: FUNCTION gbtreekey_var_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey_var_in(cstring) TO record_app;


--
-- Name: FUNCTION gbtreekey_var_out(public.gbtreekey_var); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbtreekey_var_out(public.gbtreekey_var) TO record_app;


--
-- Name: FUNCTION gtrgm_in(cstring); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_in(cstring) TO record_app;


--
-- Name: FUNCTION gtrgm_out(public.gtrgm); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_out(public.gtrgm) TO record_app;


--
-- Name: FUNCTION citext(boolean); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(boolean) TO record_app;


--
-- Name: FUNCTION citext(character); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(character) TO record_app;


--
-- Name: FUNCTION citext(inet); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext(inet) TO record_app;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea) TO record_app;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.armor(bytea, text[], text[]) TO record_app;


--
-- Name: FUNCTION autoprewarm_dump_now(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.autoprewarm_dump_now() TO record_app;


--
-- Name: FUNCTION autoprewarm_start_worker(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.autoprewarm_start_worker() TO record_app;


--
-- Name: FUNCTION cash_dist(money, money); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.cash_dist(money, money) TO record_app;


--
-- Name: FUNCTION choice(anyarray); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.choice(anyarray) TO record_app;


--
-- Name: FUNCTION citext_cmp(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_cmp(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_eq(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_eq(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_ge(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_ge(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_gt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_gt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_hash(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_hash(public.citext) TO record_app;


--
-- Name: FUNCTION citext_hash_extended(public.citext, bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_hash_extended(public.citext, bigint) TO record_app;


--
-- Name: FUNCTION citext_larger(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_larger(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_le(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_le(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_lt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_lt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_ne(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_ne(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_cmp(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_cmp(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_ge(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_ge(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_gt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_gt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_le(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_le(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_pattern_lt(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_pattern_lt(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION citext_smaller(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.citext_smaller(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.crypt(text, text) TO record_app;


--
-- Name: FUNCTION date_dist(date, date); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.date_dist(date, date) TO record_app;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dearmor(text) TO record_app;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.decrypt_iv(bytea, bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(bytea, text) TO record_app;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.digest(text, text) TO record_app;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.encrypt_iv(bytea, bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION float4_dist(real, real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.float4_dist(real, real) TO record_app;


--
-- Name: FUNCTION float8_dist(double precision, double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.float8_dist(double precision, double precision) TO record_app;


--
-- Name: FUNCTION gbt_bit_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_consistent(internal, bit, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_consistent(internal, bit, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_bit_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bit_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_consistent(internal, boolean, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_consistent(internal, boolean, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_same(public.gbtreekey2, public.gbtreekey2, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_same(public.gbtreekey2, public.gbtreekey2, internal) TO record_app;


--
-- Name: FUNCTION gbt_bool_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bool_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bpchar_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bpchar_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bpchar_consistent(internal, character, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bpchar_consistent(internal, character, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_consistent(internal, bytea, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_consistent(internal, bytea, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_bytea_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_bytea_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_consistent(internal, money, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_consistent(internal, money, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_distance(internal, money, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_distance(internal, money, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_cash_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_cash_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_date_consistent(internal, date, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_consistent(internal, date, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_distance(internal, date, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_distance(internal, date, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_date_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_date_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_date_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_consistent(internal, anyenum, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_consistent(internal, anyenum, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_enum_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_enum_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_consistent(internal, real, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_consistent(internal, real, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_distance(internal, real, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_distance(internal, real, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_float4_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float4_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_consistent(internal, double precision, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_consistent(internal, double precision, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_distance(internal, double precision, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_distance(internal, double precision, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_float8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_float8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_consistent(internal, inet, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_consistent(internal, inet, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_inet_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_inet_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_consistent(internal, smallint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_consistent(internal, smallint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_distance(internal, smallint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_distance(internal, smallint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_same(public.gbtreekey4, public.gbtreekey4, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_same(public.gbtreekey4, public.gbtreekey4, internal) TO record_app;


--
-- Name: FUNCTION gbt_int2_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int2_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_consistent(internal, integer, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_consistent(internal, integer, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_distance(internal, integer, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_distance(internal, integer, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_int4_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int4_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_consistent(internal, bigint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_consistent(internal, bigint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_distance(internal, bigint, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_distance(internal, bigint, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_int8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_int8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_consistent(internal, interval, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_consistent(internal, interval, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_distance(internal, interval, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_distance(internal, interval, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_same(public.gbtreekey32, public.gbtreekey32, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_same(public.gbtreekey32, public.gbtreekey32, internal) TO record_app;


--
-- Name: FUNCTION gbt_intv_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_intv_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_consistent(internal, macaddr8, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_consistent(internal, macaddr8, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad8_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad8_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_consistent(internal, macaddr, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_consistent(internal, macaddr, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_macad_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_macad_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_consistent(internal, numeric, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_consistent(internal, numeric, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_numeric_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_numeric_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_consistent(internal, oid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_consistent(internal, oid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_distance(internal, oid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_distance(internal, oid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_same(public.gbtreekey8, public.gbtreekey8, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_same(public.gbtreekey8, public.gbtreekey8, internal) TO record_app;


--
-- Name: FUNCTION gbt_oid_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_oid_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_text_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_consistent(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_same(public.gbtreekey_var, public.gbtreekey_var, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_same(public.gbtreekey_var, public.gbtreekey_var, internal) TO record_app;


--
-- Name: FUNCTION gbt_text_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_text_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_time_consistent(internal, time without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_consistent(internal, time without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_distance(internal, time without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_distance(internal, time without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_time_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_time_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_time_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_timetz_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_timetz_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_timetz_consistent(internal, time with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_timetz_consistent(internal, time with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_consistent(internal, timestamp without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_consistent(internal, timestamp without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_distance(internal, timestamp without time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_distance(internal, timestamp without time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_same(public.gbtreekey16, public.gbtreekey16, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_same(public.gbtreekey16, public.gbtreekey16, internal) TO record_app;


--
-- Name: FUNCTION gbt_ts_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_ts_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_consistent(internal, timestamp with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_consistent(internal, timestamp with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_tstz_distance(internal, timestamp with time zone, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_tstz_distance(internal, timestamp with time zone, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_compress(internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_consistent(internal, uuid, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_consistent(internal, uuid, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_fetch(internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_same(public.gbtreekey32, public.gbtreekey32, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_same(public.gbtreekey32, public.gbtreekey32, internal) TO record_app;


--
-- Name: FUNCTION gbt_uuid_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_uuid_union(internal, internal) TO record_app;


--
-- Name: FUNCTION gbt_var_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_var_decompress(internal) TO record_app;


--
-- Name: FUNCTION gbt_var_fetch(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gbt_var_fetch(internal) TO record_app;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_bytes(integer) TO record_app;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_random_uuid() TO record_app;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text) TO record_app;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gen_salt(text, integer) TO record_app;


--
-- Name: FUNCTION gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_query_trgm(text, internal, smallint, internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gin_extract_value_trgm(text, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_extract_value_trgm(text, internal) TO record_app;


--
-- Name: FUNCTION gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_consistent(internal, smallint, text, integer, internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gin_trgm_triconsistent(internal, smallint, text, integer, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_compress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_compress(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_consistent(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_consistent(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_decompress(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_decompress(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_distance(internal, text, smallint, oid, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_distance(internal, text, smallint, oid, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_options(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_options(internal) TO record_app;


--
-- Name: FUNCTION gtrgm_penalty(internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_penalty(internal, internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_picksplit(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_picksplit(internal, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_same(public.gtrgm, public.gtrgm, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_same(public.gtrgm, public.gtrgm, internal) TO record_app;


--
-- Name: FUNCTION gtrgm_union(internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.gtrgm_union(internal, internal) TO record_app;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.hmac(text, text, text) TO record_app;


--
-- Name: FUNCTION int2_dist(smallint, smallint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int2_dist(smallint, smallint) TO record_app;


--
-- Name: FUNCTION int4_dist(integer, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int4_dist(integer, integer) TO record_app;


--
-- Name: FUNCTION int8_dist(bigint, bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.int8_dist(bigint, bigint) TO record_app;


--
-- Name: FUNCTION interval_dist(interval, interval); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.interval_dist(interval, interval) TO record_app;


--
-- Name: FUNCTION norm_text(t text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.norm_text(t text) TO record_app;


--
-- Name: FUNCTION oid_dist(oid, oid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.oid_dist(oid, oid) TO record_app;


--
-- Name: FUNCTION pg_prewarm(regclass, mode text, fork text, first_block bigint, last_block bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_prewarm(regclass, mode text, fork text, first_block bigint, last_block bigint) TO record_app;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT blk_read_time double precision, OUT blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision) TO record_app;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO record_app;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint) TO record_app;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_armor_headers(text, OUT key text, OUT value text) TO record_app;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_key_id(bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt(bytea, bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt(text, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea) TO record_app;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_pub_encrypt_bytea(bytea, bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt(bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_decrypt_bytea(bytea, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt(text, text, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text) TO record_app;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.pgp_sym_encrypt_bytea(bytea, text, text) TO record_app;


--
-- Name: TABLE records; Type: ACL; Schema: records; Owner: record_owner
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.records TO record_app;


--
-- Name: FUNCTION records_recent(p_user uuid, p_limit integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.records_recent(p_user uuid, p_limit integer) TO record_app;


--
-- Name: FUNCTION regexp_match(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_match(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_match(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_match(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_matches(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_matches(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_matches(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_matches(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_replace(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_replace(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_replace(public.citext, public.citext, text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_replace(public.citext, public.citext, text, text) TO record_app;


--
-- Name: FUNCTION regexp_split_to_array(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_array(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_split_to_array(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_array(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION regexp_split_to_table(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_table(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION regexp_split_to_table(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.regexp_split_to_table(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION replace(public.citext, public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.replace(public.citext, public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_autocomplete(p_user uuid, p_q text, p_k integer, p_field text) TO record_app;


--
-- Name: FUNCTION search_facets(p_user uuid, p_q text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.search_facets(p_user uuid, p_q text) TO record_app;


--
-- Name: FUNCTION set_limit(real); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_limit(real) TO record_app;


--
-- Name: FUNCTION show_limit(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_limit() TO record_app;


--
-- Name: FUNCTION show_trgm(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.show_trgm(text) TO record_app;


--
-- Name: FUNCTION similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity(text, text) TO record_app;


--
-- Name: FUNCTION similarity_dist(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_dist(text, text) TO record_app;


--
-- Name: FUNCTION similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION split_part(public.citext, public.citext, integer); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.split_part(public.citext, public.citext, integer) TO record_app;


--
-- Name: FUNCTION strict_word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_dist_op(text, text) TO record_app;


--
-- Name: FUNCTION strict_word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strict_word_similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION strpos(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.strpos(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticlike(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticlike(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticlike(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticlike(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticnlike(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticnlike(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticnlike(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticnlike(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticregexeq(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexeq(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticregexeq(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexeq(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION texticregexne(public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexne(public.citext, text) TO record_app;


--
-- Name: FUNCTION texticregexne(public.citext, public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.texticregexne(public.citext, public.citext) TO record_app;


--
-- Name: FUNCTION time_dist(time without time zone, time without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.time_dist(time without time zone, time without time zone) TO record_app;


--
-- Name: FUNCTION translate(public.citext, public.citext, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.translate(public.citext, public.citext, text) TO record_app;


--
-- Name: FUNCTION ts_dist(timestamp without time zone, timestamp without time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.ts_dist(timestamp without time zone, timestamp without time zone) TO record_app;


--
-- Name: FUNCTION tstz_dist(timestamp with time zone, timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.tstz_dist(timestamp with time zone, timestamp with time zone) TO record_app;


--
-- Name: FUNCTION unaccent(text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent(text) TO record_app;


--
-- Name: FUNCTION unaccent(regdictionary, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent(regdictionary, text) TO record_app;


--
-- Name: FUNCTION unaccent_init(internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent_init(internal) TO record_app;


--
-- Name: FUNCTION unaccent_lexize(internal, internal, internal, internal); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unaccent_lexize(internal, internal, internal, internal) TO record_app;


--
-- Name: FUNCTION word_similarity(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_dist_commutator_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_commutator_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_dist_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_dist_op(text, text) TO record_app;


--
-- Name: FUNCTION word_similarity_op(text, text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.word_similarity_op(text, text) TO record_app;


--
-- Name: FUNCTION seed_demo(p_user uuid, p_n integer); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.seed_demo(p_user uuid, p_n integer) TO record_app;


--
-- Name: FUNCTION set_norm_cols(); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.set_norm_cols() TO record_app;


--
-- Name: FUNCTION touch_updated_at(); Type: ACL; Schema: records; Owner: postgres
--

GRANT ALL ON FUNCTION records.touch_updated_at() TO record_app;


--
-- Name: FUNCTION max(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.max(public.citext) TO record_app;


--
-- Name: FUNCTION min(public.citext); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.min(public.citext) TO record_app;


--
-- Name: TABLE aliases; Type: ACL; Schema: records; Owner: record_owner
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.aliases TO record_app;


--
-- Name: TABLE aliases_mv; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.aliases_mv TO record_app;


--
-- Name: TABLE artist_seed; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.artist_seed TO record_app;


--
-- Name: TABLE autocomplete_terms_mv; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.autocomplete_terms_mv TO record_app;


--
-- Name: TABLE records_staging_v2; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.records_staging_v2 TO record_app;


--
-- Name: TABLE search_doc_mv; Type: ACL; Schema: records; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE records.search_doc_mv TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA public GRANT USAGE ON SEQUENCES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: record_owner
--

ALTER DEFAULT PRIVILEGES FOR ROLE record_owner IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: records; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA records GRANT SELECT,USAGE ON SEQUENCES TO record_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: records; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA records GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO record_app;


--
-- PostgreSQL database dump complete
--

\unrestrict wUQgmvGfG6pnmGCq9rcd3exXeogbGoughXpdNxJHTsgouFPaXZpedoekLsqgr7h

