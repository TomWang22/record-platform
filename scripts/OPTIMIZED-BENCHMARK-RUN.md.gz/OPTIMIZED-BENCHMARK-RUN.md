# Optimized Benchmark Run Configuration

This document describes the optimized benchmark configuration for maximum TPS performance tuning.

## Quick Start: Optimized Run Command

```bash
SKIP_DISK_CHECK=true \
RUN_SMOKE_TESTS=false \
RUN_COLD_CACHE=false \
GENERATE_PLOTS=false \
RUN_DIFF_MODE=false \
CREATE_BENCH_BACKUP=false \
RUN_OPTIMIZE_DB=false \
USE_SQL_FUNCTION=true \
USE_AUTO_WRAPPER=false \
TRACK_IO_TIMING=off \
MODE=quick \
./scripts/run_pgbench_sweep.sh \
  --pgoptions "-c jit=off -c enable_seqscan=off \
               -c random_page_cost=1.1 \
               -c cpu_index_tuple_cost=0.0005 \
               -c cpu_tuple_cost=0.01 \
               -c effective_cache_size=4GB \
               -c work_mem=32MB \
               -c track_io_timing=off \
               -c effective_io_concurrency=300 \
               -c max_parallel_workers=1 \
               -c max_parallel_workers_per_gather=0 \
               -c maintenance_work_mem=512MB \
               -c pg_trgm.similarity_threshold=0.40 \
               -c synchronous_commit=off"
```

## Key Optimizations

### 1. SQL Function (10-20% TPS gain)
- **USE_SQL_FUNCTION=true**: Uses SQL-language function instead of PL/pgSQL
- Removes PL/pgSQL interpreter overhead
- Eliminates dynamic EXECUTE parse/plan overhead
- **Verify**: Check function language after run:
  ```sql
  SELECT l.lanname FROM pg_proc p
  JOIN pg_language l ON l.oid = p.prolang
  WHERE p.proname = 'search_records_fuzzy_ids' AND p.pronargs = 5;
  ```
  Should return `sql`, not `plpgsql`

### 2. Disable IO Timing (5-10% TPS gain)
- **TRACK_IO_TIMING=off**: Removes per-block timing overhead
- Still tracks block hits/reads, just not millisecond timings
- Use for pure TPS/latency benchmarks

### 3. Disable Parallel Query (Reduces overhead)
- **max_parallel_workers=1**: Limits parallel workers
- **max_parallel_workers_per_gather=0**: Disables parallel query plans
- Reduces coordination overhead and lock contention
- Better for high-concurrency, small queries

### 4. Aggressive Fast Mode Tuning (15-25% additional CPU reduction)
- SQL function uses `candidate_cap=24` and `min_rank=0.55` (vs 32/0.50 optimized, 40/0.50 gold)
- **candidate_cap=24**: More aggressive candidate filtering (formula: `LEAST(24, GREATEST(p_limit * 3 / 4, 20))`)
- **min_rank=0.55**: Higher similarity cutoff, reduces similarity computation overhead
- Reduces FTS candidate set size and similarity scoring work
- Less GIN index work, less similarity() CPU per query
- Only applies to SQL function (PL/pgSQL keeps 40/0.50 for gold compatibility)
- **Trade-off**: Slightly lower recall, but significantly better throughput at high concurrency

### 5. Fast Dev Mode Flags
- **SKIP_DISK_CHECK=true**: Skip disk space checks
- **RUN_SMOKE_TESTS=false**: Skip pre-bench sanity checks
- **RUN_COLD_CACHE=false**: Skip cold cache phases
- **GENERATE_PLOTS=false**: Skip plot generation
- **RUN_DIFF_MODE=false**: Skip regression diff
- **CREATE_BENCH_BACKUP=false**: Skip backup creation
- **RUN_OPTIMIZE_DB=false**: Skip DB optimization
- **MODE=quick**: Only run 8-64 clients (not 8-256)

### 5. Auto Wrapper (Production Recommendation)
- **USE_AUTO_WRAPPER=true**: Uses `search_records_fuzzy_ids_auto` wrapper
- Includes 200ms statement timeout (caps worst-case latency)
- Tries fast mode first, falls back to deep mode if too few results
- **Recommended for production**: true (smoother throughput, avoids mega-slow outliers)
- **Recommended for benchmarks**: false (while tuning pure engine capacity), then true (to see real-user behavior)

## Expected Performance

After applying all optimizations (SQL function + aggressive tuning), expect:

- **knn 64 warm**: 5-6k TPS (target: 6-8k TPS with full observability stack)
- **knn 96 warm**: 4-5k TPS (target: 6-8k TPS with full observability stack)
- **p95 latency**: Should stay under ~35ms at 64 clients
- **Query execution time**: ~2-4ms (EXPLAIN ANALYZE shows ~100ms due to overhead, actual runtime is much faster)

## Verification Steps

1. **Check function language**:
   ```bash
   PGPASSWORD=postgres psql -h localhost -p 5433 -U postgres -d records -c "
   SELECT l.lanname FROM pg_proc p
   JOIN pg_language l ON l.oid = p.prolang
   WHERE p.proname = 'search_records_fuzzy_ids' AND p.pronargs = 5;"
   ```
   Should return `sql`

2. **Check session settings**:
   ```bash
   PGPASSWORD=postgres psql -h localhost -p 5433 -U postgres -d records -c "
   SELECT name, setting FROM pg_settings
   WHERE name IN ('max_parallel_workers', 'max_parallel_workers_per_gather', 'track_io_timing');"
   ```

3. **Review peak_tps_summary.txt**:
   ```bash
   cat bench_logs/$(ls -t bench_logs | head -1)/peak_tps_summary.txt
   ```

## Comparison: Gold vs Optimized

| Setting | Gold Run | Optimized Run | Aggressive Run |
|--------|----------|---------------|----------------|
| Function Language | PL/pgSQL | SQL | SQL |
| track_io_timing | on | off | off |
| max_parallel_workers | 12 | 1 | 1 |
| max_parallel_workers_per_gather | 4 | 0 | 0 |
| candidate_cap (fast) | 40 | 32 | **24** |
| min_rank (fast) | 0.50 | 0.50 | **0.55** |
| Expected TPS gain | Baseline | +15-30% | **+30-50%** |

## Notes

- **Aggressive tuning (candidate_cap=24, min_rank=0.55)**: Best for maximum throughput under full observability stack
- **Optimized tuning (candidate_cap=32, min_rank=0.50)**: Good balance between throughput and recall
- **Gold tuning (candidate_cap=40, min_rank=0.50)**: Best recall, baseline performance
- **Production recommendation**: Use `USE_AUTO_WRAPPER=true` for production (includes timeout and fast->deep fallback)
- track_io_timing=off loses per-block timing metrics (but still tracks block hits/reads)
- Parallel query is still useful for large analytical queries (disabled for high-concurrency benchmarks)
- Aggressive tuning may reduce recall slightly, but auto wrapper provides deep mode fallback when needed
- **Query execution time note**: EXPLAIN ANALYZE shows ~100ms due to overhead, actual runtime is ~2-4ms

