# Performance Regression Findings (Nov 26, 2025)

## Diagnostic Results Summary

### ✅ Function Definition: CORRECT
- **Language**: PL/pgSQL ✓
- **Fast mode candidate_cap**: 40 (for LIMIT=50) ✓
- **min_rank**: 0.50 ✓
- **Function matches gold version**

### ⚠️ Configuration Issues Found

#### Database-Level Settings (May Not Apply to pgbench)
The diagnostic shows database-level defaults, but **pgbench uses session-level PGOPTIONS** which should override these:

| Setting | Database Default | Expected (Gold) | Status |
|---------|------------------|-----------------|--------|
| `enable_seqscan` | ON | OFF | ⚠️ Should be overridden by PGOPTIONS |
| `jit` | ON | OFF | ⚠️ Should be overridden by PGOPTIONS |
| `synchronous_commit` | ON | OFF | ⚠️ Should be overridden by PGOPTIONS |
| `effective_cache_size` | 4GB (524288 8kB) | 4GB | ✅ Correct |
| `work_mem` | 32MB (32768 kB) | 32MB | ✅ Correct |
| `random_page_cost` | 1.1 | 1.1 | ✅ Correct |

#### Critical: Verify PGOPTIONS Are Applied
The benchmark script sets these via `PGOPTIONS_EXTRA`, but we need to verify they're actually applied during pgbench runs.

### 🔍 Root Cause Analysis

The performance degradation worsens at higher concurrency:
- **64 clients**: -31% (4258 vs 6152 TPS)
- **96 clients**: -43% (4232 vs 7491 TPS)
- **128 clients**: -48% (3486 vs 6720 TPS)
- **256 clients**: -70% (1987 vs 6634 TPS)

This pattern suggests:
1. **Concurrency bottleneck**: Lock contention, connection pool exhaustion, or resource contention
2. **Configuration not applied**: PGOPTIONS may not be taking effect
3. **Environmental factors**: Disk I/O, memory pressure, or other system resources

### 🎯 Action Items

1. **Verify PGOPTIONS are applied** (added verification step to benchmark script)
2. **Check for lock contention** during high concurrency
3. **Monitor connection pool** usage
4. **Check disk I/O** saturation
5. **Verify autovacuum is disabled** during benchmarks
6. **Check for index bloat** or missing indexes

### 📊 Expected Performance (Gold Run)

| Test | Clients | Target TPS |
|------|---------|------------|
| knn warm | 64 | ~6k |
| knn warm | 96 | ~7.5k |
| knn warm | 128 | ~6.7k |
| knn warm | 256 | ~6.6k |

### 🔧 Quick Fix

Run benchmark with explicit gold configuration:

```bash
export USE_AUTO_WRAPPER=false
export USE_SQL_FUNCTION=false
export TRACK_IO_TIMING=on
export TRGM_THRESHOLD=0.40
export MODE=deep
export RUN_COLD_CACHE=true
export DISABLE_AUTOVACUUM=true

# Verify settings before running
./scripts/diagnose-performance-regression.sh

# Run benchmark
./scripts/run_pgbench_sweep.sh
```

The benchmark script now includes a verification step that will show the actual session-level settings used by pgbench on the first run.

