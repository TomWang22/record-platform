# Restoring Gold Performance (Nov 22, 2025)

## Performance Regression Analysis

### Comparison: Nov 22 (Gold) vs Nov 26 (Current)

| Test | Clients | Gold TPS | Current TPS | Degradation |
|------|---------|----------|-------------|-------------|
| knn warm | 64 | 6152 | 4258 | -31% |
| knn warm | 96 | 7491 | 4232 | -43% |
| knn warm | 128 | 6720 | 3486 | -48% |
| knn warm | 256 | 6634 | 1987 | -70% |

**Target**: 6-8k TPS consistently for both cold and warm phases

## Root Cause Analysis

The function definition appears correct (candidate_cap=40, min_rank=0.50 for fast mode), so the regression is likely due to:

1. **Configuration Differences**: PostgreSQL settings may have changed
2. **Environmental Factors**: Disk I/O, memory pressure, or other system resources
3. **Query Plan Changes**: Statistics or index usage may have changed
4. **Concurrency Bottlenecks**: The degradation worsens at higher concurrency (70% at 256 clients)

## Gold Configuration (Nov 22)

### Function Parameters
- **Fast mode**: `candidate_cap = LEAST(40, GREATEST((p_limit * 5) / 4, 25))` = **40** for LIMIT=50
- **min_rank**: **0.50**
- **Language**: PL/pgSQL (not SQL)

### PostgreSQL Settings
- `work_mem`: 32MB
- `effective_cache_size`: 4GB
- `random_page_cost`: 1.1
- `track_io_timing`: on
- `synchronous_commit`: off
- `max_parallel_workers`: 12
- `max_parallel_workers_per_gather`: 4
- `pg_trgm.similarity_threshold`: 0.40
- `jit`: off
- `enable_seqscan`: off

### Benchmark Settings
- `THREADS`: 12
- `LIMIT`: 50
- `DURATION`: 60s (or 180s for high concurrency)
- `USE_AUTO_WRAPPER`: false (use bare function)
- `USE_SQL_FUNCTION`: false (use PL/pgSQL)
- `TRACK_IO_TIMING`: on
- `TRGM_THRESHOLD`: 0.40

## Restoration Steps

### 1. Verify Function Definition

```bash
# Check current function
./scripts/diagnose-performance-regression.sh

# Verify function has correct parameters
psql -h localhost -p 5433 -U postgres -d records -c "
SELECT pg_get_functiondef(oid)
FROM pg_proc
WHERE proname = 'search_records_fuzzy_ids'
  AND pronargs = 5;
"
```

### 2. Run Benchmark with Gold Configuration

```bash
# Restore gold configuration
export USE_AUTO_WRAPPER=false
export USE_SQL_FUNCTION=false
export TRACK_IO_TIMING=on
export TRGM_THRESHOLD=0.40
export WORK_MEM_MB=32
export EFFECTIVE_CACHE_SIZE=4GB
export RANDOM_PAGE_COST=1.1
export MODE=deep  # Full sweep: 8,16,24,32,48,64,96,128,192,256
export RUN_COLD_CACHE=true  # Include cold cache tests
export DISABLE_AUTOVACUUM=true  # Prevent autovacuum interference

# Run benchmark
./scripts/run_pgbench_sweep.sh
```

### 3. Monitor During Benchmark

```bash
# In another terminal, monitor PostgreSQL
watch -n 1 'psql -h localhost -p 5433 -U postgres -d records -c "
SELECT 
  count(*) as active_connections,
  count(*) FILTER (WHERE state = '\''active'\'') as active_queries,
  count(*) FILTER (WHERE wait_event_type IS NOT NULL) as waiting
FROM pg_stat_activity
WHERE datname = '\''records'\'';
"'
```

### 4. Check for Bottlenecks

```bash
# Check lock contention
psql -h localhost -p 5433 -U postgres -d records -c "
SELECT 
  locktype,
  mode,
  count(*) as count
FROM pg_locks
GROUP BY locktype, mode
ORDER BY count DESC;
"

# Check I/O wait
psql -h localhost -p 5433 -U postgres -d records -c "
SELECT 
  datname,
  blks_read,
  blks_hit,
  round(100.0 * blks_hit / (blks_hit + blks_read), 2) as hit_ratio
FROM pg_stat_database
WHERE datname = 'records';
"
```

## Expected Results After Restoration

- **knn warm @ 64 clients**: ~6k TPS
- **knn warm @ 96 clients**: ~7.5k TPS
- **knn warm @ 128 clients**: ~6.7k TPS
- **knn warm @ 256 clients**: ~6.6k TPS

## Troubleshooting

If performance is still low:

1. **Check disk I/O**: `iostat -x 1`
2. **Check memory**: `free -h`
3. **Check PostgreSQL logs**: `docker logs <postgres-container>`
4. **Verify indexes**: Run `ANALYZE records.records;`
5. **Check for bloat**: `SELECT * FROM pg_stat_user_tables WHERE schemaname = 'records';`

## Fast Temp Tablespace (Optional)

To reduce p999 spikes:

```bash
# Setup fast temp tablespace
./scripts/setup-fast-temp-tablespace.sh

# Use it in benchmarks
export FAST_TEMP_TABLESPACE=fasttmp
./scripts/run_pgbench_sweep.sh
```

