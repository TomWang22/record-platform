# Listings Service k6 Load Test Suite

## Overview

Comprehensive load testing suite for the listings service with detailed latency percentile tracking (p1 to p99, p999, p9999, p99999, p999999, p9999999, p99999999, p100).

## Test Coverage

### Endpoints Tested

**Public Endpoints (No Auth Required):**
- `GET /api/listings/search` - Search listings
- `GET /api/listings/:id` - Get listing by ID
- `GET /api/listings/search/ebay` - eBay search integration
- `GET /api/listings/ratings/listing/:id` - Get ratings for a listing
- `GET /api/listings/ratings/seller/:id` - Get ratings for a seller

**Authenticated Endpoints (Auth Required):**
- `GET /api/listings/my-listings` - Get user's listings
- `POST /api/listings` - Create listing
- `PUT /api/listings/:id` - Update listing
- `DELETE /api/listings/:id` - Delete listing
- `POST /api/listings/:id/images` - Add image to listing
- `POST /api/listings/:id/bid` - Place bid on auction
- `POST /api/listings/:id/offer` - Make offer (OBO/Best Offer)
- `POST /api/listings/:id/watch` - Add to watchlist
- `DELETE /api/listings/:id/watch` - Remove from watchlist
- `GET /api/listings/watchlist/mine` - Get user's watchlist
- `POST /api/listings/ratings` - Create/update rating

## Latency Percentiles Tracked

The test suite tracks comprehensive latency percentiles:

- **Standard Percentiles**: p1, p5, p10, p25, p50 (median), p75, p90, p95, p99
- **Tail Percentiles**: p999, p9999, p99999, p999999, p9999999, p99999999
- **Maximum**: p100 (max observed latency)

All percentiles are reported in milliseconds and included in the generated HTML latency report.

## Usage

### Basic Test

```bash
# Run with default settings (50 VUs, 5 minutes)
./scripts/load/run-listings-tests.sh
```

### Custom Configuration

```bash
# High load test
VUS=200 DURATION=10m ./scripts/load/run-listings-tests.sh

# In-cluster testing
IN_CLUSTER=true BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000 \
  VUS=100 DURATION=5m ./scripts/load/run-listings-tests.sh

# Using NodePort
BASE_URL=https://record.local:30443 VUS=50 DURATION=5m ./scripts/load/run-listings-tests.sh
```

### Direct k6 Execution

```bash
# Run k6 directly
k6 run \
  --vus 50 \
  --duration 5m \
  --summary-export=results/listings-summary.json \
  -e BASE_URL=https://record.local:30443 \
  scripts/load/k6-listings-service-comprehensive.js
```

## Output Files

The test suite generates:

1. **JSON Summary**: `results/listings-comprehensive-{timestamp}.json`
   - Complete k6 metrics in JSON format
   - Includes all percentile data

2. **HTML Latency Report**: `results/listings-latency-report-{timestamp}.html`
   - Interactive charts and tables
   - All percentiles from p1 to p100
   - Component breakdown (search, create, bid, etc.)

3. **Test Output**: `results/listings-test-output-{timestamp}.txt`
   - Console output from k6 execution
   - Includes real-time metrics

## Latency Report Features

The generated HTML report includes:

- **Summary Metrics**: Total requests, duration, error rate, success rate
- **HTTP Latency Percentiles Chart**: Visual representation of all percentiles
- **Detailed Percentile Table**: All percentiles from p1 to p100 with descriptions
- **Component Latency Breakdown**: 
  - Search latency
  - Create listing latency
  - Bid latency
  - Offer latency
  - Watchlist latency
  - Rating latency
  - eBay search latency

## Thresholds

The test suite includes comprehensive thresholds:

- **HTTP Duration**: All percentiles from p1 to p100
- **Error Rate**: < 5% failures
- **Success Rates**: 
  - Search: > 95%
  - Create: > 90%
  - Update: > 90%
  - Bid: > 90%
  - Offer: > 90%
  - Watchlist: > 95%
  - eBay Search: > 80% (may be rate-limited)
  - Rating: > 95%

## Test Scenarios

The test simulates realistic user behavior:

1. **Public Browsing** (70% of traffic):
   - Search listings
   - View listing details
   - Browse eBay search results
   - View ratings

2. **Authenticated Actions** (30% of traffic):
   - Create listings
   - Update listings
   - Place bids
   - Make offers
   - Manage watchlist
   - Create ratings

## Custom Metrics

The test tracks custom metrics for each operation:

- `listings_search_latency_ms` - Search operation latency
- `listings_get_latency_ms` - Get listing latency
- `listings_create_latency_ms` - Create listing latency
- `listings_update_latency_ms` - Update listing latency
- `listings_bid_latency_ms` - Bid placement latency
- `listings_offer_latency_ms` - Offer creation latency
- `listings_watchlist_latency_ms` - Watchlist operations latency
- `listings_ebay_search_latency_ms` - eBay search latency
- `listings_rating_latency_ms` - Rating operations latency

## Environment Variables

- `BASE_URL`: Base URL for API (default: auto-detected)
- `IN_CLUSTER`: Set to "true" for in-cluster testing
- `API_HOST`: Host header for SNI (default: record.local)
- `VUS`: Number of virtual users (default: 50)
- `DURATION`: Test duration (default: 5m)
- `OUTPUT_DIR`: Output directory for results (default: scripts/load/results)

## Examples

### Example 1: Quick Smoke Test

```bash
VUS=10 DURATION=1m ./scripts/load/run-listings-tests.sh
```

### Example 2: Production Load Test

```bash
VUS=200 DURATION=30m ./scripts/load/run-listings-tests.sh
```

### Example 3: Soak Test

```bash
# Run for extended period with moderate load
VUS=50 DURATION=2h ./scripts/load/run-listings-tests.sh
```

### Example 4: In-Cluster Testing

```bash
# Run inside Kubernetes cluster
IN_CLUSTER=true \
  BASE_URL=http://api-gateway.record-platform.svc.cluster.local:4000 \
  VUS=100 DURATION=10m \
  ./scripts/load/run-listings-tests.sh
```

## Viewing Results

### HTML Report

Open the generated HTML report in a browser:

```bash
open results/listings-latency-report-{timestamp}.html
# or
xdg-open results/listings-latency-report-{timestamp}.html
```

### JSON Summary

Parse the JSON summary with jq:

```bash
jq '.metrics.http_req_duration.values' results/listings-comprehensive-{timestamp}.json
```

## Troubleshooting

### High Error Rates

If error rates are high:
1. Check service health: `kubectl get pods -n record-platform -l app=listings-service`
2. Check service logs: `kubectl logs -n record-platform -l app=listings-service --tail=100`
3. Verify database connectivity
4. Check for rate limiting

### Missing Percentiles

If some percentiles are missing in the report:
- k6 may not output all percentiles if there aren't enough samples
- Increase VUs or duration to get more data points
- The report will interpolate missing values where possible

### Authentication Failures

If authentication fails:
1. Verify auth-service is running
2. Check auth-service logs
3. Verify JWT token generation is working

## Integration with CI/CD

The test suite can be integrated into CI/CD pipelines:

```yaml
# Example GitHub Actions
- name: Run Listings Service Load Test
  run: |
    ./scripts/load/run-listings-tests.sh
  env:
    BASE_URL: ${{ secrets.TEST_API_URL }}
    VUS: 50
    DURATION: 5m
```

## Related Documentation

- [k6 Documentation](https://k6.io/docs/)
- [Listings Service API Documentation](../services/listings-service/README.md)
- [Latency Report Generation](./generate-latency-graph.py)

