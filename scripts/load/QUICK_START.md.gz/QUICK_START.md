# k6 Analytics Load Testing - Quick Start

## 🚀 Quick Commands

### Find Breaking Point (Start Here)
```bash
# Starts at 1K VU, ramps to 5K VU
k6 run scripts/load/k6-analytics-load-ramp.js

# Custom: Start at 2K, go to 10K
k6 run --env START_VUS=2000 --env MAX_VUS=10000 scripts/load/k6-analytics-load-ramp.js
```

### Read-Heavy Test (High Load)
```bash
# 1K → 3K VU, 90% reads, 10 minutes
k6 run scripts/load/k6-analytics-read-heavy.js

# Custom: 2K → 5K VU, 15 minutes
k6 run --env START_VUS=2000 --env MAX_VUS=5000 --env DURATION=15m scripts/load/k6-analytics-read-heavy.js
```

### Soak Test (Stability)
```bash
# 50 VU, 30 minutes
k6 run --vus 50 --duration 30m scripts/load/k6-analytics-soak.js

# Extended: 100 VU, 1 hour
k6 run --vus 100 --duration 1h scripts/load/k6-analytics-soak.js
```

### Run All Tests
```bash
./scripts/load/run-analytics-tests.sh
```

## 📊 Test Summary

| Test | VUs | Duration | Purpose |
|------|-----|----------|---------|
| Load Ramp | 1K → 5K | ~20m | Find breaking point |
| Read-Heavy | 1K → 3K | 10m | High read load |
| Soak | 50-100 | 30m-1h | Stability & memory leaks |
| Ingestion | 10 | 60s | Basic pipeline test |
| Data Quality | 5 | 30s | Validation test |
| Stress | 50 | 5m | High concurrent load |

## 🎯 What Gets Tested

- ✅ Percentiles p1-p100 calculation
- ✅ Python AI readiness (validation score ≥ 0.8)
- ✅ Data quality (confidence ≥ 0.7, completeness ≥ 0.75)
- ✅ Statistical consistency
- ✅ Performance under extreme load
- ✅ Breaking point identification
- ✅ Memory leak detection

## 📈 Expected Results

### Load Ramp Test
- **Breaking Point**: Usually between 2K-5K VU
- **Error Rate**: Should stay < 20% until breaking point
- **Throughput**: Should increase linearly until breaking point

### Read-Heavy Test
- **Read Latency**: P95 < 2s, P99 < 5s
- **Cache Hit Rate**: Should be > 50% for repeated queries
- **Throughput**: 1000+ ops/sec at 3K VU

### Soak Test
- **Memory Leak**: Response times should stay stable
- **Error Rate**: Should stay < 5% throughout
- **Data Quality**: Should remain consistent

## 🔧 Configuration

### Environment Variables
```bash
ANALYTICS_URL=http://localhost:4004
AUCTION_MONITOR_URL=http://localhost:4008
START_VUS=1000          # Starting VUs
MAX_VUS=5000            # Maximum VUs
STEP_VUS=500             # VU increment per step
STEP_DURATION=2m         # Duration per step
DURATION=10m             # Total test duration
```

### Custom Test Run
```bash
ANALYTICS_URL=http://localhost:4004 \
START_VUS=2000 \
MAX_VUS=10000 \
k6 run scripts/load/k6-analytics-load-ramp.js
```

## 📋 Results

Results are saved to:
- Console output (summary)
- `scripts/load/results/analytics-*.json`

View results:
```bash
cat scripts/load/results/analytics-*.json | jq
```

---

**Ready to find breaking points!** 🚀

