# Analytics Service - Frontend Integration Guide

## Overview

The Analytics Service provides granular price analytics data to the frontend via REST API endpoints. It also publishes real-time events to Kafka for live updates.

## API Gateway Routes

All analytics endpoints are accessible through the API Gateway at `/analytics/*`:

- **Base URL**: `http://localhost:3000/api/analytics` (via API Gateway)
- **Direct URL**: `http://localhost:4004/analytics` (direct service access)

## Frontend Endpoints

### 1. Price Prediction

**Endpoint**: `POST /analytics/predict-price`

**Request**:
```json
{
  "items": [
    {
      "query": "The Beatles Abbey Road",
      "base_price": 50.00,
      "record_grade": "NM",
      "sleeve_grade": "VG+",
      "promo": false,
      "anniversary_boost": 0.0
    }
  ]
}
```

**Response**:
```json
{
  "suggested": 52.50,
  "samples": 1
}
```

**Kafka Event**: Published to `analytics-predictions` topic

### 2. User Search History

**Endpoint**: `GET /analytics/user/:userId/history?limit=50`

**Response**:
```json
{
  "userId": "user-123",
  "history": [
    {
      "query": "The Beatles Abbey Road",
      "source": "ebay",
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "count": 1
}
```

### 3. Similar Searches / Recommendations

**Endpoint**: `GET /analytics/recommendations/similar?q=The Beatles&userId=user-123&limit=10`

**Response**:
```json
{
  "query": "The Beatles",
  "recommendations": [
    {
      "query": "The Beatles White Album",
      "count": 15,
      "last_searched": "2024-01-15T10:30:00Z"
    }
  ],
  "count": 1
}
```

### 4. Trending Searches

**Endpoint**: `GET /analytics/trending?days=7&limit=20`

**Response**:
```json
{
  "days": 7,
  "trending": [
    {
      "query": "The Beatles Abbey Road",
      "count": 42,
      "trend": "up"
    }
  ],
  "count": 1
}
```

### 5. Price Trends

**Endpoint**: `GET /analytics/price-trend?artist=The Beatles&name=Abbey Road&format=LP&days=90`

**Response**:
```json
{
  "artist": "The Beatles",
  "name": "Abbey Road",
  "format": "LP",
  "days": 90,
  "trends": [
    {
      "price": 50.00,
      "snapshot_date": "2024-01-15T00:00:00Z"
    }
  ],
  "count": 1
}
```

### 6. Log Search

**Endpoint**: `POST /analytics/log-search`

**Request**:
```json
{
  "userId": "user-123",
  "source": "ebay",
  "query": "The Beatles Abbey Road",
  "results": ["result-1", "result-2"]
}
```

**Response**:
```json
{
  "ok": true,
  "logged": true
}
```

**Kafka Event**: Published to `analytics-searches` topic

### 7. Fuzzy Search

**Endpoint**: `GET /analytics/fuzzy-search?q=Beatles Abbey&userId=user-123&limit=20`

**Response**:
```json
{
  "query": "Beatles Abbey",
  "results": {
    "similarSearches": [...],
    "priceMatches": [...],
    "searchHistory": [...]
  },
  "count": 15
}
```

## Kafka Topics

The Analytics Service publishes events to the following Kafka topics:

### `analytics-predictions`
Price prediction events when `/analytics/predict-price` is called.

**Event Format**:
```json
{
  "event_type": "price_prediction",
  "items": [...],
  "suggested_price": 52.50,
  "sample_count": 1,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### `analytics-searches`
Search logging events when `/analytics/log-search` is called.

**Event Format**:
```json
{
  "event_type": "search_logged",
  "user_id": "user-123",
  "source": "ebay",
  "query": "The Beatles Abbey Road",
  "results_count": 2,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

## Frontend Integration Examples

### React Example

```typescript
// Fetch price prediction
const predictPrice = async (items: PredictItem[]) => {
  const response = await fetch('/api/analytics/predict-price', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items }),
  })
  const data = await response.json()
  return data.suggested
}

// Get trending searches
const getTrending = async (days = 7) => {
  const response = await fetch(`/api/analytics/trending?days=${days}`)
  const data = await response.json()
  return data.trending
}

// Log search
const logSearch = async (query: string, source: string) => {
  await fetch('/api/analytics/log-search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: currentUser.id,
      source,
      query,
    }),
  })
}
```

### Kafka Consumer Example (for real-time updates)

```typescript
import { kafka } from '@common/utils/kafka'

const consumer = kafka.consumer({ groupId: 'frontend-analytics' })
await consumer.subscribe({ topics: ['analytics-predictions', 'analytics-searches'] })

await consumer.run({
  eachMessage: async ({ topic, partition, message }) => {
    const event = JSON.parse(message.value?.toString() || '{}')
    
    if (topic === 'analytics-predictions') {
      // Update UI with new prediction
      updatePricePrediction(event)
    } else if (topic === 'analytics-searches') {
      // Update search history in real-time
      updateSearchHistory(event)
    }
  },
})
```

## Integration with Python AI Service

The Analytics Service provides data to the Python AI Service, which then exposes enhanced endpoints:

- `/ai/predict-price` - Enhanced price predictions with AI
- `/ai/recommendations` - AI-powered recommendations
- `/ai/trending` - Trending items with AI insights
- `/ai/price-trends` - Price trends with AI analysis
- `/ai/chat` - Chatbot with analytics context

See `services/python-ai-service/FRONTEND_INTEGRATION.md` for Python AI frontend integration.

## Authentication

All endpoints require authentication via JWT token (except `/analytics/healthz`).

Include the token in the `Authorization` header:
```
Authorization: Bearer <jwt-token>
```

The API Gateway automatically injects user identity headers (`x-user-id`, `x-user-email`) for authenticated requests.

