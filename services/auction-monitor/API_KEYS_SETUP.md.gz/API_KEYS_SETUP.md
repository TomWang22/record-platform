# API Keys Setup Guide

This guide will help you obtain API keys for all platforms supported by the Auction Monitor service.

## eBay API Setup

### Step 1: Create eBay Developer Account

1. Go to [eBay Developers Program](https://developer.ebay.com/)
2. Click **"Join the Program"** or **"Sign In"** if you already have an account
3. Complete the registration (use your existing eBay account)

### Step 2: Create an Application

1. After signing in, go to **"My Account"** → **"Keys"**
2. Click **"Create an App Key"**
3. Fill in the form:
   - **App Name**: `Record Platform Auction Monitor`
   - **App Purpose**: Select "I want to sell items on eBay" or "I want to search for items"
   - **Company/Individual**: Your choice
   - **Website URL**: Your website (or `https://example.com` for testing)
   - **OAuth Redirect URI**: `http://localhost:8080/oauth/ebay/callback` (for local dev)
4. Click **"Create App Key"**

### Step 3: Get Your Credentials

You'll receive:
- **App ID (Client ID)**: `YourAppID-Prod-XXXX-XXXX-XXXX-XXXX-XXXX`
- **Dev ID**: `YourDevID-XXXX-XXXX-XXXX-XXXX-XXXX`
- **Cert ID (Client Secret)**: `YourCertID-XXXX-XXXX-XXXX-XXXX-XXXX`

**For Sandbox (Testing):**
- Go to **"Sandbox Keys"** tab
- Create a sandbox app key (same process)
- Use sandbox credentials for testing

### Step 4: Get OAuth Token (Production)

For production, you need an OAuth token:

1. **Option A: User Token (for your own account)**
   - Go to [eBay OAuth Token Generator](https://developer.ebay.com/my/keys)
   - Click **"Get a User Token"**
   - Select scopes: `https://api.ebay.com/oauth/api_scope/buy.marketplace.search`
   - Authorize and copy the token

2. **Option B: Application Token (for public searches)**
   - Go to **"My Account"** → **"Keys"**
   - Click **"Get a Token from eBay via Your Client ID and Secret"**
   - Use your App ID and Cert ID
   - Copy the access token

### Step 5: Environment Variables

Add to your `.env` or environment:

```bash
# eBay API (Production)
EBAY_APP_ID="YourAppID-Prod-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_DEV_ID="YourDevID-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_CERT_ID="YourCertID-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_AUTH_TOKEN="v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sIAAAAAAAAAOVXa2wUVR..."

# eBay API (Sandbox - for testing)
EBAY_SANDBOX=true
EBAY_SANDBOX_APP_ID="YourAppID-SBX-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_SANDBOX_DEV_ID="YourSandboxDevID-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_SANDBOX_CERT_ID="YourSandboxCertID-XXXX-XXXX-XXXX-XXXX-XXXX"
```

### eBay API Limits

- **Production**: 5,000 requests/day (with app key)
- **Sandbox**: Unlimited (for testing)
- **Rate Limit**: ~5 requests/second

## Discogs API Setup

### Step 1: Create Discogs Account

1. Go to [Discogs](https://www.discogs.com/)
2. Sign up or sign in with your existing account

### Step 2: Get API Token

1. Go to [Discogs Settings → Developer](https://www.discogs.com/settings/developers)
2. Click **"Generate New Token"**
3. Give it a name: `Record Platform Auction Monitor`
4. Copy the token (you'll only see it once!)

### Step 3: Environment Variables

```bash
# Discogs API
DISCOGS_USER_TOKEN="your_discogs_token_here"
```

### Discogs API Limits

- **Unauthenticated**: 60 requests/minute
- **Authenticated**: 60 requests/minute (but higher rate limit)
- **No daily limit** (just per-minute)

## Buyee (No API - Scraping Only)

Buyee doesn't have a public API. The service uses web scraping with Puppeteer.

**No API keys needed** - but be respectful:
- Rate limit: 1 request per 2 seconds
- Respect `robots.txt`
- Handle CAPTCHAs if they appear

## YahooJP Auctions (No API - Scraping Only)

YahooJP Auctions doesn't have a public API. The service uses web scraping.

**No API keys needed** - but be respectful:
- Rate limit: 1 request per 2 seconds
- Use Japanese user agent
- Handle CAPTCHAs if they appear

## CarousellHK (No API - Scraping Only)

CarousellHK doesn't have a public API. The service uses web scraping.

**No API keys needed** - but be respectful:
- Rate limit: 1 request per 2 seconds
- Use mobile user agent (mobile-first site)

## RecordCity (No API - Scraping Only)

RecordCity doesn't have a public API. The service uses web scraping across multiple regions.

**No API keys needed** - but be respectful:
- Rate limit: 1 request per 2 seconds per region
- Regions: UK, US, EU

## Complete Environment Variables

Create a `.env` file in `services/auction-monitor/`:

```bash
# Database
POSTGRES_URL_AUCTION_MONITOR=postgresql://postgres:postgres@localhost:5438/auction_monitor
POSTGRES_URL_ANALYTICS=postgresql://postgres:postgres@localhost:5439/analytics

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_PASSWORD=

# eBay API (Production)
EBAY_APP_ID=YourAppID-Prod-XXXX-XXXX-XXXX-XXXX-XXXX
EBAY_DEV_ID=YourDevID-XXXX-XXXX-XXXX-XXXX-XXXX
EBAY_CERT_ID=YourCertID-XXXX-XXXX-XXXX-XXXX-XXXX
EBAY_AUTH_TOKEN=v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sIAAAAAAAAAOVXa2wUVR...
EBAY_SANDBOX=false

# eBay API (Sandbox - for testing)
# EBAY_SANDBOX=true
# EBAY_SANDBOX_APP_ID=YourAppID-SBX-XXXX-XXXX-XXXX-XXXX-XXXX
# EBAY_SANDBOX_DEV_ID=YourSandboxDevID-XXXX-XXXX-XXXX-XXXX-XXXX
# EBAY_SANDBOX_CERT_ID=YourSandboxCertID-XXXX-XXXX-XXXX-XXXX-XXXX

# Discogs API
DISCOGS_USER_TOKEN=your_discogs_token_here

# Kafka (optional)
KAFKA_BROKER=kafka:9092
KAFKA_CLIENT_ID=auction-monitor

# Service Ports
PORT=4008
GRPC_PORT=50059
```

## Testing Your API Keys

### Test eBay API

```bash
cd services/auction-monitor
POSTGRES_URL_AUCTION_MONITOR="postgresql://postgres:postgres@localhost:5438/auction_monitor" \
EBAY_APP_ID="your_app_id" \
EBAY_AUTH_TOKEN="your_token" \
npx tsx -e "
import { eBayAdapter } from './src/platforms/ebay/adapter';
const adapter = new eBayAdapter({
  appId: process.env.EBAY_APP_ID!,
  authToken: process.env.EBAY_AUTH_TOKEN,
  sandbox: false
});
adapter.search({ query: 'The Beatles', limit: 5 }).then(listings => {
  console.log('✅ eBay API working! Found', listings.length, 'listings');
}).catch(err => {
  console.error('❌ eBay API error:', err.message);
});
"
```

### Test Discogs API

```bash
cd services/auction-monitor
DISCOGS_USER_TOKEN="your_token" \
npx tsx -e "
import { DiscogsAdapter } from './src/platforms/discogs/adapter';
const adapter = new DiscogsAdapter({
  userToken: process.env.DISCOGS_USER_TOKEN!
});
adapter.search({ query: 'The Beatles Abbey Road', limit: 5 }).then(listings => {
  console.log('✅ Discogs API working! Found', listings.length, 'listings');
}).catch(err => {
  console.error('❌ Discogs API error:', err.message);
});
"
```

## Security Best Practices

1. **Never commit API keys to git**
   - Add `.env` to `.gitignore`
   - Use environment variables in production
   - Use Kubernetes secrets for production

2. **Rotate keys regularly**
   - eBay tokens expire (check expiration)
   - Discogs tokens don't expire but can be revoked

3. **Use different keys for dev/prod**
   - Sandbox keys for development
   - Production keys for production

4. **Monitor API usage**
   - Track rate limits
   - Monitor quota usage
   - Set up alerts for quota exhaustion

## Troubleshooting

### eBay API Issues

**Error: "Invalid App ID"**
- Check that you're using the correct App ID (Production vs Sandbox)
- Verify the App ID is active in your eBay developer account

**Error: "Invalid OAuth Token"**
- Tokens expire after a certain time
- Regenerate token from eBay developer portal
- Check token scopes match your needs

**Error: "Rate limit exceeded"**
- eBay limits: 5,000 requests/day
- Use rate limiting in the service (already implemented)
- Consider caching results

### Discogs API Issues

**Error: "Invalid token"**
- Verify token is correct (no extra spaces)
- Check token hasn't been revoked
- Regenerate token if needed

**Error: "Rate limit exceeded"**
- Discogs: 60 requests/minute
- Service already implements rate limiting
- Use Redis caching to reduce API calls

## Quick Start Checklist

- [ ] Create eBay developer account
- [ ] Get eBay App ID, Dev ID, Cert ID
- [ ] Get eBay OAuth token
- [ ] Create Discogs account
- [ ] Get Discogs API token
- [ ] Add all keys to `.env` file
- [ ] Test eBay API connection
- [ ] Test Discogs API connection
- [ ] Start the ingestion worker

## Resources

- [eBay Developers Program](https://developer.ebay.com/)
- [eBay API Documentation](https://developer.ebay.com/api-docs/static/rest-landing.html)
- [Discogs API Documentation](https://www.discogs.com/developers)
- [Discogs API Rate Limits](https://www.discogs.com/developers#page:home,header:home-rate-limiting)

