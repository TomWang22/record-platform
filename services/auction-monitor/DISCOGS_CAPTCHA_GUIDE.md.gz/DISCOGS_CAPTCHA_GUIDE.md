# Discogs CAPTCHA Handling Guide

## Problem

Discogs shows CAPTCHA when:
- Viewing price trends/history pages
- Accessing detailed price statistics
- Making high-frequency API requests
- Accessing certain marketplace data

## Solution: Browser Automation

Use Puppeteer (already set up in `browser-pool.ts`) to:
1. Navigate to Discogs pages
2. Handle CAPTCHA (manual or automated)
3. Extract price history data
4. Return as structured data

## Implementation Plan

### 1. Browser Pool (Already Set Up)

**File**: `services/auction-monitor/src/lib/browser-pool.ts`

The browser pool is already configured with:
- Puppeteer instances
- Headless Chrome
- Resource limits
- Cleanup on shutdown

### 2. Discogs Price History Scraper

**File**: `services/auction-monitor/src/platforms/discogs/price-history-scraper.ts` (to be created)

```typescript
import { Browser } from 'puppeteer'
import { getBrowserPool } from '../../lib/browser-pool'

export async function scrapeDiscogsPriceHistory(releaseId: number): Promise<CompletedSale[]> {
  const browser = await getBrowserPool().acquire()
  const page = await browser.newPage()
  
  try {
    // Navigate to release page
    await page.goto(`https://www.discogs.com/release/${releaseId}`, {
      waitUntil: 'networkidle2',
      timeout: 30000,
    })
    
    // Check for CAPTCHA
    const captchaPresent = await page.$('iframe[src*="captcha"]') !== null
    
    if (captchaPresent) {
      // Option 1: Wait for manual solving (development)
      console.log('[Discogs] CAPTCHA detected, waiting for manual solve...')
      await page.waitForSelector('iframe[src*="captcha"]', { hidden: true, timeout: 120000 })
      
      // Option 2: Use CAPTCHA solving service (production)
      // const solved = await solveCaptcha(page)
    }
    
    // Navigate to price history tab
    await page.click('a[href*="price-history"]')
    await page.waitForSelector('.price-history-table', { timeout: 10000 })
    
    // Extract price data
    const prices = await page.evaluate(() => {
      const rows = Array.from(document.querySelectorAll('.price-history-table tr'))
      return rows.map(row => {
        const cells = row.querySelectorAll('td')
        return {
          date: cells[0]?.textContent?.trim(),
          price: cells[1]?.textContent?.trim(),
          currency: cells[2]?.textContent?.trim(),
        }
      })
    })
    
    // Convert to CompletedSale format
    return prices.map(p => ({
      platform: 'discogs',
      externalId: String(releaseId),
      soldPrice: parseFloat(p.price.replace(/[^0-9.]/g, '')),
      currency: p.currency || 'USD',
      soldAt: new Date(p.date),
    }))
  } finally {
    await page.close()
    await getBrowserPool().release(browser)
  }
}
```

### 3. CAPTCHA Solving Options

#### Option A: Manual (Development)
- Wait for user to solve CAPTCHA manually
- Useful for testing and development
- Not suitable for production

#### Option B: Automated Solving Service (Production)
- Use services like:
  - 2Captcha
  - AntiCaptcha
  - DeathByCaptcha
- Integrate via API
- Cost: ~$1-3 per 1000 CAPTCHAs

#### Option C: Rate Limiting (Prevention)
- Reduce request frequency
- Use Discogs API rate limits (60 requests/minute)
- Cache results aggressively
- Use Redis singleflight pattern (already implemented)

### 4. Integration with Discogs Adapter

**File**: `services/auction-monitor/src/platforms/discogs/adapter.ts`

Update `getCompletedSales()` to use browser automation:

```typescript
async getCompletedSales(criteria: SearchCriteria): Promise<CompletedSale[]> {
  // Try API first
  const apiResults = await this.getCompletedSalesFromAPI(criteria)
  
  if (apiResults.length > 0) {
    return apiResults
  }
  
  // Fall back to browser scraping for price history
  const releaseId = await this.findReleaseId(criteria.query)
  if (releaseId) {
    return await scrapeDiscogsPriceHistory(releaseId)
  }
  
  return []
}
```

## Rate Limiting Strategy

1. **API First**: Always try Discogs API first (no CAPTCHA)
2. **Cache Aggressively**: Use Redis to cache price history (24-hour TTL)
3. **Singleflight**: Use Redis Lua script to prevent duplicate requests
4. **Browser Fallback**: Only use browser when API doesn't provide data
5. **CAPTCHA Detection**: Check for CAPTCHA before scraping
6. **Retry Logic**: Exponential backoff on CAPTCHA errors

## Current Status

- ✅ Browser pool configured
- ✅ Discogs API adapter working
- ⚠️ Price history scraper: **Not yet implemented**
- ⚠️ CAPTCHA handling: **Not yet implemented**

## Next Steps

1. **Implement price history scraper** (see code above)
2. **Add CAPTCHA detection** (check for iframe)
3. **Integrate CAPTCHA solving service** (for production)
4. **Add caching** (Redis with 24-hour TTL)
5. **Add rate limiting** (prevent CAPTCHA triggers)

---

**Note**: For now, the Discogs adapter works for listing search and details. Price history can be added later when browser automation is fully implemented.

