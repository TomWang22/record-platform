# eBay API Setup - Step by Step Guide

You're at the right place! Follow these steps to create your eBay API keys.

## Step 1: Create Production Keyset

1. **Click "Create a keyset"** under the **Production** section

2. **Fill in the Application Title:**
   ```
   Record Platform Auction Monitor
   ```
   (Or any name you prefer - this is just for your reference)

3. **Click "Create"** or "Continue"

4. **You'll receive your keys:**
   - **App ID (Client ID)**: `YourAppID-Prod-XXXX-XXXX-XXXX-XXXX-XXXX`
   - **Dev ID**: `YourDevID-XXXX-XXXX-XXXX-XXXX-XXXX`
   - **Cert ID (Secret)**: `YourCertID-XXXX-XXXX-XXXX-XXXX-XXXX`
   
   ⚠️ **IMPORTANT**: Copy these immediately! You may not see the Cert ID again.

## Step 2: Create Sandbox Keyset (Optional, for Testing)

1. **Click "Create a keyset"** under the **Sandbox** section
2. **Use the same Application Title**: `Record Platform Auction Monitor`
3. **Copy your Sandbox keys** (same format, but with `-SBX-` instead of `-Prod-`)

## Step 3: Get OAuth Token

After creating your keyset, you need an OAuth token to make API calls.

### Option A: User Token (Recommended for Personal Use)

1. **Find your Production keyset** in the list
2. **Click on your App ID** or look for **"User Tokens"** button
3. **Click "Get a User Token"** or **"Generate Token"**
4. **Select Scopes:**
   - ✅ `https://api.ebay.com/oauth/api_scope/buy.marketplace.search` (for searching)
   - ✅ `https://api.ebay.com/oauth/api_scope/buy.marketplace.shopping` (for item details)
5. **Authorize** the application
6. **Copy the token** - it will look like: `v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sIAAAAAAAAAOVXa2wUVR...`

### Option B: Application Token (For Public Searches Only)

1. Go to: https://api.ebay.com/identity/v1/oauth2/token
2. Use HTTP Basic Auth:
   - Username: Your **App ID (Client ID)**
   - Password: Your **Cert ID (Secret)**
3. POST request with:
   ```
   grant_type=client_credentials
   scope=https://api.ebay.com/oauth/api_scope/buy.marketplace.search
   ```
4. Copy the `access_token` from the response

## Step 4: Save Your Keys

Create a `.env` file in `services/auction-monitor/`:

```bash
# eBay Production Keys
EBAY_APP_ID="YourAppID-Prod-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_DEV_ID="YourDevID-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_CERT_ID="YourCertID-XXXX-XXXX-XXXX-XXXX-XXXX"
EBAY_AUTH_TOKEN="v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sI..."

# Use Production (set to false for sandbox)
EBAY_SANDBOX=false

# Database
POSTGRES_URL_AUCTION_MONITOR="postgresql://postgres:postgres@localhost:5438/auction_monitor"
POSTGRES_URL_ANALYTICS="postgresql://postgres:postgres@localhost:5439/analytics"

# Discogs (get from https://www.discogs.com/settings/developers)
DISCOGS_USER_TOKEN="your_discogs_token_here"

# Redis
REDIS_URL="redis://localhost:6379/0"
```

## Step 5: Test Your Keys

```bash
cd services/auction-monitor
npx tsx scripts/test-api-keys.ts
```

## What Each Key Does

- **App ID (Client ID)**: Identifies your application to eBay
- **Dev ID**: Identifies you as the developer
- **Cert ID (Secret)**: Secret key (like a password) - keep this private!
- **OAuth Token**: Allows your app to make API calls on your behalf

## Important Notes

1. **Keep Cert ID Secret**: Never share it or commit it to git
2. **Token Expiration**: User tokens may expire - check the expiration date
3. **Rate Limits**: Production keys have 5,000 requests/day limit
4. **Sandbox**: Use sandbox keys for testing (unlimited requests)

## Troubleshooting

**"Invalid App ID"**
- Make sure you're using Production keys for production, Sandbox for sandbox
- Check for typos (especially the `-Prod-` vs `-SBX-` part)

**"Invalid Token"**
- Tokens expire - generate a new one
- Make sure you selected the correct scopes

**"Rate limit exceeded"**
- You've hit the 5,000 requests/day limit
- Wait 24 hours or use Sandbox for testing

## Next Steps

After you have your keys:

1. Save them to `.env` file
2. Test with: `npx tsx scripts/test-api-keys.ts`
3. Start the worker: `npm run start:worker`

---

**Need Help?** The eBay Developer Portal has detailed documentation at https://developer.ebay.com/

