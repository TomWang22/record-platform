# Getting Your eBay OAuth Token

You're on the right page! Now you need to get a User Token (OAuth token) to make API calls.

## What You're Looking At

You're on the **User Tokens** page for your App ID: `DailinWa-recordpl-PRD-672dab605-b3c26e79`

The "Alerts & Notifications" section is for advanced features - **you can skip this for now**.

## Step 1: Get Your OAuth Token

### Option A: Direct Token Generation (Easiest)

1. **Look for a button or link** that says:
   - "Get a User Token"
   - "Generate Token"
   - "Create Token"
   - "OAuth Token"
   - Or look for "eBay Sign-in" link

2. **Click it** - it will redirect you to eBay's OAuth page

3. **Sign in** with your eBay account (if not already signed in)

4. **Authorize the application** - eBay will ask you to allow the app to:
   - Search for items
   - View item details
   - (These are the permissions needed)

5. **Copy the token** - After authorization, you'll see a token that looks like:
   ```
   v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sIAAAAAAAAAOVXa2wUVR...
   ```
   ⚠️ **Copy this immediately!** You might not see it again.

### Option B: If You Don't See a Token Button

1. **Look for "eBay Sign-in"** link or button
2. **Or go directly to**: https://auth.ebay.com/oauth2/authorize
3. **Use these parameters:**
   - `client_id`: Your App ID (`DailinWa-recordpl-PRD-672dab605-b3c26e79`)
   - `redirect_uri`: `http://localhost:8080/oauth/ebay/callback` (or your callback URL)
   - `response_type`: `code`
   - `scope`: `https://api.ebay.com/oauth/api_scope/buy.marketplace.search`

4. **After authorization**, you'll get a code that you can exchange for a token

## Step 2: Save Your Complete Keys

You now have:
- ✅ **App ID**: `DailinWa-recordpl-PRD-672dab605-b3c26e79`
- ⏳ **Dev ID**: (from the keyset page - go back if you didn't copy it)
- ⏳ **Cert ID**: (from the keyset page - go back if you didn't copy it)
- ⏳ **OAuth Token**: (what you're getting now)

## Step 3: Quick Setup

Once you have all 4 values, run:

```bash
cd services/auction-monitor
./scripts/setup-api-keys.sh
```

Or manually create `.env`:

```bash
EBAY_APP_ID="DailinWa-recordpl-PRD-672dab605-b3c26e79"
EBAY_DEV_ID="your_dev_id_here"
EBAY_CERT_ID="your_cert_id_here"
EBAY_AUTH_TOKEN="your_oauth_token_here"
EBAY_SANDBOX=false
```

## What If You Can't Find the Token Button?

1. **Go back to the keys list**: https://developer.ebay.com/my/keys
2. **Click on your App ID** (`DailinWa-recordpl-PRD-672dab605-b3c26e79`)
3. **Look for "User Tokens" tab** or section
4. **Or use the OAuth URL directly** (see Option B above)

## Testing Your Token

After you have all keys:

```bash
cd services/auction-monitor
npx tsx scripts/test-api-keys.ts
```

## Important Notes

- **Token Expiration**: User tokens may expire (check expiration date)
- **Scopes**: Make sure you selected the search scope
- **Keep It Secret**: Never share your token or commit it to git

---

**Next**: Once you have the token, we'll test it and start the worker!

