# Getting eBay User Access Token

## ✅ You're on the Right Page!

You're on the User Tokens page. Here's what to do:

## Step-by-Step Instructions

### Step 1: Use OAuth (New Security)

Under the **"OAuth (new security)"** section, click:

**"Sign in to Production"**

This is the button/link that will start the OAuth flow.

### Step 2: Sign In and Authorize

1. You'll be redirected to eBay's sign-in page
2. **Sign in** with your eBay account
3. **Review the permissions** - you'll see what the app can access
4. **Click "Agree and Continue"** or similar button

### Step 3: Copy the Token

After authorization, you'll be redirected back and see your token displayed. It will look like:
```
v^1.1#i^1#p^1#r^0#I^3#f^0#t^H4sIAAAAAAAAAOVXa2wUVR...
```

**Copy this token immediately!**

### Step 4: Update .env File

Replace the Application Token with the User Token:

```bash
cd services/auction-monitor
# Edit .env and replace EBAY_AUTH_TOKEN with your User Token
EBAY_AUTH_TOKEN="paste_your_user_token_here"
```

Or use sed:
```bash
sed -i '' 's|EBAY_AUTH_TOKEN=".*"|EBAY_AUTH_TOKEN="your_user_token_here"|' .env
```

### Step 5: Test

```bash
npx tsx scripts/test-api-keys.ts
```

## What You'll See

When you click "Sign in to Production", you'll see a consent page showing:
- What permissions the app needs
- Terms of service
- "Agree and Continue" button

## Important Notes

- **User Tokens expire**: They typically expire in 2 hours (OAuth) or 18 months (Auth'n'Auth)
- **Keep it secure**: Don't share your User Token
- **For production**: You'll need to implement token refresh for long-running applications

## Alternative: Auth'n'Auth (Older Method)

If OAuth doesn't work, you can try the older "Auth'n'Auth" method, but OAuth is recommended for new applications.

---

**Action**: Click "Sign in to Production" under OAuth section! 🚀

