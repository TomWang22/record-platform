# eBay Keyset Disabled - How to Fix

## What You're Seeing

Your Production keyset shows:
- **Alert**: "Your Keyset is currently disabled"
- **Reason**: "Comply with marketplace deletion/account closure notification process or apply for an exemption"

This is why your app shows "non compliant" - eBay requires you to set up notifications for account deletion events.

## Two Options to Fix

### Option 1: Apply for Exemption (Easiest)

If you're just building a personal tool or don't need to handle account deletions:

1. **Click on your keyset** (the "record platform" entry under Production)
2. **Look for**: "Apply for exemption" or "Request exemption" link/button
3. **Fill out the form** - usually just need to explain why you don't need notifications
4. **Submit** - eBay will review (usually quick for personal apps)

### Option 2: Set Up Notifications (If You Need Full Compliance)

1. **Click on your keyset** ("record platform")
2. **Go to "Alerts & Notifications" tab** (you saw this earlier)
3. **Fill out the form:**
   - **Marketplace account deletion notification endpoint**: Enter an HTTPS URL (can be a placeholder for now)
   - **Verification token**: Generate a random token
   - **Email**: Your email (`tomwang22@yahoo.com` is already there)
   - **Check**: "Notify me if eBay stops sending me notifications"
4. **Click "Save"**

## Get Your Cert ID (Even If Disabled)

Even with the keyset disabled, you should still be able to see your keys:

1. **Click on "record platform"** under Production
2. **Look for your keys** (they might be visible or need to click "Show")
3. **Copy**:
   - **Dev ID**
   - **Cert ID (Secret)** - click "Show" or "Reveal" if hidden

## Try Application Token (Might Still Work)

Even with a disabled keyset, the Application Token might still work for basic API calls:

```bash
cd services/auction-monitor
EBAY_APP_ID='DailinWa-recordpl-PRD-672dab605-b3c26e79' \
EBAY_CERT_ID='your_cert_id_here' \
./scripts/get-ebay-app-token.sh
```

If it works, you're good to go! If it fails, you'll need to fix the compliance issue first.

## Quick Fix Steps

1. **Click on "record platform"** under Production
2. **Try to get your Cert ID** (click "Show" if needed)
3. **Either**:
   - Apply for exemption (easiest)
   - OR set up the notification endpoint
4. **Wait for approval** (usually 24-48 hours)
5. **Then get your token**

## Alternative: Use Sandbox for Testing

While waiting for Production approval:

1. **Create a Sandbox keyset** (click "Create a keyset" under Sandbox)
2. **Get Sandbox keys** (App ID, Dev ID, Cert ID)
3. **Use Sandbox for testing** (unlimited calls, no compliance needed)
4. **Switch to Production later** once approved

---

**Action**: Click on "record platform" to see your keys and either apply for exemption or set up notifications! 🚀

