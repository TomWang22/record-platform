# ngrok Setup - Ready to Use!

## ✅ Status

- **Webhook server**: Running on port 3000 ✅
- **ngrok**: Starting up...

## Get Your ngrok URL

The webhook server is already running. Now you need to start ngrok in a **new terminal window**:

### Option 1: Use the Helper Script

```bash
cd services/auction-monitor
./scripts/start-ngrok-webhook.sh
```

### Option 2: Manual Start

```bash
ngrok http 3000
```

## What You'll See

ngrok will display something like:

```
Session Status                online
Account                       Your Account (Plan: Free)
Version                       3.x.x
Region                        United States (us)
Latency                       -
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://abc123xyz.ngrok.io -> http://localhost:3000
```

## Copy the HTTPS URL

Copy the URL from the "Forwarding" line:
- Example: `https://abc123xyz.ngrok.io`

## Use in eBay Form

Go back to eBay's notification form and enter:

1. **Marketplace account deletion notification endpoint**:
   ```
   https://abc123xyz.ngrok.io/ebay/notifications
   ```
   (Replace with your actual ngrok URL)

2. **Verification token**:
   ```
   ebay_verify_abc123xyz789
   ```

3. **Email**: Already filled ✅

4. **Click "Save"**

## Keep ngrok Running

**Important**: Keep the ngrok terminal window open while eBay verifies your endpoint. Once verified, you can close it.

## Alternative: Get URL from ngrok Web Interface

ngrok also provides a web interface:
- Open: http://127.0.0.1:4040
- You'll see your public URL there

---

**Action**: Start ngrok in a new terminal, copy the HTTPS URL, and use it in eBay's form! 🚀

