# Setting Up ngrok for eBay Webhook

## Quick Setup

I've installed ngrok and started the webhook server. Here's what to do:

### Step 1: Start ngrok Tunnel

In a **new terminal window**, run:

```bash
cd services/auction-monitor
./scripts/start-ngrok-webhook.sh
```

Or manually:

```bash
ngrok http 3000
```

### Step 2: Copy the HTTPS URL

ngrok will display something like:

```
Forwarding  https://abc123xyz.ngrok.io -> http://localhost:3000
```

**Copy the HTTPS URL** (e.g., `https://abc123xyz.ngrok.io`)

### Step 3: Use in eBay Form

Go back to eBay's notification form and enter:

1. **Marketplace account deletion notification endpoint**:
   ```
   https://abc123xyz.ngrok.io/ebay/notifications
   ```
   (Replace `abc123xyz.ngrok.io` with your actual ngrok URL)

2. **Verification token**:
   ```
   ebay_verify_abc123xyz789
   ```

3. **Email**: Already filled ✅

4. **Click "Save"**

### Step 4: eBay Will Verify

eBay will send a verification request to your endpoint. The webhook server will:
- Accept the verification request
- Return the challenge token
- eBay will mark your endpoint as verified

### Step 5: Keep ngrok Running

**Important**: Keep the ngrok terminal window open while eBay verifies your endpoint. Once verified, you can close it.

## Alternative: Use ngrok Web Interface

If ngrok opens a web interface, you can also:
1. Open the URL shown (usually `http://127.0.0.1:4040`)
2. See your ngrok URL there
3. Copy it to use in eBay

## Troubleshooting

**"ngrok: command not found"**
- Run: `brew install ngrok/ngrok/ngrok`

**"Port 3000 already in use"**
- Stop any other services on port 3000
- Or change the port in `create-ebay-webhook-endpoint.js`

**"Webhook server not responding"**
- Check if it's running: `curl http://localhost:3000/health`
- Restart: `node scripts/create-ebay-webhook-endpoint.js`

---

**Action**: Start ngrok in a new terminal, copy the HTTPS URL, and use it in eBay's form! 🚀

