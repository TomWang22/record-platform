# eBay App "Non Compliant" - How to Fix

## What "Non Compliant" Means

eBay is saying your app needs some configuration or approval before you can use certain features. This might be blocking the User Token generation.

## Quick Fix: Use Application Token Instead

**Good news**: You don't need User Token for basic API access! You can use an **Application Token** instead, which doesn't require compliance approval.

### Step 1: Get Your Cert ID

1. **Go to**: https://developer.ebay.com/my/keys
2. **Click on your keyset** (the one with App ID `DailinWa-recordpl-PRD-672dab605-b3c26e79`)
3. **Copy these values:**
   - **Dev ID**
   - **Cert ID (Secret)** - click "Show" or "Reveal" if hidden

### Step 2: Generate Application Token

```bash
cd services/auction-monitor
EBAY_APP_ID='DailinWa-recordpl-PRD-672dab605-b3c26e79' \
EBAY_CERT_ID='your_cert_id_here' \
./scripts/get-ebay-app-token.sh
```

This will automatically generate a token that works for the Buy API (searching items).

### Step 3: Save All Keys

Create `.env` file:

```bash
EBAY_APP_ID="DailinWa-recordpl-PRD-672dab605-b3c26e79"
EBAY_DEV_ID="your_dev_id_here"
EBAY_CERT_ID="your_cert_id_here"
EBAY_AUTH_TOKEN="token_from_script_above"
EBAY_SANDBOX=false
```

## Why Application Token Works

- ✅ **No compliance needed** - Works immediately
- ✅ **Perfect for searching** - All you need for auction monitoring
- ✅ **Auto-generated** - No manual sign-in required
- ⚠️ **Expires in 2 hours** - But you can regenerate it

## If You Need User Token Later

To fix compliance and get User Token:

1. **Check what's missing:**
   - Go to your app settings
   - Look for compliance warnings
   - Fill out any required forms

2. **Common requirements:**
   - Privacy policy URL
   - Terms of service URL
   - App description
   - Redirect URLs (if using OAuth)

3. **For now**: Application Token is sufficient for your auction monitor!

## Test Your Setup

After you have all keys:

```bash
cd services/auction-monitor
npx tsx scripts/test-api-keys.ts
```

---

**Action**: Get your Cert ID from the keyset page, then run the Application Token script! 🚀

