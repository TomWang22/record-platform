# eBay Notification Form - Fill Out Guide

## What You're Looking At

You're on the "Alerts & Notifications" page with a form that needs to be filled out to enable your keyset.

## Form Fields to Fill

### 1. Marketplace account deletion notification endpoint

**Required**: An HTTPS URL where eBay will send notifications.

**Options:**

#### Option A: Use a Placeholder (Quick Fix)
```
https://example.com/ebay/notifications
```
- eBay will try to verify this, but it might fail
- You can update it later with a real endpoint

#### Option B: Use ngrok (For Testing)
1. Install ngrok: `brew install ngrok` (or download from ngrok.com)
2. Start the webhook server:
   ```bash
   cd services/auction-monitor
   node scripts/create-ebay-webhook-endpoint.js
   ```
3. In another terminal, run: `ngrok http 3000`
4. Copy the HTTPS URL (e.g., `https://abc123.ngrok.io`)
5. Use: `https://abc123.ngrok.io/ebay/notifications`

#### Option C: Use Your Own Domain
If you have a server with HTTPS:
```
https://yourdomain.com/ebay/notifications
```

### 2. Verification token

**Required**: A random string that eBay will use to verify your endpoint.

**Generate one:**
```bash
# Quick way to generate a random token
openssl rand -hex 16
```

Or use: `ebay_verify_abc123xyz789`

**Important**: Save this token! You'll need it if you set up a real endpoint.

### 3. Email to notify if marketplace account deletion notification endpoint is down

**Already filled**: `tomwang22@yahoo.com` ✅

### 4. Check Box

✅ **"Notify me if eBay stops sending me notifications"** - Check this box

## Steps to Complete

1. **Fill in the endpoint URL** (use placeholder or ngrok for now)
2. **Generate and enter verification token**
3. **Check the notification box**
4. **Click "Save"**

## After You Save

1. eBay will attempt to verify your endpoint
2. If verification fails, you might see an error
3. Your keyset should become enabled (may take a few minutes)
4. You can then get your Cert ID and generate tokens

## If Verification Fails

If eBay can't verify your endpoint:
- **Option 1**: Set up a real endpoint using ngrok (see Option B above)
- **Option 2**: Look for "Apply for exemption" link/button
- **Option 3**: Contact eBay Developer Support

## Quick Action

**Right now, fill out:**
- Endpoint: `https://example.com/ebay/notifications` (placeholder)
- Verification token: `ebay_verify_abc123xyz789`
- Check the notification box
- Click **"Save"**

Then we'll see if it works or if we need to set up a real endpoint!

---

**Action**: Fill out the form and click "Save"! 🚀

