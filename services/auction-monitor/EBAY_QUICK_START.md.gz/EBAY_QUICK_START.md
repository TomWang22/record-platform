# eBay API Keys - Quick Start

## You're Here: Application Keys Page

### What to Do Right Now:

1. **Under "Production" section, click "Create a keyset"**

2. **Enter Application Title:**
   ```
   Record Platform Auction Monitor
   ```
   (Or any name - just for your reference)

3. **Click "Create"**

4. **Copy These 3 Keys Immediately:**
   - **App ID (Client ID)**: Starts with something like `YourAppID-Prod-...`
   - **Dev ID**: Starts with something like `YourDevID-...`
   - **Cert ID (Secret)**: Starts with something like `YourCertID-...`
   
   ⚠️ **Save these now!** You might not see the Cert ID again.

5. **Get OAuth Token:**
   - Click on your **App ID** in the list
   - Look for **"User Tokens"** or **"Get a User Token"** button
   - Click it and authorize
   - Copy the token (long string starting with `v^1.1#...`)

## Save Your Keys

Run this command to set up your keys interactively:

```bash
cd services/auction-monitor
./scripts/setup-api-keys.sh
```

Or manually create `.env` file with:

```bash
EBAY_APP_ID="paste_your_app_id_here"
EBAY_DEV_ID="paste_your_dev_id_here"
EBAY_CERT_ID="paste_your_cert_id_here"
EBAY_AUTH_TOKEN="paste_your_token_here"
EBAY_SANDBOX=false
```

## Test Your Keys

```bash
cd services/auction-monitor
npx tsx scripts/test-api-keys.ts
```

If you see "✅ eBay API working!" - you're all set!

## What If You Get Stuck?

- **Can't find "Create a keyset"**: Look under the "Production" section header
- **Don't see Cert ID**: It might be hidden - click "Show" or "Reveal"
- **Token not working**: Make sure you selected the search scope
- **Need more help**: See `EBAY_API_SETUP_STEP_BY_STEP.md` for detailed instructions

## Next: Get Discogs Token

After eBay is working, get your Discogs token:
1. Go to: https://www.discogs.com/settings/developers
2. Click "Generate New Token"
3. Copy it and add to `.env` as `DISCOGS_USER_TOKEN`

---

**You're almost there!** Just create the keyset and copy the keys. 🚀

