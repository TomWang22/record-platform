# eBay Token Format Issue

## Problem

Getting "Invalid access token" (401) even with fresh User Access Token.

## Token Format

eBay User Tokens have a special format: `v^1.1#i^1#f^0#p^3#r^0#I^3#t^...`

This is eBay's proprietary token format, not a standard OAuth Bearer token.

## Possible Solutions

### 1. Token Encoding

eBay tokens with special characters (`#`, `^`) might need URL encoding in the Authorization header.

### 2. Different Authentication Method

eBay User Tokens might need to be used differently than standard Bearer tokens. Some eBay APIs might require:
- Different header format
- Token in query parameters
- Different endpoint

### 3. Scope Issue

The token might not have the correct scope for Buy API search. Check if the OAuth consent included:
- `https://api.ebay.com/oauth/api_scope/buy.marketplace.search`

### 4. API Endpoint Issue

The Buy API might require a different authentication method or endpoint for User Tokens vs Application Tokens.

## Next Steps

1. **Check OAuth Scopes**: Verify the token was granted with Buy API search scope
2. **Try URL Encoding**: Test with URL-encoded token in Authorization header
3. **Check eBay Documentation**: Look for specific requirements for User Tokens with Buy API
4. **Alternative**: Consider using Application Token with Finding API (older API but might work)

## Current Status

- ✅ Token saved correctly
- ✅ Adapter updated to Buy API
- ❌ Getting "Invalid access token" error
- ⚠️ Token format might need special handling

---

**Action**: Check if the token has the correct scopes, or try using Application Token with Finding API as fallback.

