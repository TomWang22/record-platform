# Quick Guide: Getting Your eBay OAuth Token

## You Have Your App ID! ✅
**App ID**: `DailinWa-recordpl-PRD-672dab605-b3c26e79`

## Now Get Your Token

### Easiest Method: Use eBay Developer Portal

1. **Go back to your keys list**: https://developer.ebay.com/my/keys
2. **Click on your App ID**: `DailinWa-recordpl-PRD-672dab605-b3c26e79`
3. **Look for one of these:**
   - "Get a User Token" button
   - "User Tokens" tab
   - "OAuth Token" link
   - "eBay Sign-in" link
4. **Click it** - you'll be redirected to eBay's sign-in
5. **Sign in** and **authorize** the application
6. **Copy the token** (long string starting with `v^1.1#...`)

### Alternative: Direct OAuth URL

If you can't find the button, open this URL in your browser:

```
https://auth.ebay.com/oauth2/authorize?client_id=DailinWa-recordpl-PRD-672dab605-b3c26e79&redirect_uri=http://localhost:8080/oauth/ebay/callback&response_type=code&scope=https://api.ebay.com/oauth/api_scope/buy.marketplace.search
```

After authorization, you'll get a code. You'll need to exchange it for a token (see below).

### Simplest: Application Token (For Testing)

For quick testing, you can use an Application Token instead of User Token:

1. **Get your Cert ID** (from the keyset page)
2. **Make a POST request** to get token:

```bash
curl -X POST https://api.ebay.com/identity/v1/oauth2/token \
  -u "DailinWa-recordpl-PRD-672dab605-b3c26e79:YOUR_CERT_ID" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope/buy.marketplace.search"
```

This returns an `access_token` you can use.

## What You Still Need

Make sure you also have:
- ✅ **App ID**: `DailinWa-recordpl-PRD-672dab605-b3c26e79` (you have this!)
- ⏳ **Dev ID**: From the keyset page
- ⏳ **Cert ID**: From the keyset page  
- ⏳ **OAuth Token**: What you're getting now

## After You Have Everything

1. **Save to `.env`**:
   ```bash
   cd services/auction-monitor
   ./scripts/setup-api-keys.sh
   ```

2. **Test**:
   ```bash
   npx tsx scripts/test-api-keys.ts
   ```

3. **Start worker**:
   ```bash
   npm run start:worker
   ```

---

**Tip**: The "Alerts & Notifications" section you're seeing is for advanced features. You can skip it for now - you just need the OAuth token to make API calls.

