# k6 Load Testing for Analytics Pipeline

## Overview

Comprehensive k6 load tests for the analytics pipeline with real data patterns. These tests validate:
- Percentile calculation accuracy (p1-p100)
- Python AI readiness
- Data quality under load
- Performance benchmarks

## Test Scripts

### 1. Load Ramp Test (`k6-analytics-load-ramp.js`) ⭐ **START HERE**

**Purpose**: Find the breaking point by starting at 1K VU and scaling up.

**Features**:
- Starts at 1,000 VU
- Gradually increases to 5,000 VU (configurable)
- Identifies maximum capacity
- Tracks when system struggles

**Usage**:
```bash
# Default: 1K → 5K VU
k6 run scripts/load/k6-analytics-load-ramp.js

# Custom range
k6 run --env START_VUS=2000 --env MAX_VUS=10000 scripts/load/k6-analytics-load-ramp.js
```

**Metrics Tracked**:
- `breaking_point_reached`: Count of breaking point events
- `percentile_validation`: Rate under extreme load
- `python_ai_ready`: Rate under extreme load
- Peak VUs reached

### 2. Read-Heavy Test (`k6-analytics-read-heavy.js`) ⭐ **HIGH LOAD**

**Purpose**: Test read-heavy workload (90% reads, 10% writes) starting at 1K VU.

**Features**:
- Starts at 1,000 VU, scales to 3,000 VU
- 90% read operations (price trends, fuzzy search, similar searches, trending)
- 10% write operations (predict price)
- Read latency tracking

**Usage**:
```bash
# Default: 1K → 3K VU, 10 minutes
k6 run scripts/load/k6-analytics-read-heavy.js

# Custom
k6 run --env START_VUS=2000 --env MAX_VUS=5000 --env DURATION=15m scripts/load/k6-analytics-read-heavy.js
```

**Metrics Tracked**:
- `read_latency_ms`: Read operation latency
- `write_latency_ms`: Write operation latency
- `cache_hit_rate`: Cache effectiveness
- `percentile_validation`: Data quality under read load

### 3. Soak Test (`k6-analytics-soak.js`) ⭐ **STABILITY**

**Purpose**: Long-duration test to find memory leaks and stability issues.

**Features**:
- 30+ minutes duration
- Steady load (50-100 VU)
- Memory leak detection
- Stability validation

**Usage**:
```bash
# Default: 50 VU, 30 minutes
k6 run scripts/load/k6-analytics-soak.js

# Extended: 100 VU, 1 hour
k6 run --vus 100 --duration 1h scripts/load/k6-analytics-soak.js
```

**Metrics Tracked**:
- `memory_leak_indicator`: Response time degradation over time
- `percentile_validation`: Data quality over long duration
- `python_ai_ready`: Consistency over time

### 4. Analytics Ingestion Pipeline (`k6-analytics-ingestion.js`)

**Purpose**: Tests the analytics ingestion pipeline with realistic data patterns.

**Features**:
- Simulates listing ingestion
- Validates data quality (percentiles p1-p100)
- Tests Python AI readiness
- Performance metrics

**Usage**:
```bash
k6 run --vus 10 --duration 60s scripts/load/k6-analytics-ingestion.js
k6 run --vus 50 --duration 5m --env BASE_URL=http://localhost:4008 scripts/load/k6-analytics-ingestion.js
```

**Metrics Tracked**:
- `percentile_validation_passed`: Rate of successful percentile validation
- `python_ai_ready`: Rate of Python AI ready data
- `data_quality_score`: Average data quality score
- `ingestion_latency_ms`: Latency for ingestion operations
- `processing_errors`: Count of processing errors

### 2. Data Quality Validation (`k6-analytics-data-quality.js`)

**Purpose**: Validates data quality after ingestion by querying actual processed data.

**Features**:
- Queries real database for processed listings
- Validates percentiles p1-p100 in stored data
- Checks Python AI readiness
- Verifies statistical consistency

**Usage**:
```bash
k6 run --vus 5 --duration 30s scripts/load/k6-analytics-data-quality.js
k6 run --vus 10 --duration 2m --env ANALYTICS_URL=http://localhost:4004 scripts/load/k6-analytics-data-quality.js
```

**Metrics Tracked**:
- `percentile_complete_p1_p100`: Rate of complete percentile data
- `python_ai_ready`: Rate of Python AI ready data
- `validation_score`: Average validation score
- `statistical_consistency`: Rate of statistically consistent data
- `data_quality_issues`: Count of data quality issues

### 3. Stress Test (`k6-analytics-stress.js`)

**Purpose**: Hard stress testing under high concurrent load.

**Features**:
- High concurrent load (50-100 VUs)
- Long duration (5-10 minutes)
- Real data patterns
- Validates data quality under stress

**Usage**:
```bash
k6 run --vus 100 --duration 10m scripts/load/k6-analytics-stress.js
k6 run --stages 0s:10,30s:50,2m:100,5m:100,7m:50,10m:0 scripts/load/k6-analytics-stress.js
```

**Metrics Tracked**:
- `percentile_validation`: Rate of successful validation under stress
- `python_ai_ready`: Rate of Python AI ready data under stress
- `data_quality_score`: Average data quality score under stress
- `throughput_ops_per_sec`: Operations per second
- `errors`: Error count

## Quick Start

### Run All Tests

```bash
# Make script executable (first time only)
chmod +x scripts/load/run-analytics-tests.sh

# Run all tests (includes ramp, read-heavy, soak)
./scripts/load/run-analytics-tests.sh

# Skip long tests (faster)
SKIP_SOAK=true SKIP_STRESS=true ./scripts/load/run-analytics-tests.sh

# Run only breaking point tests
k6 run scripts/load/k6-analytics-load-ramp.js
k6 run scripts/load/k6-analytics-read-heavy.js
```

### Test Progression (Recommended Order)

1. **Load Ramp** (find breaking point): `k6 run scripts/load/k6-analytics-load-ramp.js`
2. **Read-Heavy** (high read load): `k6 run scripts/load/k6-analytics-read-heavy.js`
3. **Soak** (stability): `k6 run --vus 50 --duration 30m scripts/load/k6-analytics-soak.js`

### Run Individual Tests

```bash
# Ingestion test
k6 run --vus 10 --duration 60s scripts/load/k6-analytics-ingestion.js

# Data quality test
k6 run --vus 5 --duration 30s scripts/load/k6-analytics-data-quality.js

# Stress test
k6 run --vus 50 --duration 5m scripts/load/k6-analytics-stress.js
```

## Configuration

### Environment Variables

- `BASE_URL`: Base URL for auction monitor (default: `http://localhost:4008`)
- `ANALYTICS_URL`: Analytics service URL (default: `http://localhost:4004`)
- `AUCTION_MONITOR_URL`: Auction monitor URL (default: `http://localhost:4008`)
- `TOKEN`: Authentication token (if required)
- `VUS`: Virtual users (default: 10)
- `DURATION`: Test duration (default: `60s`)

### Example with Custom Configuration

```bash
BASE_URL=http://localhost:4008 \
ANALYTICS_URL=http://localhost:4004 \
k6 run --vus 20 --duration 2m scripts/load/k6-analytics-ingestion.js
```

## Performance Thresholds

### Ingestion Test
- **HTTP Duration**: p95 < 500ms, p99 < 1000ms
- **Error Rate**: < 5%
- **Percentile Validation**: > 95%
- **Python AI Ready**: > 90%
- **Data Quality Score**: > 0.85

### Data Quality Test
- **HTTP Duration**: p95 < 1000ms, p99 < 2000ms
- **Error Rate**: < 2%
- **Percentile Complete**: > 95%
- **Python AI Ready**: > 90%
- **Validation Score**: > 0.85
- **Statistical Consistency**: > 90%

### Stress Test
- **HTTP Duration**: p95 < 2000ms, p99 < 5000ms
- **Error Rate**: < 10% (allows degradation under stress)
- **Percentile Validation**: > 85%
- **Python AI Ready**: > 80%
- **Data Quality Score**: > 0.75

## Test Data Patterns

Tests use realistic query patterns:
- Real artist/album combinations (The Beatles - Abbey Road, Pink Floyd - Dark Side, etc.)
- Varied price ranges ($20-$220)
- Different conditions (Very Good, Good, Fair, Excellent)
- Multiple formats (LP, CD, Cassette, 7", 12")

## Validation Checks

### Percentile Validation
- All percentiles p1-p100 exist
- Percentile ordering: p1 ≤ p2 ≤ ... ≤ p100
- Min ≤ p1 and p100 ≤ max
- All values are numbers and non-negative

### Python AI Readiness
- Confidence score ≥ 0.7
- Completeness score ≥ 0.75
- Sample size ≥ 10
- All percentiles p1-p100 present
- Validation score ≥ 0.8

### Statistical Consistency
- Mean is within min-max range
- Median is within min-max range
- p50 (median) is close to median field
- Standard deviation is non-negative

## Results

Results are exported to:
- Console output (summary)
- JSON files in `results/` directory
- Custom metrics in k6 output

### View Results

```bash
# View JSON results
cat results/analytics-*.json | jq

# View specific test
jq '.metrics' results/analytics-ingestion-*.json
```

## Integration with CI/CD

Add to CI/CD pipeline:

```yaml
- name: Run Analytics Load Tests
  run: |
    k6 run --vus 10 --duration 60s \
      --env BASE_URL=${{ env.BASE_URL }} \
      --env ANALYTICS_URL=${{ env.ANALYTICS_URL }} \
      scripts/load/k6-analytics-ingestion.js
```

## Troubleshooting

### High Error Rates
- Check database connectivity
- Verify services are running
- Check for rate limiting
- Review service logs

### Low Data Quality Scores
- Ensure sufficient test data in database
- Check confidence/completeness thresholds
- Verify percentile calculation logic

### Performance Issues
- Check database query performance
- Review connection pool settings
- Monitor resource usage (CPU, memory)
- Check for database locks

## Next Steps

1. ✅ Run ingestion test to validate pipeline
2. ✅ Run data quality test to verify stored data
3. ✅ Run stress test to find breaking points
4. ⚠️ Analyze results and optimize
5. ⚠️ Set up continuous monitoring

---

**Status**: ✅ Ready for testing with real data!

