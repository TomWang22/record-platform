# Quick Start Guide

## 1. Set Up API Keys

### Option A: Interactive Setup (Recommended)

```bash
cd services/auction-monitor
./scripts/setup-api-keys.sh
```

This will guide you through:
- eBay API keys (App ID, Dev ID, Cert ID, OAuth Token)
- Discogs API token
- Database URLs (defaults provided)

### Option B: Manual Setup

1. **Get eBay API Keys:**
   - Go to https://developer.ebay.com/
   - Sign in with your eBay account
   - Create an App Key
   - Get OAuth token
   - See `API_KEYS_SETUP.md` for detailed instructions

2. **Get Discogs API Token:**
   - Go to https://www.discogs.com/settings/developers
   - Generate a new token
   - See `API_KEYS_SETUP.md` for detailed instructions

3. **Create `.env` file:**
   ```bash
   cd services/auction-monitor
   cp .env.example .env  # If you have an example file
   # Or create manually with the variables from API_KEYS_SETUP.md
   ```

## 2. Test API Keys

```bash
cd services/auction-monitor
npx tsx scripts/test-api-keys.ts
```

This will verify:
- ✅ eBay API connection
- ✅ Discogs API connection
- ⚠️  Scraping platforms (no keys needed)

## 3. Verify Database

The database migration should already be complete. Verify:

```bash
docker exec record-platform-postgres-auction-monitor-1 psql -U postgres -d auction_monitor -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'auction_monitor';"
```

Should show: **10 tables**

## 4. Test Pipeline

```bash
cd services/auction-monitor
POSTGRES_URL_AUCTION_MONITOR="postgresql://postgres:postgres@localhost:5438/auction_monitor" \
npx tsx src/test-pipeline.ts
```

Should show:
- ✅ Valid listing processed
- ✅ Invalid listing rejected
- ✅ Database accessible

## 5. Start Worker

```bash
cd services/auction-monitor

# Load environment variables
export $(cat .env | xargs)

# Start worker
npm run start:worker
```

Or with explicit variables:

```bash
POSTGRES_URL_AUCTION_MONITOR="postgresql://postgres:postgres@localhost:5438/auction_monitor" \
POSTGRES_URL_ANALYTICS="postgresql://postgres:postgres@localhost:5439/analytics" \
DISCOGS_USER_TOKEN="your_token" \
EBAY_APP_ID="your_app_id" \
EBAY_AUTH_TOKEN="your_token" \
npm run start:worker
```

## 6. Monitor

The worker will:
- Poll platforms for new listings
- Process through pipeline
- Match to user watches
- Ingest to Analytics Service

Check logs for:
- Processing counts
- Error messages
- API rate limit warnings

## Troubleshooting

### "API key not set"
- Run `./scripts/setup-api-keys.sh` again
- Check `.env` file exists and has correct values
- Verify environment variables are exported

### "Database connection failed"
- Check PostgreSQL container is running: `docker ps | grep postgres-auction-monitor`
- Verify connection string: `postgresql://postgres:postgres@localhost:5438/auction_monitor`
- Test connection: `docker exec record-platform-postgres-auction-monitor-1 psql -U postgres -d auction_monitor -c "SELECT 1;"`

### "No listings found"
- Check API keys are valid (run test script)
- Verify rate limits aren't exceeded
- Check platform adapters are working

## Next Steps

- Set up user watches (via API or database)
- Configure Analytics Service integration
- Set up monitoring dashboards
- Add notifications for watch matches

---

**Need Help?** See `API_KEYS_SETUP.md` for detailed API key instructions.

