# Auction Monitor - Service Integrations

## Overview

The Auction Monitor service provides granular price analytics data to multiple services:
- **Social Service**: Negotiation assistance, mood analysis, price context
- **Shopping Service**: Buyer price evaluation, negotiation suggestions, auction "temperature" reading
- **Listings Service**: Seller recommendations, pricing guidance, listing optimization

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│              Auction Monitor Service                        │
│  (Data Collection: eBay, Discogs, Buyee, YahooJP, etc.)    │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Analytics Service                             │
│  • Granular Percentiles (p1-p99)                           │
│  • Historical Price Data                                   │
│  • Market Trends                                           │
│  • Price Distribution Analysis                             │
└──────────────┬───────────────────────┬──────────────────────┘
               │                       │                       │
               ▼                       ▼                       ▼
    ┌──────────────┐      ┌──────────────┐      ┌──────────────┐
    │   Social     │      │   Shopping    │      │   Listings   │
    │   Service    │      │   Service     │      │   Service    │
    └──────────────┘      └──────────────┘      └──────────────┘
```

## Granular Percentiles (p1-p99)

### Why Granular Percentiles?

Instead of coarse percentiles (p25, p50, p75, p95), we calculate **every percentile from p1 to p99**. This enables:

1. **Precise Price Positioning**: "This listing is at the 47th percentile" (not just "between p25 and p50")
2. **Better Negotiation Guidance**: Exact percentile-based recommendations
3. **Accurate AI Predictions**: Granular data for ML models
4. **Detailed Market Analysis**: Price distribution curves

### Implementation

```typescript
interface PricePercentiles {
  p1: number    // 1st percentile (lowest prices)
  p2: number
  // ... p3 through p98
  p99: number   // 99th percentile (highest prices)
  
  // Summary statistics
  min: number
  max: number
  mean: number
  median: number
  stdDev: number
  count: number
  confidence: 'high' | 'medium' | 'low'
}
```

### Example Usage

```typescript
// Current listing price: $50.00
// Percentiles show:
percentiles = {
  p1: 25.00,   // 1% of similar items sold for ≤ $25
  p25: 45.00,  // 25% sold for ≤ $45
  p50: 48.00,  // 50% sold for ≤ $48 (median)
  p75: 52.00,  // 75% sold for ≤ $52
  p99: 75.00,  // 99% sold for ≤ $75
  // ... all percentiles from p1 to p99
}

// Current price ($50) is at approximately p60 (60th percentile)
// This means 60% of similar items sold for less, 40% sold for more
```

## 1. Social Service Integration

### Use Case: Negotiation Assistance

**Scenario**: Buyer and seller negotiating price via chat

**Data Provided by Analytics**:
- Granular percentiles (p1-p99) for price context
- Historical price trends
- Similar item sales
- Market demand indicators

**Python AI Contribution**:
- Sentiment analysis of messages
- Mood detection (frustrated, enthusiastic, hesitant)
- Response suggestions based on price context
- Negotiation strategy recommendations

### API Endpoints

```typescript
// Social Service calls Analytics Service
GET /analytics/price-percentiles?catalog_number=SO-383&condition=NM
Response: {
  percentiles: { p1: 25, p2: 27, ..., p99: 75 },
  currentPrice: 50,
  pricePosition: 0.60,  // 60th percentile
  recommendation: "Fair price - slightly above median"
}

// Social Service calls Python AI for negotiation help
POST /python-ai/negotiation-assist
Body: {
  conversation: [...],
  priceContext: { percentiles, currentPrice, pricePosition },
  userRole: "buyer" | "seller"
}
Response: {
  suggestedResponse: "...",
  mood: "frustrated",
  strategy: "compromise",
  priceSuggestion: 47.50
}
```

### Example Flow

```
Buyer: "Would you consider $45?"
  ↓
Social Service → Analytics: Get percentiles for this item
  ↓
Analytics: Returns { p25: 45, p50: 48, p75: 52, currentPrice: 50, pricePosition: 0.60 }
  ↓
Social Service → Python AI: Analyze negotiation
  ↓
Python AI: {
  mood: "buyer is negotiating",
  priceContext: "$45 is at p25 (good deal for buyer)",
  suggestion: "Seller might accept $47-48 (p50-p60 range)"
}
  ↓
Social Service: Suggests response to seller
  "I understand your position. Based on recent sales, $48 seems fair. 
   Would you consider meeting in the middle at $47.50?"
```

### Bigger Context Analysis

**New Drops Detection**:
```typescript
// Social Service can analyze market trends
GET /analytics/market-trends?artist=The Beatles&album=Abbey Road
Response: {
  recentActivity: "high",  // Many new listings
  priceTrend: "decreasing",  // Prices dropping
  newDrops: true,  // New items being listed
  recommendation: "Wait - prices may drop further"
}
```

## 2. Shopping Service Integration

### Use Case: Buyer Price Evaluation

**Scenario**: Buyer viewing an item, deciding if it's worth buying

**Data Provided by Analytics**:
- Granular percentiles (p1-p99)
- Historical price comparison
- Similar item sales
- Auction "temperature" (bid activity, watchers, time remaining)

**Python AI Contribution**:
- Value assessment ("Excellent deal", "Fair price", "Overpriced")
- Negotiation suggestions (OBO - "or best offer")
- Risk analysis (scam detection, seller reliability)
- Auction temperature reading (bidding activity analysis)

### API Endpoints

```typescript
// Shopping Service calls Analytics Service
GET /analytics/evaluate-price?listing_id=12345
Response: {
  percentiles: { p1: 25, ..., p99: 75 },
  currentPrice: 50,
  pricePosition: 0.60,
  valueAssessment: {
    rating: "fair_price",
    confidence: 0.85,
    reasoning: "Price is at 60th percentile, condition justifies it"
  },
  similarSales: [...],
  marketTrend: "stable"
}

// For auctions: Read "temperature"
GET /analytics/auction-temperature?listing_id=12345
Response: {
  bidCount: 5,
  watcherCount: 12,
  timeRemaining: "2 hours",
  temperature: "hot",  // "cold", "warm", "hot"
  prediction: "Likely to sell above p75",
  recommendation: "Bid now if interested"
}
```

### Example Flow

```
Buyer views item: $50.00, OBO (or best offer)
  ↓
Shopping Service → Analytics: Evaluate price
  ↓
Analytics: {
  percentiles: { p25: 45, p50: 48, p75: 52 },
  currentPrice: 50,
  pricePosition: 0.60,
  valueAssessment: "Fair price - slightly above median"
}
  ↓
Shopping Service → Python AI: Analyze negotiation opportunity
  ↓
Python AI: {
  worthIt: true,
  negotiationSuggestion: {
    startingOffer: 45.00,  // p25
    maximumAcceptable: 52.00,  // p75
    successProbability: 0.65
  },
  recommendation: "Good opportunity - try offering $45-48"
}
  ↓
Shopping Service: Shows buyer
  "Fair price. Based on recent sales, try negotiating to $45-48 range.
   Seller accepts offers, so you have a 65% chance of success."
```

### Auction Temperature Reading

**For Auction Listings**:
```typescript
// Analyze bidding activity
GET /analytics/auction-temperature?listing_id=12345
Response: {
  bidCount: 8,
  watcherCount: 15,
  timeRemaining: "1 hour",
  bidVelocity: "high",  // Bids coming in fast
  temperature: "hot",
  prediction: {
    finalPrice: 55.00,  // Likely to exceed p75
    confidence: 0.80
  },
  recommendation: "Bid now if interested - high activity suggests competitive bidding"
}
```

## 3. Listings Service Integration

### Use Case: Seller Listing Optimization

**Scenario**: Seller creating a new listing, needs help with pricing, description, photos

**Data Provided by Analytics**:
- Granular percentiles (p1-p99) for pricing guidance
- Successful listing patterns (titles, descriptions, photos)
- Historical sales data
- Market trends

**Python AI Contribution**:
- Title optimization (SEO, keywords)
- Description generation (based on successful listings)
- Price recommendations (optimal listing price)
- Photo suggestions (what photos work best)

### API Endpoints

```typescript
// Listings Service calls Analytics Service
GET /analytics/pricing-guidance?artist=The Beatles&album=Abbey Road&condition=NM&format=LP
Response: {
  percentiles: { p1: 25, ..., p99: 75 },
  recommendedPrice: 48.00,  // p50 (median)
  priceRange: {
    min: 45.00,  // p25
    max: 52.00   // p75
  },
  reasoning: "Median price is $48. Listing at p50 maximizes visibility and sales probability"
}

// Get successful listing patterns
GET /analytics/successful-listings?catalog_number=SO-383
Response: {
  topTitles: [...],
  topDescriptions: [...],
  photoPatterns: [...],
  keywordPerformance: {
    "sealed": 0.15,  // 15% boost in views
    "original": 0.12,
    "stereo": 0.08
  }
}

// Listings Service calls Python AI for optimization
POST /python-ai/optimize-listing
Body: {
  itemDetails: { artist, album, condition, format, catalogNumber },
  analyticsData: { percentiles, successfulListings, keywordPerformance }
}
Response: {
  optimizedTitle: "The Beatles - Abbey Road (1969, Stereo, Near Mint) Original UK Pressing",
  optimizedDescription: "...",
  suggestedPrice: 48.00,
  keywords: ["original", "stereo", "1969", "UK pressing"],
  photoSuggestions: ["front cover", "back cover", "label", "sleeve condition"]
}
```

### Example Flow

```
Seller creates listing draft:
  - Title: "Abbey Road"
  - Description: "Good condition"
  - Price: $60.00
  ↓
Listings Service → Analytics: Get pricing guidance
  ↓
Analytics: {
  percentiles: { p25: 45, p50: 48, p75: 52 },
  recommendedPrice: 48.00,
  priceRange: { min: 45, max: 52 }
}
  ↓
Listings Service → Analytics: Get successful listing patterns
  ↓
Analytics: {
  topTitles: ["The Beatles - Abbey Road (1969, Stereo, Near Mint)..."],
  keywordPerformance: { "sealed": 0.15, "original": 0.12 }
}
  ↓
Listings Service → Python AI: Optimize listing
  ↓
Python AI: {
  optimizedTitle: "The Beatles - Abbey Road (1969, Stereo, Near Mint) Original UK Pressing",
  optimizedDescription: "Original 1969 UK stereo pressing...",
  suggestedPrice: 48.00,
  keywords: ["original", "stereo", "1969"]
}
  ↓
Listings Service: Shows seller recommendations
  "Your price ($60) is above p75 ($52). Consider listing at $48 (p50) 
   for better visibility. Here's an optimized title and description."
```

## Data Quality Requirements

### For All Services

**Minimum Requirements**:
- Confidence score ≥ 0.7 (high-quality data only)
- At least 5 similar items for percentiles (medium confidence)
- At least 10 similar items for high confidence percentiles

**Granular Percentile Calculation**:
- Requires sorted price array
- Linear interpolation for precise percentiles
- Handles edge cases (single price, few prices)

### Service-Specific Requirements

**Social Service**:
- Real-time price context (current percentiles)
- Historical trends (price changes over time)
- Market activity (new drops, demand indicators)

**Shopping Service**:
- Current price evaluation (percentile position)
- Auction temperature (bid activity, watchers)
- Negotiation guidance (OBO suggestions)

**Listings Service**:
- Pricing guidance (optimal listing price)
- Successful listing patterns (titles, descriptions)
- Keyword performance (what works best)

## Implementation Status

### ✅ Completed
- Granular percentile calculation (p1-p99)
- Analytics ingestion pipeline
- Data quality thresholds (≥0.7)

### 🚧 In Progress
- Service integration endpoints
- Python AI service integration
- Real-time price context API

### 📋 TODO
- Social Service negotiation endpoints
- Shopping Service evaluation endpoints
- Listings Service optimization endpoints
- Auction temperature analysis
- New drops detection

## Next Steps

1. **Implement Service Endpoints**: Create APIs for Social, Shopping, Listings services
2. **Python AI Integration**: Connect Python AI service for advanced analysis
3. **Real-Time Updates**: WebSocket/SSE for live price updates
4. **Caching**: Redis caching for frequently accessed percentiles
5. **Monitoring**: Track API usage, response times, data quality

