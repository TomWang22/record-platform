# Auction Monitor - Comprehensive Test Plan

## Overview

This document outlines the testing strategy for the Auction Monitor service, Analytics Service integration, and data quality validation before feeding to Python AI Service.

## Current Status

### ✅ Implemented Components
1. **Platform Adapters**: eBay (API), Discogs (API + browser scraping)
2. **Staging Pipeline**: Raw → Normalized → Validated
3. **Data Quality Engine**: Confidence scoring, deduplication, enrichment
4. **Analytics Ingestion**: Price percentiles, historical comparison, Discogs price history
5. **Discogs Price History**: Browser automation with CAPTCHA handling

### ⚠️ Testing Requirements
1. **Service Health**: Verify services are running and healthy
2. **Data Quality**: Ensure confidence thresholds are met (≥0.7 for Analytics)
3. **End-to-End Flow**: Test complete pipeline from ingestion to Analytics
4. **Python AI Readiness**: Verify data quality for AI inference

## Data Quality Thresholds

### Confidence Score Levels

```
┌─────────────────────────────────────────────────────────┐
│ Confidence Score Thresholds                             │
├─────────────────────────────────────────────────────────┤
│ ≥ 0.5: Stored in normalized_listings                    │
│ ≥ 0.7: Fed to Analytics Service                        │
│ ≥ 0.8: High-quality data for Python AI                  │
└─────────────────────────────────────────────────────────┘
```

### Confidence Score Calculation

**Factors:**
- **Completeness** (0.0-1.0): Required fields present
- **Source Reliability** (0.0-1.0): Platform trustworthiness
  - eBay: 0.95 (Official API)
  - Discogs: 0.95 (Official API)
  - Buyee: 0.75 (Scraping)
  - YahooJP: 0.75 (Scraping)
- **Data Freshness** (0.0-1.0): How recent the data is
- **Enrichment Bonus** (+10%): Catalog number match
- **Validation Errors** (-10% per error): Penalty for issues

**Formula:**
```
confidence = completeness × source_reliability × freshness × enrichment_bonus × (1 - error_penalty)
```

## Test Scenarios

### 1. Service Health Check

**Objective**: Verify all services are running and healthy

**Steps**:
```bash
# Check Docker services
docker-compose ps

# Check auction-monitor health
curl http://localhost:4006/healthz

# Check analytics-service health
curl http://localhost:4004/healthz

# Check database connections
docker exec -it record-platform-postgres-auction-monitor-1 psql -U postgres -d auction_monitor -c "SELECT 1"
```

**Expected Results**:
- ✅ All services show "healthy" or "running"
- ✅ Health endpoints return 200 OK
- ✅ Database connections successful

### 2. Data Ingestion Test

**Objective**: Test end-to-end data flow from platform to normalized listings

**Test Data**:
```typescript
// Test listing with high-quality data
const testListing = {
  platform: 'ebay',
  externalId: 'test-123',
  url: 'https://ebay.com/item/test-123',
  title: 'The Beatles - Abbey Road (1969, UK, Stereo, LP)',
  price: 50.00,
  currency: 'USD',
  condition: 'Near Mint',
  format: 'LP',
  artist: 'The Beatles',
  album: 'Abbey Road',
  catalogNumber: 'SO-383',
  seller: {
    id: 'seller-123',
    feedbackScore: 1000,
  },
  images: ['https://example.com/image.jpg'],
}
```

**Steps**:
```bash
# Run ingestion worker test
cd services/auction-monitor
npm run test:ingestion

# Or manually test
npx tsx src/test-pipeline.ts
```

**Expected Results**:
- ✅ Raw listing stored in `raw_listings`
- ✅ Normalized listing stored in `normalized_listings`
- ✅ Confidence score ≥ 0.7 (for eBay with catalog number)
- ✅ Discogs enrichment successful (if catalog number matches)
- ✅ Validation passes

**Validation Queries**:
```sql
-- Check raw listing
SELECT * FROM auction_monitor.raw_listings 
WHERE external_id = 'test-123';

-- Check normalized listing
SELECT 
  id, platform, title, current_price, confidence_score,
  discogs_release_id, catalog_match_confidence
FROM auction_monitor.normalized_listings
WHERE external_id = 'test-123';

-- Check enrichment
SELECT 
  discogs_release_id, catalog_match_confidence, enriched_fields
FROM auction_monitor.normalized_listings
WHERE catalog_number = 'SO-383';
```

### 3. Analytics Ingestion Test

**Objective**: Verify Analytics Service receives high-quality data

**Prerequisites**:
- At least 1 normalized listing with confidence ≥ 0.7
- Listing has catalog_number OR (artist + album + format)

**Steps**:
```bash
# Trigger analytics ingestion
cd services/auction-monitor
npx tsx -e "
import { AnalyticsIngestionPipeline } from './src/analytics/ingestion-pipeline';
import { Pool } from 'pg';

const auctionPool = new Pool({ connectionString: process.env.POSTGRES_URL_AUCTION_MONITOR });
const analyticsPool = new Pool({ connectionString: process.env.POSTGRES_URL_ANALYTICS });

const pipeline = new AnalyticsIngestionPipeline(auctionPool, analyticsPool);
const result = await pipeline.ingestNewListings();
console.log('Processed:', result.processed, 'Errors:', result.errors);
"
```

**Expected Results**:
- ✅ Listings with confidence ≥ 0.7 are processed
- ✅ Price percentiles calculated (p25, p50, p75, p95)
- ✅ Historical comparison performed
- ✅ Price snapshots stored in `price_history`
- ✅ Analytics snapshots updated in `analytics.price_snapshots`

**Validation Queries**:
```sql
-- Check price history
SELECT 
  ph.snapshot_at, ph.price, ph.metadata->>'percentiles' as percentiles
FROM auction_monitor.price_history ph
JOIN auction_monitor.normalized_listings nl ON ph.normalized_listing_id = nl.id
WHERE nl.external_id = 'test-123'
ORDER BY ph.snapshot_at DESC
LIMIT 5;

-- Check analytics snapshots
SELECT 
  snap_date, artist, name, format, median_price, sample_count
FROM analytics.price_snapshots
WHERE artist = 'The Beatles' AND name = 'Abbey Road'
ORDER BY snap_date DESC
LIMIT 5;
```

### 4. Discogs Price History Test

**Objective**: Test browser automation for Discogs price history

**Prerequisites**:
- Discogs User Token configured
- Browser pool set up (Puppeteer)
- Test release ID (e.g., 249504 - Abbey Road)

**Steps**:
```bash
# Test Discogs price history scraper
cd services/auction-monitor
npx tsx -e "
import { scrapeDiscogsPriceHistory } from './src/platforms/discogs/price-history-scraper';

const priceHistory = await scrapeDiscogsPriceHistory({
  releaseId: 249504, // Abbey Road
  waitForCaptcha: true,
  captchaTimeout: 120000,
});

console.log('Price history entries:', priceHistory.length);
console.log('Sample entry:', priceHistory[0]);
"
```

**Expected Results**:
- ✅ Browser navigates to Discogs release page
- ✅ CAPTCHA detected (if present)
- ✅ Price history extracted (if no CAPTCHA or after solving)
- ✅ Returns array of price history entries with:
  - Date
  - Price
  - Currency
  - Condition (media + sleeve)
  - Seller (if available)

**Note**: This test may require manual CAPTCHA solving in development mode.

### 5. Data Quality Validation

**Objective**: Verify data quality meets Python AI requirements

**Quality Checks**:

1. **Completeness**:
```sql
SELECT 
  COUNT(*) as total,
  COUNT(CASE WHEN artist IS NOT NULL THEN 1 END) as has_artist,
  COUNT(CASE WHEN album IS NOT NULL THEN 1 END) as has_album,
  COUNT(CASE WHEN catalog_number IS NOT NULL THEN 1 END) as has_catalog,
  COUNT(CASE WHEN format IS NOT NULL THEN 1 END) as has_format,
  COUNT(CASE WHEN condition IS NOT NULL THEN 1 END) as has_condition,
  AVG(completeness_score) as avg_completeness
FROM auction_monitor.normalized_listings
WHERE confidence_score >= 0.7;
```

2. **Confidence Distribution**:
```sql
SELECT 
  CASE 
    WHEN confidence_score >= 0.8 THEN 'High (≥0.8)'
    WHEN confidence_score >= 0.7 THEN 'Medium (0.7-0.8)'
    WHEN confidence_score >= 0.5 THEN 'Low (0.5-0.7)'
    ELSE 'Very Low (<0.5)'
  END as confidence_tier,
  COUNT(*) as count,
  AVG(completeness_score) as avg_completeness,
  AVG(CASE WHEN discogs_release_id IS NOT NULL THEN 1.0 ELSE 0.0 END) as enrichment_rate
FROM auction_monitor.normalized_listings
GROUP BY confidence_tier
ORDER BY confidence_tier DESC;
```

3. **Enrichment Rate**:
```sql
SELECT 
  platform,
  COUNT(*) as total,
  COUNT(CASE WHEN discogs_release_id IS NOT NULL THEN 1 END) as enriched,
  ROUND(100.0 * COUNT(CASE WHEN discogs_release_id IS NOT NULL THEN 1 END) / COUNT(*), 2) as enrichment_rate_pct
FROM auction_monitor.normalized_listings
WHERE confidence_score >= 0.7
GROUP BY platform;
```

**Expected Results**:
- ✅ ≥80% of listings have artist + album
- ✅ ≥60% have catalog numbers
- ✅ ≥70% enrichment rate for eBay/Discogs
- ✅ Average completeness ≥ 0.75 for confidence ≥ 0.7

### 6. Python AI Service Integration Test

**Objective**: Verify Python AI Service can consume Analytics data

**Prerequisites**:
- Analytics Service running
- Price snapshots in `analytics.price_snapshots`
- Python AI Service running

**Steps**:
```bash
# Test Python AI price prediction
curl -X POST http://localhost:5005/predict \
  -H "Content-Type: application/json" \
  -d '{
    "items": [{
      "query": "The Beatles Abbey Road",
      "base_price": 50.00,
      "record_grade": "NM",
      "sleeve_grade": "NM"
    }]
  }'
```

**Expected Results**:
- ✅ Python AI Service responds with price prediction
- ✅ Uses Analytics Service data (median prices, trends)
- ✅ Returns confidence score
- ✅ Handles missing data gracefully

## Service Restart Checklist

### Before Testing

1. **Stop Services** (if running):
```bash
docker-compose down
```

2. **Rebuild Services** (if code changed):
```bash
# Rebuild auction-monitor
docker-compose build auction-monitor

# Rebuild analytics-service (if changed)
docker-compose build analytics-service
```

3. **Start Services**:
```bash
docker-compose up -d auction-monitor analytics-service python-ai-service
```

4. **Wait for Health**:
```bash
# Wait for services to be healthy
docker-compose ps

# Check logs
docker-compose logs -f auction-monitor
```

### Service Dependencies

```
auction-monitor
  ├── postgres (auction_monitor DB)
  ├── redis (caching, rate limiting)
  └── kafka (optional, for async processing)

analytics-service
  ├── postgres (analytics DB)
  └── redis (caching)

python-ai-service
  ├── analytics-service (HTTP)
  └── redis (model caching)
```

## Test Execution Order

1. ✅ **Service Health Check** (5 min)
2. ✅ **Data Ingestion Test** (10 min)
3. ✅ **Analytics Ingestion Test** (10 min)
4. ✅ **Discogs Price History Test** (15 min, may require CAPTCHA)
5. ✅ **Data Quality Validation** (10 min)
6. ✅ **Python AI Integration Test** (5 min)

**Total Time**: ~55 minutes

## Success Criteria

### Minimum Requirements
- ✅ All services healthy and responding
- ✅ Data ingestion working (eBay + Discogs)
- ✅ Normalized listings stored with confidence ≥ 0.5
- ✅ Analytics ingestion processing listings with confidence ≥ 0.7
- ✅ Price percentiles calculated correctly
- ✅ Data quality metrics meet thresholds

### Production Readiness
- ✅ ≥80% of listings have confidence ≥ 0.7
- ✅ ≥70% enrichment rate (catalog number matches)
- ✅ ≥90% data completeness for high-confidence listings
- ✅ Python AI Service successfully consuming Analytics data
- ✅ Error rate < 5%
- ✅ All monitoring/alerting in place

## Troubleshooting

### Common Issues

1. **Services Not Starting**:
   - Check Docker logs: `docker-compose logs <service>`
   - Verify environment variables: `.env` file
   - Check database connections

2. **Low Confidence Scores**:
   - Verify platform adapters are working
   - Check enrichment (Discogs catalog matching)
   - Review validation errors

3. **Analytics Not Processing**:
   - Verify confidence threshold (≥0.7)
   - Check database connections
   - Review ingestion pipeline logs

4. **Discogs CAPTCHA Issues**:
   - Set `DISCOGS_WAIT_FOR_CAPTCHA=true` for manual solving
   - Consider automated CAPTCHA solving service for production
   - Reduce scraping frequency

## Next Steps After Testing

1. **Fix Issues**: Address any problems found during testing
2. **Performance Tuning**: Optimize slow queries, add indexes
3. **Monitoring**: Set up alerts for data quality metrics
4. **Documentation**: Update runbooks with test results
5. **Production Deployment**: Deploy to production after all tests pass

