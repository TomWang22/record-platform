# Comprehensive Test Suite Plan

## Overview

This document outlines the comprehensive test suite for the Auction Monitor analytics pipeline, focusing on data quality, performance, and Python AI readiness.

## Test Categories

### 1. Unit Tests

#### 1.1 Percentile Calculation Tests
- **File**: `src/__tests__/percentiles.test.ts`
- **Tests**:
  - Verify p1-p99 calculation for various data sizes
  - Test edge cases (1 item, 2 items, 100 items, 1000 items)
  - Verify percentile ordering (p1 < p2 < ... < p99)
  - Test with duplicate prices
  - Test with extreme outliers
  - Verify summary statistics (min, max, mean, median, stdDev)

#### 1.2 Data Quality Tests
- **File**: `src/__tests__/data-quality.test.ts`
- **Tests**:
  - Confidence scoring calculation
  - Completeness scoring
  - Source reliability scoring
  - Enrichment bonus calculation
  - Threshold validation (≥0.5, ≥0.7, ≥0.8)

#### 1.3 Historical Comparison Tests
- **File**: `src/__tests__/historical.test.ts`
- **Tests**:
  - 90-day window calculation
  - Trend detection (increasing/decreasing/stable)
  - Average price calculation
  - Price change percentage

### 2. Integration Tests

#### 2.1 Full Pipeline Test
- **File**: `scripts/test-full-pipeline.ts`
- **Tests**:
  - Service health check
  - eBay data ingestion
  - Discogs data ingestion
  - Analytics ingestion
  - Data quality validation

#### 2.2 Comprehensive Analytics Test
- **File**: `scripts/test-analytics-comprehensive.ts`
- **Tests**:
  - Granular percentiles (p1-p99) calculation
  - Data quality pipeline (confidence filtering)
  - Historical comparison
  - Python AI data format validation
  - Performance (1000 listings)

### 3. Load Tests

#### 3.1 Analytics Service Load Test
- **File**: `scripts/load-test-analytics.ts`
- **Tests**:
  - 100 listings
  - 500 listings
  - 1,000 listings
  - 5,000 listings
  - 10,000 listings

**Metrics Tracked**:
- Throughput (listings/sec)
- Average time per listing
- Memory usage
- Database query performance
- Percentile calculation time
- Error rate

**Performance Targets**:
- Throughput: ≥10 listings/sec
- Average time: ≤100ms per listing
- Memory: ≤500MB for 10,000 listings
- Error rate: <1%

### 4. End-to-End Tests

#### 4.1 Data Flow Test
- **Test Flow**:
  1. Platform adapter (eBay/Discogs) → Raw listings
  2. Staging pipeline → Normalized listings
  3. Analytics pipeline → Price history with percentiles
  4. Python AI → Data format validation

#### 4.2 Data Quality Gate Test
- **Test Flow**:
  1. Create listings with varying confidence scores
  2. Verify only high-confidence (≥0.7) are processed
  3. Verify low-confidence (<0.7) are filtered out
  4. Verify Python AI receives only quality data

### 5. Data Quality Tests

#### 5.1 Confidence Score Distribution
- **Test**: Verify confidence score distribution
- **Target**: ≥50% of listings have confidence ≥0.7

#### 5.2 Completeness Score
- **Test**: Verify completeness score calculation
- **Target**: Average completeness ≥0.75

#### 5.3 Enrichment Rate
- **Test**: Verify Discogs catalog matching
- **Target**: ≥70% enrichment rate for eBay/Discogs

### 6. Python AI Readiness Tests

#### 6.1 Data Format Validation
- **Required Fields**:
  - `percentiles.p1` through `percentiles.p99`
  - `percentiles.min`, `percentiles.max`
  - `percentiles.mean`, `percentiles.median`
  - `percentiles.stdDev`
  - `percentiles.count`
  - `pricePosition`

#### 6.2 Data Type Validation
- **Tests**:
  - All numeric fields are numbers (not strings)
  - Price position is between 0.0 and 1.0
  - Count is a positive integer
  - Percentiles are non-negative numbers

#### 6.3 Data Completeness
- **Tests**:
  - All percentiles p1-p99 are present
  - No null/undefined values
  - Summary statistics are calculated

## Test Execution

### Run All Tests
```bash
cd services/auction-monitor

# Unit tests
npm test

# Integration tests
npm run test:pipeline
npm run test:analytics

# Load tests
npm run test:load
```

### Run Specific Test Suite
```bash
# Full pipeline test
npm run test:pipeline

# Comprehensive analytics test
npm run test:analytics

# Load test
npm run test:load
```

## Test Data Requirements

### Test Database
- **Auction Monitor DB**: `postgresql://postgres:postgres@localhost:5438/auction_monitor`
- **Analytics DB**: `postgresql://postgres:postgres@localhost:5439/analytics`

### Test Data Generation
- **Small**: 100 listings (for unit tests)
- **Medium**: 1,000 listings (for integration tests)
- **Large**: 10,000 listings (for load tests)

### Test Data Characteristics
- **Confidence Scores**: Mix of 0.45, 0.65, 0.75, 0.85, 0.95
- **Prices**: Random distribution (10-210 USD)
- **Platforms**: eBay, Discogs, test platform
- **Conditions**: Very Good, Good, Fair

## Performance Benchmarks

### Percentile Calculation
- **Target**: <50ms for 100 listings
- **Target**: <500ms for 1,000 listings
- **Target**: <5s for 10,000 listings

### Database Queries
- **Target**: <100ms per query
- **Target**: <1s for batch operations

### Memory Usage
- **Target**: <100MB for 1,000 listings
- **Target**: <500MB for 10,000 listings

## Continuous Testing

### Pre-Commit Hooks
- Run unit tests
- Run integration tests
- Verify data quality

### CI/CD Pipeline
- Run all tests on every commit
- Run load tests on pull requests
- Generate test reports

## Test Reports

### Test Results Format
- **Console Output**: Real-time test progress
- **CSV Export**: Load test results
- **JSON Export**: Detailed test results

### Metrics Dashboard
- **Throughput**: Listings processed per second
- **Latency**: Average time per listing
- **Error Rate**: Percentage of failed operations
- **Memory Usage**: Heap and RSS memory

## Troubleshooting

### Common Issues

#### 1. Low Throughput
- **Cause**: Database connection pool too small
- **Fix**: Increase pool size in connection string

#### 2. High Memory Usage
- **Cause**: Too many concurrent operations
- **Fix**: Reduce batch size or concurrent batches

#### 3. Percentile Calculation Errors
- **Cause**: Insufficient data points
- **Fix**: Ensure at least 10 listings for accurate percentiles

#### 4. Data Quality Failures
- **Cause**: Low confidence scores
- **Fix**: Verify data completeness and source reliability

## Next Steps

1. ✅ Create comprehensive test suite
2. ✅ Create load testing script
3. ⚠️ Run tests with real data
4. ⚠️ Optimize performance based on results
5. ⚠️ Set up CI/CD pipeline
6. ⚠️ Create test reports dashboard

---

**Status**: ✅ Test suite created, ready for execution

