# Python AI Service - Frontend Integration Guide

## Overview

The Python AI Service provides AI-powered price predictions, recommendations, and chat functionality. It integrates with the Analytics Service to provide enhanced insights.

## API Gateway Routes

All Python AI endpoints are accessible through the API Gateway at `/ai/*`:

- **Base URL**: `http://localhost:3000/api/ai` (via API Gateway)
- **Direct URL**: `http://localhost:5005` (direct service access)

## Frontend Endpoints

### 1. Price Prediction (AI-Enhanced)

**Endpoint**: `POST /ai/predict-price`

**Request**:
```json
{
  "items": [
    {
      "query": "The Beatles Abbey Road",
      "base_price": 50.00,
      "record_grade": "NM",
      "sleeve_grade": "VG+",
      "promo": false,
      "anniversary_boost": 0.0
    }
  ]
}
```

**Response**:
```json
{
  "suggested": 52.50,
  "local_suggested": 52.00,
  "analytics_suggested": 53.00,
  "samples": 1,
  "estimates": [52.50],
  "t_ms": 150
}
```

**Features**:
- Blends local AI prediction with Analytics Service prediction
- Returns both individual estimates and blended suggestion
- Includes processing time in milliseconds

### 2. Recommendations (AI-Powered)

**Endpoint**: `GET /ai/recommendations?q=The Beatles&user_id=user-123&limit=10`

**Response**:
```json
{
  "query": "The Beatles",
  "recommendations": [
    {
      "query": "The Beatles White Album",
      "count": 15,
      "last_searched": "2024-01-15T10:30:00Z"
    }
  ],
  "source": "analytics"
}
```

**Features**:
- Uses Analytics Service for similar searches
- Personalized based on user_id (if provided)
- Returns source of recommendations

### 3. Trending Items (AI-Enhanced)

**Endpoint**: `GET /ai/trending?days=7&limit=20`

**Response**:
```json
{
  "days": 7,
  "trending": [
    {
      "query": "The Beatles Abbey Road",
      "count": 42,
      "trend": "up"
    }
  ],
  "source": "analytics"
}
```

**Features**:
- Aggregates trending data from Analytics Service
- Returns source of trending data

### 4. Price Trends (AI Analysis)

**Endpoint**: `GET /ai/price-trends?q=The Beatles Abbey Road`

**Response**:
```json
{
  "count": 25,
  "low": 45.00,
  "p50": 50.00,
  "high": 75.00,
  "query": "The Beatles Abbey Road",
  "discogs_titles": ["Abbey Road - The Beatles", ...],
  "ebay_price_summ": {
    "count": 25,
    "low": 45.00,
    "p50": 50.00,
    "high": 75.00
  }
}
```

**Features**:
- Fetches data from both eBay and Discogs
- Returns price statistics (low, median, high)
- Includes Discogs title matches
- Cached in Redis for 2 minutes

### 5. AI Chatbot

**Endpoint**: `POST /ai/chat`

**Request**:
```json
{
  "message": "What's a good price for The Beatles Abbey Road?",
  "user_id": "user-123",
  "context": "negotiation"
}
```

**Response**:
```json
{
  "message": "What's a good price for The Beatles Abbey Road?",
  "response": "I understand you're asking about: What's a good price for The Beatles Abbey Road?\n\nBased on similar searches, I found: The Beatles White Album, The Beatles Sgt. Pepper's\n\nI can help you find price trends. Try asking about a specific record or use the price-trends endpoint.",
  "analytics_context": {
    "recommendations": [...]
  },
  "timestamp": 1705315800.0
}
```

**Features**:
- Uses Analytics Service for context
- Provides intelligent responses based on analytics data
- Cached in Redis for 5 minutes
- Can be extended with LLM integration

## Frontend Integration Examples

### React Example

```typescript
// AI Price Prediction
const predictPrice = async (items: PredictItem[]) => {
  const response = await fetch('/api/ai/predict-price', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items }),
  })
  const data = await response.json()
  return {
    suggested: data.suggested,
    local: data.local_suggested,
    analytics: data.analytics_suggested,
    processingTime: data.t_ms,
  }
}

// AI Recommendations
const getRecommendations = async (query: string, userId?: string) => {
  const params = new URLSearchParams({ q: query, limit: '10' })
  if (userId) params.append('user_id', userId)
  
  const response = await fetch(`/api/ai/recommendations?${params}`)
  const data = await response.json()
  return data.recommendations
}

// AI Chat
const chat = async (message: string, userId?: string, context?: string) => {
  const response = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, user_id: userId, context }),
  })
  const data = await response.json()
  return data.response
}

// Price Trends
const getPriceTrends = async (query: string) => {
  const response = await fetch(`/api/ai/price-trends?q=${encodeURIComponent(query)}`)
  const data = await response.json()
  return {
    low: data.low,
    median: data.p50,
    high: data.high,
    count: data.count,
    discogsTitles: data.discogs_titles,
  }
}
```

### Vue Example

```vue
<template>
  <div>
    <input v-model="query" @input="getRecommendations" />
    <div v-for="rec in recommendations" :key="rec.query">
      {{ rec.query }} ({{ rec.count }} searches)
    </div>
    
    <button @click="predictPrice">Predict Price</button>
    <div v-if="prediction">
      Suggested: ${{ prediction.suggested }}
      (Analytics: ${{ prediction.analytics }}, Local: ${{ prediction.local }})
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const query = ref('')
const recommendations = ref([])
const prediction = ref(null)

const getRecommendations = async () => {
  const res = await fetch(`/api/ai/recommendations?q=${query.value}`)
  const data = await res.json()
  recommendations.value = data.recommendations
}

const predictPrice = async () => {
  const res = await fetch('/api/ai/predict-price', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      items: [{ query: query.value }],
    }),
  })
  const data = await res.json()
  prediction.value = data
}
</script>
```

## Integration Flow

```
Frontend
  ↓
API Gateway (/api/ai/*)
  ↓
Python AI Service
  ↓
Analytics Service (for data)
  ↓
Returns AI-enhanced results
```

## Authentication

All endpoints require authentication via JWT token (except `/ai/healthz`).

Include the token in the `Authorization` header:
```
Authorization: Bearer <jwt-token>
```

The API Gateway automatically injects user identity headers for authenticated requests.

## Caching

- **Price Trends**: Cached in Redis for 2 minutes
- **Chat Responses**: Cached in Redis for 5 minutes
- **Recommendations**: Uses Analytics Service caching

## Error Handling

All endpoints return standard HTTP status codes:
- `200`: Success
- `400`: Bad Request (missing/invalid parameters)
- `401`: Unauthorized (missing/invalid token)
- `500`: Internal Server Error

Error responses:
```json
{
  "error": "Error message",
  "details": "Detailed error information"
}
```

