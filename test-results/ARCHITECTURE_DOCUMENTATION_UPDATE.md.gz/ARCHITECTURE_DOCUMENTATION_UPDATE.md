# Architecture Documentation Update: Envoy Split

**Date**: January 5, 2026  
**Author**: Tom  
**Status**: Complete

---

## Summary

Complete overhaul of architecture documentation to reflect the Envoy split: **Envoy for gRPC**, **Caddy for HTTP/3 + web + REST**.

---

## Changes Made

### README.md

#### System Architecture Diagram
- ✅ Updated to show Envoy for gRPC (port 10000) and Caddy for HTTP/3 + web + REST (port 30443)
- ✅ Clear separation of traffic types
- ✅ Shows both proxies with their specific responsibilities

#### Highlights Section
- ✅ Multi-protocol edge: Updated to mention Envoy for gRPC
- ✅ Full gRPC inter-service communication: Updated to mention Envoy handles all gRPC traffic

#### Full Multi-Protocol Support Section
- ✅ Updated to mention Envoy gRPC routing (port 10000)
- ✅ Updated to mention TLS transport via Envoy
- ✅ Key technical achievements: Updated to Envoy

#### Edge & Routing Section
- ✅ Caddy: Updated to reflect HTTP/3, web, and REST API focus
- ✅ Envoy: New section added with first-class gRPC support details
- ✅ Removed references to Caddy gRPC routing

#### Inter-Service Communication Section
- ✅ Updated to mention Envoy gRPC proxy (port 10000)
- ✅ Removed references to Caddy gRPC proxy
- ✅ Added architecture decision note

#### Auth & Identity Flow Section
- ✅ Updated to show Envoy in the flow: Caddy → ingress → gateway → Envoy → auth-service

#### Supporting Infrastructure Section
- ✅ Edge & Routing: Updated to mention Envoy
- ✅ Removed references to Caddy gRPC routing

### ENGINEERING.md

#### High-Level Architecture Diagram
- ✅ Updated to show Envoy for gRPC and Caddy for HTTP/3 + web + REST
- ✅ Clear separation with decision rationale

#### Why Caddy Over Nginx/Traefik?
- ✅ Updated to reflect HTTP/3, web, and REST API focus
- ✅ Added note about gRPC limitations (Issue #17 in Runbook.md)

#### Why Envoy for gRPC? (NEW SECTION)
- ✅ Comprehensive new section explaining the decision
- ✅ Rationale: First-class gRPC support, proven functionality, etc.
- ✅ Architecture details: Envoy for gRPC, Caddy for HTTP/3 + web + REST
- ✅ Trade-offs and mitigation strategies
- ✅ Reference to investigation documentation

#### gRPC Communication Section
- ✅ Updated to mention Envoy gRPC routing
- ✅ Removed references to Caddy gRPC routing

#### Data Flow Diagrams
- ✅ Authentication Flow: Updated to show Envoy
- ✅ Record Search Flow: Updated to show Envoy
- ✅ Real-Time Messaging Flow: Updated to show Envoy

#### Edge & Routing Technology Stack
- ✅ Updated to mention Envoy for gRPC
- ✅ Updated Caddy description to focus on HTTP/3, web, REST

---

## Architecture Summary

### Envoy (gRPC Proxy)
- **Port**: 10000
- **Traffic**: All gRPC requests
- **Features**:
  - First-class gRPC support
  - Never routes through HTTP handlers
  - Trailer preservation
  - Error handling for gRPC
  - HEADERS/DATA ordering enforcement
- **Status**: ✅ Proven functionality (Envoy test passed)

### Caddy (Edge Proxy)
- **Port**: 30443 (NodePort)
- **Traffic**: HTTP/3, web app (Next.js), REST API (/api/*), static assets
- **Features**:
  - HTTP/2 + HTTP/3 (QUIC) support
  - TLS termination (TLS 1.2/1.3 only)
  - Zero-downtime CA rotation
  - Web app serving
  - REST API routing
- **Status**: ✅ Excels at HTTP/3, web, and REST

---

## Decision Rationale

**What We Tried**:
1. Added `protocol grpc` matcher
2. Verified route order
3. Enhanced Node.js header logging
4. Removed Host header manipulation
5. Hard-isolated gRPC routes
6. Envoy test (PASSED)

**What We Proved**:
1. Node.js server is correct (direct connections work, Envoy works)
2. Issue is Caddy-specific (same server fails with Caddy, works with Envoy)
3. Root cause: Caddy generates HTTP responses for gRPC requests before proxying
4. Not a connection preface issue (HTTP/2 connection established correctly)
5. Not an ALPN issue (protocol negotiation works correctly)

**Why We Chose Envoy**:
1. First-class gRPC support
2. Proven functionality (Envoy test passed immediately)
3. No HTTP handler interference
4. Trailer preservation
5. Error handling (forbids HTTP error pages on gRPC streams)

**Trade-offs**:
- ✅ Reliability: Envoy works immediately
- ✅ Performance: Each proxy optimized for its use case
- ✅ Maintainability: Clear separation of concerns
- ✅ Industry standard: Proven architecture pattern
- ❌ Two proxies to manage (more operational complexity)
- ❌ Two configs to maintain (Caddyfile + Envoy YAML)
- ❌ Additional resource usage (two proxy processes)

**Mitigation**:
- Documentation: Clear documentation of routing rules
- Automation: Scripts to manage both configs
- Monitoring: Unified monitoring for both proxies
- Standard pattern: This is a well-known architecture pattern

---

## Files Updated

1. ✅ `README.md` - Complete architecture overhaul
2. ✅ `ENGINEERING.md` - Complete architecture overhaul
3. ✅ `Runbook.md` - Issue #17 added (January 5, 2026)
4. ✅ `test-results/CADDY_ENVOY_DECISION.md` - Decision documentation
5. ✅ `test-results/CADDY_GITHUB_ISSUE.md` - Issue report (reframed)
6. ✅ `test-results/ARCHITECTURE_DOCUMENTATION_UPDATE.md` - This file

---

## Verification

All references to "Caddy gRPC routing" have been updated to reflect:
- Envoy handles all gRPC traffic
- Caddy handles HTTP/3, web, and REST API traffic
- Clean separation of concerns
- Industry standard pattern

---

## Conclusion

**Status**: ✅ Complete

All architecture documentation now accurately reflects the Envoy split:
- **Envoy for gRPC** (port 10000)
- **Caddy for HTTP/3 + web + REST** (port 30443)

This is a clean separation of concerns, not a workaround. It's an industry standard pattern used by many production systems.

---

**Last Updated**: January 5, 2026  
**Author**: Tom
