# Baseline Performance Metrics - 1 Replica Per Service

**Date**: January 6, 2026  
**Test Type**: Comprehensive k6 Load Test  
**TLS**: Strict TLS (CA certificate verification)  
**Duration**: 5 minutes  
**VUs**: 50  

## Pod Configuration (Baseline)

### Service Pods (All at 1 Replica)
- **analytics-service**: 1/1
- **auth-service**: 1/1
- **api-gateway**: 1/1
- **auction-monitor**: 1/1
- **listings-service**: 1/1
- **python-ai-service**: 1/1
- **records-service**: 1/1
- **shopping-service**: 1/1
- **social-service**: 1/1

### Ingress
- **caddy-h3**: 2/2 (kept at 2 for zero-downtime rotations)

## Test Results

### Overall Metrics
- **Total Requests**: 10,522
- **Request Rate**: 33.01 req/s
- **Error Rate**: 1.43% (151 errors)
- **Average Duration**: 1.28s
- **Median Duration**: 632.92ms
- **p90 Duration**: 2.84s
- **p95 Duration**: 4.4s
- **Max Duration**: 30s (timeout)

### Service Success Rates (1 Replica Each)

| Service | Success Rate | Requests | Errors | Notes |
|---------|-------------|----------|--------|-------|
| **records** | 99.91% | 2,333 | 2 | ✅ Excellent |
| **shopping** | 99.75% | 2,010 | 5 | ✅ Excellent |
| **analytics** | 99.74% | 771 | 2 | ✅ Excellent |
| **auth** | 99.67% | 1,551 | 5 | ✅ Excellent (bcrypt budgeted) |
| **social** | 99.67% | 1,514 | 5 | ✅ Excellent |
| **listings** | 99.26% | 2,014 | 15 | ✅ Good |
| **python_ai** | 60.06% | 176 | 117 | ⚠️ **BOTTLENECK** |

### Service Latency Metrics (p95)

| Service | p95 Latency | Avg Latency | Max Latency | Notes |
|---------|-------------|-------------|-------------|-------|
| **analytics** | 1.59s | 499ms | 7.19s | ✅ Good |
| **shopping** | 2.58s | 784ms | 11.78s | ✅ Good |
| **auth** | 2.66s | 784ms | 10.59s | ✅ Good (bcrypt overhead expected) |
| **social** | 3.36s | 1.09s | 19.03s | ✅ Acceptable |
| **records** | 5.98s | 1.57s | 14.09s | ⚠️ High p95 |
| **listings** | 6.29s | 1.95s | 16.57s | ⚠️ High p95 |
| **python_ai** | 27.09s | 3.65s | 30s | ❌ **CRITICAL BOTTLENECK** (timeouts) |

### Key Findings

1. **Python AI Service is the Primary Bottleneck**:
   - 60% success rate (117 errors out of 293 requests)
   - p95 latency: 27.09s (very high)
   - Many requests timing out at 30s
   - **Action Required**: Investigate Python AI service performance

2. **Records and Listings Services Have High p95 Latency**:
   - Records: p95 = 5.98s (acceptable but high)
   - Listings: p95 = 6.29s (acceptable but high)
   - **Action Required**: Optimize database queries, connection pooling

3. **Auth Service Performance is Good**:
   - 99.67% success rate despite bcrypt overhead
   - p95 latency: 2.66s (acceptable for bcrypt operations)
   - **Status**: ✅ Well-budgeted for security constraints

4. **Most Services Perform Excellently**:
   - 6 out of 7 services have >99% success rates
   - Overall error rate: 1.43% (excellent for baseline)
   - **Status**: ✅ System is stable at baseline

## Analysis

### Baseline Performance Characteristics
- **Purpose**: Establish baseline with minimal resources (1 pod per service)
- **Use Case**: Identify bottlenecks before scaling
- **Next Steps**: Optimize concurrency and resource usage before scaling up

### Auth Service Budgeting
- **Security Constraint**: bcrypt is CPU-intensive (intentional for security)
- **Budget**: Must account for auth service CPU usage when optimizing
- **Strategy**: Optimize other services first, then scale auth if needed

## Next Steps

### Immediate Actions (Without Scaling)

1. **Python AI Service Investigation** (CRITICAL):
   - Investigate why 40% of requests are failing
   - Check for memory leaks, slow database queries, or blocking operations
   - Review connection pooling and timeout settings
   - **Goal**: Get success rate to >95% before scaling

2. **Records and Listings Optimization**:
   - Review database connection pool settings
   - Optimize slow queries (p95 is high)
   - Check for connection timeouts or retry logic issues
   - **Goal**: Reduce p95 latency to <3s

3. **Concurrency Improvements**:
   - Review connection pooling across all services
   - Optimize request handling (async/await patterns)
   - Check for blocking operations in request handlers
   - **Goal**: Improve throughput without scaling

4. **Auth Service Budgeting**:
   - ✅ Already well-optimized (99.67% success with bcrypt)
   - Monitor CPU usage during load
   - Ensure sufficient CPU allocation for bcrypt operations
   - **Status**: No immediate action needed

### After Optimization

5. **Incremental Scaling**:
   - Scale only services that still need it after optimization
   - Start with Python AI (if optimization doesn't help)
   - Then Records/Listings if p95 latency remains high
   - **Goal**: Scale only what's necessary

## Comparison: Baseline vs Previous (Mixed Scaling)

### Previous Test (Mixed Scaling - 2 replicas for some services):
- Overall error rate: ~48% (much worse)
- Success rates: 46-61% (much worse)
- **Conclusion**: Baseline (1 replica) performs **much better** than mixed scaling

### Baseline (1 Replica All Services):
- Overall error rate: 1.43% (excellent)
- Success rates: 99%+ for 6/7 services (excellent)
- **Conclusion**: System is stable and performant at baseline

### Key Insight:
**Scaling without optimization can make things worse!** The baseline (1 replica) performs significantly better than the previous mixed scaling configuration. This suggests:
- Resource contention when scaling
- Need for optimization before scaling
- Importance of establishing baseline first
