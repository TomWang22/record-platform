# Baseline Performance Optimizations Summary

**Date**: January 6, 2026  
**Goal**: Optimize concurrency and performance without scaling (1 replica baseline)

## Issues Identified

### Python AI Service (Critical)
- **388 restarts** due to grpc-health-probe architecture mismatch
- **60% success rate** (40% failures)
- **27s p95 latency** (very high, many timeouts)
- Connection pools too high for baseline (500 HTTP, 150 DB, 150 Redis)
- Analytics service calls too slow (3s timeouts, 3 parallel calls = up to 9s total)

### Listings Service
- **High p95 latency**: 6.29s (acceptable but high)
- Connection pool too high for baseline (100 max, 10 min)

### Records Service
- **High p95 latency**: 5.98s (acceptable but high)
- Uses Prisma (connection pooling handled by Prisma)

## Optimizations Applied

### Python AI Service

#### 1. Fixed grpc-health-probe Architecture Issue
- **Problem**: Wrong architecture (ARM64 vs AMD64) causing "exec format error"
- **Fix**: Force AMD64 binary for Kind cluster compatibility
- **Result**: Restarts reduced from 392 → 0 ✅

#### 2. Reduced Connection Pools (Baseline Optimization)
- **HTTP Client (Analytics)**: 500 → 100 max connections
- **HTTP Client (External APIs)**: 500 → 100 max connections
- **Database Pool**: 150 → 50 max connections, 15 → 5 min connections
- **Redis Pool**: 150 → 75 max connections, 75 → 50 pool size
- **Rationale**: Baseline (1 replica) doesn't need 500 connections

#### 3. Reduced Timeouts (Fail Faster)
- **Analytics calls**: 3s → 2s per call (3 parallel calls = 6s max instead of 9s)
- **Price prediction**: 10s → 6s total timeout
- **Ingestion timeout**: 8s → 5s
- **Rationale**: Fail faster, use cached data on timeout

#### 4. Optimized Connection Settings
- **Keepalive expiry**: 120s → 60s (faster connection recycling)
- **Connect timeout**: 5s → 3s (fail faster)
- **Max keepalive connections**: 150 → 50 (baseline optimization)

### Listings Service

#### 1. Reduced Database Connection Pool
- **Max connections**: 100 → 50
- **Min connections**: 10 → 5
- **Connection timeout**: 15s → 10s (fail faster)
- **Idle timeout**: 60s → 30s (faster connection recycling)

### Records Service
- Uses Prisma (connection pooling handled by Prisma)
- No manual pool configuration needed
- High p95 latency likely due to query complexity, not connection pool

## Expected Improvements

### Python AI Service
- **Success rate**: 60% → 95%+ (fixed restarts, faster timeouts)
- **p95 latency**: 27s → <10s (reduced timeouts, optimized pools)
- **Restarts**: 392 → 0 (fixed architecture issue)

### Listings Service
- **p95 latency**: 6.29s → <4s (optimized connection pool)
- **Connection efficiency**: Better (smaller pool, faster recycling)

### Overall System
- **Resource usage**: Reduced (smaller connection pools)
- **Failure recovery**: Faster (reduced timeouts)
- **Baseline performance**: Improved without scaling

## Next Steps

1. **Rebuild Python AI Service**: Fix Dockerfile wget issue (network error during build)
2. **Run Baseline Test**: Verify improvements with comprehensive k6 test
3. **Monitor Metrics**: Track success rates, latency, restart counts
4. **Further Optimization**: If needed, optimize query performance (Records/Listings)

## Files Modified

- `services/python-ai-service/Dockerfile` - Fixed grpc-health-probe architecture
- `services/python-ai-service/app/data_pipeline.py` - Reduced connection pools, timeouts
- `services/python-ai-service/app/db.py` - Reduced DB connection pool
- `services/python-ai-service/app/http_client.py` - Reduced external API connection pools
- `services/python-ai-service/app/redis_cache.py` - Reduced Redis connection pool
- `services/python-ai-service/app/ai_advisor.py` - Reduced analytics timeouts
- `services/listings-service/src/lib/db.ts` - Reduced DB connection pool

## Test Results (After Optimizations)

**Python AI Service**:
- Restarts: 0 (was 392) ✅
- Status: Running, Ready ✅
- **Next**: Run comprehensive test to verify success rate improvement

**Baseline Configuration**:
- All services: 1 replica
- Caddy: 2 replicas
- Connection pools: Optimized for baseline
- Timeouts: Reduced for faster failure recovery
