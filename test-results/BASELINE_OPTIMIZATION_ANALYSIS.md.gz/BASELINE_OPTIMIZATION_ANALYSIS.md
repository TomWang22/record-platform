# Baseline Optimization Analysis - Performance Degradation Investigation

**Date**: January 6, 2026  
**Test**: Baseline Comprehensive Test (50 VUs, 5m)  
**Issue**: Performance degraded significantly after connection pool optimizations

## Test Duration Analysis

### Wall-Clock Time
- **Test Duration**: 5m16.4s (normal for 5-minute test)
- **Not the issue**: Test didn't take longer in absolute time

### Efficiency Metrics
- **Original Baseline**: 1,556 iterations, 1.43% error rate
- **Current Test**: 2,127 iterations, 64.12% error rate
- **Key Finding**: More iterations but 64% are errors → wasted time

## Performance Degradation

### Original Baseline (Before Optimizations)
- **Total Requests**: 10,522
- **Request Rate**: 33.01 req/s
- **Error Rate**: 1.43%
- **Success Rates**: 99%+ for all services
- **Iteration Duration**: avg 9.82s, p95 28.92s

### After Aggressive Optimizations
- **Total Requests**: 14,477 (+37% - more retries)
- **Request Rate**: 45.75 req/s (+38% - faster failures)
- **Error Rate**: 64.12% (45x worse!)
- **Success Rates**: 34-38% for all services
- **Iteration Duration**: avg 7.14s, p95 29.36s

## Root Cause Analysis

### 1. Connection Pool Exhaustion
**Problem**: Connection pools reduced too aggressively
- Python AI DB: 150 → 50 max connections
- Python AI HTTP: 500 → 100 max connections
- Listings DB: 100 → 50 max connections

**Impact**:
- 50 max connections insufficient for 50 VUs
- Services wait for available connections
- Connection pool creation timeouts (15s)
- Cascading connection starvation

### 2. Cascading Failures
**Problem**: All services failing simultaneously
- Auth: 37.61% success (was 99.67%)
- Records: 38.27% success (was 99.91%)
- Listings: 35.72% success (was 99.26%)
- All services: 34-38% success (was 99%+)

**Impact**:
- System-wide failure (not isolated to one service)
- Suggests systemic issue (connection pool exhaustion)
- Each service failure causes more load on others

### 3. Timeout Cascades
**Problem**: Requests timing out due to connection waits
- Many requests hit 30s timeout limit
- p95 iteration duration: 29.36s (hitting timeout)
- Max iteration: 55.2s (multiple timeouts)

**Impact**:
- Each timeout wastes 30s
- Timeouts cause retries → more load
- More load → more timeouts → vicious cycle

### 4. Request Pattern Changes
**Problem**: More requests but mostly failures
- 14,477 requests (vs 10,522) - 37% more
- 64.12% error rate (vs 1.43%) - 45x worse
- Higher request rate (45 vs 33) - but mostly retries

**Impact**:
- System thrashing instead of processing
- Wasted time on failed requests
- More load from retries → more failures

## Why Test "Took So Long"

The test didn't take longer in wall-clock time, but it was **much less efficient**:

1. **Connection Pool Exhaustion**: Services waiting for connections → timeouts
2. **High Error Rate**: 64% of requests fail → retries → more load
3. **Timeout Cascades**: Many requests hit 30s timeout → long iterations
4. **System Thrashing**: More requests but mostly failures → wasted time

## Solution Applied

### Connection Pool Rebalancing
Reverted to balanced values (not too aggressive):

- **Python AI DB**: 50 → 75 max, 5 → 10 min
- **Python AI HTTP**: 100 → 150 max
- **Python AI Redis**: 75 → 100 max
- **Python AI External APIs**: 100 → 125 max
- **Listings DB**: 50 → 75 max, 5 → 10 min

### Kept Good Optimizations
- Timeout optimizations (fail faster is good)
- Keepalive optimizations (faster connection recycling)
- grpc-health-probe architecture fix (restarts: 392 → 0)

## Next Steps

1. **Rebuild Services**: With balanced connection pools
2. **Retest Baseline**: Verify performance improvement
3. **Fine-Tune**: Adjust pools based on test results
4. **Document**: Optimal connection pool sizes for baseline

## Key Learnings

1. **Connection pools too small**: Cause connection exhaustion → timeouts
2. **Systemic failures**: All services failing suggests connection pool issue
3. **Balance is key**: Not too small (exhaustion) or too large (resource waste)
4. **Test efficiency matters**: More requests but mostly failures = wasted time

## Metrics to Monitor

- Connection pool utilization
- Connection wait times
- Timeout rates
- Error rates by service
- Iteration duration percentiles
