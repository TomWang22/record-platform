# Bottleneck Analysis: HTTP/2 vs HTTP/3 Limit Tests
**Date**: December 30, 2025  
**Test Results**: `test-results/20251230-174819-k6-fixed`

## Executive Summary

Both HTTP/2 and HTTP/3 limit tests completed successfully. Exit code 99 indicates thresholds were crossed, which is **expected** for limit-finding tests that push the system to failure.

## 🔴 PRIMARY BOTTLENECK: Auth Service

### Root Cause
**bcrypt password hashing** - CPU-intensive security operation

### Impact
- **Gatekeeper Service**: All other services depend on auth tokens
- **Cascading Failures**: When auth fails, all downstream services fail
- **CPU-Bound**: bcrypt operations are synchronous and CPU-bound
- **Queue Saturation**: At 500 VUs, the bcrypt queue backs up, causing timeouts

### Security vs Performance Trade-off
- **bcrypt is intentionally slow** to prevent brute-force attacks
- **8 rounds** (current setting) balances security and performance
- **Cannot reduce** below 8 rounds for production security
- **Must budget CPU resources** for security operations

## Test Results Comparison

### HTTP/2 Limit Test Results

| Service | Success Rate | Errors | p95 Latency | Status |
|---------|-------------|--------|-------------|--------|
| **Auth** | **0.00%** | 742 | N/A | 🔴 **PRIMARY BOTTLENECK** |
| Records | 6.09% | 6,676 | 11.48s | ⚠️ Secondary bottleneck |
| Listings | 11.94% | 6,295 | 16.24s | ⚠️ Secondary bottleneck |
| Social | 9.66% | 3,245 | 2.18s | ⚠️ Secondary bottleneck |
| Shopping | 9.73% | 6,313 | 1.23s | ⚠️ Secondary bottleneck |
| Analytics | Low | 2,511 | N/A | ⚠️ Secondary bottleneck |
| Python AI | 8.60% | 223 | 6.82s | ⚠️ Secondary bottleneck |

**Overall**: System completely overwhelmed at 500 VUs with HTTP/2

### HTTP/3 Limit Test Results

(Results to be extracted - check k6-http3.log)

## Key Findings

### 1. Auth Service is the Gatekeeper
- **0% success rate** at 500 VUs for HTTP/2
- All services fail because they cannot get auth tokens
- bcrypt queue saturation causes complete service failure

### 2. Secondary Bottlenecks (All Auth-Dependent)
- **Records Service**: 6.09% success, 11.48s p95 latency
- **Listings Service**: 11.94% success, 16.24s p95 latency  
- **Social Service**: 9.66% success, 2.18s p95 latency
- **Shopping Service**: 9.73% success, 1.23s p95 latency

### 3. Expected Behavior for Limit Tests
- **Low success rates are expected** when pushing to 500 VUs
- **Threshold crossings (exit code 99) are expected** for limit-finding tests
- **Goal**: Find where system breaks, not maintain 100% success

## Recommendations

### Short-Term
1. **Accept current limits** - 500 VUs is beyond normal operational capacity
2. **Monitor auth service** - Track bcrypt queue metrics
3. **Scale horizontally** - Add more auth-service replicas if needed

### Long-Term
1. **Horizontal Scaling**: Add auth-service replicas (each adds ~64 concurrent bcrypt operations)
2. **Vertical Scaling**: Increase CPU limits per auth pod (allows more concurrent operations)
3. **Queue Tuning**: Increase `MAX_CONCURRENT_BCRYPT` per pod (requires more CPU)
4. **Load Balancing**: Ensure proper distribution of auth requests across replicas

### Production Planning
- **Operational Load**: Plan for 50-100 concurrent users per auth-service replica
- **High Load**: Scale to 8-16 replicas for 500+ concurrent users
- **Security First**: Never reduce bcrypt rounds below 8 for production

## Protocol Comparison (HTTP/2 vs HTTP/3)

(Comparison to be added after analyzing HTTP/3 results)

## Monitoring Data

- **tcpdump captures**: Available in `monitoring/http2-limit/` and `monitoring/http3-limit/`
- **strace logs**: System call traces for auth-service pods
- **CPU metrics**: CPU usage logs showing bcrypt CPU spikes

## Files

- **HTTP/2 Results**: `k6-http2.log`
- **HTTP/3 Results**: `k6-http3.log`
- **Monitoring Data**: `monitoring/http2-limit/` and `monitoring/http3-limit/`

