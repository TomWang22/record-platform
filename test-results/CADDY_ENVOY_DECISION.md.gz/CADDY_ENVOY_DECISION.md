# Decision: Envoy for gRPC, Caddy for HTTP/3 + Web + REST

**Date**: January 5, 2026  
**Author**: Tom  
**Status**: Final Decision

---

## Executive Summary

After extensive investigation, we've decided to use **Envoy for gRPC routing** and **Caddy for HTTP/3 + web + REST**. This is a clean separation of concerns based on proven functionality, not a workaround.

---

## What We Tried

### Investigation Steps

1. ✅ **Added `protocol grpc` matcher** - No effect
2. ✅ **Verified route order** - gRPC routes come first
3. ✅ **Enhanced Node.js header logging** - Not reached (error occurs before handler)
4. ✅ **Removed Host header manipulation** - No effect
5. ✅ **Hard-isolated gRPC routes** - No effect
6. ✅ **Envoy test** - **PASSED** (definitive proof)

### Key Findings

**Caddy Behavior**:
- ✅ Successfully negotiates HTTP/2 upstream
- ✅ Opens HTTP/2 stream
- ❌ **Routes gRPC requests through HTTP handler paths**
- ❌ Generates HTTP 403 (text/plain) responses
- ❌ grpc-js sees invalid gRPC → "Unknown protocol"

**Envoy Behavior**:
- ✅ Successfully negotiates HTTP/2 upstream
- ✅ Opens HTTP/2 stream
- ✅ **Never routes gRPC through HTTP handlers**
- ✅ Preserves trailers correctly
- ✅ Forbids HTTP error pages on gRPC streams
- ✅ Enforces correct HEADERS/DATA ordering

**Proof**: Envoy test **PASSED** - same Node.js server works perfectly through Envoy.

---

## What We Proved

1. **Node.js server is correct**: Direct connections work, Envoy works
2. **Issue is Caddy-specific**: Same server fails with Caddy, works with Envoy
3. **Root cause**: Caddy generates HTTP responses for gRPC requests before proxying
4. **Not a connection preface issue**: HTTP/2 connection is established correctly
5. **Not an ALPN issue**: Protocol negotiation works correctly

---

## Why We Chose Envoy

### Technical Reasons

1. **First-class gRPC support**: Envoy has native gRPC awareness
2. **Proven functionality**: Envoy test passed immediately
3. **No HTTP handler interference**: Envoy never routes gRPC through HTTP handlers
4. **Trailer preservation**: Envoy correctly handles gRPC trailers
5. **Error handling**: Envoy forbids HTTP error pages on gRPC streams

### Architectural Reasons

1. **Separation of concerns**: 
   - Envoy: gRPC (specialized)
   - Caddy: HTTP/3, web, REST (specialized)
2. **Industry standard**: Many production systems use this exact architecture
3. **Not a hack**: This is a legitimate, well-documented pattern
4. **Maintainability**: Each proxy does what it's best at

---

## Tradeoffs

### Advantages

✅ **Reliability**: Envoy works immediately, no fighting with Caddy  
✅ **Performance**: Each proxy optimized for its use case  
✅ **Maintainability**: Clear separation of concerns  
✅ **Industry standard**: Proven architecture pattern  
✅ **Future-proof**: Easy to scale each component independently  

### Disadvantages

❌ **Two proxies to manage**: More operational complexity  
❌ **Two configs to maintain**: Caddyfile + Envoy YAML  
❌ **Additional resource usage**: Two proxy processes  
❌ **Routing complexity**: Need to route gRPC to Envoy, HTTP to Caddy  

### Mitigation

- **Documentation**: Clear documentation of routing rules
- **Automation**: Scripts to manage both configs
- **Monitoring**: Unified monitoring for both proxies
- **Standard pattern**: This is a well-known architecture pattern

---

## Implementation Plan

### Step 1: Freeze Caddy gRPC Config

- ✅ Keep existing Caddyfile gRPC routes (for reference)
- ✅ Document that gRPC routing is not functional via Caddy
- ✅ Focus Caddy on HTTP/3 + web + REST

### Step 2: Commit Envoy Split

- ✅ Envoy for all gRPC traffic
- ✅ Caddy for HTTP/3 + web + REST
- ✅ Clean separation of concerns

### Step 3: File Caddy Issue

- ✅ Frame correctly: "Caddy generates HTTP responses for gRPC requests"
- ✅ Not: "missing preface", "HTTP/2 bug", "ALPN bug"
- ✅ Include Envoy test results as proof

### Step 4: Document Decision

- ✅ This document
- ✅ Runbook.md entry
- ✅ Architecture decision record

---

## Architecture

```
Client
  │
  ├─ gRPC requests → Envoy (port 10000) → gRPC services
  │
  └─ HTTP/3 + web + REST → Caddy (port 30443) → HTTP services
```

**Routing Rules**:
- **gRPC**: `grpcurl` → Envoy → gRPC services
- **HTTP/3**: `curl --http3` → Caddy → HTTP services
- **REST API**: `curl` → Caddy → API Gateway → REST services
- **Web**: Browser → Caddy → Webapp

---

## Files

- `test-results/CADDY_ENVOY_DECISION.md` - This document
- `test-results/CADDY_GITHUB_ISSUE.md` - Caddy issue report
- `test-results/CADDY_REAL_BUG_ANALYSIS.md` - Detailed bug analysis
- `infra/k8s/base/envoy-test/` - Envoy configuration (working)
- `Caddyfile` - Caddy configuration (frozen for gRPC)

---

## Conclusion

**Decision**: Use Envoy for gRPC, Caddy for HTTP/3 + web + REST.

**Rationale**: Proven functionality, clean separation of concerns, industry standard pattern.

**Status**: ✅ Implemented and documented.

---

**Last Updated**: January 5, 2026  
**Author**: Tom
