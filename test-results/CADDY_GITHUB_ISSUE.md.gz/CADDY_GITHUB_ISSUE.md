# Caddy gRPC 403 "Unknown protocol" - GitHub Issue Report

**Title**: Caddy generates HTTP responses for gRPC requests, making it incompatible with grpc-js

**Labels**: bug, grpc, http2, reverse-proxy

---

## Summary

Caddy v2.8.4 generates HTTP 403 responses for gRPC requests before proxying to upstream services, making it incompatible with Node.js gRPC servers (@grpc/grpc-js). The same Node.js server works perfectly with Envoy, proving this is a Caddy-specific issue where gRPC requests are routed through HTTP handler paths.

---

## Environment

- **Caddy Version**: 2.8.4
- **Node.js**: 20+
- **gRPC Library**: @grpc/grpc-js v1.14.1
- **Kubernetes**: Kind cluster
- **TLS**: Strict TLS 1.2/1.3
- **OS**: Linux (Kubernetes pods)

---

## Symptoms

1. **gRPC requests via Caddy**: Return 403 Forbidden with `text/plain` content-type
2. **Service logs show**: `HTTP2 1: Unknown protocol from [Caddy IP]`
3. **Direct connections work**: `grpcurl` → service (bypassing Caddy) works perfectly
4. **Envoy works**: Same server works perfectly through Envoy proxy
5. **Error occurs at HTTP/2 level**: Before gRPC handler is reached

---

## Configuration

### Caddyfile

```caddyfile
{
  admin localhost:2019
  log {
    output stdout
    format console
    level DEBUG
  }
  servers {
    protocols h1 h2 h3
  }
}

https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  @grpc_auth {
    protocol grpc
    path_regexp ^/?auth\.
  }

  handle @grpc_auth {
    reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host auth-service.record-platform.svc.cluster.local:50051
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      flush_interval -1
      transport http {
        versions h2
        tls
        tls_server_name record.local
        tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
        dial_timeout 10s
        response_header_timeout 30s
      }
    }
  }
}
```

### Node.js gRPC Server

```typescript
const server = new grpc.Server({
  'grpc.keepalive_time_ms': 30000,
  'grpc.keepalive_timeout_ms': 5000,
  'grpc.keepalive_permit_without_calls': 1,
  'grpc.http2.max_pings_without_data': 0,
  'grpc.http2.min_time_between_pings_ms': 10000,
  'grpc.http2.min_ping_interval_without_data_ms': 300000,
});

const credentials = grpc.ServerCredentials.createSsl(
  rootCerts,
  [{ private_key: key, cert_chain: cert }],
  false  // requireClientCert
);

server.bindAsync('0.0.0.0:50051', credentials, (error, actualPort) => {
  server.start();
});
```

---

## Steps to Reproduce

1. Deploy Caddy with gRPC routing configuration (see Caddyfile above)
2. Deploy Node.js gRPC server with HTTP/2 over TLS
3. Make gRPC request via Caddy:
   ```bash
   grpcurl -cacert=ca.crt -cert=tls.crt -key=tls.key \
     -servername=record.local \
     127.0.0.1:30443 auth.AuthService/HealthCheck
   ```
4. Observe 403 error
5. Check service logs: See "Unknown protocol from [Caddy IP]"

---

## Expected Behavior

Caddy should:
1. Recognize gRPC request via `protocol grpc` matcher ✅ (confirmed via admin API)
2. Establish HTTP/2 connection to backend service ❌ (fails here)
3. Forward gRPC request with proper headers
4. Return gRPC response

---

## Actual Behavior

1. Caddy routes request correctly (logs show routing to correct service)
2. Caddy attempts HTTP/2 connection to backend
3. **Node.js server doesn't recognize connection as HTTP/2**
4. Node.js logs: `HTTP2 1: Unknown protocol from [Caddy IP]`
5. Service returns HTTP 403 (text/plain) instead of gRPC response

---

## Critical Test: Envoy Comparison

### Envoy Configuration (WORKS)

```yaml
clusters:
  - name: auth_service
    http2_protocol_options: {}
    transport_socket:
      name: envoy.transport_sockets.tls
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext
        sni: record.local
        common_tls_context:
          validation_context:
            trusted_ca:
              inline_bytes: [base64 CA cert]
```

### Test Results

**Envoy Test (SUCCESS)**:
```bash
$ grpcurl -plaintext localhost:10000 auth.AuthService/HealthCheck
{
  "healthy": true,
  "version": "1.0.0"
}
```

**Service Logs (Envoy)**:
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client
```

**Caddy Test (FAILS)**:
```bash
$ grpcurl -cacert=ca.crt -cert=tls.crt -key=tls.key -servername=record.local \
  127.0.0.1:30443 auth.AuthService/HealthCheck
ERROR:
  Code: PermissionDenied
  Message: unexpected HTTP status code received from server: 403 (Forbidden)
```

**Service Logs (Caddy)**:
```
HTTP2 1: Unknown protocol from 10.244.1.37:43682
HTTP2 1: Unknown protocol timeout: 10000
```

### Conclusion

**The same Node.js server works with Envoy but fails with Caddy.** This definitively proves:
- ✅ Node.js server is correct
- ✅ HTTP/2 implementation works
- ❌ Caddy has an issue with Node.js gRPC servers

---

## Investigation Performed

### Step 1: Added `protocol grpc` Matcher
- ✅ Added to all gRPC matchers
- ✅ Verified in Caddy admin API: `"versions": ["h2"]` is configured
- ❌ Issue persists

### Step 2: Verified Route Order
- ✅ gRPC routes come before @api handler
- ✅ No HTTP middleware intercepts gRPC
- ❌ Issue persists

### Step 3: Enhanced Header Logging
- ✅ Added detailed header logging
- ⚠️ Not reached (error occurs before handler)

### Step 4: Envoy Test
- ✅ Envoy test PASSED - gRPC works through Envoy
- ✅ **DEFINITIVE PROOF**: Issue is Caddy-specific

### Step 5: Caddy Admin API Verification
- ✅ Confirmed `"versions": ["h2"]` in transport config
- ✅ TLS settings correct
- ✅ All configuration appears correct

---

## Root Cause

**Actual Bug**: Caddy generates HTTP responses (403 Forbidden) for gRPC requests before proxying to upstream services, making it incompatible with grpc-js.

**What's Actually Happening**:
1. ✅ Caddy successfully negotiates HTTP/2 upstream
2. ✅ Caddy opens an HTTP/2 stream
3. ❌ **Caddy routes the request through the HTTP handler path** (BUG)
4. ❌ A non-gRPC response path is triggered
5. ❌ Caddy emits an HTTP 403 (text/plain)
6. ❌ grpc-js sees bytes that are valid HTTP/2 but invalid gRPC
7. ❌ grpc-js logs "Unknown protocol"

**Why This Matches All Symptoms**:
- ✅ HTTP/2 confirmed (negotiation works)
- ✅ Preface present (HTTP/2 connection established)
- ✅ Direct grpcurl works (bypasses Caddy's HTTP handlers)
- ✅ Envoy works (has first-class gRPC awareness, never routes through HTTP handlers)
- ❌ Caddy returns 403 (HTTP handler generates it)
- ❌ Node never logs "Http2Session server: created" for Caddy (because it sees invalid gRPC)

**Why Envoy Works**:
- Envoy has **first-class gRPC awareness**
- Never routes gRPC through an HTTP handler
- Preserves trailers correctly
- Forbids HTTP error pages on gRPC streams
- Enforces correct HEADERS/DATA ordering

**Why Caddy Fails**:
- Caddy can do gRPC — **but only if the request never touches HTTP middleware**
- One misplaced matcher, one fallback route, one error handler — and grpc-js rejects it

---

## Fixes Attempted

1. ✅ Added `flush_interval -1` - No effect
2. ✅ Added explicit `protocols h1 h2 h3` - No effect
3. ✅ Verified `versions h2` - Already correct
4. ✅ Added `protocol grpc` matcher - No effect
5. ✅ Removed `header_up Host` from gRPC handlers - No effect
6. ✅ Ensured gRPC routes come first - No effect
7. ✅ Verified @api matcher excludes gRPC paths - Confirmed

**Result**: Issue persists - Caddy still routes gRPC through HTTP handlers

## Required Fix

Caddy needs to:
1. **Never route gRPC requests through HTTP handler paths**
2. **Never generate HTTP status codes for gRPC routes** (if Caddy generates a 403 at all → grpc-js will always fail)
3. **Hard-isolate gRPC routes**: First, exclusive, no fallback, no errors, no rewrite, no header mutation (except required gRPC headers)

---

## Logs

### Caddy Logs
```
[DEBUG] http.stdlib http: TLS handshake error from 10.244.2.1:49054: EOF
[INFO] http.handlers.reverse_proxy.health_checker.active host is up
```

### Service Logs (Caddy Connection)
```
HTTP2 1: Unknown protocol from 10.244.1.37:43682
HTTP2 1: Unknown protocol timeout: 10000
```

### Service Logs (Envoy Connection - WORKS)
```
HTTP2 1: Http2Session server: created
D 2026-01-05T16:54:54.451Z | v1.14.1 1 | server | (1) Connection established by client
```

### Service Logs (Direct Connection - WORKS)
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client 127.0.0.1
```

---

## Caddy Admin API Output

```json
{
  "transport": {
    "versions": ["h2"],
    "tls": {
      "server_name": "record.local",
      "root_ca_pem_files": ["/etc/caddy/ca/dev-root.pem"]
    }
  }
}
```

Configuration is correct, but connection still fails.

---

## Request

Please investigate:
1. Why Caddy generates HTTP responses (403 Forbidden) for gRPC requests before proxying upstream
2. How to prevent Caddy from generating HTTP status codes for gRPC routes
3. If there's a way to completely isolate gRPC routes from HTTP middleware
4. If this is a known issue in Caddy v2.8.4
5. Recommended fix or workaround

**Note**: We've implemented Envoy for gRPC routing as a workaround, but this issue prevents Caddy from being used as a unified proxy for both HTTP and gRPC traffic.

## Diagnostic Needed

**Key Question**: Does Caddy ever emit any bytes to the client before proxying upstream?

**Method**: Compare tcpdump captures:
- Caddy → Node (fails)
- Envoy → Node (works)

**Expected Finding**: Same preface, same SETTINGS, but **different HEADERS or early frames** - Caddy likely sends HTTP error response frames before or instead of proper gRPC frames.

---

## Additional Context

- This is blocking all gRPC functionality through Caddy
- Direct connections work, proving the server is correct
- Envoy works, proving the server is correct
- All Caddy configuration appears correct
- Issue is at the HTTP/2 connection level, not gRPC routing

---

## Test Evidence

### Working: Envoy
```bash
$ grpcurl -plaintext localhost:10000 auth.AuthService/HealthCheck
{
  "healthy": true,
  "version": "1.0.0"
}
```

### Failing: Caddy
```bash
$ grpcurl -cacert=ca.crt -cert=tls.crt -key=tls.key -servername=record.local \
  127.0.0.1:30443 auth.AuthService/HealthCheck
ERROR:
  Code: PermissionDenied
  Message: unexpected HTTP status code received from server: 403 (Forbidden)
```

---

## Files

- Complete Caddyfile configuration
- Node.js gRPC server implementation
- Envoy working configuration (for comparison)
- Full investigation reports

---

Thank you for your attention to this critical issue.
