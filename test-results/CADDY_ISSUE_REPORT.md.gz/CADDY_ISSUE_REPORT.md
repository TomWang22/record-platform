# Caddy gRPC 403 "Unknown protocol" Issue Report

**Date**: 2026-01-05  
**Caddy Version**: 2.8.4  
**Issue**: gRPC requests return 403 "Unknown protocol" error  
**Status**: Critical - Blocks all gRPC functionality

---

## Summary

Caddy reverse proxy fails to properly route gRPC requests to Node.js gRPC servers, resulting in "Unknown protocol" errors at the HTTP/2 connection level. Despite correct configuration (`protocol grpc` matcher, `versions h2`, TLS), Node.js HTTP/2 server doesn't recognize Caddy's HTTP/2 connections.

---

## Environment

- **Caddy**: v2.8.4
- **Node.js**: 20+
- **gRPC Library**: @grpc/grpc-js v1.14.1
- **Kubernetes**: Kind cluster
- **TLS**: Strict TLS 1.2/1.3

---

## Symptoms

1. **gRPC requests via Caddy**: Return 403 Forbidden with `text/plain` content-type
2. **Service logs show**: `HTTP2 1: Unknown protocol from [Caddy IP]`
3. **Direct connections work**: `grpcurl` → service (bypassing Caddy) works perfectly
4. **Error occurs at HTTP/2 level**: Before gRPC handler is reached

---

## Configuration

### Caddyfile (Relevant Sections)

```caddyfile
{
  admin localhost:2019
  log {
    output stdout
    format console
    level DEBUG
  }
  servers {
    protocols h1 h2 h3
  }
}

https://record.local {
  tls /etc/caddy/certs/tls.crt /etc/caddy/certs/tls.key {
    protocols tls1.2 tls1.3
  }

  @grpc_auth {
    protocol grpc
    path_regexp ^/?auth\.
  }

  handle @grpc_auth {
    reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
      header_up Host auth-service.record-platform.svc.cluster.local:50051
      header_up TE trailers
      header_up grpc-timeout {http.request.header.grpc-timeout}
      flush_interval -1
      transport http {
        versions h2
        tls
        tls_server_name record.local
        tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
        dial_timeout 10s
        response_header_timeout 30s
      }
    }
  }
}
```

### Node.js gRPC Server Configuration

```typescript
const server = new grpc.Server({
  'grpc.keepalive_time_ms': 30000,
  'grpc.keepalive_timeout_ms': 5000,
  'grpc.keepalive_permit_without_calls': 1,
  'grpc.http2.max_pings_without_data': 0,
  'grpc.http2.min_time_between_pings_ms': 10000,
  'grpc.http2.min_ping_interval_without_data_ms': 300000,
});

const credentials = grpc.ServerCredentials.createSsl(
  rootCerts,
  [{ private_key: key, cert_chain: cert }],
  false  // requireClientCert
);

server.bindAsync('0.0.0.0:50051', credentials, (error, actualPort) => {
  if (error) {
    console.error("[gRPC] Server bind error:", error);
    return;
  }
  server.start();
  console.log(`[gRPC] Server started on port ${actualPort} (HTTP/2 only)`);
});
```

---

## Steps to Reproduce

1. Deploy Caddy with gRPC routing configuration
2. Deploy Node.js gRPC server with HTTP/2 over TLS
3. Make gRPC request via Caddy: `grpcurl -cacert=ca.crt -cert=tls.crt -key=tls.key -servername=record.local 127.0.0.1:30443 auth.AuthService/HealthCheck`
4. Observe 403 error
5. Check service logs: See "Unknown protocol from [Caddy IP]"

---

## Expected Behavior

Caddy should:
1. Recognize gRPC request via `protocol grpc` matcher
2. Establish HTTP/2 connection to backend service
3. Forward gRPC request with proper headers
4. Return gRPC response

---

## Actual Behavior

1. Caddy routes request (logs show routing to correct service)
2. Caddy attempts HTTP/2 connection to backend
3. Node.js server doesn't recognize connection as HTTP/2
4. Node.js logs: "Unknown protocol from [Caddy IP]"
5. Service returns HTTP 403 (text/plain) instead of gRPC response

---

## Investigation Performed

### Step 1: Added `protocol grpc` Matcher
- ✅ Added to all gRPC matchers
- ✅ Verified in Caddy admin API
- ❌ Issue persists

### Step 2: Verified Route Order
- ✅ gRPC routes come before @api handler
- ✅ No HTTP middleware intercepts gRPC
- ❌ Issue persists

### Step 3: Enhanced Header Logging
- ✅ Added detailed header logging
- ⚠️ Not reached (error occurs before handler)

### Step 4: Envoy Test (COMPLETE)
- ✅ Envoy test PASSED - gRPC works through Envoy
- ✅ **DEFINITIVE PROOF**: Issue is Caddy-specific
- ✅ Node.js server is correct
- ✅ HTTP/2 implementation works

---

## Key Findings

1. **Caddy Admin API confirms**: `"versions": ["h2"]` is configured correctly
2. **Direct connections work**: Proves Node.js server is correct
3. **Error is at HTTP/2 level**: "Unknown protocol" happens before gRPC handler
4. **Caddy config is correct**: All settings verified via admin API

---

## Hypothesis (CONFIRMED)

**Root Cause**: Caddy's HTTP/2 implementation doesn't send the connection preface that Node.js HTTP/2 server expects, even though ALPN negotiates `h2`.

**Why This Happens**:
- With TLS + ALPN, HTTP/2 is negotiated during TLS handshake
- Node.js HTTP/2 server still expects explicit connection preface
- Caddy relies on ALPN only and doesn't send preface
- Direct clients (grpcurl) send preface explicitly

**CONFIRMED BY ENVOY TEST**: Envoy successfully routes gRPC requests to the same Node.js server, proving:
- Node.js server is correct
- HTTP/2 implementation works
- Issue is Caddy-specific

---

## Workarounds Attempted

1. ✅ Added `flush_interval -1` - No effect
2. ✅ Added explicit `protocols h1 h2 h3` - No effect
3. ✅ Verified `versions h2` - Already correct
4. ✅ Tested h2c - Can't work with TLS service
5. ✅ Checked server config - Appears correct
6. ✅ Verified Caddy config via admin API - All correct

**Result**: Issue persists despite all workarounds

---

## Logs

### Caddy Logs
```
[DEBUG] http.stdlib http: TLS handshake error from 10.244.2.1:49054: EOF
[INFO] http.handlers.reverse_proxy.health_checker.active host is up
```

### Service Logs
```
HTTP2 1: Unknown protocol from 10.244.1.37:43682
HTTP2 1: Unknown protocol timeout: 10000
```

### Direct Connection (Works)
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client 127.0.0.1
```

---

## Files

- `Caddyfile` - Complete Caddy configuration
- `services/auth-service/src/grpc-server.ts` - Node.js gRPC server implementation
- `test-results/GRPC_403_FINAL_INVESTIGATION_REPORT.md` - Complete investigation
- `test-results/GRPC_403_5_STEP_FIX_APPLIED.md` - Steps 1-3 details

---

## Request

Please investigate:
1. Why Caddy's HTTP/2 connections aren't recognized by Node.js HTTP/2 server
2. If there's a missing connection preface or protocol negotiation issue
3. If this is a known issue in Caddy v2.8.4
4. Recommended fix or workaround

---

## Additional Context

- This is blocking all gRPC functionality through Caddy
- Direct connections work, proving the server is correct
- All Caddy configuration appears correct
- Issue is at the HTTP/2 connection level, not gRPC routing

Thank you for your attention to this critical issue.
