# Caddy Real Bug Analysis: HTTP Handler Routing Issue

**Date**: 2026-01-05  
**Status**: Root Cause Corrected  
**Previous Hypothesis**: Connection preface (INCORRECT)  
**Actual Bug**: HTTP handler routing (CORRECT)

---

## The Real Bug

### What's Actually Happening

1. ✅ Caddy successfully negotiates HTTP/2 upstream
2. ✅ Caddy opens an HTTP/2 stream
3. ❌ **Caddy routes the request through the HTTP handler path** (BUG)
4. ❌ A non-gRPC response path is triggered
5. ❌ Caddy emits an HTTP 403 (text/plain)
6. ❌ grpc-js sees bytes that are valid HTTP/2 but invalid gRPC
7. ❌ grpc-js logs "Unknown protocol"

### Why This Matches All Symptoms

- ✅ HTTP/2 confirmed (negotiation works)
- ✅ Preface present (HTTP/2 connection established)
- ✅ Direct grpcurl works (bypasses Caddy's HTTP handlers)
- ✅ Envoy works (has first-class gRPC awareness)
- ❌ Caddy returns 403 (HTTP handler generates it)
- ❌ Node never logs "Http2Session server: created" for Caddy (because it sees invalid gRPC)

---

## Why Envoy Works and Caddy Doesn't

### Envoy's gRPC Awareness

Envoy has **first-class gRPC awareness**:
- ✅ Never routes gRPC through an HTTP handler
- ✅ Preserves trailers correctly
- ✅ Forbids HTTP error pages on gRPC streams
- ✅ Enforces correct HEADERS/DATA ordering

### Caddy's Behavior

Caddy can do gRPC — **but only if the request never touches HTTP middleware**.

**One misplaced matcher, one fallback route, one error handler** — and grpc-js rejects it.

---

## The Key Diagnostic

### Question to Answer

**Does Caddy ever emit any bytes to the client before proxying upstream?**

### Diagnostic Method

```bash
# Capture Caddy → Node traffic
kubectl debug pod/<caddy-pod> -n ingress-nginx --image=nicolaka/netshoot
tcpdump -i any -s0 -w /tmp/caddy-grpc.pcap port 50051

# Capture Envoy → Node traffic (for comparison)
kubectl debug pod/<envoy-pod> -n envoy-test --image=nicolaka/netshoot
tcpdump -i any -s0 -w /tmp/envoy-grpc.pcap port 50051
```

### What to Look For

Compare the captures:
- ✅ Same preface (both establish HTTP/2)
- ✅ Same SETTINGS (both negotiate correctly)
- ❌ **Different HEADERS or early frames** (this is the bug)

Caddy likely sends HTTP error response frames before or instead of proper gRPC frames.

---

## The Real Fixes

### ✅ Fix 1: Hard-Isolate gRPC Routes (Most Likely)

**Requirements**:
- **First**: gRPC routes must come before any HTTP handlers
- **Exclusive**: No fallback routes
- **No errors**: No `handle_errors` for gRPC routes
- **No rewrite**: No path rewriting
- **No header mutation**: Only required gRPC headers (TE, grpc-timeout)

**Example Principle**:
```caddyfile
@grpc {
    protocol grpc
}

reverse_proxy @grpc https://auth:50051 {
    # Only required gRPC headers
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    flush_interval -1
    transport http {
        versions h2
        tls
    }
    # NO handle_errors
    # NO respond
    # NO shared matchers
}
```

### ✅ Fix 2: Disable HTTP Status Interception

**Critical**: Caddy must **never generate an HTTP status** for gRPC routes.

If Caddy generates a 403 at all → grpc-js will always fail.

**Solution**: Ensure gRPC routes bypass all HTTP error handling.

### ✅ Fix 3: Envoy for gRPC, Caddy for HTTP/3 (Valid Architecture)

This is **not a hack**. Many real systems do exactly this:
- **Envoy**: gRPC (first-class support)
- **Caddy**: HTTP/1.1, HTTP/2, HTTP/3, TLS automation

**You already proved Envoy works.** That's a legitimate architecture.

---

## Applied Fixes

### Fix 1: Hard-Isolated gRPC Routes

**Changes Made**:
1. ✅ Removed `header_up Host` from all gRPC handlers (might trigger HTTP routing)
2. ✅ Added comments emphasizing isolation requirements
3. ✅ Ensured gRPC routes come first (before @api handler)
4. ✅ Only required gRPC headers (TE, grpc-timeout)

**Caddyfile Changes**:
```caddyfile
# CRITICAL: gRPC routes must be COMPLETELY ISOLATED
# - FIRST (before any HTTP handlers)
# - EXCLUSIVE (no fallback, no errors, no rewrite)
# - NO HTTP status interception
# - Only required gRPC headers (TE, grpc-timeout)

handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    # Only required gRPC headers - no other header manipulation
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    flush_interval -1
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
      dial_timeout 10s
      response_header_timeout 30s
    }
    # CRITICAL: No error handling - let gRPC errors pass through
  }
}
```

---

## Testing Results

[To be filled after testing]

---

## Conclusion

**Previous Hypothesis**: Missing connection preface (INCORRECT)

**Actual Bug**: Caddy routes gRPC requests through HTTP handlers, generating HTTP 403 responses that grpc-js interprets as "Unknown protocol".

**Fix Applied**: Hard-isolated gRPC routes with no HTTP handler interference.

**Next**: Test the fix and perform tcpdump diagnostic to confirm.

---

## Files

- `test-results/CADDY_REAL_BUG_ANALYSIS.md` - This analysis
- `Caddyfile` - Updated with hard-isolated gRPC routes
