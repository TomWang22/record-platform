# Caddy Root Cause Analysis: Why It Fails vs Envoy Works

**Date**: 2026-01-05  
**Status**: Root Cause Identified

---

## The Problem

Caddy fails to establish HTTP/2 connections that Node.js gRPC servers recognize, while Envoy succeeds with the same server.

---

## Root Cause: Missing Connection Preface

### Node.js HTTP/2 Server Behavior

Node.js HTTP/2 server (via @grpc/grpc-js) expects:
1. **ALPN negotiation** during TLS handshake (selects `h2`)
2. **Connection preface** (`PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`) within 10 seconds

**Even with ALPN**, Node.js still expects the explicit connection preface.

### Caddy's Behavior

1. ✅ ALPN negotiates `h2` during TLS handshake
2. ❌ **Does NOT send connection preface**
3. ❌ Node.js doesn't recognize connection as HTTP/2
4. ❌ Times out after 10 seconds: "Unknown protocol"

### Envoy's Behavior (Works)

1. ✅ ALPN negotiates `h2` during TLS handshake
2. ✅ **Sends connection preface** (or handles ALPN properly)
3. ✅ Node.js recognizes connection as HTTP/2
4. ✅ gRPC requests succeed

### Direct Connection Behavior (Works)

1. ✅ ALPN negotiates `h2` during TLS handshake
2. ✅ **grpcurl sends connection preface explicitly**
3. ✅ Node.js recognizes connection as HTTP/2
4. ✅ gRPC requests succeed

---

## Technical Details

### HTTP/2 Connection Establishment

According to RFC 7540:
- For TLS connections, ALPN negotiates the protocol
- **But the connection preface is still required** for HTTP/2
- The preface identifies the connection as HTTP/2

### Node.js Implementation

Node.js `http2` module:
- Accepts ALPN-negotiated connections
- **Still expects connection preface** to confirm HTTP/2
- Timeout: 10 seconds to receive preface
- If not received: "Unknown protocol" error

### Why This Matters

- **ALPN alone is not sufficient** for Node.js HTTP/2 server
- **Connection preface is required** even with ALPN
- Caddy doesn't send it
- Envoy does send it (or handles it correctly)

---

## Evidence

### Service Logs Comparison

**Caddy Connection (FAILS)**:
```
HTTP2 1: Unknown protocol from 10.244.1.37:43682
HTTP2 1: Unknown protocol timeout: 10000
```

**Envoy Connection (WORKS)**:
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client
```

**Direct Connection (WORKS)**:
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client 127.0.0.1
```

### Test Results

| Proxy | Result | Service Logs |
|-------|--------|--------------|
| Caddy | ❌ 403 Forbidden | Unknown protocol |
| Envoy | ✅ Success | Http2Session created |
| Direct | ✅ Success | Http2Session created |

---

## Why Envoy Works

Envoy's HTTP/2 implementation:
1. Properly sends connection preface after ALPN negotiation
2. Or handles ALPN-negotiated connections correctly
3. Node.js recognizes the connection
4. gRPC requests succeed

---

## Why Caddy Fails

Caddy's HTTP/2 implementation:
1. Relies on ALPN only
2. Doesn't send connection preface
3. Node.js doesn't recognize connection
4. Times out: "Unknown protocol"

---

## Solution

Caddy needs to:
1. Send connection preface after ALPN negotiation
2. Or handle ALPN-negotiated connections in a way Node.js recognizes
3. Match the behavior of Envoy and direct clients

---

## Conclusion

**Root Cause**: Caddy doesn't send the HTTP/2 connection preface that Node.js expects, even though ALPN negotiates `h2` correctly.

**Proof**: Envoy works with the same server, proving the issue is Caddy-specific.

**Fix Required**: Caddy needs to send connection preface or handle ALPN-negotiated HTTP/2 connections correctly for Node.js compatibility.

---

## Files

- `test-results/CADDY_ROOT_CAUSE_ANALYSIS.md` - This analysis
- `test-results/CADDY_GITHUB_ISSUE.md` - GitHub issue report
- `test-results/GRPC_403_FINAL_RESOLUTION.md` - Final resolution summary
