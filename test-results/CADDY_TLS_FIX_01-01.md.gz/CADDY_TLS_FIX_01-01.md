# Caddy gRPC TLS Fix (January 1, 2025)

## Summary

Fixed Caddy gRPC routing to use TLS (h2) instead of cleartext (h2c), eliminating the protocol mismatch that caused routing failures.

## Problem

**Root Cause**: Caddyfile used `versions h2c` (HTTP/2 cleartext) but services use `grpc.ServerCredentials.createSsl()` (TLS).

**Impact**:
- Caddy tried: `h2c (cleartext) -> service:50051`
- Services expected: `TLS (HTTPS/2) -> service:50051`
- Result: Connection failures, routing errors

## Solution

**Changed all gRPC routing blocks from h2c to h2 + tls**:

### Before:
```caddyfile
transport http {
  versions h2c  # HTTP/2 cleartext - NOT TLS!
}
```

### After:
```caddyfile
transport http {
  versions h2  # HTTP/2 with TLS (not h2c)
  tls
}
```

## Changes Made

1. **@grpc_health block**: Changed from `h2c` to `h2 + tls`
2. **All individual service blocks** (8 services):
   - auth-service
   - records-service
   - social-service
   - listings-service
   - analytics-service
   - shopping-service
   - auction-monitor
   - python-ai-service
3. **Fixed service ports in @grpc_health**:
   - social-service: 50051 → 50056
   - listings-service: 50051 → 50057
   - analytics-service: 50051 → 50054

## Files Modified

- `Caddyfile`: All gRPC routing blocks updated
- `Runbook.md`: Issue #16 updated with fix status

## Deployment

1. Updated Caddy ConfigMap:
   ```bash
   kubectl -n ingress-nginx create configmap caddy-h3 \
     --from-file=Caddyfile=Caddyfile --dry-run=client -o yaml | kubectl apply -f -
   ```

2. Restarted Caddy pods:
   ```bash
   kubectl -n ingress-nginx rollout restart deployment/caddy-h3
   ```

3. Verified pods ready:
   ```bash
   kubectl -n ingress-nginx wait --for=condition=ready pod -l app=caddy-h3 --timeout=120s
   ```

## Expected Results

✅ **gRPC routing via NodePort should now work with TLS**
- No more protocol mismatch
- Caddy TLS matches service TLS configuration
- Fallback logic still available but should not be needed

## Testing

To verify the fix works:
```bash
# Test gRPC via NodePort with strict TLS
grpcurl \
  -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  -H "Host: record.local" \
  -H "Content-Type: application/grpc" \
  -H "TE: trailers" \
  -import-path proto \
  -proto proto/records.proto \
  "127.0.0.1:30443" \
  "/records.RecordsService/HealthCheck"
```

## Notes

- Port 5000 block still uses h2c (for backward compatibility, but not recommended)
- All production gRPC routing (port 443) now uses TLS
- Fallback logic in `grpc_test` function still works but should not be needed

---

**Date**: January 1, 2025  
**Author**: Tom

