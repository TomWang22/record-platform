# Docker VM Corruption Recovery Plan

## Current Situation

- **Docker VM Status**: Corrupted (EXT4 filesystem errors, journal aborted)
- **Docker API**: Returning 500 errors (cannot access containers/volumes)
- **Disk Space**: 93% full (400GB/460GB used)
- **Docker VM Size**: 140GB
- **Postgres Volumes**: 8 named volumes inside corrupted VM (inaccessible)

## Postgres Volumes at Risk

The following Postgres volumes are stored in the corrupted VM:
1. `pgdata` - Main records database (port 5433)
2. `pgdata-social` - Social service database (port 5434)
3. `pgdata-listings` - Listings service database (port 5435)
4. `pgdata-shopping` - Shopping service database (port 5436)
5. `pgdata-auth` - Auth service database (port 5437)
6. `pgdata-auction-monitor` - Auction monitor database (port 5438)
7. `pgdata-analytics` - Analytics service database (port 5439)
8. `pgdata-python-ai` - Python AI service database (port 5440)

## Recovery Options

### Option 1: Attempt Volume Recovery (Advanced, Low Success Rate)

**Pros**: Might recover some data
**Cons**: 
- Requires mounting corrupted VM disk image
- Complex and time-consuming
- Success rate is low with filesystem corruption
- Requires Linux tools or VM mounting

**Steps**:
1. Stop Docker completely
2. Mount the VM disk image (`~/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw`)
3. Run `fsck` on the mounted filesystem
4. Attempt to extract volume data from `/var/lib/docker/volumes/`
5. Restore to new Docker instance

**Note**: This is complex and may not work if corruption is severe.

### Option 2: Reset Docker VM (Recommended)

**Pros**: 
- Fast and reliable
- Will fix Docker corruption
- Allows you to continue working immediately

**Cons**:
- **Will lose all Postgres data** (unless you have backups)
- Need to recreate containers
- Need to re-seed databases

**Steps**:
1. Quit Docker completely
2. Remove corrupted VM (forces recreation)
3. Restart Docker Desktop
4. Recreate Postgres containers (they'll be empty)
5. Re-seed databases from migrations/schemas

## Recommended Action: Reset Docker VM

Since:
- Docker API is completely non-functional (500 errors)
- VM filesystem is corrupted
- Disk was 100% full (likely cause of corruption)
- Volume data is inaccessible through normal means

**The safest path is to reset Docker and accept data loss**, then:
1. Ensure you have database migration scripts (Prisma schemas)
2. Re-run migrations to recreate schema structure
3. Re-seed any test/development data
4. Set up regular backups going forward

## Prevention for Future

1. **Monitor disk space** - Keep at least 20% free
2. **Set up regular Postgres backups** - Use `postgres-backup` service in docker-compose
3. **Consider moving Postgres to external volume** - Use Docker named volumes with external drivers
4. **Enable Docker disk space limits** - Configure Docker Desktop resource limits

## Next Steps

1. Run the reset script (see `scripts/reset-docker-vm.sh`)
2. Verify Docker starts successfully
3. Start Postgres containers: `docker-compose up -d postgres postgres-auth postgres-social postgres-listings postgres-shopping postgres-auction-monitor postgres-analytics postgres-python-ai`
4. Run database migrations for each service
5. Re-seed test data if needed

