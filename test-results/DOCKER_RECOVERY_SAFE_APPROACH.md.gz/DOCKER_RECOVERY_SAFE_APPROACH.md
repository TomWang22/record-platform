# Docker VM Recovery - Safe Approach

## Current Status

✅ **Docker.raw EXISTS** - 140GB at:
   `~/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw`

⚠️ **Disk Space**: 35GB free (not enough to backup 140GB Docker.raw on same drive)

## Recovery Strategy (Ordered by Safety)

### Step 1: Attempt Docker Repair (Safest - No Data Loss Risk)

**Goal**: Try to get Docker to boot the existing VM

**Actions**:
1. Quit Docker Desktop completely
2. Restart macOS (clears any locks/handles)
3. Increase Docker disk size (if it's at limit)
4. Try starting Docker Desktop again

**Why this might work**:
- Sometimes corruption is just metadata inconsistency
- Restart can clear file locks
- Disk space increase can resolve filesystem errors

### Step 2: Extract Volumes from Docker.raw (If Step 1 Fails)

**Goal**: Mount Docker.raw and extract Postgres data directories

**Method**: Use `hdiutil` or `qemu-img` to mount the disk image

**Steps**:
1. Convert Docker.raw to a mountable format (if needed)
2. Mount the filesystem
3. Navigate to `/var/lib/docker/volumes/`
4. Copy Postgres data directories out
5. Restore to new Docker instance

**Tools needed**:
- `hdiutil` (macOS built-in)
- Or `qemu-img` + `qemu-nbd` (if available)
- Or Docker's own tools

### Step 3: Clean Reset (Last Resort)

**Only if**:
- Steps 1 & 2 fail
- Data extraction impossible
- Need to continue working immediately

## Immediate Actions (Do Now)

### Option A: Backup to External Drive (If Available)

```bash
# If you have external drive mounted
EXTERNAL_DRIVE="/Volumes/YourDrive"
if [[ -d "$EXTERNAL_DRIVE" ]]; then
  echo "Backing up Docker.raw to external drive..."
  cp ~/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw \
     "$EXTERNAL_DRIVE/docker-raw-backup-$(date +%Y%m%d-%H%M%S).raw"
  echo "✅ Backup complete"
fi
```

### Option B: Try Recovery Without Full Backup

Since we don't have space for full backup, we can:
1. Try repair first (no risk)
2. If repair fails, attempt extraction (data still in Docker.raw)
3. Only reset if extraction fails

## Next Steps

1. **Try Docker repair** (restart macOS, increase disk size, restart Docker)
2. **If repair works**: Immediately dump Postgres data
3. **If repair fails**: Attempt volume extraction from Docker.raw
4. **If extraction fails**: Then consider reset

## Postgres Volume Locations in Docker.raw

If we can mount Docker.raw, Postgres data should be at:
- `/var/lib/docker/volumes/pgdata/_data/`
- `/var/lib/docker/volumes/pgdata-auth/_data/`
- `/var/lib/docker/volumes/pgdata-social/_data/`
- `/var/lib/docker/volumes/pgdata-listings/_data/`
- `/var/lib/docker/volumes/pgdata-shopping/_data/`
- `/var/lib/docker/volumes/pgdata-auction-monitor/_data/`
- `/var/lib/docker/volumes/pgdata-analytics/_data/`
- `/var/lib/docker/volumes/pgdata-python-ai/_data/`

Each contains the full Postgres data directory with:
- `PG_VERSION`
- `base/` (database files)
- `pg_wal/` (write-ahead log)
- `global/` (cluster-wide data)

## Recovery Scripts

See:
- `scripts/attempt-docker-repair.sh` - Try to repair Docker VM
- `scripts/extract-docker-volumes.sh` - Extract volumes from Docker.raw (if repair fails)

