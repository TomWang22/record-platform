# Docker VM Reset - Summary & Recovery Steps

## Current Situation

✅ **Docker VM is corrupted** - Cannot access containers/volumes (500 errors)
✅ **Recovery script created** - `scripts/reset-docker-vm.sh`
✅ **Database schemas are safe** - Prisma schemas and SQL migrations are in Git

## What Will Be Lost

⚠️ **All Postgres data in Docker volumes**:
- `pgdata` (main records)
- `pgdata-auth` (auth service)
- `pgdata-social` (social service)
- `pgdata-listings` (listings service)
- `pgdata-shopping` (shopping service)
- `pgdata-auction-monitor` (auction monitor)
- `pgdata-analytics` (analytics service)
- `pgdata-python-ai` (python AI service)

## What Is Safe (In Git)

✅ **Database schemas**:
- Prisma schemas: `services/*/prisma/schema.prisma`
- SQL migrations: `infra/db/*.sql`
- Docker Compose config: `docker-compose.yml`

## Recovery Steps After Docker Reset

### 1. Reset Docker VM

```bash
./scripts/reset-docker-vm.sh
```

This will:
- Quit Docker Desktop
- Remove corrupted VM
- Restart Docker Desktop
- Wait for Docker to be ready

### 2. Start Postgres Containers

```bash
docker-compose up -d postgres postgres-auth postgres-social postgres-listings postgres-shopping postgres-auction-monitor postgres-analytics postgres-python-ai
```

### 3. Run Database Migrations

Each service has Prisma migrations. Run them:

```bash
# Auth service
cd services/auth-service
pnpm prisma migrate deploy

# Social service
cd services/social-service
pnpm prisma migrate deploy

# Listings service
cd services/listings-service
pnpm prisma migrate deploy

# Shopping service
cd services/shopping-service
pnpm prisma migrate deploy

# Auction Monitor service
cd services/auction-monitor
pnpm prisma migrate deploy

# Analytics service
cd services/analytics-service
pnpm prisma migrate deploy

# Python AI service
cd services/python-ai-service
# Check if it uses Prisma or raw SQL
```

### 4. Verify Databases

```bash
# Check all Postgres containers are running
docker ps | grep postgres

# Test connections
psql -h localhost -p 5433 -U postgres -d postgres -c "\dt"
psql -h localhost -p 5437 -U postgres -d postgres -c "\dn"  # Check auth schema
```

### 5. Re-seed Test Data (If Needed)

If you had test data, you'll need to:
- Re-run any seed scripts
- Re-create test users
- Re-populate test records

## Prevention Going Forward

1. **Monitor disk space** - Keep >20% free
2. **Set up regular backups** - Use the `postgres-backup` service in docker-compose
3. **Consider external volumes** - Move Postgres data to external Docker volumes
4. **Docker resource limits** - Configure Docker Desktop to limit disk usage

## Quick Reference: Postgres Ports

| Service | Port | Volume | Schema |
|---------|------|--------|--------|
| Main | 5433 | pgdata | records |
| Auth | 5437 | pgdata-auth | auth |
| Social | 5434 | pgdata-social | social |
| Listings | 5435 | pgdata-listings | listings |
| Shopping | 5436 | pgdata-shopping | shopping |
| Auction Monitor | 5438 | pgdata-auction-monitor | auction_monitor |
| Analytics | 5439 | pgdata-analytics | analytics |
| Python AI | 5440 | pgdata-python-ai | python_ai |

