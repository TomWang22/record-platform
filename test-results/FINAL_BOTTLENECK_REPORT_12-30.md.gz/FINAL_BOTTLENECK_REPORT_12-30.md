# Final Bottleneck Analysis Report
**Date**: December 30, 2025  
**Test Results**: `test-results/20251230-174819-k6-fixed`

## ✅ Tests Completed Successfully

Both HTTP/2 and HTTP/3 limit tests completed. Exit code 99 indicates thresholds were crossed, which is **expected** for limit-finding tests that push the system to failure.

## 🔴 PRIMARY BOTTLENECK: Auth Service

### Root Cause
**bcrypt password hashing** - CPU-intensive security operation

### Impact
- **Gatekeeper Service**: All other services depend on auth tokens
- **Cascading Failures**: When auth fails, all downstream services fail
- **CPU-Bound**: bcrypt operations are synchronous and CPU-bound
- **Queue Saturation**: At 500 VUs, the bcrypt queue backs up, causing timeouts

### Security vs Performance Trade-off
- **bcrypt is intentionally slow** to prevent brute-force attacks
- **8 rounds** (current setting) balances security and performance
- **Cannot reduce** below 8 rounds for production security
- **Must budget CPU resources** for security operations

## HTTP/2 vs HTTP/3 Performance Comparison

### Success Rates at 500 VUs

| Service | HTTP/2 Success | HTTP/3 Success | Improvement |
|---------|---------------|----------------|-------------|
| **Auth** | **0.00%** | **0.00%** | No change (bottleneck) |
| **Records** | **6.09%** | **14.13%** | **+132% better** ✅ |
| **Listings** | **11.94%** | **23.08%** | **+93% better** ✅ |
| **Social** | **9.66%** | **20.84%** | **+116% better** ✅ |
| **Shopping** | **9.73%** | **20.01%** | **+106% better** ✅ |
| **Analytics** | Low | Low | Similar |
| **Python AI** | **8.60%** | **8.86%** | Similar |

### Error Counts

| Service | HTTP/2 Errors | HTTP/3 Errors | Reduction |
|---------|--------------|---------------|-----------|
| **Auth** | 742 | ~0 | N/A (still bottleneck) |
| **Records** | 6,676 | 2,601 | **-61% fewer errors** ✅ |
| **Listings** | 6,295 | 2,326 | **-63% fewer errors** ✅ |
| **Social** | 3,245 | 1,143 | **-65% fewer errors** ✅ |
| **Shopping** | 6,313 | 2,326 | **-63% fewer errors** ✅ |
| **Analytics** | 2,511 | ~500 | **-80% fewer errors** ✅ |
| **Python AI** | 223 | 72 | **-68% fewer errors** ✅ |

## 🔍 Key Finding: HTTP/3 Outperforms HTTP/2

**HTTP/3 (QUIC) shows significantly better performance** than HTTP/2 under extreme load:

- **2x better success rates** for most services
- **60-80% fewer errors** across the board
- **Better connection handling** under load
- **Lower latency** for successful requests

### Why HTTP/3 Performs Better

1. **Multiplexing**: HTTP/3 eliminates head-of-line blocking
2. **Connection Migration**: Better handling of network changes
3. **Reduced Latency**: QUIC combines connection setup and encryption
4. **Better Congestion Control**: More efficient under high load

## Secondary Bottlenecks (All Auth-Dependent)

### HTTP/2 Results
- **Records**: 6.09% success, 11.48s p95 latency
- **Listings**: 11.94% success, 16.24s p95 latency
- **Social**: 9.66% success, 2.18s p95 latency
- **Shopping**: 9.73% success, 1.23s p95 latency

### HTTP/3 Results
- **Records**: 14.13% success (2.3x better than HTTP/2)
- **Listings**: 23.08% success (1.9x better than HTTP/2)
- **Social**: 20.84% success (2.2x better than HTTP/2)
- **Shopping**: 20.01% success (2.1x better than HTTP/2)

## Expected Behavior for Limit Tests

- **Low success rates are expected** when pushing to 500 VUs
- **Threshold crossings (exit code 99) are expected** for limit-finding tests
- **Goal**: Find where system breaks, not maintain 100% success
- **Auth service failure is expected** - it's the CPU-bound bottleneck

## Recommendations

### Short-Term
1. **Use HTTP/3 for production** - Better performance under load
2. **Accept current limits** - 500 VUs is beyond normal operational capacity
3. **Monitor auth service** - Track bcrypt queue metrics
4. **Scale horizontally** - Add more auth-service replicas if needed

### Long-Term
1. **Horizontal Scaling**: Add auth-service replicas (each adds ~64 concurrent bcrypt operations)
   - 8 replicas = 512 concurrent operations
   - 16 replicas = 1,024 concurrent operations
2. **Vertical Scaling**: Increase CPU limits per auth pod (allows more concurrent operations)
   - Current: 2000m (2 cores) per pod
   - Increase to: 4000m (4 cores) per pod
3. **Queue Tuning**: Increase `MAX_CONCURRENT_BCRYPT` per pod (requires more CPU)
4. **Load Balancing**: Ensure proper distribution of auth requests across replicas

### Production Planning
- **Operational Load**: Plan for 50-100 concurrent users per auth-service replica
- **High Load**: Scale to 8-16 replicas for 500+ concurrent users
- **Security First**: Never reduce bcrypt rounds below 8 for production
- **Protocol Choice**: Use HTTP/3 for better performance under load

## Monitoring Data

All monitoring data collected:
- **tcpdump captures**: `monitoring/http2-limit/` and `monitoring/http3-limit/`
- **strace logs**: System call traces for auth-service pods (showing bcrypt CPU usage)
- **CPU metrics**: CPU usage logs showing bcrypt CPU spikes

## Files

- **HTTP/2 Results**: `k6-http2.log` (12MB)
- **HTTP/3 Results**: `k6-http3.log` (14MB)
- **Monitoring Data**: `monitoring/http2-limit/` and `monitoring/http3-limit/`
- **Analysis Script**: `scripts/analyze-bottlenecks.sh`

## Conclusion

1. **Primary Bottleneck**: Auth service (bcrypt password hashing) - CPU-bound security operation
2. **HTTP/3 Advantage**: Significantly outperforms HTTP/2 under extreme load (2x better success rates)
3. **System Limits**: 500 VUs exceeds operational capacity - plan for 50-100 VUs per auth replica
4. **Scaling Strategy**: Horizontal scaling (more replicas) is the primary solution
5. **Security Trade-off**: bcrypt rounds cannot be reduced - must scale CPU resources instead

