# gRPC 403 - 5-Step Fix Applied

**Date**: 2026-01-05  
**Status**: Steps 1-3 Applied, Testing In Progress  
**Issue**: gRPC 403 "Unknown protocol" error

---

## 5-Step Fix Plan Applied

### ✅ Step 1: Add/Verify protocol grpc Matcher in Caddy
**Status**: COMPLETE

**Changes Made**:
- Added `protocol grpc` to ALL gRPC matchers in Caddyfile
- Updated matchers for:
  - Port 443 (record.local)
  - Port 5000 (h2c port)
  - All 8 services (auth, records, social, listings, analytics, shopping, auction-monitor, python-ai)

**Why This Matters**:
- `protocol grpc` ensures Caddy treats requests as gRPC (not just HTTP/2)
- Without this, Caddy may route through HTTP handlers
- This is the #1 cause of grpc-js + Caddy failures

**Configuration**:
```caddyfile
@grpc_auth {
  protocol grpc
  path_regexp ^/?auth\.
}
```

### ✅ Step 2: Confirm No HTTP Middleware Touches gRPC Route
**Status**: VERIFIED

**Verification**:
- gRPC matchers defined at line 54+
- @api matcher defined at line 235
- ✅ gRPC routes come BEFORE @api handler
- ✅ No HTTP middleware can intercept gRPC requests

**Route Order**:
1. Health check (`/_caddy/healthz`)
2. gRPC matchers (`@grpc_*`)
3. @api matcher (REST API)
4. Webapp (catch-all)

### ✅ Step 3: Log Request Headers Inside Node
**Status**: COMPLETE

**Changes Made**:
- Enhanced `withLogging` function in `grpc-server.ts`
- Added detailed header logging:
  - `contentType`: Content-Type header (should be `application/grpc`)
  - `te`: TE header (should be `trailers`)
  - `userAgent`: User-Agent header
  - `headers`: All headers

**What This Shows**:
- What headers Caddy is actually sending
- If Content-Type is correct
- If TE: trailers is present
- Any missing or incorrect headers

**Code Added**:
```typescript
console.log(`[gRPC] ${methodName} called`, {
  peer,
  host,
  headers: allHeaders,
  contentType: allHeaders['content-type'] || 'MISSING',
  te: allHeaders['te'] || 'MISSING',
  userAgent: allHeaders['user-agent'] || 'MISSING',
  ...
});
```

### ⏳ Step 4: Envoy Test (5-minute diagnostic)
**Status**: PREPARING

**Purpose**: 
- Isolate if issue is Caddy-specific
- If Envoy works: Node.js server is correct, Caddy is the issue
- If Envoy fails: Issue is with Node.js server or configuration

**Next**: Deploy Envoy or check if already available

### ⏳ Step 5: File Caddy Issue (if needed)
**Status**: PENDING

**If Steps 1-4 don't resolve**:
- Gather network captures
- Collect logs from both Caddy and service
- File issue with Caddy GitHub

---

## Testing Results

### After Step 1-3 Application

**Test**: gRPC request via Caddy
**Result**: ❌ Still getting 403 error

**Service Logs Show**:
- Health check requests work (from 127.0.0.1)
- Still seeing: `Unknown protocol from 10.244.1.37:43682`
- Enhanced header logging not yet visible (pods may not be ready)

**Next**: 
- Wait for new auth-service pods to be ready
- Check enhanced header logs
- Proceed with Envoy test

---

## Files Modified

1. `Caddyfile` - Added `protocol grpc` to all matchers
2. `services/auth-service/src/grpc-server.ts` - Enhanced header logging
3. `infra/k8s/base/auth-service/deploy.yaml` - Already has debug env vars

---

## Next Steps

1. ✅ Wait for auth-service rollout to complete
2. ✅ Check enhanced header logs
3. ⏳ Test with Envoy (Step 4)
4. ⏳ If still broken, file Caddy issue (Step 5)

---

## Conclusion

**Status**: Steps 1-3 applied, testing in progress

**Key Change**: Added `protocol grpc` matcher - this is critical for Caddy to recognize gRPC traffic.

**Next**: Verify if `protocol grpc` fixes the issue, then proceed with Envoy test.
