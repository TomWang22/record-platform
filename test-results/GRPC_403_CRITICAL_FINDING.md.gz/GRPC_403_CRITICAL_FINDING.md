# gRPC 403 - Critical Finding from Caddy Logs

**Date**: January 4, 2025  
**Status**: 🔍 **ANALYZING** - Found key discrepancy in Caddy logs  
**Priority**: Critical - Identified potential root cause

---

## 🎯 Critical Observation from Caddy Logs

### Request Details from Caddy

From Caddy logs (upstream roundtrip):
```json
{
  "upstream": "auth-service.record-platform.svc.cluster.local:50051",
  "request": {
    "host": "auth-service.record-platform.svc.cluster.local:50051",
    "uri": "/auth.AuthService/HealthCheck",
    "headers": {
      "Host": ["record.local"],
      "Content-Type": ["application/grpc"],
      "Te": ["trailers"],
      ...
    }
  },
  "headers": {"Content-Type": ["text/plain"]},
  "status": 403
}
```

### Key Finding

**Discrepancy**: Caddyfile specifies:
```caddyfile
header_up Host auth-service.record-platform.svc.cluster.local:50051
```

But Caddy logs show the Host header is still `"Host": ["record.local"]`!

**However**: Response is HTTP 403 with `text/plain`, which is NOT a gRPC response format.

---

## Analysis

### What This Means

1. **Request Format**: The request looks correct for gRPC:
   - Path: `/auth.AuthService/HealthCheck` ✅
   - Content-Type: `application/grpc` ✅
   - TE: `trailers` ✅
   - Method: POST ✅
   - HTTP/2: ✅

2. **Response Format**: The response is HTTP, not gRPC:
   - Status: 403 (HTTP status code)
   - Content-Type: `text/plain` (HTTP, not gRPC)
   - NOT a gRPC status code (which would be in gRPC format)

3. **Host Header**: 
   - Caddyfile sets: `header_up Host auth-service.record-platform.svc.cluster.local:50051`
   - Log shows: `Host: record.local`
   - Either Caddy isn't applying `header_up Host`, or the log shows the original header

### Hypothesis

**Theory**: Auth-service is NOT recognizing the request as gRPC, so it's returning an HTTP 403 response instead of processing it as a gRPC request.

**Why would this happen?**
- The request reaches auth-service (Caddy connects successfully)
- But auth-service doesn't recognize it as gRPC
- So it returns HTTP 403 (text/plain)

**Possible causes**:
1. Host header mismatch causes auth-service to reject request
2. Request format is slightly different from what auth-service expects
3. HTTP/2 negotiation issue
4. Something else in the request format that auth-service doesn't like

---

## Next Steps

1. **Verify Host Header**: Check if `header_up Host` is actually being applied
2. **Compare Headers**: Compare exact headers between direct (works) and via Caddy (403)
3. **Test Host Header**: Try different Host header values to see if that's the issue
4. **Check Auth-Service Code**: Look for any Host header validation in auth-service

---

## Related Files

- `Caddyfile` - Caddy configuration (line 78: `header_up Host`)
- `test-results/GRPC_403_ROOT_CAUSE_FOUND.md` - Root cause identification
- `services/auth-service/src/grpc-server.ts` - Auth-service gRPC server
