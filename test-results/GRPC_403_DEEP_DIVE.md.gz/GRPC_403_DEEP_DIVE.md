# gRPC 403 - Deep Dive Analysis

**Date**: January 4, 2025  
**Status**: 🔬 **DEEP INVESTIGATION** - Analyzing request format differences  
**Priority**: Critical - Identify exact cause of 403

---

## Current Status

### What Works ✅
- Direct connection (bypass Caddy): Works
- Direct TLS (same settings as Caddy): Works
- gRPC handler code: Works
- TLS configuration: Works

### What Fails ❌
- Via Caddy: HTTP 403 (text/plain), not gRPC response

---

## Key Observation

**Response Format**: HTTP 403 with `text/plain`, NOT a gRPC response.

This means auth-service's gRPC server is **NOT recognizing the request as gRPC** when it comes from Caddy, even though:
- Path: `/auth.AuthService/HealthCheck` ✅
- Content-Type: `application/grpc` ✅
- TE: `trailers` ✅
- Method: POST ✅
- HTTP/2: ✅ (from Caddy logs)

---

## Hypothesis: Request Format Issue

### Theory

Node.js `@grpc/grpc-js` server validates incoming requests. If the request format doesn't match exactly what it expects, it might return HTTP 403 instead of processing as gRPC.

**Possible causes**:
1. **Header format**: Some header might be in the wrong format
2. **HTTP/2 frame format**: HTTP/2 frames might be formatted differently
3. **Path encoding**: Path might be encoded differently
4. **Header order**: Header order might matter
5. **Additional headers**: Extra headers from Caddy might confuse the server

### Comparison Needed

Compare the **exact request format** between:
- **Direct connection** (works): What does grpcurl send?
- **Via Caddy** (403): What does Caddy forward?

---

## Hypothesis: HTTP/2 Negotiation

### Theory

Even though Caddy logs show `"proto": "HTTP/2.0"`, there might be an issue with HTTP/2 negotiation between Caddy and auth-service.

**Possible causes**:
1. **ALPN mismatch**: ALPN negotiation might fail
2. **HTTP/2 settings**: HTTP/2 connection settings might be incompatible
3. **HTTP/2 frames**: Frame format might be different

### Check

- Verify ALPN in TLS handshake
- Compare HTTP/2 settings between direct and via Caddy
- Check for HTTP/2 errors in logs

---

## Hypothesis: Host Header

### Theory

Caddyfile sets `header_up Host auth-service.record-platform.svc.cluster.local:50051`, but logs show `Host: record.local`.

**Possible causes**:
1. `header_up Host` isn't being applied
2. Caddy logs show original header, but actual request has modified header
3. Host header mismatch causes rejection

### Check

- Verify if `header_up Host` is actually applied
- Test with different Host header values
- Check if removing Host header helps (already tested - didn't help)

---

## Next Steps

1. **Compare Request Formats**: 
   - Capture exact request from direct connection (works)
   - Capture exact request from Caddy (403)
   - Compare byte-by-byte or header-by-header

2. **Test HTTP/2 Settings**:
   - Verify HTTP/2 negotiation
   - Check ALPN in TLS handshake
   - Compare HTTP/2 settings

3. **Check Node.js gRPC Library Behavior**:
   - Look for known issues with proxy/load balancer
   - Check if there's validation that could cause 403
   - Review library documentation

4. **Test Different Configurations**:
   - Try different Caddy transport settings
   - Test with/without certain headers
   - Try different HTTP/2 configurations

---

## Related Files

- `Caddyfile` - Caddy configuration
- `services/auth-service/src/grpc-server.ts` - gRPC server code
- `test-results/GRPC_403_CRITICAL_FINDING.md` - Previous findings
