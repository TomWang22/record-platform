# gRPC 403 Deep Dive Investigation - We Cannot Let This Slide

**Date**: 2026-01-05  
**Status**: Deep Investigation In Progress  
**Issue**: gRPC 403 "Unknown protocol" - Critical issue that must be resolved

---

## Investigation Priority: CRITICAL

This issue blocks gRPC communication through Caddy, which is essential for the platform. We must find the root cause and fix it.

---

## What We Know

### ✅ Confirmed Facts
1. **Direct connections work**: `grpcurl` → service (HTTP/2 recognized, requests succeed)
2. **Caddy connections fail**: Caddy → service ("Unknown protocol" error)
3. **Service is correct**: HTTP/2 implementation works (proven by direct connections)
4. **Caddy is configured**: `versions h2` specified, TLS configured
5. **Error is consistent**: "Unknown protocol from [Caddy IP]" appears every time

### ❌ What We Don't Know
1. **What Caddy actually sends**: Need to see actual HTTP/2 frames
2. **Why Node.js doesn't recognize it**: What's different from working connections?
3. **If Caddy is using HTTP/2**: Or falling back to HTTP/1.1
4. **If there's a Caddy bug**: Version-specific issue with HTTP/2

---

## Deep Investigation Plan

### Phase 1: Network-Level Analysis
**Goal**: See what Caddy actually sends vs what works

**Actions**:
1. Capture packets from Caddy pod to auth-service
2. Capture packets from direct connection (grpcurl → service)
3. Compare HTTP/2 frames, connection preface, ALPN negotiation
4. Identify exact differences

**Tools**:
- `tcpdump` in pods (if available)
- `kubectl debug` with debug container
- Network policy to capture traffic

### Phase 2: Caddy Behavior Analysis
**Goal**: Verify Caddy is actually using HTTP/2

**Actions**:
1. Check Caddy admin API for runtime config
2. Enable more verbose Caddy logging
3. Check Caddy logs for protocol information
4. Verify Caddy isn't falling back to HTTP/1.1

**Tools**:
- Caddy admin API (port 2019)
- Enhanced Caddy logging
- Caddy metrics/telemetry

### Phase 3: Node.js HTTP/2 Server Analysis
**Goal**: Understand what Node.js expects

**Actions**:
1. Check Node.js http2 module documentation
2. Check @grpc/grpc-js HTTP/2 requirements
3. See if server can be configured to accept ALPN-only connections
4. Check if there's a way to disable connection preface requirement

**Tools**:
- Node.js documentation
- @grpc/grpc-js source code
- Server configuration options

### Phase 4: Caddy Version/Bug Check
**Goal**: Determine if this is a known Caddy issue

**Actions**:
1. Check Caddy GitHub issues for similar problems
2. Check Caddy changelog for HTTP/2 fixes
3. Test with different Caddy version (if possible)
4. Check Caddy community forums

**Tools**:
- Caddy GitHub issues
- Caddy documentation
- Caddy community

### Phase 5: Alternative Solutions
**Goal**: Find workarounds or alternative approaches

**Actions**:
1. Test with different reverse proxy (nginx, envoy)
2. Check if service can be configured differently
3. Consider bypassing Caddy for gRPC (direct service-to-service)
4. Check if there's a Caddy plugin that helps

**Tools**:
- Alternative proxies
- Service configuration changes
- Architecture modifications

---

## Current Hypothesis

### Primary Hypothesis
**Caddy's HTTP/2 implementation doesn't send the connection preface that Node.js HTTP/2 server expects, even though ALPN negotiates h2.**

**Why This Happens**:
- With TLS + ALPN, HTTP/2 is negotiated during TLS handshake
- Node.js HTTP/2 server still expects explicit connection preface
- Caddy relies on ALPN only and doesn't send preface
- Direct clients (grpcurl) send preface explicitly

### Secondary Hypothesis
**Caddy is falling back to HTTP/1.1 despite `versions h2` configuration.**

**Why This Might Happen**:
- HTTP/2 negotiation fails silently
- Caddy falls back to HTTP/1.1
- Service rejects HTTP/1.1 (HTTP/2 only)
- Results in "Unknown protocol" error

### Tertiary Hypothesis
**There's a Caddy v2.8.4 bug with HTTP/2 over TLS to Node.js servers.**

**Why This Might Be**:
- Version-specific issue
- Known bug in Caddy
- Incompatibility with Node.js HTTP/2 implementation

---

## Immediate Next Steps

1. **Network Capture**: Get actual packet captures to see what's being sent
2. **Caddy Admin API**: Check runtime configuration
3. **Enhanced Logging**: Get more details from both Caddy and service
4. **Caddy Issues**: Check for known bugs
5. **Alternative Test**: Try different proxy to isolate issue

---

## Files Created

- `test-results/GRPC_403_DEEP_DIVE_INVESTIGATION.md` - This investigation plan

---

## Conclusion

**Status**: Deep investigation in progress

**Priority**: CRITICAL - This blocks gRPC functionality

**Approach**: Systematic investigation from network level up to application level

**Goal**: Find root cause and implement fix
