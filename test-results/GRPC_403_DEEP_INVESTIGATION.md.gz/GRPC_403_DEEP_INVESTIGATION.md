# gRPC 403 Deep Investigation: Unknown Protocol Root Cause

**Date**: 2026-01-05  
**Status**: Deep Investigation In Progress  
**Issue**: "Unknown protocol" error persists after flush_interval fix

---

## Investigation Summary

### Fix Applied
- ✅ Added `flush_interval -1` to all gRPC handlers
- ✅ Updated ConfigMap `caddy-h3`
- ✅ Restarted Caddy pods
- ❌ Issue persists: Still getting "Unknown protocol from 10.244.1.34"

### Current Error
```
HTTP2 1: Unknown protocol from 10.244.1.34:58778
HTTP2 1: Unknown protocol timeout: 10000
```

Where `10.244.1.34` is the new Caddy pod IP after restart.

---

## Deep Investigation Steps

### Step 1: Understanding "Unknown Protocol" Error

**Node.js HTTP/2 Server Behavior**:
- Expects HTTP/2 connection preface: `PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`
- Has 10-second timeout to receive preface
- With TLS + ALPN, HTTP/2 is negotiated during TLS handshake
- **Problem**: Node.js may still expect explicit connection preface even with ALPN

### Step 2: Working vs Failing Connections

**✅ Working (Direct Connection)**:
- Client: `grpcurl` with TLS certs
- Protocol: HTTP/2 over TLS (h2)
- ALPN: Negotiates `h2` during TLS handshake
- Result: Service recognizes HTTP/2, processes request

**❌ Failing (Caddy Connection)**:
- Client: Caddy reverse proxy
- Protocol: Should be HTTP/2 over TLS (h2)
- ALPN: Should negotiate `h2` during TLS handshake
- Result: Service doesn't recognize protocol, logs "Unknown protocol"

**Key Difference**: The connection source (direct vs Caddy proxy)

### Step 3: Caddy Configuration Analysis

**Current Caddyfile**:
```caddyfile
transport http {
  versions h2
  tls
  tls_server_name record.local
  tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
  dial_timeout 10s
  response_header_timeout 30s
}
```

**What This Should Do**:
- Force HTTP/2 (`versions h2`)
- Use TLS to backend
- Set SNI to `record.local`
- Use trusted CA certs

**Potential Issues**:
1. `versions h2` might not be forcing HTTP/2 correctly
2. Caddy might fall back to HTTP/1.1 if HTTP/2 negotiation fails
3. ALPN negotiation might not be working correctly

### Step 4: Node.js HTTP/2 Server Configuration

**Service Configuration** (from `grpc-server.ts`):
```typescript
credentials = grpc.ServerCredentials.createSsl(
  rootCerts,
  [{ private_key: key, cert_chain: cert }],
  requireClientCert as any
);

server.bindAsync(
  `0.0.0.0:${port}`,
  credentials,
  (error, actualPort) => {
    server.start();
  }
);
```

**What This Does**:
- Creates TLS server with certificates
- Binds to `0.0.0.0:50051`
- Uses `@grpc/grpc-js` which wraps Node.js HTTP/2

**Potential Issues**:
- Node.js HTTP/2 server might expect connection preface even with ALPN
- There might be a mismatch in how ALPN is handled

### Step 5: Hypothesis - ALPN vs Connection Preface

**The Problem**:
- With TLS, HTTP/2 is negotiated via ALPN during TLS handshake
- Node.js HTTP/2 server might still expect the connection preface
- Caddy might not send the preface when using ALPN

**Why Direct Connections Work**:
- `grpcurl` might send the connection preface explicitly
- Or the way `grpcurl` establishes the connection matches what Node.js expects

**Why Caddy Connections Fail**:
- Caddy might rely solely on ALPN without sending preface
- Or Caddy's HTTP/2 implementation differs from what Node.js expects

### Step 6: Potential Solutions

#### Solution A: Force HTTP/2 Connection Preface
- Check if Caddy can be configured to send explicit preface
- Or configure Node.js server to not require preface with ALPN

#### Solution B: Use h2c (Cleartext HTTP/2)
- Test with `h2c://` instead of `https://`
- Not recommended for production, but useful for debugging

#### Solution C: Check Caddy Version/Bug
- Verify Caddy v2.8.4 has correct HTTP/2 implementation
- Check for known bugs with HTTP/2 over TLS

#### Solution D: Different Node.js HTTP/2 Configuration
- Check if `@grpc/grpc-js` or Node.js HTTP/2 server needs different config
- May need to configure server to accept ALPN-only HTTP/2

### Step 7: Next Investigation Steps

1. **Check ALPN Negotiation**:
   - Verify `h2` is negotiated in TLS handshake
   - Check if both Caddy and service support ALPN correctly

2. **Test with h2c**:
   - Try cleartext HTTP/2 to isolate TLS/ALPN issues
   - If h2c works, the issue is TLS/ALPN related

3. **Check Caddy Logs**:
   - Look for protocol information in Caddy logs
   - Verify Caddy is actually using HTTP/2

4. **Network Capture**:
   - Use tcpdump to capture actual HTTP/2 frames
   - Compare working (direct) vs failing (Caddy) connections

5. **Node.js HTTP/2 Server Options**:
   - Check if server needs different configuration
   - May need to configure to accept ALPN-only HTTP/2

---

## Files Created

- `test-results/GRPC_403_DEEP_INVESTIGATION.md` - This investigation report

---

## Conclusion

**Status**: Deep investigation in progress

**Key Finding**: The "Unknown protocol" error indicates Node.js HTTP/2 server doesn't recognize Caddy's HTTP/2 connection, even though:
- Caddy is configured for HTTP/2 (`versions h2`)
- TLS is used correctly
- ALPN should negotiate `h2`

**Next**: Investigate ALPN negotiation, test with h2c, and check if Node.js server needs different configuration.
