# gRPC 403 - Direct Connection Test

**Date**: January 4, 2025  
**Status**: 🧪 **TESTING** - Direct connection to auth-service  
**Priority**: Critical - Determine if issue is in auth-service or Caddy

---

## Test Plan

### Objective

Test direct connection to auth-service (bypass Caddy) to determine if:
1. **Auth-service gRPC handler works** → Issue is in Caddy or Caddy->auth-service connection
2. **Auth-service gRPC handler fails** → Issue is in auth-service itself

---

## Test Setup

### Direct Connection (Bypass Caddy)

**Method**: Port-forward to auth-service, make direct gRPC request

**Command**:
```bash
# Port-forward
kubectl -n record-platform port-forward svc/auth-service 50051:50051

# Direct request
grpcurl -insecure \
  -H "Content-Type: application/grpc" \
  -H "TE: trailers" \
  -import-path ./proto \
  -proto ./proto/auth.proto \
  localhost:50051 auth.AuthService/HealthCheck
```

### Expected Results

#### If Direct Works ✅

**Meaning**: Auth-service gRPC handler works correctly

**Conclusion**: Issue is in:
- Caddy routing/configuration
- Caddy->auth-service TLS connection
- Caddy->auth-service HTTP/2 setup
- Response conversion by Caddy

**Next Steps**:
1. Check Caddy configuration
2. Check Caddy->auth-service TLS setup
3. Check Caddy->auth-service HTTP/2 connection
4. Check response handling in Caddy

#### If Direct Fails ❌

**Meaning**: Auth-service gRPC handler has issues

**Conclusion**: Issue is in:
- Auth-service gRPC server
- HTTP server intercepting requests
- TLS/HTTP/2 configuration
- Port binding/listening

**Next Steps**:
1. Check if HTTP server is intercepting gRPC requests
2. Check gRPC server startup/logs
3. Check TLS/HTTP/2 configuration
4. Check port binding

---

## Key Findings from Caddy Logs

### Caddy Receives Response from Auth-Service

**From Caddy logs**:
```
"upstream roundtrip": {
  "upstream": "auth-service.record-platform.svc.cluster.local:50051",
  "duration": 0.139223584,
  "status": 403,
  "headers": {"Content-Type": ["text/plain"]}
}
```

**What This Means**:
- ✅ Caddy connects to auth-service
- ✅ Auth-service responds
- ❌ Response is HTTP 403 with text/plain (not gRPC)

**Key Question**: Why does auth-service return HTTP 403 instead of gRPC response?

---

## Hypotheses

### Hypothesis 1: HTTP Server Intercepting

**Theory**: Express HTTP server (port 4001) intercepts requests on port 50051.

**Evidence Against**:
- HTTP server listens on port 4001
- gRPC server listens on port 50051
- Different ports, should be separate

**But**: Could there be port forwarding or interception?

### Hypothesis 2: gRPC Server Not Listening

**Theory**: gRPC server isn't actually listening on port 50051.

**Evidence**:
- Logs show "Server started on port 50051"
- But requests might not reach handler

**Test**: Direct connection will reveal if server is listening

### Hypothesis 3: TLS/HTTP/2 Connection Issue

**Theory**: Direct connection (insecure) works, but TLS/HTTP/2 connection fails.

**Evidence**:
- Caddy uses TLS/HTTP/2
- Direct test uses insecure (no TLS)
- Different connection methods

**Test**: Direct connection will reveal if TLS is the issue

### Hypothesis 4: Response Format Issue

**Theory**: gRPC handler processes request, but response format is wrong.

**Evidence**:
- No enhanced logs (handler not called)
- But Caddy receives response (something responds)

**Test**: Direct connection will reveal if handler is called

---

## Test Results

### Direct Connection

- ✅ Port-forward: Started
- ⏳ Request: Made
- ⏳ Response: Pending
- ⏳ Logs: Captured

### Analysis

- ⏳ Comparison: Direct vs Via Caddy
- ⏳ Root cause: Identified
- ⏳ Fix: Implemented

---

## Related Files

- `test-results/GRPC_403_NO_HANDLER_LOGS.md` - No handler logs finding
- `test-results/GRPC_403_ROOT_CAUSE_INVESTIGATION.md` - Investigation notes
- `services/auth-service/src/server.ts` - HTTP server startup
- `services/auth-service/src/grpc-server.ts` - gRPC server startup
