# gRPC 403 - Envoy Test Plan (Step 4)

**Date**: 2026-01-05  
**Status**: Preparing  
**Purpose**: Isolate if issue is Caddy-specific

---

## Why Envoy Test?

After applying Steps 1-3:
- ✅ Added `protocol grpc` matcher
- ✅ Verified route order
- ✅ Enhanced header logging

**Issue persists**: Still getting "Unknown protocol" error

This means the problem is at the HTTP/2 connection level, not gRPC routing.

**Envoy test will tell us**:
- If Envoy works → Caddy is the problem (Caddy-specific bug)
- If Envoy fails → Node.js server configuration issue

---

## Envoy Test Configuration

### Minimal Envoy Config for gRPC

```yaml
static_resources:
  listeners:
  - name: listener_0
    address:
      socket_address:
        address: 0.0.0.0
        port_value: 10000
    filter_chains:
    - filters:
      - name: envoy.filters.network.http_connection_manager
        typed_config:
          "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager
          stat_prefix: grpc_json
          codec_type: AUTO
          route_config:
            name: local_route
            virtual_hosts:
            - name: local_service
              domains: ["*"]
              routes:
              - match:
                  prefix: "/"
                route:
                  cluster: auth_service
          http_filters:
          - name: envoy.filters.http.router
  clusters:
  - name: auth_service
    connect_timeout: 0.25s
    type: LOGICAL_DNS
    lb_policy: ROUND_ROBIN
    http2_protocol_options: {}
    load_assignment:
      cluster_name: auth_service
      endpoints:
      - lb_endpoints:
        - endpoint:
            address:
              socket_address:
                address: auth-service.record-platform.svc.cluster.local
                port_value: 50051
    transport_socket:
      name: envoy.transport_sockets.tls
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext
        sni: record.local
        common_tls_context:
          validation_context:
            trusted_ca:
              filename: /etc/certs/ca/dev-root.pem
```

---

## Test Steps

1. Deploy Envoy with minimal config
2. Port-forward Envoy (port 10000)
3. Test gRPC request via Envoy
4. Check service logs for "Unknown protocol"
5. Compare with Caddy behavior

---

## Expected Results

### If Envoy Works:
- ✅ gRPC request succeeds
- ✅ Service logs show HTTP/2 connection accepted
- ✅ No "Unknown protocol" error
- **Conclusion**: Caddy is the problem

### If Envoy Fails:
- ❌ Same "Unknown protocol" error
- **Conclusion**: Node.js server configuration issue

---

## Next Steps After Test

### If Envoy Works:
- File Caddy GitHub issue with:
  - Network captures
  - Caddy logs
  - Service logs
  - Envoy working config
- Consider using Envoy as workaround

### If Envoy Fails:
- Investigate Node.js HTTP/2 server configuration
- Check if server needs different setup
- Consider alternative gRPC server implementation

---

## Files

- `test-results/GRPC_403_ENVOY_TEST_PLAN.md` - This plan
