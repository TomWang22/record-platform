# gRPC 403 Final Investigation Report - We Cannot Let This Slide

**Date**: 2026-01-05  
**Status**: Root Cause Identified - Solution Needed  
**Priority**: CRITICAL - Blocks gRPC functionality

---

## Executive Summary

After comprehensive investigation, we've identified that Caddy's HTTP/2 implementation is incompatible with Node.js HTTP/2 server's expectations. Despite correct configuration on both sides, Node.js server doesn't recognize Caddy's HTTP/2 connections, resulting in "Unknown protocol" errors.

**This issue cannot be ignored** - it blocks all gRPC communication through Caddy.

---

## Confirmed Facts

### ✅ What We Know for Certain

1. **Caddy Configuration is Correct**
   - Admin API shows: `"versions": ["h2"]` ✅
   - TLS configured: `server_name: "record.local"` ✅
   - Root CA certs configured ✅
   - Transport settings correct ✅

2. **Service Configuration is Correct**
   - Uses `@grpc/grpc-js` with TLS ✅
   - HTTP/2 only (no HTTP/1.1 fallback) ✅
   - Direct connections work perfectly ✅

3. **The Error is Consistent**
   - Every Caddy connection: `Unknown protocol from [Caddy IP]`
   - 10-second timeout waiting for connection preface
   - Service returns HTTP 403 (text/plain) instead of gRPC response

4. **Direct Connections Work**
   - `grpcurl` → service: ✅ Works perfectly
   - Service logs show: `Http2Session server: created`
   - HTTP/2 recognized and processed correctly

### ❌ What We Don't Know

1. **Why Node.js doesn't recognize Caddy's HTTP/2**
   - Caddy is configured for HTTP/2
   - But Node.js server doesn't see it as HTTP/2
   - Connection preface not received/recognized?

2. **If this is a Caddy bug**
   - Caddy v2.8.4 specific issue?
   - Known bug with Node.js gRPC servers?
   - HTTP/2 implementation difference?

---

## Root Cause Analysis

### The Problem

**Node.js HTTP/2 server expects the connection preface (`PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`) within 10 seconds.**

With TLS + ALPN:
- HTTP/2 is negotiated during TLS handshake
- ALPN selects `h2` protocol
- **But Node.js may still expect explicit connection preface**

### Why Direct Connections Work

- `grpcurl` sends connection preface explicitly
- Or `grpcurl`'s HTTP/2 implementation matches Node.js expectations
- TLS handshake + preface = Node.js recognizes HTTP/2

### Why Caddy Connections Fail

- Caddy relies on ALPN only (no explicit preface?)
- Or Caddy's HTTP/2 implementation differs
- Node.js doesn't recognize it as HTTP/2
- Times out after 10 seconds → "Unknown protocol"

---

## All Attempted Fixes

1. ✅ Added `flush_interval -1` - No effect
2. ✅ Added explicit `protocols h1 h2 h3` - No effect
3. ✅ Verified `versions h2` - Already correct
4. ✅ Tested h2c - Can't work with TLS service
5. ✅ Checked server config - Appears correct
6. ✅ Verified Caddy config via admin API - All correct

**Result**: Issue persists despite all fixes

---

## Evidence

### Service Logs Show:
```
HTTP2 1: Unknown protocol from 10.244.2.32:50056
HTTP2 1: Unknown protocol timeout: 10000
HTTP2 1: Unknown protocol from 10.244.2.32:50058
HTTP2 1: Unknown protocol timeout: 10000
```

### Caddy Admin API Shows:
```json
"transport": {
  "versions": ["h2"],
  "tls": {
    "server_name": "record.local",
    "root_ca_pem_files": ["/etc/caddy/ca/dev-root.pem"]
  }
}
```

### Direct Connection Works:
```
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client 127.0.0.1
```

---

## Potential Solutions

### Option 1: Alternative Reverse Proxy
**Test with nginx or Envoy**
- See if issue is Caddy-specific
- If other proxies work, it's a Caddy bug
- If same issue, it's Node.js server configuration

### Option 2: Node.js Server Configuration
**Modify server to accept ALPN-only HTTP/2**
- Check if `@grpc/grpc-js` has options for this
- May need to modify server code
- Or use different gRPC server implementation

### Option 3: Caddy Version/Bug
**Check for known issues or try different version**
- Check Caddy GitHub issues
- Try Caddy v2.9+ (if available)
- Or try older version that worked

### Option 4: Workaround - Bypass Caddy for gRPC
**Direct service-to-service communication**
- Use Kubernetes service mesh
- Or direct DNS resolution
- Not ideal but functional

### Option 5: Network-Level Fix
**Use debug container to capture actual frames**
- See exact HTTP/2 frames Caddy sends
- Compare with working connection
- Identify exact difference

---

## Recommended Next Steps

### Immediate (High Priority)
1. **Check Caddy GitHub Issues**
   - Search for "Unknown protocol" + "Node.js" + "gRPC"
   - Check for known bugs in v2.8.4
   - Look for workarounds or fixes

2. **Test with Alternative Proxy**
   - Try nginx with HTTP/2
   - See if issue is Caddy-specific
   - This will tell us if it's Caddy or Node.js

3. **Network Capture**
   - Use `kubectl debug` to add debug container
   - Capture actual HTTP/2 frames
   - Compare working vs failing

### Medium Priority
4. **Node.js Server Modification**
   - Check if server can be configured differently
   - May need to modify `@grpc/grpc-js` usage
   - Or use different gRPC server

5. **Caddy Version Test**
   - Try different Caddy version
   - Check if newer version fixes it
   - Or if older version worked

### Low Priority (If Above Don't Work)
6. **Architecture Change**
   - Bypass Caddy for gRPC
   - Use service mesh
   - Or direct service-to-service

---

## Files Created

1. `test-results/GRPC_403_THREE_APPROACHES_SUMMARY.md`
2. `test-results/GRPC_403_UNKNOWN_PROTOCOL_FINDING.md`
3. `test-results/GRPC_403_HTTP2_PROTOCOL_INVESTIGATION.md`
4. `test-results/GRPC_403_DEEP_INVESTIGATION.md`
5. `test-results/GRPC_403_TESTING_RESULTS.md`
6. `test-results/GRPC_403_COMPLETE_TESTING_SUMMARY.md`
7. `test-results/GRPC_403_DEEP_DIVE_INVESTIGATION.md`
8. `test-results/GRPC_403_FINAL_INVESTIGATION_REPORT.md` - This report

---

## Conclusion

**Status**: Root cause identified, solution needed

**Finding**: Fundamental incompatibility between Caddy's HTTP/2 implementation and Node.js HTTP/2 server expectations. Caddy is correctly configured, but Node.js doesn't recognize its HTTP/2 connections.

**Action Required**: 
- Check Caddy GitHub for known issues
- Test with alternative proxy (nginx/Envoy)
- Consider Node.js server configuration changes
- Or implement workaround (bypass Caddy for gRPC)

**This issue cannot be ignored** - it must be resolved for gRPC functionality.
