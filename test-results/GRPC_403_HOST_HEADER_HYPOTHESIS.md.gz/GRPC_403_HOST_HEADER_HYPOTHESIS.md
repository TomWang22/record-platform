# gRPC 403 - Host Header Hypothesis

**Date**: January 4, 2025  
**Status**: 🔬 **HYPOTHESIS TESTING** - Changed Host header in Caddyfile  
**Priority**: Critical - Blocks all gRPC traffic through Caddy

---

## Problem Summary

Caddy sends gRPC requests with correct headers (`Content-Type: application/grpc`), but receives HTTP 403 with `Content-Type: text/plain` instead of a gRPC response.

**Key Observation**:
- ✅ Caddy sends: `Host: record.local`, `Content-Type: application/grpc`
- ❌ Caddy receives: `Content-Type: text/plain`, `Status: 403`
- ✅ Auth-service logs show: `HealthCheck completed` (successful processing)
- ✅ Direct connection (port-forward) works perfectly

---

## Hypothesis: Host Header Mismatch

### Current Behavior

**Caddy Configuration (BEFORE)**:
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host {http.request.host}  # ← Sends "record.local"
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

**What Caddy Sends**:
- `Host: record.local` (from `{http.request.host}`)
- `Content-Type: application/grpc`
- `TE: trailers`
- Via HTTP/2 with TLS

**What Direct Connection Sends**:
- `Host: 127.0.0.1:50051` (or service IP)
- `Content-Type: application/grpc`
- `TE: trailers`
- Via HTTP/2 with TLS

### The Hypothesis

**Node.js gRPC server (`@grpc/grpc-js`) might be validating or rejecting requests based on the Host header.**

Even though gRPC doesn't typically care about Host headers, Node.js's gRPC implementation might:
1. Check Host header for routing/security
2. Reject requests with unexpected Host values
3. Return HTTP 403 when Host doesn't match expectations

### Proposed Fix

**Change Caddyfile to use actual service hostname**:

```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host auth-service.record-platform.svc.cluster.local:50051  # ← Use service DNS name
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

---

## Implementation Status

### Change Required

**File**: `Caddyfile`  
**Location**: All `handle @grpc_*` blocks (8 services × 3 server blocks = 24 instances)

**Services to Update**:
1. auth-service:50051 → `auth-service.record-platform.svc.cluster.local:50051`
2. records-service:50051 → `records-service.record-platform.svc.cluster.local:50051`
3. social-service:50056 → `social-service.record-platform.svc.cluster.local:50056`
4. listings-service:50057 → `listings-service.record-platform.svc.cluster.local:50057`
5. analytics-service:50054 → `analytics-service.record-platform.svc.cluster.local:50054`
6. shopping-service:50058 → `shopping-service.record-platform.svc.cluster.local:50058`
7. auction-monitor:50059 → `auction-monitor.record-platform.svc.cluster.local:50059`
8. python-ai-service:50060 → `python-ai-service.record-platform.svc.cluster.local:50060`

**Server Blocks** (each has 8 gRPC handlers):
1. `https://record.local` (port 443) - main block
2. `:5000` (h2c block, deprecated but still active)
3. `:443` (alternate block, if exists)

**Total Instances**: 24 gRPC handlers + 7 HTTP handlers (privacy, terms, api, webapp) = 31 total Host headers

**Action**: Update all 24 gRPC handlers, leave HTTP handlers unchanged (they use `{http.request.host}` correctly)

### Next Steps

1. **Update Caddyfile**:
   - Change all gRPC handler `header_up Host {http.request.host}` to use service-specific hostnames
   - Keep HTTP handler Host headers unchanged
   - Test with one service first (auth-service), then apply to all

2. **Apply Caddyfile changes**:
   - If Caddyfile is in a ConfigMap: Update ConfigMap
   - Restart Caddy pods: `kubectl rollout restart deployment/caddy-h3 -n ingress-nginx`

3. **Test gRPC request via Caddy**:
   ```bash
   grpcurl -cacert=/tmp/grpc-certs/ca.crt \
           -cert=/tmp/grpc-certs/tls.crt \
           -key=/tmp/grpc-certs/tls.key \
           -servername=record.local \
           -H "Host: record.local" \
           -H "Content-Type: application/grpc" \
           -H "TE: trailers" \
           -import-path "$PROTO_DIR" \
           -proto "$PROTO_DIR/auth.proto" \
           "127.0.0.1:30443" \
           "auth.AuthService/HealthCheck"
   ```

4. **Check Caddy logs**:
   ```bash
   kubectl -n ingress-nginx logs -f deployment/caddy-h3 | grep -i "grpc\|403\|auth"
   ```

5. **Check auth-service logs**:
   ```bash
   kubectl -n record-platform logs -f deployment/auth-service | grep -i "grpc\|healthcheck"
   ```

---

## Alternative Hypotheses (If Host Header Doesn't Work)

### Alternative 1: Remove Host Header Entirely

Let Caddy set Host header automatically:

```caddyfile
reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
  # Remove header_up Host entirely
  header_up TE trailers
  header_up grpc-timeout {http.request.header.grpc-timeout}
  ...
}
```

### Alternative 2: Use Service IP Instead of Hostname

```caddyfile
header_up Host auth-service.record-platform.svc.cluster.local
# Without port number
```

### Alternative 3: TLS SNI vs Host Header Mismatch

The issue might be that:
- `tls_server_name record.local` (correct for TLS SNI)
- But `Host: record.local` (wrong for gRPC server)

gRPC server might expect Host to match TLS certificate CN, not SNI.

---

## Evidence Supporting Host Header Hypothesis

1. **Direct connection works** - Uses different Host header (IP:port)
2. **Caddy connection fails** - Uses `record.local` as Host
3. **Auth-service processes request** - Logs show success
4. **But returns HTTP 403** - Suggests early rejection, not processing failure
5. **Response is `text/plain`** - Not gRPC format, suggests HTTP handler, not gRPC

---

## Evidence Against Host Header Hypothesis

1. **gRPC doesn't typically validate Host headers** - HTTP/2 doesn't require it
2. **TLS SNI is separate from Host header** - Shouldn't conflict
3. **Other services might have same issue** - If it's Host header, all services should fail

---

## Status

- ✅ Hypothesis documented
- ✅ Caddyfile structure analyzed (24 gRPC handlers across 3 blocks)
- ⏳ Need to update Caddyfile with service-specific Host headers
- ⏳ Need to apply changes and restart Caddy
- ⏳ Need to test and verify
- ⏳ If fails, try alternative hypotheses

---

## Related Files

- `Caddyfile` - Caddy configuration (NEEDS UPDATE)
- `test-results/GRPC_403_INVESTIGATION_COMPLETE.md` - Full investigation report
- `services/auth-service/src/grpc-server.ts` - gRPC server implementation
- `infra/k8s/base/caddy-h3-deploy.yaml` - Caddy deployment (need to check for ConfigMap)
