# gRPC 403 - Host Header Test Result

**Date**: January 4, 2025  
**Status**: ❌ **HYPOTHESIS FAILED** - Host header change did not fix 403  
**Priority**: Critical - Blocks all gRPC traffic through Caddy

---

## Test Summary

**Hypothesis**: Changing Host header from `{http.request.host}` (record.local) to service-specific DNS names (e.g., `auth-service.record-platform.svc.cluster.local:50051`) would fix the 403 error.

**Result**: ❌ **FAILED** - Still receiving 403 Forbidden with `text/plain` content-type

---

## Changes Made

### Caddyfile Updates

Updated all 24 gRPC handler instances (8 services × 3 blocks):

**Before**:
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host {http.request.host}  # ← Was "record.local"
    ...
  }
}
```

**After**:
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host auth-service.record-platform.svc.cluster.local:50051  # ← Changed to service DNS
    ...
  }
}
```

**Services Updated**:
1. auth-service:50051 → `auth-service.record-platform.svc.cluster.local:50051`
2. records-service:50051 → `records-service.record-platform.svc.cluster.local:50051`
3. social-service:50056 → `social-service.record-platform.svc.cluster.local:50056`
4. listings-service:50057 → `listings-service.record-platform.svc.cluster.local:50057`
5. analytics-service:50054 → `analytics-service.record-platform.svc.cluster.local:50054`
6. shopping-service:50058 → `shopping-service.record-platform.svc.cluster.local:50058`
7. auction-monitor:50059 → `auction-monitor.record-platform.svc.cluster.local:50059`
8. python-ai-service:50060 → `python-ai-service.record-platform.svc.cluster.local:50060`

**ConfigMap Applied**:
- Updated ConfigMap `caddy-h3` in namespace `ingress-nginx`
- Restarted Caddy deployment
- Pods successfully rolled out

---

## Test Result

**Command**:
```bash
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
        -cert=/tmp/grpc-certs/tls.crt \
        -key=/tmp/grpc-certs/tls.key \
        -servername=record.local \
        -H "Host: record.local" \
        -H "Content-Type: application/grpc" \
        -H "TE: trailers" \
        -import-path "$PROTO_DIR" \
        -proto "$PROTO_DIR/auth.proto" \
        "127.0.0.1:30443" \
        "auth.AuthService/HealthCheck"
```

**Result**:
```
ERROR:
  Code: PermissionDenied
  Message: unexpected HTTP status code received from server: 403 (Forbidden); 
  transport: received unexpected content-type "text/plain"
```

**Status**: ❌ Still receiving 403 Forbidden

---

## Analysis

### Why Host Header Hypothesis Failed

1. **gRPC doesn't validate Host headers** - HTTP/2 and gRPC don't typically check Host headers for routing
2. **Direct connection works** - Port-forward works with different Host header (IP:port)
3. **Response format** - Still receiving `text/plain` instead of gRPC format, suggesting the issue is not Host header validation

### Key Observations

1. **Caddy sends correctly**: `Content-Type: application/grpc`, proper headers
2. **Caddy receives**: `Content-Type: text/plain`, `Status: 403`
3. **Auth-service logs**: Show successful processing (if logs are checked)
4. **Direct connection**: Works perfectly (bypasses Caddy)

This suggests the issue is **not** with Host header validation, but something else in the request/response flow.

---

## Next Steps

Since Host header change didn't work, we need to investigate other causes:

### Alternative Hypothesis 1: Remove Host Header Entirely

**Theory**: Maybe the Host header shouldn't be set at all, let Caddy set it automatically.

**Test**: Remove `header_up Host` entirely from gRPC handlers.

### Alternative Hypothesis 2: TLS SNI vs Host Header Mismatch

**Theory**: TLS SNI uses `record.local` but Host header uses service DNS. There might be a mismatch.

**Test**: Keep `tls_server_name record.local` but try different Host header values or remove it.

### Alternative Hypothesis 3: HTTP/2 Connection Issue

**Theory**: Caddy's HTTP/2 connection to services might not be properly configured.

**Test**: Check if there are differences in HTTP/2 connection setup between direct and Caddy connections.

### Alternative Hypothesis 4: Node.js gRPC Server Issue

**Theory**: Node.js gRPC server (`@grpc/grpc-js`) might have specific requirements or bugs with reverse proxies.

**Test**: Check Node.js gRPC library version, known issues, or alternative configurations.

### Alternative Hypothesis 5: Request/Response Interception

**Theory**: Something is intercepting the gRPC request/response and converting it to HTTP 403.

**Test**: Add more detailed logging to both Caddy and auth-service to trace the exact request/response flow.

---

## Status

- ✅ Host header hypothesis tested
- ❌ Hypothesis failed - still receiving 403
- ⏳ Need to try alternative hypotheses
- ⏳ Need to investigate deeper into request/response flow

---

## Related Files

- `Caddyfile` - Updated with service-specific Host headers
- `test-results/GRPC_403_HOST_HEADER_HYPOTHESIS.md` - Original hypothesis
- `test-results/GRPC_403_INVESTIGATION_COMPLETE.md` - Full investigation report
