# gRPC 403 HTTP/2 Protocol Investigation - Complete Analysis

**Date**: 2026-01-05  
**Status**: Investigation Complete, Fix Applied  
**Issue**: gRPC requests via Caddy return 403 Forbidden due to "Unknown protocol" error

---

## Executive Summary

**Root Cause Identified**: Caddy connects to the gRPC service, but the Node.js HTTP/2 server doesn't recognize the protocol. The service logs show "Unknown protocol from 10.244.2.22" (Caddy's IP), indicating the HTTP/2 connection preface is not being received or recognized.

**Fix Applied**: Added `flush_interval -1` to all gRPC handlers in Caddyfile to disable buffering, which may help with HTTP/2 connection preface delivery.

---

## Investigation Steps Completed

### Step 1: Caddy Version and HTTP/2/3 Support
- ✅ **Caddy Version**: v2.8.4
- ✅ **HTTP/2 Support**: Enabled (configured with `versions h2`)
- ✅ **HTTP/3 Support**: Enabled automatically on port 443 with TLS

### Step 2: Protocol Analysis
- ✅ **Caddy Configuration**: `transport http { versions h2 }` with TLS
- ✅ **Service Configuration**: HTTP/2 only, TLS enabled, ALPN = h2
- ✅ **Direct Connection**: WORKS (HTTP/2 recognized)
- ❌ **Caddy Connection**: FAILS (Unknown protocol)

### Step 3: Log Analysis

#### Caddy Logs Show:
```
upstream roundtrip: 0.029s
proto: "HTTP/2.0"
tls.proto: "h2"
status: 403
Content-Type: "text/plain"
```

**Key Finding**: Caddy thinks it's using HTTP/2.0 and TLS h2, but the service doesn't recognize it.

#### Service Logs Show:
```
✅ Working (127.0.0.1 - direct/health check):
  HTTP2 1: Http2Session server: created
  D ... | server | (1) Connection established by client 127.0.0.1

❌ Failing (10.244.2.22 - Caddy):
  HTTP2 1: Unknown protocol from 10.244.2.22:55336
  HTTP2 1: Unknown protocol timeout: 10000
```

**Key Finding**: Service recognizes HTTP/2 from direct connections but not from Caddy.

### Step 4: Direct Connection Test
- ✅ **Direct TLS Connection**: WORKS
  - `grpcurl` with TLS certs → Service accepts HTTP/2
  - Service logs show: `Http2Session server: created`
  - Response: `{"healthy": true, "version": "1.0.0"}`

- ❌ **Caddy Connection**: FAILS
  - Caddy → Service: Connection established but protocol not recognized
  - Service logs: `Unknown protocol from 10.244.2.22`
  - Response: HTTP 403 (text/plain)

### Step 5: Root Cause Analysis

**The Problem**: Node.js HTTP/2 server expects the HTTP/2 connection preface (`PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`) within 10 seconds. If it doesn't receive it, it logs "Unknown protocol" and rejects the connection.

**Why This Happens**:
1. **ALPN Negotiation**: With TLS, HTTP/2 is negotiated via ALPN during the TLS handshake. The connection preface may not be sent explicitly.
2. **Caddy's HTTP/2 Implementation**: Caddy may handle HTTP/2 over TLS differently than direct connections.
3. **Buffering**: Caddy's response buffering may interfere with the HTTP/2 connection preface delivery.

**Evidence**:
- Direct TLS connections work (grpcurl → service)
- Caddy connections fail (Caddy → service)
- Both use TLS and HTTP/2, but Caddy's connection is not recognized

### Step 6: Fix Applied

**Solution**: Add `flush_interval -1` to all gRPC handlers to disable buffering.

**Why This Helps**:
- Disables response buffering, allowing immediate HTTP/2 frame delivery
- May help with connection preface recognition
- Recommended for gRPC streaming responses

**Changes Made**:
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host auth-service.record-platform.svc.cluster.local:50051
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    flush_interval -1  # Disable buffering for gRPC streaming
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
      dial_timeout 10s
      response_header_timeout 30s
    }
  }
}
```

**Applied to**: All 8 gRPC service handlers (auth, records, social, listings, analytics, shopping, auction-monitor, python-ai)

---

## Protocol Requirements for gRPC

### HTTP/2 vs HTTP/3 for gRPC

**gRPC Requirements**:
- **Primary**: HTTP/2 (required by gRPC specification)
- **Optional**: HTTP/3 (QUIC) - experimental support in some gRPC implementations

**Current Configuration**:
- ✅ **HTTP/2**: Configured and required (`versions h2`)
- ✅ **HTTP/3**: Enabled automatically on port 443 (Caddy v2.8+)
- ✅ **TLS**: Required for production (strict TLS 1.2/1.3)

**Service-to-Service Communication**:
- **Protocol**: HTTP/2 over TLS (h2)
- **ALPN**: `h2` negotiated during TLS handshake
- **Connection Preface**: Required for HTTP/2 (may be implicit with ALPN)

---

## Next Steps

### 1. Test the Fix
After Caddy reloads the configuration:
```bash
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  -H "Host: record.local" \
  127.0.0.1:30443 auth.AuthService/HealthCheck
```

### 2. Monitor Logs
- **Caddy logs**: Check for successful upstream connections
- **Service logs**: Check if "Unknown protocol" error is resolved
- **Debug logs**: Verify HTTP/2 session creation

### 3. If Fix Doesn't Work

**Alternative Solutions**:
1. **Check ALPN Negotiation**: Verify `h2` is negotiated in TLS handshake
2. **Try h2c (Cleartext)**: If TLS is the issue, test with h2c (not recommended for production)
3. **Caddy Version**: Check if Caddy v2.8.4 has known HTTP/2 issues
4. **Service Configuration**: Verify service's HTTP/2 server configuration
5. **Network Capture**: Use tcpdump to capture actual HTTP/2 frames

---

## Files Created

1. `test-results/GRPC_403_THREE_APPROACHES_SUMMARY.md` - All three investigation approaches
2. `test-results/GRPC_403_UNKNOWN_PROTOCOL_FINDING.md` - Root cause analysis
3. `test-results/GRPC_403_HTTP2_PROTOCOL_INVESTIGATION.md` - This comprehensive report

---

## Conclusion

**Status**: Investigation complete, fix applied, testing pending

**Key Findings**:
1. ✅ Caddy connects to service (connection established)
2. ✅ Caddy uses HTTP/2.0 and TLS h2
3. ❌ Service doesn't recognize Caddy's HTTP/2 protocol
4. ✅ Direct connections work (proves service HTTP/2 is correct)
5. ✅ Fix applied: `flush_interval -1` to disable buffering

**Next**: Test the fix and verify the "Unknown protocol" error is resolved.
