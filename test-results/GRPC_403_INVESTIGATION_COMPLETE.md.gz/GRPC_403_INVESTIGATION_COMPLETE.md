# gRPC 403 Investigation - Complete Findings

**Date**: January 4, 2025  
**Status**: 🔴 **ISSUE IDENTIFIED** - Auth-service returns HTTP 403 instead of gRPC response  
**Priority**: Critical - Blocks all gRPC traffic through Caddy

---

## Executive Summary

After comprehensive investigation including Caddy version check, direct vs Caddy comparison, and detailed log analysis, we've identified the core issue:

**Auth-service processes gRPC requests successfully, but returns HTTP 403 with `text/plain` content-type instead of a proper gRPC response.**

---

## Key Findings

### 1. Caddy Version
- **Current**: v2.8.4 (h1:q3pe0wpBj1OcHFZ3n/1nl4V4bxBrYoSoab7rL9BMYNk=)
- **Latest**: v2.10.2 (2024-2025)
- **Note**: Version is 1.5 years old, but unlikely to be the root cause

### 2. Service TLS Configuration
- ✅ **All services**: Client cert verification DISABLED
  - `GRPC_REQUIRE_CLIENT_CERT` not set
  - `requireClientCert = false` in all service code
- ✅ **Certificates**: All use `record.local` (CN=record.local, DNS:record.local)
- ✅ **TLS config**: Caddy uses `tls_server_name record.local` (correct)

### 3. Direct vs Caddy Comparison

**Direct Connection (WORKS)**:
```bash
kubectl port-forward pod/auth-service-xxx 50051:50051
grpcurl -cacert=/tmp/grpc-certs/ca.crt ... 127.0.0.1:50051 auth.AuthService/HealthCheck
# Result: ✅ Success - returns healthy status
```

**Via Caddy (FAILS)**:
```bash
grpcurl -cacert=/tmp/grpc-certs/ca.crt ... 127.0.0.1:30443 auth.AuthService/HealthCheck
# Result: ❌ 403 Forbidden (text/plain)
```

### 4. Critical Log Evidence

**Caddy Debug Logs (Line 536 from terminal)**:
```json
{
  "upstream": "auth-service.record-platform.svc.cluster.local:50051",
  "duration": 0.021384292,
  "request": {
    "uri": "/auth.AuthService/HealthCheck",
    "headers": {
      "Content-Type": ["application/grpc"],
      "Host": ["record.local"],
      "Te": ["trailers"]
    }
  },
  "headers": {
    "Content-Type": ["text/plain"]
  },
  "status": 403
}
```

**Auth-Service Logs**:
```
[gRPC] HealthCheck called
[gRPC] HealthCheck completed in 31ms
```

**Key Observation**:
- ✅ Request: `Content-Type: application/grpc` (correct)
- ❌ Response: `Content-Type: text/plain` (HTTP error, not gRPC!)
- ❌ Status: `403` (HTTP status code, not gRPC status)
- ✅ Auth-service logs show successful processing

---

## Root Cause Analysis

### The Contradiction

1. **Auth-service processes successfully** - logs show `HealthCheck completed`
2. **Caddy receives HTTP 403** - with `text/plain` content-type
3. **Direct connection works** - bypassing Caddy succeeds

This suggests:
- Auth-service gRPC handler IS executing
- But the response is being converted to HTTP 403 somewhere
- This conversion happens ONLY when accessed via Caddy (not direct)

### Possible Causes

#### Hypothesis 1: Auth-Service HTTP Server Intercepting (MOST LIKELY)
**Theory**: Auth-service runs both HTTP (port 4001) and gRPC (port 50051) servers. The HTTP server might be intercepting requests on port 50051 and returning 403.

**Evidence**:
- Direct connection works (goes directly to gRPC server)
- Via Caddy fails (might hit HTTP server somehow)
- Response format is HTTP (403, text/plain) not gRPC

**Test**: Check if auth-service HTTP server is listening on port 50051

#### Hypothesis 2: Node gRPC Library Response Conversion
**Theory**: Node.js gRPC library might be converting gRPC errors to HTTP responses when accessed via proxy.

**Evidence**:
- Auth-service logs show success
- But response is HTTP format
- Could be a Node.js gRPC library quirk

**Test**: Check Node.js gRPC library version and known issues

#### Hypothesis 3: Caddy HTTP/2 Connection Issue
**Theory**: Caddy's HTTP/2 connection to auth-service might be misconfigured, causing auth-service to reject it as non-gRPC.

**Evidence**:
- Caddy uses `versions h2` (HTTP/2)
- Direct connection works (also HTTP/2)
- But response format is wrong

**Test**: Check HTTP/2 connection details

---

## Service Logs Summary

### Auth-Service
- No startup logs visible (might need to check earlier logs)
- Runtime logs show successful gRPC processing

### Records-Service
- `[records gRPC] Starting secure server with ALPN h2`
- `[records gRPC] server listening on 50051`

### Social-Service
- `[gRPC] Starting secure HTTP/2-only server with strict TLS`
- `[gRPC] Client certificate verification is DISABLED (dev mode)`
- `[social] gRPC server listening on port 50056 (HTTP/2 only)`

### Listings-Service
- `[gRPC] Starting secure HTTP/2-only server with strict TLS`
- `[gRPC] Client certificate verification is DISABLED (dev mode)`
- `[gRPC] Listings server started on port 50057 (HTTP/2 only)`

### Analytics-Service
- `[gRPC] Starting secure HTTP/2-only server with ALPN = h2`
- `[gRPC] Client certificate verification is DISABLED (dev mode)`

### Shopping-Service
- `[gRPC] Starting secure HTTP/2-only server with strict TLS`
- `[gRPC] Client certificate verification is DISABLED (dev mode)`

### Auction-Monitor
- `[gRPC] Starting secure HTTP/2-only server with ALPN = h2`
- `[gRPC] Client certificate verification is DISABLED (dev mode)`

### Python-AI-Service
- SSL verification warnings (data pipeline, not gRPC)
- No gRPC startup logs visible

---

## Configuration Status

### Caddyfile (Current)
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host {http.request.host}
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

**Status**: ✅ Configuration appears correct
- HTTP/2 enabled (`versions h2`)
- TLS configured correctly
- gRPC headers preserved (`TE: trailers`)
- Path matching works (Caddy routes correctly)

---

## Next Steps

### Immediate Actions

1. **Check Auth-Service Port Configuration**
   - Verify HTTP server is NOT listening on port 50051
   - Check if there's port conflict or misconfiguration
   - Review auth-service startup code

2. **Compare Request Headers**
   - Capture exact headers sent by direct connection
   - Capture exact headers sent by Caddy
   - Identify any differences

3. **Test Other Services**
   - Try records-service or social-service via Caddy
   - See if issue is auth-service specific or global
   - Compare working vs non-working services

4. **Check Auth-Service Code**
   - Review gRPC server startup code
   - Check for any HTTP middleware intercepting gRPC
   - Look for response conversion logic

### Long-term Solutions

1. **Upgrade Caddy** (if issue persists)
   - Current: v2.8.4
   - Latest: v2.10.2
   - May have gRPC handling improvements

2. **Verify Service Architecture**
   - Ensure HTTP and gRPC servers are completely separate
   - Verify no middleware is shared between them
   - Check port binding configuration

---

## Related Files

- `Caddyfile` - Caddy configuration
- `services/auth-service/src/grpc-server.ts` - gRPC server implementation
- `services/auth-service/src/server.ts` - HTTP server implementation
- `test-results/GRPC_ROUTING_403_INVESTIGATION_REPORT.md` - Previous investigation
- `test-results/GRPC_403_RESPONSE_HANDLING_ISSUE.md` - Response handling investigation

---

## Status

**Current**: Issue identified - Auth-service returns HTTP 403 instead of gRPC response when accessed via Caddy  
**Blocking**: All gRPC health checks and testing  
**Workaround**: Use direct port-forward for gRPC testing (bypasses Caddy)  
**Next**: Investigate why auth-service converts gRPC responses to HTTP 403 when accessed via Caddy
