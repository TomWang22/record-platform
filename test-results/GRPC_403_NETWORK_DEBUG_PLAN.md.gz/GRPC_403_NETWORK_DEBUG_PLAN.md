# gRPC 403 - Network Debugging Plan

**Date**: January 4, 2025  
**Status**: 🔧 **SETTING UP** - Network debugging tools  
**Priority**: Critical - Need to see actual network traffic

---

## Objective

Use network debugging tools (tcpdump, netstat, ss) to capture and analyze actual network traffic between:
1. **Direct connection** (works)
2. **Via Caddy** (403)

This will reveal the exact differences at the network level.

---

## Tools Needed

### Required Tools
- `tcpdump` - Capture packets
- `netstat` or `ss` - Check connections
- `kubectl debug` - Add debugging containers (optional)

### Challenges
- Pods may not have these tools installed
- Pods may run as non-root (tcpdump needs root)
- Need to capture traffic inside Kubernetes cluster

---

## Approaches

### Approach 1: Use kubectl debug (Best)

**Method**: Use `kubectl debug` to add ephemeral debug container with tools

**Steps**:
1. Add debug container with tcpdump
2. Share network namespace with auth-service pod
3. Capture traffic on port 50051
4. Make requests (direct and via Caddy)
5. Compare captured traffic

**Command**:
```bash
kubectl debug auth-service-pod -it --image=nicolaka/netshoot --share-processes --copy-to=auth-service-debug
```

### Approach 2: Install Tools in Pod (If Possible)

**Method**: Install tcpdump in existing pod (requires root)

**Steps**:
1. Exec into pod
2. Install tcpdump (if package manager available)
3. Run tcpdump
4. Make requests
5. Analyze output

**Limitation**: Pods typically run as non-root

### Approach 3: Use /proc/net/tcp (Simple but Limited)

**Method**: Read `/proc/net/tcp` directly (no tools needed)

**Steps**:
1. Check connections before request
2. Make request
3. Check connections after request
4. Compare connection states

**Limitation**: Limited information, but works without tools

### Approach 4: Node.js Debug Logging

**Method**: Enable Node.js/gRPC debug logging

**Environment Variables**:
- `NODE_DEBUG=http2` - HTTP/2 debug logging
- `GRPC_VERBOSITY=DEBUG` - gRPC verbose logging
- `GRPC_TRACE=all` - gRPC trace logging

**Steps**:
1. Add debug env vars to deployment
2. Restart pod
3. Make requests
4. Check logs for connection details

### Approach 5: Sidecar Debug Container

**Method**: Add debug sidecar to deployment

**Steps**:
1. Create debug sidecar container
2. Share network namespace
3. Run tcpdump in sidecar
4. Capture traffic

**Limitation**: Requires deployment modification

---

## Recommended Approach

Start with **Approach 3** (check /proc/net/tcp) as it's simplest and works immediately.

Then try **Approach 4** (Node.js debug logging) to get more details from the application level.

If needed, use **Approach 1** (kubectl debug) for full packet capture.

---

## What to Look For

### Network-Level Differences
1. **Connection establishment**: TLS handshake differences
2. **HTTP/2 negotiation**: ALPN protocol selection
3. **HTTP/2 frames**: Frame types and order
4. **Headers**: Exact header format and values
5. **Request path**: Path encoding and format

### Connection States
- Direct: Connection state, peer address
- Via Caddy: Connection state, peer address (should be Caddy's IP)

### HTTP/2 Details
- ALPN negotiation: Should be `h2` (HTTP/2)
- HTTP/2 settings: Connection settings
- Frame types: HEADERS, DATA, etc.

---

## Next Steps

1. ✅ Check available tools in pods
2. ⏳ Try /proc/net/tcp approach
3. ⏳ Try Node.js debug logging
4. ⏳ Try kubectl debug if needed
5. ⏳ Compare network traffic between direct and via Caddy
6. ⏳ Identify exact differences
7. ⏳ Fix the issue

---

## Related Files

- `test-results/GRPC_403_DEEP_DIVE.md` - Deep dive analysis
- `test-results/GRPC_403_CRITICAL_FINDING.md` - Critical findings
- `services/auth-service/src/grpc-server.ts` - gRPC server code
