# gRPC 403 - No Handler Logs Finding

**Date**: January 4, 2025  
**Status**: 🔍 **CRITICAL FINDING** - 403 occurs before handler  
**Priority**: Critical - 403 is not from gRPC handler

---

## Critical Finding

### Observation

✅ **Enhanced Logging**: Code is in the file (`services/auth-service/src/grpc-server.ts`)  
✅ **HealthCheck Wrapped**: `HealthCheck: withLogging(authService.HealthCheck, "HealthCheck")` (line 612)  
✅ **Request Made**: `grpcurl` makes request via Caddy  
❌ **Result**: 403 Forbidden  
❌ **NO LOGS**: No `[gRPC] HealthCheck called` logs appear!

### What This Means

**Critical Insight**: If requests were reaching the gRPC handler, we would see enhanced logging. Since we see NO logs, requests are NOT reaching the handler.

**Conclusion**: The 403 is generated BEFORE the gRPC handler receives the request.

---

## Where Could 403 Come From?

### 1. Caddy (Most Likely)

**Theory**: Caddy is rejecting the request before forwarding to auth-service.

**Evidence**:
- 403 comes from Caddy
- No logs from auth-service
- Request doesn't reach handler

**Possible Causes**:
- Routing rule mismatch
- TLS/authentication failure
- Host header mismatch
- Path matching issue

### 2. TLS Layer

**Theory**: TLS handshake or certificate validation fails.

**Evidence**:
- TLS is required (strict TLS)
- Client certificates are sent
- Certificate validation might fail

**Possible Causes**:
- Certificate mismatch
- SNI mismatch
- TLS version mismatch
- Certificate chain issue

### 3. Network Policy

**Theory**: Kubernetes network policy blocks the connection.

**Evidence**:
- Network policies exist
- Pods are in different namespaces
- Connection might be blocked

**Possible Causes**:
- Network policy rules
- Namespace isolation
- Service mesh policy

### 4. gRPC Server Startup Issue

**Theory**: gRPC server isn't fully ready or listening.

**Evidence**:
- Server logs show "Server started"
- But requests might not reach handler
- Server might not be fully initialized

**Possible Causes**:
- Server not fully started
- Port not listening
- Handler not registered

---

## Next Steps

### Step 1: Verify Request Reaches Auth-Service

**Test**: Make direct request to auth-service (bypass Caddy)

**Command**:
```bash
# Port-forward to auth-service
kubectl -n record-platform port-forward svc/auth-service 50051:50051

# Make direct request
grpcurl -insecure -H "Content-Type: application/grpc" -H "TE: trailers" \
  -import-path ./proto -proto ./proto/auth.proto \
  localhost:50051 auth.AuthService/HealthCheck
```

**Expected**:
- If direct works: Caddy is the issue
- If direct fails: Auth-service is the issue

### Step 2: Check Caddy Logs

**Look For**:
- Request routing logs
- TLS handshake logs
- Upstream connection logs
- 403 generation logs

**Expected**:
- Caddy logs should show where 403 is generated
- Compare with auth-service logs (should be empty)

### Step 3: Check Network Connectivity

**Test**: Verify Caddy can connect to auth-service

**Command**:
```bash
# From Caddy pod
kubectl -n ingress-nginx exec -it <caddy-pod> -- sh
# Inside pod
nc -zv auth-service.record-platform.svc.cluster.local 50051
```

**Expected**:
- Connection should succeed
- If fails: Network issue

### Step 4: Check TLS Configuration

**Verify**:
- Caddy's TLS config for upstream
- Auth-service's TLS certificates
- Certificate validation settings

**Expected**:
- TLS config should match
- Certificates should be valid
- SNI should match

---

## Related Files

- `services/auth-service/src/grpc-server.ts` - Enhanced logging code (line 612)
- `Caddyfile` - Caddy routing configuration
- `test-results/GRPC_403_ROOT_CAUSE_INVESTIGATION.md` - Investigation notes
