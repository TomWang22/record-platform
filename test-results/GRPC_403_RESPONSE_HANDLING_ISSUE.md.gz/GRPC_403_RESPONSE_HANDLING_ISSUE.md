# gRPC 403 Response Handling Issue

**Date**: January 3, 2025  
**Issue**: gRPC requests return 403 Forbidden via Caddy, but auth-service processes them successfully  
**Status**: 🔴 **INVESTIGATION IN PROGRESS**  
**Priority**: High - Blocks gRPC health checks

---

## Executive Summary

gRPC health checks via Caddy NodePort (30443) return `403 Forbidden` with `text/plain` content-type. However, investigation reveals:

1. ✅ **Caddy routes correctly** - Debug logs show "selected upstream: auth-service:50051"
2. ✅ **Auth-service processes successfully** - Logs show "[gRPC] HealthCheck completed in 31ms"
3. ❌ **Caddy receives 403** - Upstream roundtrip shows "status": 403, "headers": {"Content-Type": ["text/plain"]}
4. ✅ **Direct connection works** - Port-forward directly to auth-service:50051 succeeds

**Conclusion**: This is NOT a routing issue. Auth-service is successfully processing requests and returning responses, but Caddy is receiving 403. This suggests a **response handling/format issue** between Caddy and auth-service.

---

## Evidence

### Caddy Debug Logs
```
2026/01/04 22:33:42.554 DEBUG   http.handlers.reverse_proxy     selected upstream
  {"dial": "auth-service.record-platform.svc.cluster.local:50051", "total_upstreams": 1}

2026/01/04 22:33:42.655 DEBUG   http.handlers.reverse_proxy     upstream roundtrip
  {"upstream": "auth-service.record-platform.svc.cluster.local:50051", "duration": 0.098607083,
   "request": {"uri": "/auth.AuthService/HealthCheck", ...},
   "headers": {"Content-Type": ["text/plain"]}, "status": 403}
```

### Auth-Service Logs
```
[gRPC] HealthCheck called
[gRPC] HealthCheck completed in 31ms
```

### Direct Connection Test
```bash
# Direct port-forward (WORKS)
kubectl port-forward pod/auth-service-xxx 50051:50051
grpcurl -cacert=/tmp/grpc-certs/ca.crt ... 127.0.0.1:50051 auth.AuthService/HealthCheck
# Result: ✅ Success (returns healthy status)

# Via Caddy (FAILS)
grpcurl -cacert=/tmp/grpc-certs/ca.crt ... 127.0.0.1:30443 auth.AuthService/HealthCheck
# Result: ❌ 403 Forbidden (text/plain)
```

---

## Key Findings

1. **Services don't require client certificates**
   - `GRPC_REQUIRE_CLIENT_CERT` is not set
   - `requireClientCert = false` in auth-service code
   - Client certificate configuration in Caddy is unnecessary

2. **Certificate configuration is correct**
   - Auth-service certificate: `CN=record.local, DNS:record.local`
   - Caddy config: `tls_server_name record.local` ✅

3. **Path matching works**
   - Pattern: `^/?auth\.` matches `/auth.AuthService/HealthCheck` ✅
   - Handler order is correct (gRPC handlers before catch-all) ✅

4. **Request reaches auth-service**
   - Caddy debug logs confirm upstream selection ✅
   - Auth-service logs confirm request processing ✅

5. **Response format issue**
   - Auth-service completes successfully (logs show completion)
   - But Caddy receives 403 with text/plain
   - This suggests Caddy is not properly handling the gRPC response

---

## Configuration

### Current Caddyfile (gRPC handler)
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host {http.request.host}
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

### Attempted Fixes (All Failed)

1. ❌ Added client certificates (`tls_client_cert_file`, `tls_client_key_file`)
   - **Result**: Caddy accepted config but 403 persisted
   - **Reason**: Services don't require client certs

2. ❌ Changed to `tls_client_auth { certificates { ... } }`
   - **Result**: Syntax error - invalid Caddyfile syntax

3. ❌ Changed `tls_server_name` to service hostname
   - **Result**: Certificate mismatch (cert is for `record.local`, not service hostname)

4. ❌ Changed `header_up Host` to service hostname
   - **Result**: 403 persisted (not actually applied due to search_replace error)

---

## Hypothesis

### Hypothesis 1: Caddy gRPC Response Handling Bug
**Theory**: Caddy v2.8.4 has a bug in handling gRPC responses over HTTP/2 with TLS.

**Evidence**:
- Request reaches backend ✅
- Backend processes successfully ✅
- But Caddy receives 403 instead of gRPC response ❌
- Direct connection works (bypasses Caddy) ✅

**Test**: Check Caddy version and known issues

### Hypothesis 2: HTTP/2 vs gRPC Protocol Mismatch
**Theory**: Caddy is not properly preserving gRPC response format over HTTP/2.

**Evidence**:
- Config uses `versions h2` (HTTP/2) ✅
- But response shows `text/plain` (HTTP error format) ❌
- gRPC should use `application/grpc` content-type ✅

**Test**: Try different transport configuration

### Hypothesis 3: TLS Handshake Issue
**Theory**: TLS handshake between Caddy and auth-service fails, causing auth-service to return HTTP error instead of gRPC response.

**Evidence**:
- TLS configuration appears correct ✅
- But 403 with text/plain suggests HTTP error, not gRPC error ❌
- Direct connection works with same certs ✅

**Test**: Check TLS handshake logs on auth-service side

### Hypothesis 4: Response Interception
**Theory**: Some middleware or proxy between Caddy and auth-service is intercepting the response and returning 403.

**Evidence**:
- Direct connection works ✅
- But via Caddy it fails ❌
- Caddy connects directly to service (no intermediate proxy) ✅

**Test**: Check for service mesh or ingress controllers

---

## Next Steps

1. **Check auth-service TLS/gRPC server logs** for any errors or warnings
2. **Compare request/response headers** between direct connection and Caddy connection
3. **Test with a simpler gRPC service** to see if issue is service-specific
4. **Check Caddy version and known issues** related to gRPC response handling
5. **Try different Caddy transport configurations** (e.g., remove `tls_server_name`, try different HTTP versions)
6. **Check if auth-service HTTP server is intercepting** (though port 50051 should be gRPC-only)

---

## Related Files

- `Caddyfile` - Caddy configuration
- `services/auth-service/src/grpc-server.ts` - gRPC server implementation
- `test-results/GRPC_ROUTING_403_INVESTIGATION_REPORT.md` - Previous investigation

---

## Status

**Current**: Investigation ongoing - identified that issue is in response handling, not routing  
**Blocking**: gRPC health checks cannot be performed via Caddy  
**Workaround**: Use direct port-forward for gRPC testing (bypasses Caddy)
