# gRPC 403 - Root Cause Found

**Date**: January 4, 2025  
**Status**: 🎯 **ROOT CAUSE IDENTIFIED** - Issue is in Caddy TLS/upstream configuration  
**Priority**: Critical - Fix Caddy configuration

---

## 🎯 Critical Finding

### Direct Connection Test: SUCCESS ✅

**Test**: Direct connection to auth-service (bypass Caddy)

**Command**:
```bash
kubectl -n record-platform port-forward svc/auth-service 50051:50051
grpcurl -insecure localhost:50051 auth.AuthService/HealthCheck
```

**Result**: ✅ **SUCCESS**
```json
{
  "healthy": true,
  "version": "1.0.0"
}
```

### Via Caddy: FAILURE ❌

**Test**: Connection via Caddy (normal path)

**Command**:
```bash
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  127.0.0.1:30443 auth.AuthService/HealthCheck
```

**Result**: ❌ **403 Forbidden** (text/plain)

---

## 📊 Conclusion

**Root Cause**: Issue is in **Caddy or Caddy->auth-service connection**, NOT in auth-service itself!

### What Works ✅

- ✅ Auth-service gRPC handler works correctly
- ✅ Auth-service gRPC server is listening correctly
- ✅ Direct connection returns proper gRPC response
- ✅ gRPC protocol works

### What Fails ❌

- ❌ Via Caddy: Returns HTTP 403 with text/plain
- ❌ Caddy->auth-service connection/response handling
- ❌ TLS/HTTP/2 between Caddy and auth-service

---

## 🔍 Key Difference

### Direct Connection (Works)

- **Protocol**: Insecure (no TLS)
- **Method**: Direct gRPC connection
- **Result**: ✅ Proper gRPC response

### Via Caddy (Fails)

- **Protocol**: HTTPS (TLS)
- **Method**: Caddy reverse_proxy with TLS
- **Result**: ❌ HTTP 403 (text/plain)

**Key Difference**: **TLS!**

---

## 🎯 Root Cause Hypotheses

### Hypothesis 1: Caddy TLS Configuration Issue

**Theory**: Caddy's TLS configuration for upstream connection is incorrect.

**Evidence**:
- Direct (no TLS): Works
- Via Caddy (TLS): Fails
- Caddy uses TLS for upstream connection

**Possible Issues**:
- `tls_server_name` doesn't match auth-service certificate
- `tls_trusted_ca_certs` path incorrect
- Certificate validation fails
- TLS version mismatch

### Hypothesis 2: Caddy HTTP/2 Configuration Issue

**Theory**: Caddy's HTTP/2 configuration for upstream connection is incorrect.

**Evidence**:
- Direct (HTTP/2): Works
- Via Caddy (HTTP/2): Fails
- gRPC requires HTTP/2

**Possible Issues**:
- HTTP/2 not enabled for upstream
- HTTP/2 version mismatch
- HTTP/2 connection handling issue

### Hypothesis 3: Caddy Response Conversion Issue

**Theory**: Caddy converts gRPC response to HTTP 403.

**Evidence**:
- Caddy receives response from auth-service
- But returns HTTP 403 (text/plain)
- Caddy logs show "upstream roundtrip" with status 403

**Possible Issues**:
- Caddy doesn't recognize gRPC response
- Caddy converts response incorrectly
- Caddy routing issue

### Hypothesis 4: Certificate Mismatch

**Theory**: Auth-service certificate doesn't match what Caddy expects.

**Evidence**:
- Direct (no TLS): Works
- Via Caddy (TLS): Fails
- TLS handshake might fail

**Possible Issues**:
- Certificate subject doesn't match `tls_server_name`
- Certificate chain incomplete
- Certificate validation fails

---

## 🔧 Next Steps

### Step 1: Check Caddy TLS Configuration

**Verify**:
- `tls_server_name` in Caddyfile matches auth-service certificate subject
- `tls_trusted_ca_certs` path is correct
- Certificate files are mounted correctly

**Check**:
```bash
# Check Caddyfile TLS config
grep -A 15 "@grpc_auth" Caddyfile | grep -A 12 "reverse_proxy" | grep -i tls

# Check auth-service certificate subject
kubectl -n record-platform exec auth-service-pod -- \
  openssl x509 -in /etc/certs/tls.crt -noout -subject
```

### Step 2: Check Caddy Logs

**Look For**:
- TLS handshake errors
- Certificate validation errors
- Upstream connection errors
- Response conversion logs

**Command**:
```bash
kubectl -n ingress-nginx logs -l app=caddy-h3 --tail=100 | \
  grep -i "auth-service\|tls\|certificate\|403"
```

### Step 3: Test with TLS Directly

**Test**: Direct connection with TLS (not via Caddy)

**Command**:
```bash
# Port-forward with TLS
kubectl -n record-platform port-forward svc/auth-service 50051:50051

# Make TLS request
grpcurl -cacert=/path/to/ca.crt \
  -cert=/path/to/client.crt \
  -key=/path/to/client.key \
  -servername=record.local \
  localhost:50051 auth.AuthService/HealthCheck
```

**Expected**:
- If TLS direct works: Caddy configuration issue
- If TLS direct fails: Auth-service TLS configuration issue

### Step 4: Compare Caddy Configuration

**Compare**:
- Caddyfile TLS settings for gRPC vs HTTP
- TLS settings for different services
- Certificate paths and validation

**Check**:
- Are TLS settings correct for gRPC upstream?
- Are certificates mounted correctly?
- Is certificate validation too strict?

---

## 📝 Related Files

- `Caddyfile` - Caddy configuration (check TLS settings for `@grpc_auth`)
- `test-results/GRPC_403_DIRECT_CONNECTION_TEST.md` - Direct connection test results
- `test-results/GRPC_403_NO_HANDLER_LOGS.md` - No handler logs finding
- `services/auth-service/src/grpc-server.ts` - gRPC server (works correctly)

---

## ✅ Verification

**Direct Connection**: ✅ Works  
**Auth-Service**: ✅ Works  
**Root Cause**: ❌ Caddy configuration/connection

**Next**: Fix Caddy TLS/upstream configuration
