# gRPC 403 - Root Cause Investigation

**Date**: January 4, 2025  
**Status**: 🔬 **INVESTIGATING** - Enhanced logging deployed, analyzing logs  
**Priority**: Critical - Identify root cause of response conversion

---

## Investigation Summary

### Deployment Status

✅ **Docker Build**: Fixed (build from root context)  
✅ **Proto Files**: Verified and included  
✅ **Enhanced Logging**: Deployed  
✅ **Image**: Loaded to Kind cluster `h3`  
✅ **Pods**: Recreated with new image  
⏳ **Pods Status**: Starting up (need to be ready for testing)

---

## Key Finding: The Contradiction

### From Previous Logs (Before Enhanced Logging)

**Auth-Service Logs**:
```
[gRPC] HealthCheck called
[gRPC] HealthCheck completed in 64ms
```

**Caddy Response**:
```
Status: 403 Forbidden
Content-Type: text/plain
```

### What This Means

**Critical Insight**:
- ✅ Auth-service **receives** the request
- ✅ Auth-service **processes** it successfully  
- ✅ Auth-service **completes** the request
- ❌ But Caddy receives **403 with text/plain** (not gRPC response)

**Conclusion**: This is **NOT** a request rejection issue. This is a **response conversion issue**.

---

## Root Cause Hypotheses

### Hypothesis 1: Response Conversion by Node.js gRPC Library

**Theory**: Node.js gRPC library (`@grpc/grpc-js`) converts successful gRPC responses to HTTP 403 when connection issues occur.

**Evidence**:
- Auth-service logs show success
- Caddy receives HTTP 403 (not gRPC status)
- Response is text/plain (HTTP format, not gRPC)

**How to Test**:
- Check if there are connection errors in auth-service logs
- Check if gRPC library logs any errors
- Compare successful direct connection vs Caddy connection

### Hypothesis 2: HTTP Server Intercepting

**Theory**: Express HTTP server (port 4001) might be intercepting gRPC requests on port 50051.

**Evidence Against**:
- HTTP server listens on port 4001
- gRPC server listens on port 50051
- Different ports, should be separate

**But**: Could there be port forwarding or interception?

### Hypothesis 3: TLS/HTTP/2 Connection Issue

**Theory**: TLS handshake or HTTP/2 connection succeeds for request, but fails during response transmission, causing gRPC library to convert response to HTTP 403.

**Evidence**:
- Direct connection works (bypasses Caddy)
- Via Caddy fails (two-hop connection)
- TLS is configured correctly
- HTTP/2 is enabled

**How to Test**:
- Check TLS connection status in logs
- Check HTTP/2 connection details
- Compare connection setup between direct and Caddy

### Hypothesis 4: Response Format Issue

**Theory**: Auth-service generates response in wrong format, or callback is called incorrectly, causing gRPC library to convert to HTTP 403.

**Evidence**:
- Auth-service logs show `callback(null, {...})`
- But Caddy receives HTTP 403
- Response format might be wrong

**How to Test**:
- Check callback usage in code
- Verify response format
- Check for any response transformation

---

## What Enhanced Logging Will Reveal

### Expected Enhanced Logs

```javascript
[gRPC] HealthCheck called {
  peer: 'ipv4:10.244.x.x:xxxxx',
  host: 'auth-service.record-platform.svc.cluster.local:50051',
  metadata: {
    'content-type': 'application/grpc',
    'te': 'trailers',
    'grpc-timeout': '...',
    'host': 'record.local',
    ...
  },
  timestamp: '2025-01-04T23:55:00.000Z'
}
[gRPC] HealthCheck completed in 31ms
```

### What to Look For

1. **Request Reception**: Does auth-service receive the request?
   - Look for `[gRPC] HealthCheck called` with metadata

2. **Connection Details**: What does auth-service see?
   - Peer IP (should be Caddy's IP)
   - Host header (what Caddy sends)
   - Metadata (all headers)

3. **Response Generation**: Does auth-service generate response?
   - Look for `[gRPC] HealthCheck completed`
   - Check if callback is called

4. **Error Sources**: Any errors in logs?
   - Connection errors
   - TLS errors
   - Response errors

---

## Analysis Plan

### Step 1: Verify Enhanced Logging is Active

- Check if new pods have enhanced logging
- Verify logs show metadata, peer, host
- Confirm enhanced logging is working

### Step 2: Make Test Request

- Make gRPC request via Caddy
- Capture enhanced logs from auth-service
- Capture logs from Caddy

### Step 3: Compare Logs

- Compare timestamps (match request/response)
- Compare metadata (what auth-service receives)
- Compare connection details (peer, host)
- Identify any errors

### Step 4: Identify Conversion Point

- If auth-service processes successfully
- But Caddy receives 403
- Find where conversion happens
- Check response format
- Check connection state

### Step 5: Root Cause

- Identify exact cause
- Implement fix
- Verify fix works

---

## Current Status

- ✅ Enhanced logging deployed
- ⏳ Pods starting (need to be ready)
- ⏳ Need to make test request with ready pods
- ⏳ Need to analyze enhanced logs
- ⏳ Need to identify root cause

---

## Related Files

- `test-results/GRPC_403_KEY_FINDING.md` - The contradiction finding
- `test-results/GRPC_403_STEP_5_LOGGING.md` - Enhanced logging implementation
- `test-results/GRPC_403_DOCKER_BUILD_FIX.md` - Docker build fix
- `services/auth-service/src/grpc-server.ts` - Enhanced logging code
