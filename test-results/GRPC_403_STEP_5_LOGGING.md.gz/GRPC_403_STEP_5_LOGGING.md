# gRPC 403 - Step 5: Detailed Logging Implementation

**Date**: January 4, 2025  
**Status**: ✅ **IMPLEMENTED** - Enhanced logging added to auth-service  
**Priority**: Critical - Needed to trace request/response flow

---

## Step 5: Add More Detailed Logging

### Hypothesis

Need more detailed logs to trace the exact request/response flow and identify where the 403 is generated.

### Implementation

**Enhanced gRPC Logging Middleware** (`services/auth-service/src/grpc-server.ts`):

```typescript
// Before
function withLogging(handler: any, methodName: string) {
  return async (call: any, callback: any) => {
    const start = Date.now();
    console.log(`[gRPC] ${methodName} called`);
    // ...
  };
}

// After - Added detailed request metadata logging
function withLogging(handler: any, methodName: string) {
  return async (call: any, callback: any) => {
    const start = Date.now();
    
    // Log request metadata and connection details
    try {
      const metadata = call.metadata?.getMap() || {};
      const peer = call.getPeer?.() || 'unknown';
      const host = call.host || 'unknown';
      console.log(`[gRPC] ${methodName} called`, {
        peer,
        host,
        metadata: Object.keys(metadata).length > 0 ? metadata : 'none',
        timestamp: new Date().toISOString()
      });
    } catch (metaErr: any) {
      console.log(`[gRPC] ${methodName} called (metadata unavailable)`, {
        error: metaErr.message
      });
    }
    
    // ... rest of handler
  };
}
```

**Enhanced Server Startup Logging**:

```typescript
server.bindAsync(
  `0.0.0.0:${port}`,
  credentials,
  (error, actualPort) => {
    if (error) {
      console.error("[gRPC] Server bind error:", error);
      return;
    }
    server.start();
    console.log(`[gRPC] Server started on port ${actualPort} (HTTP/2 only, no HTTP/1.1 fallback)`);
    console.log(`[gRPC] Server listening on 0.0.0.0:${actualPort}`);
    console.log(`[gRPC] TLS enabled: ${credentials !== null}`);
    console.log(`[gRPC] Ready to accept connections`);
  }
);
```

### What We'll Log

1. **Request Metadata**: Headers, authentication info, custom metadata
2. **Connection Peer**: Client IP address and port
3. **Connection Host**: Hostname/address
4. **Timestamp**: Request time for correlation
5. **Server Status**: TLS status, binding confirmation

### Current Caddy Logging

**Already Enabled**:
- Log level: `DEBUG` ✅
- Output: `stdout`
- Format: `console`

**What Caddy Logs**:
- Request routing decisions
- Upstream connection attempts
- Response status codes
- Roundtrip timing
- HTTP/2 connection details

### Next Steps

1. **Rebuild auth-service**:
   ```bash
   cd services/auth-service
   npm run build
   ```

2. **Rebuild Docker image**:
   ```bash
   docker build -t auth-service:latest services/auth-service
   ```

3. **Load image to Kind cluster**:
   ```bash
   kind load docker-image auth-service:latest
   ```

4. **Restart auth-service deployment**:
   ```bash
   kubectl -n record-platform rollout restart deployment/auth-service
   ```

5. **Make test gRPC request via Caddy**

6. **Capture logs from both Caddy and auth-service**:
   ```bash
   # Caddy logs
   kubectl -n ingress-nginx logs -f deployment/caddy-h3 | grep -i "grpc\|auth\|403"
   
   # Auth-service logs
   kubectl -n record-platform logs -f deployment/auth-service | grep -i "grpc\|healthcheck"
   ```

7. **Analyze logs** to identify:
   - Where the 403 is generated
   - What request headers/metadata are received
   - Connection details (peer, host)
   - Response flow

### Expected Log Output

**Auth-Service** (with enhanced logging):
```
[gRPC] Server started on port 50051 (HTTP/2 only, no HTTP/1.1 fallback)
[gRPC] Server listening on 0.0.0.0:50051
[gRPC] TLS enabled: true
[gRPC] Ready to accept connections
[gRPC] HealthCheck called {
  peer: 'ipv4:10.244.x.x:xxxxx',
  host: 'auth-service.record-platform.svc.cluster.local:50051',
  metadata: { 'content-type': 'application/grpc', 'te': 'trailers', ... },
  timestamp: '2025-01-04T23:55:00.000Z'
}
[gRPC] HealthCheck completed in 31ms
```

**Caddy** (already logging):
```
DEBUG http.handlers.reverse_proxy upstream roundtrip {
  "upstream": "auth-service.record-platform.svc.cluster.local:50051",
  "duration": 0.021384292,
  "request": {
    "uri": "/auth.AuthService/HealthCheck",
    "headers": {"Content-Type": ["application/grpc"], ...}
  },
  "headers": {"Content-Type": ["text/plain"]},
  "status": 403
}
```

### Analysis Plan

Once we have detailed logs, we'll look for:

1. **Request Reception**: Does auth-service receive the request?
   - Look for `[gRPC] HealthCheck called` log
   - Check metadata/headers received

2. **Connection Details**: What peer/host does auth-service see?
   - Is peer from Caddy's IP?
   - Is host header correct?

3. **Response Generation**: Does auth-service generate a response?
   - Look for `[gRPC] HealthCheck completed` log
   - Check if callback is called

4. **Response Transformation**: Where does the response become 403?
   - Compare Caddy logs (403) with auth-service logs (success)
   - Identify transformation point

5. **Error Sources**: Any errors in logs?
   - Connection errors
   - TLS handshake errors
   - Metadata errors

### Status

- ✅ Enhanced logging code added
- ⏳ Need to rebuild and deploy
- ⏳ Need to test and capture logs
- ⏳ Need to analyze results

---

## Related Files

- `services/auth-service/src/grpc-server.ts` - Enhanced with detailed logging
- `test-results/GRPC_403_STEP_BY_STEP_RESULTS.md` - Steps 1-4 results
- `test-results/GRPC_403_STEP_BY_STEP_INVESTIGATION.md` - Investigation plan
