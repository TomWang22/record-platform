# gRPC 403 - Step-by-Step Investigation

**Date**: January 4, 2025  
**Status**: 🔬 **IN PROGRESS** - Testing hypotheses step by step  
**Priority**: Critical - Blocks all gRPC traffic through Caddy

---

## Investigation Plan

Testing 5 hypotheses step by step:

1. **Remove Host Header Entirely** - Let Caddy set it automatically
2. **Check TLS SNI vs Host Header Mismatch** - Verify SNI configuration
3. **Investigate HTTP/2 Connection Setup** - Compare direct vs Caddy connections
4. **Check Node.js gRPC Library Version/Issues** - Verify library compatibility
5. **Add More Detailed Logging** - Trace exact request/response flow

---

## Step 1: Remove Host Header Entirely

### Hypothesis

**Theory**: Maybe the Host header shouldn't be set at all. Caddy should set it automatically based on the upstream target.

**Test**: Remove `header_up Host` entirely from gRPC handlers.

### Implementation

**Changed** (auth-service only for initial test):
```diff
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
-   header_up Host auth-service.record-platform.svc.cluster.local:50051
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    ...
  }
}
```

**Status**: ⏳ Testing...

---

## Step 2: Check TLS SNI vs Host Header Mismatch

### Hypothesis

**Theory**: TLS SNI uses `record.local` but services might expect different hostname in Host header or SNI.

**Test**: Verify SNI configuration matches certificate and service expectations.

---

## Step 3: Investigate HTTP/2 Connection Setup

### Hypothesis

**Theory**: Caddy's HTTP/2 connection to services might not be properly configured, causing auth-service to reject it.

**Test**: Compare HTTP/2 connection setup between direct and Caddy connections.

---

## Step 4: Check Node.js gRPC Library Version/Issues

### Hypothesis

**Theory**: Node.js gRPC server (`@grpc/grpc-js`) might have specific requirements or bugs with reverse proxies.

**Test**: Check Node.js gRPC library version, known issues, or alternative configurations.

---

## Step 5: Add More Detailed Logging

### Hypothesis

**Theory**: Need more detailed logs to trace the exact request/response flow and identify where the 403 is generated.

**Test**: Add detailed logging to both Caddy and auth-service to trace request/response flow.

---

## Status

- ⏳ Step 1: Remove Host Header - Testing...
- ⏳ Step 2: TLS SNI mismatch - Pending
- ⏳ Step 3: HTTP/2 connection - Pending
- ⏳ Step 4: Node.js gRPC library - Pending
- ⏳ Step 5: Detailed logging - Pending

---

## Related Files

- `Caddyfile` - Caddy configuration (updated for Step 1)
- `test-results/GRPC_403_HOST_HEADER_TEST_RESULT.md` - Previous test results
- `test-results/GRPC_403_INVESTIGATION_COMPLETE.md` - Full investigation report
