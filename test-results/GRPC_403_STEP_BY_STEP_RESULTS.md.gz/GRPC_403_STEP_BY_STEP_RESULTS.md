# gRPC 403 - Step-by-Step Investigation Results

**Date**: January 4, 2025  
**Status**: 🔬 **IN PROGRESS** - Steps 1-4 tested, Step 5 (detailed logging) next  
**Priority**: Critical - Blocks all gRPC traffic through Caddy

---

## Summary

Testing 5 hypotheses step by step. Steps 1-4 tested, all failed to fix the issue. Next: Add more detailed logging (Step 5) to trace the exact request/response flow.

---

## Step 1: Remove Host Header Entirely ❌

### Hypothesis
Remove `header_up Host` and let Caddy set it automatically.

### Implementation
**Changed** (auth-service only for initial test):
```diff
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
-   header_up Host auth-service.record-platform.svc.cluster.local:50051
    header_up TE trailers
    ...
  }
}
```

### Test Result
**Command**:
```bash
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
        -cert=/tmp/grpc-certs/tls.crt \
        -key=/tmp/grpc-certs/tls.key \
        -servername=record.local \
        -H "Host: record.local" \
        "127.0.0.1:30443" \
        "auth.AuthService/HealthCheck"
```

**Result**: ❌ **Still 403 Forbidden** with `text/plain`

**Conclusion**: Host header is NOT the root cause.

---

## Step 2: TLS SNI vs Host Header Mismatch ⚠️

### Hypothesis
Services might reject connections if SNI doesn't match expectations.

### Configuration Check
- **Caddy config**: `tls_server_name record.local`
- **Certificate CN**: `record.local`
- **Certificate Issuer**: `dev-root.local`

### Analysis
**Current Setup**:
- TLS SNI: `record.local` ✅
- Certificate CN: `record.local` ✅
- Certificate issuer: `dev-root.local` ✅
- CA cert mounted: `/etc/caddy/ca/dev-root.pem` ✅

**Status**: Configuration looks correct. SNI matches certificate.

**Conclusion**: TLS SNI configuration appears correct. Not likely the root cause, but cannot rule out completely without deeper testing.

---

## Step 3: HTTP/2 Connection Setup ⚠️

### Hypothesis
Caddy's HTTP/2 connection to services might not be properly configured.

### Current Configuration
```caddyfile
transport http {
  versions h2
  tls
  tls_server_name record.local
  tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
}
```

### Analysis
- HTTP/2 enabled: ✅ (`versions h2`)
- TLS enabled: ✅
- Direct connection works (also HTTP/2 with TLS)
- Caddy connection fails

**Key Difference**: 
- Direct: Client → Service (direct connection)
- Caddy: Client → Caddy → Service (two-hop connection)

**Conclusion**: Need deeper investigation. HTTP/2 connection setup looks correct, but there might be subtle differences in how Caddy establishes the connection vs direct client.

---

## Step 4: Node.js gRPC Library Version/Issues ⚠️

### Hypothesis
Node.js gRPC library (`@grpc/grpc-js`) might have specific requirements or bugs with reverse proxies.

### Version Information
- **@grpc/grpc-js**: `^1.9.0`
- **Node.js**: `v20.19.6`
- **@grpc/proto-loader**: `^0.7.10`

### Analysis
- Using relatively recent version of `@grpc/grpc-js` (1.9.0)
- Node.js v20.19.6 is current LTS
- Library is actively maintained

**Known Issues**: Need to check for known issues with reverse proxies, but version looks reasonable.

**Conclusion**: Version looks current. Need to investigate known issues with reverse proxies or specific configurations.

---

## Step 5: Add More Detailed Logging ⏳

### Hypothesis
Need more detailed logs to trace the exact request/response flow and identify where the 403 is generated.

### Current Logging
**Caddy**:
- Log level: `DEBUG` ✅
- Output: `stdout`
- Format: `console`

**Auth-Service**:
- Basic logging: `[gRPC] {methodName} called` / `completed`
- Error logging: `[gRPC] {methodName} failed`
- No request/response header logging
- No connection details logging

### Next Steps
1. Add request header logging to auth-service gRPC server
2. Add response logging to auth-service
3. Add connection details logging
4. Capture full request/response cycle in Caddy logs

**Status**: ⏳ **Pending** - Need to implement

---

## Overall Findings

### What We Know
1. ✅ Caddy routing works (correct upstream selected)
2. ✅ Auth-service processes request (logs show completion)
3. ❌ Caddy receives 403 with `text/plain` instead of gRPC response
4. ✅ Direct connection works perfectly
5. ❌ Host header changes don't fix it
6. ⚠️ TLS SNI config looks correct
7. ⚠️ HTTP/2 config looks correct
8. ⚠️ Node.js gRPC library version looks reasonable

### What We Don't Know
1. ❓ Where exactly is the 403 generated?
2. ❓ Why is response `text/plain` instead of gRPC format?
3. ❓ What's different between direct and Caddy connections?
4. ❓ Are there any request/response headers being modified?
5. ❓ Is there any middleware/interceptor causing this?

### Next Actions
1. **Step 5**: Add detailed logging to trace request/response flow
2. **Alternative**: Investigate if there's an HTTP server intercepting gRPC requests
3. **Alternative**: Check if there are any request/response transformers
4. **Alternative**: Test with different gRPC services to see if issue is auth-service specific

---

## Status

- ❌ Step 1: Remove Host Header - **FAILED** (still 403)
- ⚠️ Step 2: TLS SNI - **Config looks correct** (not likely cause)
- ⚠️ Step 3: HTTP/2 Connection - **Config looks correct** (need deeper investigation)
- ⚠️ Step 4: Node.js gRPC Library - **Version looks reasonable** (need to check known issues)
- ⏳ Step 5: Detailed Logging - **PENDING** (next step)

---

## Related Files

- `Caddyfile` - Updated for Step 1 (Host header removed)
- `test-results/GRPC_403_STEP_BY_STEP_INVESTIGATION.md` - Investigation plan
- `test-results/GRPC_403_HOST_HEADER_TEST_RESULT.md` - Previous test results
- `test-results/GRPC_403_INVESTIGATION_COMPLETE.md` - Full investigation report
