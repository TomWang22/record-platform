# gRPC 403 - tcpdump Network Capture

**Date**: January 4, 2025  
**Status**: 📦 **CAPTURED** - Network packets captured with tcpdump  
**Priority**: Critical - Analyze captured packets to find root cause

---

## Network Capture Setup

### Tools Available

✅ **tcpdump**: Installed in auth-service pod (pod runs as root)  
✅ **kubectl debug**: Available (alternative option)  
✅ **/proc/net/tcp**: Readable (simple connection info)

### Capture Method

Used tcpdump directly in the pod:
- Installed tcpdump (pod runs as root)
- Started background capture on port 50051
- Made test requests (direct and via Caddy)
- Stopped capture
- Analyzed packets
- Copied capture file to host

---

## Capture Details

### Capture File

**Location on host**: `/tmp/grpc-capture-auth-service.pcap`  
**Capture command**: `tcpdump -i any -w /tmp/grpc-capture.pcap -s 0 port 50051`  
**Filter**: Port 50051 (gRPC port)

### Test Requests Made

1. **Direct connection** (works):
   - `grpcurl -insecure localhost:50054`
   - Via kubectl port-forward
   - ✅ **Result**: Success (gRPC response)

2. **Via Caddy** (403):
   - `grpcurl ... 127.0.0.1:30443`
   - Via Caddy reverse proxy
   - ❌ **Result**: HTTP 403 (text/plain)

---

## What to Analyze

### Network-Level Differences

1. **TLS Handshake**:
   - Compare TLS handshake between direct and via Caddy
   - Check ALPN negotiation (should be `h2` for HTTP/2)
   - Verify certificate exchange

2. **HTTP/2 Frames**:
   - Compare HTTP/2 frame types and order
   - Check HEADERS frame contents
   - Verify DATA frames

3. **Request Headers**:
   - Compare exact header values
   - Check header order
   - Verify header encoding

4. **Path**:
   - Compare request path format
   - Check path encoding
   - Verify :path pseudo-header

5. **Response**:
   - Compare response format
   - Check status codes
   - Verify content-type

---

## Analysis Commands

### Basic Analysis

```bash
# Count packets
tcpdump -r /tmp/grpc-capture-auth-service.pcap | wc -l

# Show packet summary
tcpdump -r /tmp/grpc-capture-auth-service.pcap -n -c 50

# Show HTTP/2 headers
tcpdump -r /tmp/grpc-capture-auth-service.pcap -A -s 0 | grep -E ':method|:path|:authority|content-type'
```

### Detailed Analysis

```bash
# Show full packet contents (hex + ASCII)
tcpdump -r /tmp/grpc-capture-auth-service.pcap -x -s 0

# Filter by IP (to separate direct vs Caddy)
tcpdump -r /tmp/grpc-capture-auth-service.pcap host <Caddy_IP>
tcpdump -r /tmp/grpc-capture-auth-service.pcap host <direct_client_IP>
```

### Using Wireshark (if available)

```bash
# Open in Wireshark
wireshark /tmp/grpc-capture-auth-service.pcap

# Or use tshark
tshark -r /tmp/grpc-capture-auth-service.pcap -Y "tcp.port == 50051"
```

---

## Expected Findings

### Direct Connection (Works)

- ✅ TLS handshake: ALPN = h2
- ✅ HTTP/2 HEADERS frame with correct path
- ✅ HTTP/2 DATA frames
- ✅ HTTP/2 response frames
- ✅ gRPC response format

### Via Caddy (403)

- ✅ TLS handshake: ALPN = h2 (should match)
- ⚠️ HTTP/2 HEADERS frame: May have differences
- ⚠️ HTTP/2 response: HTTP 403 status
- ❌ Response: text/plain (not gRPC)

---

## Next Steps

1. ✅ Capture packets (DONE)
2. ⏳ Analyze packets in detail
3. ⏳ Compare direct vs via Caddy
4. ⏳ Identify exact differences
5. ⏳ Find root cause
6. ⏳ Implement fix

---

## Related Files

- `/tmp/grpc-capture-auth-service.pcap` - Captured packets
- `test-results/GRPC_403_NETWORK_DEBUG_PLAN.md` - Network debugging plan
- `test-results/GRPC_403_DEEP_DIVE.md` - Deep dive analysis
