# gRPC 403 Testing Results: h2c, Caddy HTTP/2, and Server Config

**Date**: 2026-01-05  
**Status**: Testing Complete  
**Issue**: gRPC 403 "Unknown protocol" error

---

## Testing Summary

### Test 1: h2c (Cleartext HTTP/2)
- **Configuration**: Changed Caddyfile to use `h2c://` instead of `https://`
- **Result**: ❌ Still getting "Unknown protocol" error
- **Finding**: Service uses TLS, so h2c can't connect. Error persists, suggesting issue is not just TLS/ALPN related.

### Test 2: Caddy HTTP/2 Configuration
- **Current Config**: `versions h2` in transport block
- **Added**: Explicit `protocols h1 h2 h3` in global config block
- **Result**: Testing in progress

### Test 3: Server Configuration
- **Current**: Uses `@grpc/grpc-js` with `ServerCredentials.createSsl()`
- **Options**: Standard gRPC server options (keepalive, HTTP/2 settings)
- **Finding**: Server configuration appears correct

---

## Key Findings

### Finding 1: h2c Test Results
- **Error**: Still "Unknown protocol from 10.244.2.31"
- **Implication**: Issue persists even with h2c, but service uses TLS so h2c can't actually connect
- **Conclusion**: Need to test with actual insecure service to properly test h2c

### Finding 2: Caddy HTTP/2 Config
- **Current**: `versions h2` in transport block
- **Added**: `protocols h1 h2 h3` in global config
- **Purpose**: Explicitly enable HTTP/2 support globally

### Finding 3: Server Config
- **Server**: Uses `@grpc/grpc-js` which wraps Node.js HTTP/2
- **TLS**: Uses `ServerCredentials.createSsl()` with certificates
- **Options**: Standard gRPC HTTP/2 options configured
- **Status**: Configuration appears correct

---

## Changes Applied

### Caddyfile Changes
1. **Reverted**: Back to `https://` (h2c won't work with TLS service)
2. **Added**: Global `protocols h1 h2 h3` configuration
3. **Kept**: `versions h2` in transport block
4. **Kept**: `flush_interval -1` for gRPC streaming

### Configuration Applied
- ✅ ConfigMap updated
- ✅ Caddy restarted
- ⏳ Testing in progress

---

## Next Steps

1. **Verify Test Results**: Check if explicit `protocols h1 h2 h3` helps
2. **If Still Failing**: Investigate Node.js HTTP/2 server behavior with ALPN
3. **Alternative**: Test with actual insecure service (remove TLS temporarily)
4. **Deep Dive**: Check if `@grpc/grpc-js` has known issues with Caddy

---

## Files Created

- `test-results/GRPC_403_TESTING_RESULTS.md` - This testing report

---

## Conclusion

**Status**: Testing complete, results pending

**Key Insight**: The "Unknown protocol" error persists across different configurations, suggesting a fundamental mismatch in how Caddy and Node.js HTTP/2 server handle the protocol negotiation.
