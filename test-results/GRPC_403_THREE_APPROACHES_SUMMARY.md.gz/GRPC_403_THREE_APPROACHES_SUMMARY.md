# gRPC 403 Investigation: Three Approaches Summary

**Date**: 2026-01-05  
**Status**: In Progress  
**Issue**: gRPC requests via Caddy return 403 Forbidden, but direct connections work

---

## Executive Summary

We executed three parallel approaches to investigate the gRPC 403 issue:

1. **Approach A**: Simpler tcpdump capture (step-by-step)
2. **Approach B**: Analysis of existing capture files
3. **Approach C**: Enable Node.js/gRPC debug logging

**Key Finding**: All tcpdump captures inside the pod show ONLY localhost traffic. Caddy's traffic (from IP 10.244.2.22) is NOT visible due to pod network namespace isolation.

---

## Approach A: Simpler tcpdump Capture

### Method
- Used `timeout 30` to run tcpdump for exactly 30 seconds
- Made direct request (port-forward) while capture ran
- Made Caddy request while capture still ran
- Retrieved capture file: `/tmp/grpc-simple-auth.pcap`

### Results
- ✅ Capture successful: 75 packets, 16KB
- ❌ **Problem**: All traffic is `127.0.0.1` (localhost)
- ❌ Caddy IP `10.244.2.22` traffic NOT visible

### Why This Happened
- Direct request uses `kubectl port-forward` → localhost
- Caddy connects from pod IP `10.244.2.22` → auth-service pod IP
- Inside the pod's network namespace, we only see localhost traffic
- Pod network isolation prevents seeing inter-pod traffic

### Files Created
- `/tmp/grpc-simple-auth.pcap` (16KB, 75 packets)

---

## Approach B: Analysis of Existing Capture Files

### Files Analyzed
1. `/tmp/grpc-capture-auth-service.pcap` (old, first attempt)
   - 73 packets, 16KB
   - All traffic: `127.0.0.1` (localhost)

2. `/tmp/grpc-simple-auth.pcap` (new, simpler method)
   - 75 packets, 16KB
   - All traffic: `127.0.0.1` (localhost)

### Key Findings

#### 1. All Traffic is Localhost
Both captures show ONLY localhost traffic:
```
22:20:41.038213 lo0   In  IP 127.0.0.1.45622 > 127.0.0.1.50051: Flags [S]
22:20:41.045824 lo0   In  IP 127.0.0.1.45622 > 127.0.0.1.50051: Flags [P.], length 253
22:20:41.078025 lo0   In  IP 127.0.0.1.50051 > 127.0.0.1.45622: Flags [P.], length 2158
```

#### 2. TLS Handshake Visible
- Client Hello: 253 bytes (TLS handshake)
- Server Hello: 2158 bytes (TLS response with certificate)
- ALPN negotiation shows `h2` (HTTP/2)
- Server name: `record.local`

#### 3. HTTP/2 Frames Present
- Connection preface visible
- Settings frames
- Headers frames
- Data frames

#### 4. Critical Gap
- **No Caddy traffic visible** (should be from `10.244.2.22`)
- This means we're missing the actual failing request!

### Why This Matters
The captures show successful direct connections, but NOT the failing Caddy-proxied connections. We need to capture from a different perspective.

---

## Approach C: Enable Node.js/gRPC Debug Logging

### Implementation
Added debug environment variables to `infra/k8s/base/auth-service/deploy.yaml`:

```yaml
env:
  # ... existing vars ...
  - name: GRPC_VERBOSITY
    value: "DEBUG"
  - name: GRPC_TRACE
    value: "all"
  - name: NODE_DEBUG
    value: "http2"
```

### What This Enables
- **GRPC_VERBOSITY=DEBUG**: Detailed gRPC library logging
- **GRPC_TRACE=all**: All gRPC trace events (connection, handshake, frames)
- **NODE_DEBUG=http2**: Node.js HTTP/2 module debug logging

### Expected Output
When enabled, we should see:
- gRPC connection establishment details
- HTTP/2 frame-level logging
- TLS handshake details
- Request/response metadata
- Any errors or rejections

### Status
- ✅ Deployment file updated
- ⏳ **Next**: Apply deployment and check logs

---

## Critical Finding: Network Capture Limitation

### The Problem
**Pod network namespace isolation prevents seeing inter-pod traffic.**

When we run `tcpdump` inside the `auth-service` pod:
- ✅ We see: localhost traffic (port-forward, health checks)
- ❌ We miss: Caddy's traffic (from `10.244.2.22`)

### Why
Kubernetes pods have isolated network namespaces. Traffic from Caddy pod (`10.244.2.22`) to auth-service pod appears on the pod's network interface, but `tcpdump -i any` inside the pod may not capture it correctly, or the traffic is being routed through the service mesh (Linkerd).

### Solutions

#### Option 1: Capture at Node Level
```bash
# Run tcpdump on the Kubernetes node
# This sees ALL traffic on the node's network interfaces
```

#### Option 2: Capture from Caddy Pod
```bash
# Run tcpdump inside Caddy pod
# This sees what Caddy sends to auth-service
kubectl -n ingress-nginx exec <caddy-pod> -- tcpdump ...
```

#### Option 3: Use Linkerd Tap (Service Mesh)
```bash
# If using Linkerd, use `linkerd tap` to see traffic
linkerd tap auth-service -n record-platform
```

#### Option 4: Use Debug Logging (Approach C)
- Enable gRPC/HTTP/2 debug logging
- Check service logs for connection details
- This shows what the service sees, not network packets

---

## Next Steps

### Immediate Actions
1. ✅ **Approach C**: Apply deployment with debug logging
   ```bash
   kubectl apply -f infra/k8s/base/auth-service/deploy.yaml
   kubectl -n record-platform rollout restart deployment/auth-service
   ```

2. **Check Debug Logs**
   ```bash
   kubectl -n record-platform logs -l app=auth-service --tail=100 -f
   ```

3. **Make Test Request**
   ```bash
   grpcurl -cacert=/tmp/grpc-certs/ca.crt \
     -cert=/tmp/grpc-certs/tls.crt \
     -key=/tmp/grpc-certs/tls.key \
     -servername=record.local \
     -H "Host: record.local" \
     127.0.0.1:30443 auth.AuthService/HealthCheck
   ```

4. **Analyze Logs**
   - Look for gRPC connection details
   - Check HTTP/2 frame information
   - Identify any rejection reasons

### Alternative: Capture from Caddy
If debug logging doesn't reveal the issue, capture from Caddy's perspective:

```bash
CADDY_POD=$(kubectl -n ingress-nginx get pods -l app=caddy-h3 -o jsonpath='{.items[0].metadata.name}')
kubectl -n ingress-nginx exec $CADDY_POD -- tcpdump -i any -w /tmp/caddy-to-auth.pcap -s 0 host 10.244.2.22 and port 50051
```

### Alternative: Node-Level Capture
If we have access to the Kubernetes node:

```bash
# On the node
tcpdump -i any -w /tmp/node-capture.pcap -s 0 port 50051
```

---

## Summary of Findings

| Approach | Status | Key Finding |
|----------|--------|-------------|
| **A: Simpler tcpdump** | ✅ Complete | Capture successful, but only localhost traffic visible |
| **B: Capture Analysis** | ✅ Complete | Both captures show only localhost; Caddy traffic missing |
| **C: Debug Logging** | ⏳ Pending | Deployment updated, needs application and log review |

### Root Cause Hypothesis
The 403 error is likely caused by:
1. **Request format mismatch**: Caddy may be sending requests in a format the service doesn't recognize
2. **HTTP/2 frame issue**: Caddy's HTTP/2 frames may differ from direct connections
3. **TLS/SNI issue**: Service may be rejecting based on TLS parameters
4. **Path/header issue**: Request path or headers may not match service expectations

**Next**: Debug logging (Approach C) should reveal what the service actually receives and why it rejects it.

---

## Files Created

1. `/tmp/grpc-simple-auth.pcap` - New capture (75 packets)
2. `/tmp/grpc-capture-auth-service.pcap` - Old capture (73 packets)
3. `infra/k8s/base/auth-service/deploy.yaml` - Updated with debug env vars
4. `test-results/GRPC_403_THREE_APPROACHES_SUMMARY.md` - This report

---

## Conclusion

All three approaches have been executed:
- **A & B**: Revealed network capture limitation (pod isolation)
- **C**: Debug logging enabled, ready for deployment and log analysis

**Next**: Apply deployment, check logs, and identify the exact cause of the 403 error.
