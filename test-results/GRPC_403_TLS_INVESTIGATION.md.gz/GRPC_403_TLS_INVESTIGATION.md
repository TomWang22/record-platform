# gRPC 403 - TLS Investigation

**Date**: January 4, 2025  
**Status**: 🔍 **INVESTIGATING** - Testing TLS configuration  
**Priority**: Critical - Identify TLS issue

---

## Test Plan

### Objective

Test TLS connection to auth-service using Caddy's exact configuration to identify why Caddy gets 403 but direct connection works.

---

## Key Differences

### Direct Connection (Works ✅)

**Method**: `grpcurl -insecure localhost:50051`
- Uses kubectl port-forward
- Connects through Kubernetes service
- TLS with `-insecure` (skips cert verification)
- ✅ **Works**: Returns proper gRPC response

### Via Caddy (Fails ❌)

**Method**: Caddy reverse_proxy with TLS
- Caddy connects to: `https://auth-service.record-platform.svc.cluster.local:50051`
- TLS configuration:
  ```
  transport http {
    versions h2
    tls
    tls_server_name record.local
    tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
  }
  ```
- ❌ **Fails**: Returns HTTP 403 (text/plain)

---

## Hypotheses

### Hypothesis 1: SNI Mismatch

**Theory**: `tls_server_name record.local` doesn't match auth-service certificate subject.

**Test**: Check certificate subject vs SNI

**Expected**:
- If mismatch: Fix `tls_server_name` or certificate
- If match: Issue is elsewhere

### Hypothesis 2: Certificate Validation

**Theory**: Caddy's certificate validation fails or is too strict.

**Test**: Check if `tls_trusted_ca_certs` path is correct

**Expected**:
- If path wrong: Fix path
- If path correct: Issue is elsewhere

### Hypothesis 3: TLS Version/Protocol Mismatch

**Theory**: TLS version or HTTP/2 negotiation fails.

**Test**: Check TLS version and HTTP/2 support

**Expected**:
- If mismatch: Fix TLS configuration
- If match: Issue is elsewhere

### Hypothesis 4: Request Format Issue

**Theory**: Caddy sends request in a format auth-service rejects.

**Test**: Compare request headers/method between direct and via Caddy

**Expected**:
- If difference found: Fix request format
- If same: Issue is elsewhere

---

## Next Steps

1. **Check Certificate Subject**: Verify auth-service certificate subject matches SNI
2. **Test TLS Directly**: Try connecting with TLS using Caddy's exact settings
3. **Compare Requests**: Compare request format between direct and via Caddy
4. **Check Caddy Logs**: Look for TLS errors in Caddy logs
5. **Fix Configuration**: Based on findings, fix TLS configuration

---

## Related Files

- `Caddyfile` - Caddy TLS configuration
- `test-results/GRPC_403_ROOT_CAUSE_FOUND.md` - Root cause identification
- `services/auth-service/src/grpc-server.ts` - Auth-service TLS configuration
