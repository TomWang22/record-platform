# gRPC 403 Root Cause: Unknown Protocol from Caddy

**Date**: 2026-01-05  
**Status**: Root Cause Identified  
**Issue**: gRPC requests via Caddy return 403 Forbidden

---

## Critical Finding

**Debug logs reveal the root cause:**

```
HTTP2 1: Unknown protocol from 10.244.2.22:55336
HTTP2 1: Unknown protocol timeout: 10000
```

**Where:**
- `10.244.2.22` = Caddy's pod IP
- `55336` = Source port from Caddy

---

## What This Means

### The Problem
The `auth-service` gRPC server is receiving a connection from Caddy, but it does **NOT recognize the protocol**. The Node.js HTTP/2 server expects the HTTP/2 connection preface (`PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`), but it's not receiving it.

### Why This Happens
Node.js HTTP/2 server has a 10-second timeout to receive the HTTP/2 connection preface. If it doesn't receive it, it logs "Unknown protocol" and rejects the connection.

### The Result
- Connection is rejected
- Caddy receives an error/connection reset
- Caddy returns 403 Forbidden to the client

---

## Comparison: Working vs Failing

### ✅ Working (Direct Connection / Health Check)
```
HTTP2 1: Http2Session server: received a connection
HTTP2 1: Http2Session server: created
D ... | server | (1) Connection established by client 127.0.0.1:44172
```

### ❌ Failing (Caddy Connection)
```
HTTP2 1: Unknown protocol from 10.244.2.22:55336
HTTP2 1: Unknown protocol timeout: 10000
```

**Key Difference**: Working connections immediately establish HTTP/2 session. Failing connections never receive the HTTP/2 connection preface.

---

## Root Cause Hypothesis

### Hypothesis 1: Caddy Not Sending HTTP/2 Connection Preface
Caddy's `transport http { versions h2 }` should force HTTP/2, but it may not be sending the connection preface correctly.

### Hypothesis 2: TLS/ALPN Negotiation Failure
The TLS handshake or ALPN negotiation may be failing, causing Caddy to fall back to HTTP/1.1, which the service rejects.

### Hypothesis 3: Caddy Using HTTP/1.1 Despite Configuration
Despite `versions h2`, Caddy may be using HTTP/1.1 for some reason (bug, misconfiguration, or fallback).

### Hypothesis 4: Protocol Mismatch in TLS Mode
Caddy is configured to use `https://` (TLS) to connect to the backend, but the service may be expecting a different protocol negotiation.

---

## Caddyfile Configuration

Current configuration for `auth-service`:

```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host auth-service.record-platform.svc.cluster.local:50051
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

**Key settings:**
- `versions h2` - Should force HTTP/2
- `tls` - Use TLS to backend
- `tls_server_name record.local` - SNI for TLS handshake

---

## Service Configuration

The `auth-service` gRPC server:
- Expects HTTP/2 only (no HTTP/1.1 fallback)
- Uses TLS with ALPN negotiation
- Listens on `0.0.0.0:50051`
- Uses `@grpc/grpc-js` which requires HTTP/2

---

## Next Steps

### 1. Check Caddy's Actual Behavior
- Verify Caddy is actually using HTTP/2
- Check if Caddy is sending the connection preface
- Look for TLS/ALPN negotiation errors in Caddy logs

### 2. Test Direct HTTP/2 Connection
- Use `curl` or `grpcurl` to test direct HTTP/2 connection to auth-service
- Verify the service accepts HTTP/2 connections correctly

### 3. Check TLS/ALPN
- Verify ALPN negotiation in TLS handshake
- Ensure `h2` is negotiated correctly

### 4. Potential Fixes

#### Option A: Force HTTP/2 More Explicitly
```caddyfile
transport http {
  versions h2
  tls
  tls_server_name record.local
  tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
  # Add explicit HTTP/2 settings
}
```

#### Option B: Check Caddy Version
- Verify Caddy version supports HTTP/2 properly
- Check for known bugs in Caddy's HTTP/2 implementation

#### Option C: Use HTTP/2 Cleartext (h2c)
- If TLS is the issue, try h2c (HTTP/2 cleartext)
- But this may not work if service requires TLS

#### Option D: Debug Caddy's Transport
- Enable more verbose logging in Caddy
- Check what protocol Caddy actually uses

---

## Files Created

- `test-results/GRPC_403_UNKNOWN_PROTOCOL_FINDING.md` - This report

---

## Conclusion

**Root Cause**: Caddy is connecting to `auth-service`, but the service does not recognize the protocol. The HTTP/2 connection preface is not being received, causing the connection to be rejected.

**Next**: Investigate why Caddy is not sending the HTTP/2 connection preface correctly, or why the service is not receiving it.
