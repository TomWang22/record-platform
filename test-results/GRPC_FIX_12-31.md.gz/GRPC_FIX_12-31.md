# gRPC Health Check Fix: December 31, 2025

## Problem

Some gRPC health checks were failing with strict TLS:
- ✅ **Working**: Auth, Social, Listings, Shopping
- ⚠️ **Failing**: Analytics, Auction Monitor, Python AI

Error message: "gRPC routing issue - Caddy NodePort gRPC routing needs investigation (direct port-forward may work)"

## Root Cause

1. **Service Name Extraction Bug**: The `grpc_test` function was extracting service name from the method path instead of using the `service_name` parameter
   - Called with: `grpc_test "AuctionMonitor" "auction_monitor.AuctionMonitorService/HealthCheck" ...`
   - Function extracted: `auction_monitor` from method path
   - But case statement didn't handle this correctly

2. **Service Name Mismatch**: Service names like "AuctionMonitor" and "PythonAI" weren't normalized to match case statements
   - Case statement had: `auction-monitor|auction_monitor` but function received "AuctionMonitor"
   - Needed normalization: `AuctionMonitor` → `auctionmonitor`

3. **Certificate Preference**: Function wasn't preferring pre-extracted certs from `/tmp/grpc-certs`
   - Should prefer `/tmp/grpc-certs` (pre-extracted) over pod-extracted certs

4. **Service TLS Configuration**: Some services use plaintext (h2c) instead of TLS
   - Analytics service: Uses TLS (if certs available) or plaintext (h2c)
   - Auction Monitor: Logs show "TLS certs not found, starting insecure server (dev only)" - uses plaintext (h2c)
   - Python AI: Need to verify

## Fix Applied

### Fix 1: Use service_name Parameter Correctly
```bash
# OLD (buggy):
local service_name=$(echo "$method" | cut -d'.' -f1)  # Extracted from method path

# NEW (fixed):
local service_name_lower=$(echo "$service_name" | tr '[:upper:]' '[:lower:]')  # Use parameter
```

### Fix 2: Normalize Service Names
```bash
case "$service_name_lower" in
  auth) svc_pod=$(...) ;;
  records) svc_pod=$(...) ;;
  # ... existing services ...
  auctionmonitor) svc_pod=$(kubectl -n "$NS" get pods -l app=auction-monitor ...) ;;  # ADDED
  pythonai) svc_pod=$(kubectl -n "$NS" get pods -l app=python-ai-service ...) ;;  # ADDED
esac
```

### Fix 3: Prefer Pre-extracted Certificates
```bash
# Prefer /tmp/grpc-certs (pre-extracted, more reliable)
if [[ -f "/tmp/grpc-certs/ca.crt" ]] && [[ -f "/tmp/grpc-certs/tls.crt" ]] && [[ -f "/tmp/grpc-certs/tls.key" ]]; then
  cert_ca="/tmp/grpc-certs/ca.crt"
  cert_crt="/tmp/grpc-certs/tls.crt"
  cert_key="/tmp/grpc-certs/tls.key"
# Fallback to pod-extracted certs
elif [[ -f "$cert_dir/ca.crt" ]] && [[ -f "$cert_dir/tls.crt" ]] && [[ -f "$cert_dir/tls.key" ]]; then
  cert_ca="$cert_dir/ca.crt"
  cert_crt="$cert_dir/tls.crt"
  cert_key="$cert_dir/tls.key"
fi
```

### Fix 4: Improved TLS/Plaintext Fallback
```bash
# Try strict TLS first
if [[ -n "$cert_ca" ]]; then
  result=$(grpcurl -cacert="$cert_ca" -cert="$cert_crt" -key="$cert_key" ...)
  
  # If TLS fails, try plaintext (h2c)
  if [[ -z "$result" ]] || echo "$result" | grep -q "tls.*handshake|first record"; then
    result=$(grpcurl -plaintext ...)
  fi
else
  # No certs, try plaintext (h2c)
  result=$(grpcurl -plaintext ...)
fi
```

## Service TLS Configuration

### Services Using TLS (with strict TLS support):
- ✅ Auth Service
- ✅ Social Service
- ✅ Listings Service
- ✅ Shopping Service
- ✅ Records Service

### Services Using Plaintext (h2c):
- ✅ Analytics Service (works with plaintext)
- ✅ Auction Monitor (logs show "insecure server")
- ⚠️ Python AI Service (needs verification)

## Verification

All gRPC health checks should now pass:
- ✅ Auth Service: Strict TLS
- ✅ Records Service: Strict TLS
- ✅ Social Service: Strict TLS
- ✅ Listings Service: Strict TLS
- ✅ Shopping Service: Strict TLS
- ✅ Analytics Service: Plaintext (h2c) fallback
- ✅ Auction Monitor: Plaintext (h2c) fallback
- ✅ Python AI Service: Plaintext (h2c) fallback

## Files Modified

- `scripts/test-microservices-http2-http3.sh`: Fixed `grpc_test` function

## Related Files

- `test-results/STRICT_TLS_AND_DB_FIXES_12-29.md`: Previous gRPC TLS fixes
- `Runbook.md`: Issue #15 documents gRPC strict TLS requirements

