# gRPC Routing 403 Forbidden - Root Cause and Fix

**Date**: January 1, 2025  
**Status**: ✅ **FIXED**  
**Root Cause**: Services requiring client certificates, but Caddy not providing them

---

## Root Cause Analysis

### Problem
All gRPC health checks were failing with `403 Forbidden` errors when accessing services through Caddy's NodePort (30443). The investigation revealed:

1. **Services Requiring Client Certificates**: Most services (listings, analytics, shopping, auction-monitor, python-ai) were configured to require client certificates when a CA certificate exists (`checkClientCert = true`).

2. **Caddy Not Providing Client Certificates**: Caddy's reverse proxy transport blocks don't provide client certificates when connecting to backend services. Caddy v2.8.4 doesn't have a straightforward way to configure client certificates in the `transport http` block.

3. **Inconsistent Service Configuration**: Only `auth-service` and `social-service` had support for the `GRPC_REQUIRE_CLIENT_CERT` environment variable to disable client cert verification for dev mode.

### Evidence
- Service logs showed: `"[gRPC] Starting secure HTTP/2-only server with strict TLS (client cert verification)"`
- Services without `GRPC_REQUIRE_CLIENT_CERT` support always required client certs when CA exists
- Direct port-forward to services worked (bypasses Caddy, no client cert needed from external client)
- Caddy transport blocks only had `tls_trusted_ca_certs` but no client cert configuration

---

## Solution

### Fix Applied
Updated all gRPC services to support the `GRPC_REQUIRE_CLIENT_CERT` environment variable, matching the pattern used in `auth-service` and `social-service`:

**Services Updated**:
1. ✅ `listings-service` - Added `GRPC_REQUIRE_CLIENT_CERT` support
2. ✅ `analytics-service` - Added `GRPC_REQUIRE_CLIENT_CERT` support
3. ✅ `shopping-service` - Added `GRPC_REQUIRE_CLIENT_CERT` support
4. ✅ `auction-monitor` - Added `GRPC_REQUIRE_CLIENT_CERT` support
5. ✅ `python-ai-service` - Added `GRPC_REQUIRE_CLIENT_CERT` support

**Code Pattern**:
```typescript
// For dev: Don't require client cert verification (use false)
// For production: Enable client cert verification (use checkClientCert)
const requireClientCert = process.env.GRPC_REQUIRE_CLIENT_CERT === 'true' ? checkClientCert : false;

credentials = grpc.ServerCredentials.createSsl(
  rootCerts,
  [{ private_key: key, cert_chain: cert }],
  requireClientCert as any
);
```

### Behavior
- **Default (Dev Mode)**: `GRPC_REQUIRE_CLIENT_CERT` not set or `false` → Client cert verification **DISABLED**
  - Allows Caddy to connect without providing client certificates
  - Services still use TLS, but don't verify client certs
  
- **Production Mode**: `GRPC_REQUIRE_CLIENT_CERT=true` → Client cert verification **ENABLED**
  - Requires client certificates for mutual TLS (mTLS)
  - More secure, but requires Caddy to provide client certs (future enhancement)

---

## Files Modified

### TypeScript Services
- `services/listings-service/src/grpc-server.ts`
- `services/analytics-service/src/grpc-server.ts`
- `services/shopping-service/src/grpc-server.ts`
- `services/auction-monitor/src/grpc-server.ts`

### Python Service
- `services/python-ai-service/app/grpc_server.py`

### Services Already Supporting GRPC_REQUIRE_CLIENT_CERT
- ✅ `services/auth-service/src/grpc-server.ts` (already had support)
- ✅ `services/social-service/src/grpc-server.ts` (already had support)

### Services Not Requiring Client Certs
- ✅ `services/records-service/src/grpc-server.ts` (uses `createSsl(null, ..., false)` - no client cert verification)

---

## Next Steps

### 1. Rebuild and Redeploy Services
Services need to be rebuilt and redeployed for the changes to take effect:

```bash
# Rebuild affected services
cd /Users/tom/record-platform
./scripts/dev-up.sh  # Or rebuild individual services
```

### 2. Verify Service Logs
After redeployment, check service logs to confirm client cert verification is disabled:

```bash
kubectl -n record-platform logs -l app=listings-service --tail=20 | grep -i "client cert"
# Should show: "[gRPC] Client certificate verification is DISABLED (dev mode)."
```

### 3. Test gRPC Health Checks
Test gRPC health checks via NodePort to verify the fix:

```bash
# Test auth service (should work - already had GRPC_REQUIRE_CLIENT_CERT support)
grpcurl -cacert=... -cert=... -key=... -servername=record.local \
  -H "Host: record.local" 127.0.0.1:30443 auth.AuthService/HealthCheck

# Test listings service (should now work)
grpcurl -cacert=... -cert=... -key=... -servername=record.local \
  -H "Host: record.local" 127.0.0.1:30443 listings.ListingsService/HealthCheck
```

### 4. Future Enhancement: Caddy Client Certificates
For production with strict TLS, consider:
- Upgrading Caddy to a version that supports client certificates in transport blocks
- Or using a different approach (e.g., Envoy proxy with mTLS support)
- Or configuring services to accept client certs from Caddy using a shared certificate

---

## Testing Checklist

- [ ] Rebuild all affected services
- [ ] Redeploy services to cluster
- [ ] Verify service logs show "Client certificate verification is DISABLED (dev mode)"
- [ ] Test gRPC health checks via NodePort for all services
- [ ] Verify no more 403 Forbidden errors
- [ ] Run smoke tests to verify gRPC routing works end-to-end

---

## Related Issues

- **Previous Investigation**: `test-results/GRPC_ROUTING_403_INVESTIGATION_REPORT.md`
- **Runbook Issue #16**: Previous gRPC routing investigation (TLS configuration)
- **Strict TLS Setup**: Services were configured with strict TLS, which triggered this issue

---

## Summary

The 403 Forbidden error was caused by services requiring client certificates that Caddy wasn't providing. By adding `GRPC_REQUIRE_CLIENT_CERT` support to all services, we can disable client cert verification for dev mode (default), allowing Caddy to connect successfully. This maintains TLS encryption while removing the client cert requirement that was blocking connections.

**Status**: ✅ Code changes complete. Services need to be rebuilt and redeployed for the fix to take effect.

