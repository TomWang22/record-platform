# gRPC Routing 403 Forbidden Investigation Report

**Date**: January 1, 2025  
**Issue**: gRPC health checks failing with 403 Forbidden via Caddy NodePort  
**Status**: 🔴 **UNRESOLVED** - Requires further investigation  
**Priority**: High - Blocks gRPC health checks and comprehensive testing

---

## Executive Summary

All gRPC health checks are failing with `403 Forbidden` errors when accessing services through Caddy's NodePort (30443). The error indicates that Caddy is returning an HTTP error page (`text/plain` content-type) instead of routing requests to gRPC handlers. This suggests requests are not matching the gRPC matchers and are being rejected or routed to the wrong handler.

**Key Finding**: Despite multiple configuration attempts, requests consistently return 403, indicating a fundamental routing issue rather than a TLS or backend connectivity problem.

---

## Problem Statement

### Symptoms
- All gRPC health checks fail via NodePort (port 30443)
- Error: `403 Forbidden` with `text/plain` content-type
- Direct port-forward to service pods works (bypasses Caddy)
- Services are running and healthy (logs show gRPC requests being processed)
- TLS configuration is correct (`h2` with `tls`)

### Error Details
```
ERROR:
  Code: PermissionDenied
  Message: unexpected HTTP status code received from server: 403 (Forbidden); 
  transport: received unexpected content-type "text/plain"
```

### Affected Services
- ✅ Auth Service (works via direct port-forward)
- ❌ Records Service
- ❌ Social Service
- ❌ Listings Service
- ❌ Analytics Service
- ❌ Shopping Service
- ❌ Auction Monitor Service
- ❌ Python AI Service

---

## Historical Context

### Previous Working State
According to the Runbook (Issue #16), gRPC routing previously worked but had a different issue:
- **Previous Problem**: Caddy used `h2c` (HTTP/2 cleartext) but services use TLS
- **Previous Fix**: Changed to `h2` with `tls` in transport blocks
- **Status**: This TLS fix was applied and should be working

### What Changed
The current 403 issue appeared after:
1. Removing `protocol grpc` from matchers (because it wasn't detecting gRPC requests)
2. Attempting to use `path_regexp` only for routing
3. Various attempts to fix routing with different matcher combinations

**Note**: The user reported "we did not have a issue with in the past", suggesting this is a regression or configuration change that broke previously working functionality.

---

## Current Configuration

### Caddyfile Structure

#### Server Blocks
1. **`https://record.local`** - Primary vhost (lines 8-234)
2. **`:5000`** - Internal h2c port (deprecated, lines 238-396)
3. **`:443`** - Catch-all for any hostname (lines 400-595)

#### gRPC Matchers (in `https://record.local` block)
```caddyfile
@grpc_auth {
  protocol grpc
  path_regexp ^auth\\.
}
@grpc_records {
  protocol grpc
  path_regexp ^records\\.
}
# ... (similar for other services)
```

#### Handler Order (Critical!)
```
Line 17:  handle @privacy
Line 26:  handle @terms
Line 69:  handle @grpc_auth        ← gRPC handlers
Line 84:  handle @grpc_records
Line 99:  handle @grpc_social
Line 114: handle @grpc_listings
Line 129: handle @grpc_analytics
Line 144: handle @grpc_shopping
Line 159: handle @grpc_auction_monitor
Line 174: handle @grpc_python_ai
Line 201: handle @api                ← REST API handler (comes AFTER gRPC)
Line 220: handle { ... }             ← Webapp catch-all
```

**✅ Handler order is correct** - gRPC handlers come before @api handler.

#### gRPC Reverse Proxy Configuration
```caddyfile
handle @grpc_auth {
  reverse_proxy https://auth-service.record-platform.svc.cluster.local:50051 {
    header_up Host {http.request.host}
    header_up TE trailers
    header_up grpc-timeout {http.request.header.grpc-timeout}
    transport http {
      versions h2
      tls
      tls_server_name record.local
      tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
    }
  }
}
```

**Note**: Client certificates (`tls_client_cert` / `tls_client_key`) were attempted but may not be valid Caddy v2.8.4 syntax. Services require client certificates (`checkClientCert = true`), which may be causing the 502→403 transition.

---

## Investigation Attempts

### Attempt 1: Path-Only Matcher
**Hypothesis**: `protocol grpc` detection wasn't working, so use `path_regexp` only.

**Configuration**:
```caddyfile
@grpc_auth {
  path_regexp ^(/)?auth\.
}
```

**Result**: ❌ Still 403 Forbidden

### Attempt 2: Path + Content-Type Header
**Hypothesis**: Add explicit `Content-Type: application/grpc` header matcher.

**Configuration**:
```caddyfile
@grpc_auth {
  path_regexp ^(/)?auth\.
  header Content-Type application/grpc
}
```

**Result**: ❌ Still 403 Forbidden

### Attempt 3: Escaped Dot Pattern
**Hypothesis**: Regexp dot (`.`) matches any character, need to escape it.

**Configuration**:
```caddyfile
@grpc_auth {
  path_regexp ^auth\\.
}
```

**Result**: ❌ Still 403 Forbidden

### Attempt 4: Simplified Pattern (No Optional Leading Slash)
**Hypothesis**: Optional leading slash `^(/)?` might be causing issues.

**Configuration**:
```caddyfile
@grpc_auth {
  path_regexp ^auth\\.
}
```

**Result**: ❌ Still 403 Forbidden

### Attempt 5: protocol grpc + path_regexp Combined
**Hypothesis**: Maybe both conditions are needed together.

**Configuration**:
```caddyfile
@grpc_auth {
  protocol grpc
  path_regexp ^auth\\.
}
```

**Result**: ❌ Still 403 Forbidden

### Attempt 6: Client Certificates in Transport
**Hypothesis**: Services require client certificates, Caddy needs to provide them.

**Configuration**:
```caddyfile
transport http {
  versions h2
  tls
  tls_server_name record.local
  tls_trusted_ca_certs /etc/caddy/ca/dev-root.pem
  tls_client_cert /etc/caddy/certs/tls.crt
  tls_client_key /etc/caddy/certs/tls.key
}
```

**Result**: ⚠️ Caddy validated without errors, but still 403. Syntax may be invalid or not supported in Caddy v2.8.4.

---

## Technical Details

### Caddy Version
```
v2.8.4 h1:q3pe0wpBj1OcHFZ3n/1nl4V4bxBrYoSoab7rL9BMYNk=
```

### Test Command
```bash
grpcurl \
  -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  -H "Host: record.local" \
  -H "Content-Type: application/grpc" \
  -H "TE: trailers" \
  -import-path "proto" \
  -proto "proto/auth.proto" \
  -max-time 5 \
  "127.0.0.1:30443" \
  "auth.AuthService/HealthCheck"
```

### Path Pattern Testing
```bash
# Pattern: ^auth\.
# Test path: auth.AuthService/HealthCheck
# Match result: YES (pattern matches correctly)
```

### Handler Order Verification
- ✅ gRPC handlers come BEFORE @api handler
- ✅ gRPC handlers come BEFORE webapp catch-all
- ✅ @api matcher pattern `^/(api/|auth/|records/|...)` does NOT match gRPC paths (uses dot, not slash)

### Service Status
- ✅ All services are running and healthy
- ✅ Services are listening on gRPC ports (logs show requests being processed)
- ✅ Direct port-forward to services works (confirms services are functional)
- ✅ TLS certificates are correctly mounted in Caddy pod

---

## Root Cause Analysis

### Hypothesis 1: protocol grpc Detection Failure
**Theory**: Caddy's `protocol grpc` matcher is not detecting gRPC requests correctly, causing matchers to fail.

**Evidence**:
- Initial investigation showed `protocol grpc` wasn't working
- Combined with `path_regexp` still doesn't work
- Caddy v2.8.4 may have a bug or different behavior

**Test**: Try removing `protocol grpc` entirely and use only `path_regexp` (already attempted - didn't work)

### Hypothesis 2: Wrong Server Block Selection
**Theory**: Requests are hitting `:443` catch-all block instead of `https://record.local` block.

**Evidence**:
- SNI (Server Name Indication) might not be working correctly
- Host header might not be matching
- NodePort routing might not preserve SNI

**Test**: Check Caddy logs to see which server block handles the request

### Hypothesis 3: Default Deny Policy
**Theory**: Caddy has a default deny for unmatched requests or gRPC requests without proper protocol detection.

**Evidence**:
- 403 is a "Forbidden" error, not "Not Found"
- Suggests explicit rejection rather than routing failure
- `text/plain` content-type suggests Caddy's error page

**Test**: Check for any security policies or default deny directives

### Hypothesis 4: Client Certificate Requirement
**Theory**: Services require client certificates, and without them, requests are rejected at the service level (not Caddy).

**Evidence**:
- Services use `checkClientCert = true` when CA cert exists
- Caddy transport blocks don't have valid client cert syntax
- Initial error was 502 (backend connection), now 403 (routing/authentication)

**Test**: Verify if `tls_client_cert` / `tls_client_key` are valid Caddy directives

### Hypothesis 5: HTTP/2 Connection Reuse Issue
**Theory**: HTTP/2 connection reuse with misaligned SNI/Host headers causes Caddy to reject requests.

**Evidence**:
- Web search results mention this as a known Caddy issue
- Could explain why it worked before but doesn't now

**Test**: Disable HTTP/2 or force HTTP/1.1 to test

---

## What We Know Works

1. ✅ **Direct Port-Forward**: `kubectl port-forward` directly to service pods works
2. ✅ **Services Are Healthy**: Logs show gRPC requests being processed when accessed directly
3. ✅ **TLS Configuration**: `h2` with `tls` is correct (per Runbook)
4. ✅ **Path Patterns Match**: Regexp patterns correctly match gRPC paths
5. ✅ **Handler Order**: gRPC handlers come before @api handler
6. ✅ **Certificates**: TLS certificates are correctly mounted and accessible

---

## What Doesn't Work

1. ❌ **NodePort Routing**: All requests via `127.0.0.1:30443` return 403
2. ❌ **protocol grpc Matcher**: Doesn't detect gRPC requests (or combined matchers fail)
3. ❌ **Client Certificates**: Syntax may be invalid or not supported
4. ❌ **All Matcher Combinations**: None of the attempted configurations work

---

## Next Steps for Investigation

### Immediate Actions

1. **Enable Caddy Debug Logging**
   ```bash
   kubectl -n ingress-nginx exec <caddy-pod> -- caddy run --config /etc/caddy/Caddyfile --adapter caddyfile --log-level debug
   ```
   - This will show which handler processes each request
   - Will reveal if requests hit wrong server block
   - Will show matcher evaluation results

2. **Check Caddy Access Logs**
   ```bash
   kubectl -n ingress-nginx logs <caddy-pod> --tail=100 | grep -iE "403|forbidden|auth|grpc"
   ```
   - Look for access log entries showing 403 responses
   - Check which handler returned the 403

3. **Verify Client Certificate Syntax**
   - Check Caddy v2.8.4 documentation for `tls_client_cert` / `tls_client_key`
   - May need different syntax or approach for client certificates
   - Services require client certs, so this is critical

4. **Test HTTP/1.1 vs HTTP/2**
   - Try forcing HTTP/1.1 to rule out HTTP/2 connection reuse issues
   - Test if disabling HTTP/2 in Caddy helps

5. **Check Git History**
   - Review previous working Caddyfile configuration
   - Compare with current configuration
   - Identify what changed

### Long-Term Solutions

1. **Verify Caddy Version Compatibility**
   - Check if Caddy v2.8.4 has known issues with gRPC routing
   - Consider upgrading or downgrading Caddy version
   - Review Caddy changelog for gRPC-related changes

2. **Alternative Routing Approach**
   - Consider using different port for gRPC (separate from HTTP)
   - Use path-based routing with explicit `/grpc/` prefix
   - Implement gRPC gateway pattern

3. **Service Configuration**
   - Consider making client certificates optional for dev (use `GRPC_REQUIRE_CLIENT_CERT=false`)
   - This would allow testing routing without client cert complexity
   - Can re-enable strict TLS once routing works

---

## Configuration Files

### Current Caddyfile Location
- **Path**: `/Users/tom/record-platform/Caddyfile`
- **Applied to**: `caddy-h3` pod in `ingress-nginx` namespace
- **ConfigMap**: `caddy-h3` in `ingress-nginx` namespace

### Key Sections
- **Lines 42-73**: gRPC matchers for `https://record.local`
- **Lines 69-193**: gRPC handler blocks
- **Lines 400-595**: `:443` catch-all block with duplicate gRPC routing

### Service Configuration
- **Services**: All use `grpc.ServerCredentials.createSsl()` with `checkClientCert = true`
- **Certificates**: Mounted at `/etc/certs/` in service pods
- **CA Cert**: Available at `/etc/caddy/ca/dev-root.pem` in Caddy pod

---

## Test Results

### Smoke Test Results
```
Test 15a: gRPC Auth Service - HealthCheck via HTTP/2
⚠️  gRPC Auth HealthCheck failed
Response: gRPC routing issue - Caddy NodePort gRPC routing needs investigation

Test 15b: gRPC Records Service - HealthCheck via HTTP/2
⚠️  gRPC Records HealthCheck failed
Response: gRPC routing issue - Caddy NodePort gRPC routing needs investigation

... (all services fail with same error)
```

### Direct Port-Forward Test
```bash
# This works - confirms services are functional
kubectl -n record-platform port-forward pod/auth-service-xxx 50051:50051
grpcurl -cacert=... -cert=... -key=... localhost:50051 auth.AuthService/HealthCheck
# Result: ✅ Works correctly
```

---

## Related Documentation

- **Runbook.md**: Issue #16 - Previous gRPC routing investigation
- **ENGINEERING.md**: System architecture and performance documentation
- **Caddyfile**: Current configuration (accepted by user)
- **test-microservices-http2-http3.sh**: Smoke test script with gRPC health checks

---

## Questions for Next Agent

1. **What was the previous working Caddyfile configuration?**
   - Can we check git history?
   - What matchers were used?
   - Was `protocol grpc` working before?

2. **Is `tls_client_cert` / `tls_client_key` valid Caddy v2.8.4 syntax?**
   - Documentation reference?
   - Alternative syntax?
   - How to provide client certificates to backend services?

3. **Why is Caddy returning 403 instead of routing to gRPC handlers?**
   - Is there a default deny policy?
   - Are matchers being evaluated?
   - Is the wrong server block handling requests?

4. **Should we disable client certificate requirement temporarily?**
   - To test routing without TLS complexity
   - Use `GRPC_REQUIRE_CLIENT_CERT=false` in services
   - Re-enable once routing works

5. **Is there a Caddy v2.8.4 bug with gRPC routing?**
   - Known issues?
   - Workarounds?
   - Version upgrade/downgrade needed?

---

## Conclusion

The 403 Forbidden error persists despite multiple configuration attempts. The issue appears to be a fundamental routing problem where Caddy is not matching gRPC requests to the appropriate handlers. The error suggests requests are being rejected or routed to the wrong handler rather than reaching the gRPC reverse proxy blocks.

**Critical Next Step**: Enable Caddy debug logging to see exactly which handler processes the request and why matchers are not matching. This will provide definitive evidence of where the routing is failing.

**Recommendation**: Focus on understanding why Caddy is returning 403 instead of routing to gRPC handlers. The configuration appears correct, so the issue may be:
1. A Caddy version-specific bug
2. A matcher evaluation issue
3. A server block selection problem
4. A client certificate requirement blocking requests

---

**Report Generated**: January 1, 2025  
**Investigation Duration**: ~2 hours  
**Status**: Requires further investigation with debug logging enabled

