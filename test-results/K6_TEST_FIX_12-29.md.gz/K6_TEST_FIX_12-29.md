# k6 Test Fix: December 29, 2025

## Problem

The k6 test script (`scripts/run-k6-tests-simple.sh`) was stuck and k6 never started.

### Symptoms
- Monitoring processes running (tcpdump, strace, CPU logs updating)
- k6 process never started
- No k6 output log file created
- Script stuck at "Running k6 HTTP/2 test..." message

### Root Cause

**Command Substitution Blocking**: Line 100 in `run-k6-tests-simple.sh`:
```bash
MONITOR_PIDS=$(start_monitoring "HTTP/2" "http2-limit")
```

The `start_monitoring()` function starts background processes that keep stdout/stderr open. When command substitution tries to capture output, it blocks waiting for those background processes to close their file descriptors, causing the script to hang.

## Solution

Created `scripts/run-k6-tests-fixed.sh` with these fixes:

1. **No Command Substitution for PIDs**: Instead of capturing PIDs via command substitution, write them to a file:
   ```bash
   # OLD (blocks):
   MONITOR_PIDS=$(start_monitoring ...)
   
   # NEW (non-blocking):
   start_monitoring "HTTP/2" "http2-limit"
   MONITOR_PID_FILE="$MONITOR_DIR/http2-limit/pids.txt"
   ```

2. **Explicit k6 Process Verification**: After starting k6, verify it's actually running:
   ```bash
   k6 run ... > log.txt 2>&1 &
   K6_PID=$!
   sleep 2
   if ! kill -0 "$K6_PID" 2>/dev/null; then
     fail "k6 process died immediately"
   fi
   ```

3. **Better Error Messages**: Added explicit messages showing what command is being run and where output goes.

4. **Simplified Monitoring**: All monitoring output redirected to files immediately to prevent blocking.

## Usage

### Step 1: Clean Up Stuck Processes (in NEW terminal)
```bash
./scripts/cleanup-stuck-tests.sh
```

### Step 2: Run Fixed Test
```bash
./scripts/run-k6-tests-fixed.sh
```

## What the Fixed Script Does

1. **Starts Monitoring** (tcpdump, strace, CPU metrics)
2. **Runs HTTP/2 Limit Test** (~4 minutes)
   - Verifies k6 actually started
   - Waits with 6-minute timeout
   - Saves output to `k6-http2.log`
3. **Stops Monitoring**
4. **Copies tcpdump captures**
5. **Waits 30 seconds** for services to recover
6. **Repeats for HTTP/3**

## Expected Output

```
=== Fixed k6 Test with Monitoring ===
Results: test-results/20251229-HHMMSS-k6-fixed

=== Starting monitoring for HTTP/2...
✅ tcpdump started (PID: 12345)
✅ strace started on auth-service-xxx (PID: 12346)
✅ CPU monitoring started (PID: 12347)
✅ Monitoring started (3 processes)

=== Test 1: HTTP/2 Limit Test ===
Running k6 HTTP/2 test...
Command: k6 run --http-debug=false scripts/load/k6-e2e-find-limit.js
Output will be saved to: test-results/.../k6-http2.log
✅ k6 started (PID: 12348)
Waiting for k6 to complete (max 6 minutes)...
✅ k6 HTTP/2 test completed successfully
```

## Files Created

- `scripts/cleanup-stuck-tests.sh` - Cleanup script for stuck processes
- `scripts/run-k6-tests-fixed.sh` - Fixed test script
- `test-results/K6_TEST_FIX_12-29.md` - This document

## Prevention

- **Never use command substitution for background processes** that keep file descriptors open
- **Always verify processes started** before waiting for them
- **Redirect all background process output** to files immediately
- **Use PID files** instead of command substitution for process tracking

