# Node.js HTTP/2 Server Configuration Investigation

**Date**: 2026-01-05  
**Purpose**: Investigate if Node.js HTTP/2 server can be configured to accept ALPN-only connections

---

## Current Configuration

### gRPC Server Setup

```typescript
const server = new grpc.Server({
  'grpc.keepalive_time_ms': 30000,
  'grpc.keepalive_timeout_ms': 5000,
  'grpc.keepalive_permit_without_calls': 1,
  'grpc.http2.max_pings_without_data': 0,
  'grpc.http2.min_time_between_pings_ms': 10000,
  'grpc.http2.min_ping_interval_without_data_ms': 300000,
});

const credentials = grpc.ServerCredentials.createSsl(
  rootCerts,
  [{ private_key: key, cert_chain: cert }],
  false  // requireClientCert
);

server.bindAsync('0.0.0.0:50051', credentials, (error, actualPort) => {
  server.start();
});
```

---

## The Problem

Node.js HTTP/2 server expects a connection preface (`PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n`) within 10 seconds. With TLS + ALPN:
- HTTP/2 is negotiated during TLS handshake
- ALPN selects `h2` protocol
- **But Node.js may still expect explicit connection preface**

---

## Investigation Areas

### 1. @grpc/grpc-js Options

**Current options used**:
- `grpc.http2.max_pings_without_data`
- `grpc.http2.min_time_between_pings_ms`
- `grpc.http2.min_ping_interval_without_data_ms`

**Potential options to investigate**:
- Connection preface timeout
- ALPN-only mode
- HTTP/2 negotiation settings

### 2. Node.js http2 Module

The underlying Node.js `http2` module may have options for:
- Accepting ALPN-only connections
- Disabling connection preface requirement
- Custom connection handling

### 3. Alternative Approaches

1. **Use native Node.js http2 server** instead of grpc-js
2. **Custom connection handler** that accepts ALPN-only
3. **Different gRPC server implementation**

---

## Research Findings

[To be filled with web search results]

---

## Potential Solutions

### Option 1: Configure grpc-js for ALPN-only
If grpc-js supports it, configure to accept ALPN-negotiated connections without explicit preface.

### Option 2: Use Node.js http2.createSecureServer directly
Bypass grpc-js and use Node.js http2 module directly with custom handling.

### Option 3: Accept both ALPN and preface
Configure server to accept either ALPN-negotiated or preface-initiated connections.

---

## Next Steps

1. Check @grpc/grpc-js documentation for ALPN options
2. Investigate Node.js http2 module options
3. Test alternative server configurations
4. Consider if this is a grpc-js limitation

---

## Files

- `services/auth-service/src/grpc-server.ts` - Current server implementation
- `test-results/NODEJS_HTTP2_INVESTIGATION.md` - This file

---

## Conclusion

**Envoy Test Result**: ✅ **SUCCESS**

Envoy successfully routes gRPC requests to the Node.js server, proving:
- Node.js server is correct
- HTTP/2 implementation works
- Server accepts ALPN-negotiated HTTP/2 connections
- Issue is **Caddy-specific**, not Node.js server configuration

**Finding**: The Node.js HTTP/2 server (via @grpc/grpc-js) correctly accepts HTTP/2 connections when properly established. The issue is with how Caddy establishes HTTP/2 connections, not with the Node.js server configuration.

**No changes needed** to Node.js server configuration - the server works correctly with Envoy and direct connections.
