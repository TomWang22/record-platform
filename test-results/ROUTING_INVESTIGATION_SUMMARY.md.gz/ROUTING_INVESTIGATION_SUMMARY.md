# gRPC Routing Investigation Summary (January 1, 2025)

## Root Cause Analysis

### Issue: Most gRPC Health Checks Fail via NodePort

**Symptoms**:
- ✅ Auth gRPC: Works (via direct port-forward)
- ❌ Records, Social, Listings, Analytics, Shopping, Auction Monitor, Python AI: All fail with "routing issue"

**Root Cause**:
1. **NodePort gRPC Test Uses `-insecure` Flag**: The `grpc_test` function tries NodePort with `-insecure`, which may:
   - Return empty result on timeout
   - Return different error patterns that don't match fallback condition
   - Succeed but not actually work (false positive)

2. **Fallback Condition Too Narrow**: The fallback only triggers on specific error patterns:
   - `502|Bad Gateway|malformed header|Unavailable|routing issue|gRPC routing|needs investigation`
   - But NodePort may return: timeout, connection refused, empty result, or other errors

3. **Caddy gRPC Routing**: Caddyfile has gRPC routing configured, but:
   - Uses `h2c` (HTTP/2 cleartext) transport
   - Routes based on path regexp (e.g., `^/auth\.`, `^/records\.`)
   - NodePort may not properly route gRPC over TLS

### Fix Applied

**Updated `grpc_test` function**:
1. **Try Strict TLS First**: Use proper certificates (`-cacert`, `-cert`, `-key`) instead of `-insecure`
2. **More Aggressive Fallback**: Check for ANY error pattern OR missing success indicators
3. **Always Try Port-Forward**: If NodePort result doesn't contain "healthy"/"success"/"SERVING", fall back to port-forward

**Code Changes**:
```bash
# Before: Only tried -insecure, fallback only on specific errors
result=$(grpcurl -insecure ...) || result=""
if [[ -z "$result" ]] || echo "$result" | grep -q -iE "502|Bad Gateway|..."; then
  # port-forward fallback
fi

# After: Try strict TLS first, then insecure, fallback on ANY error or missing success
if [[ -f "/tmp/grpc-certs/ca.crt" ]]; then
  nodeport_result=$(grpcurl -cacert=... -cert=... -key=... ...) || nodeport_result=""
fi
if [[ -z "$nodeport_result" ]] || echo "$nodeport_result" | grep -q -iE "error|..."; then
  nodeport_result=$(grpcurl -insecure ...) || nodeport_result=""
fi
if [[ -z "$result" ]] || echo "$result" | grep -q -iE "error|..." || ! echo "$result" | grep -q -iE "healthy|success"; then
  # port-forward fallback (MORE AGGRESSIVE)
fi
```

## k6 Test Timeout Issue

**Symptoms**:
- k6 tests timeout after 15 minutes
- Tests show 95% completion but don't finish
- Low success rates: 16-35% across services

**Root Causes**:
1. **System Overload**: 100 VUs is too much for current system capacity
2. **Service Failures**: Many 502/503 errors ("upstream error", "gRPC timeout")
3. **gRPC Timeouts**: Records service showing "gRPC call CreateRecord timed out after 10000ms"

**Evidence from k6 Logs**:
- HTTP/2: auth 34.93%, records 26.09%, listings 32.96%, social 22.77%
- HTTP/3: Similar low success rates
- Many "502 Bad Gateway" and "social upstream error" / "listings upstream error"

## Social Service Health Probe Issues

**Symptoms**:
- 19 pod restarts
- Health probe timeouts: "command timed out after 10s"
- Probe uses: `grpc-health-probe` with strict TLS, 5s connect timeout, 5s RPC timeout

**Root Cause**:
- Social service gRPC server may be slow to respond during high load
- Health probe timeout (10s) is too short for overloaded service
- Service may be crashing/restarting due to resource exhaustion

## Recommendations

1. **✅ Fixed gRPC Fallback**: More aggressive port-forward fallback implemented
2. **⚠️ Reduce k6 Load**: Lower VUs from 100 to 50 for comprehensive tests
3. **⚠️ Increase Health Probe Timeouts**: Increase social service health probe timeouts
4. **⚠️ Investigate Service Capacity**: System is overloaded at 100 VUs
5. **⚠️ Fix Caddy gRPC Routing**: Investigate why NodePort gRPC routing doesn't work (may need TLS configuration)

## Next Steps

1. Re-run smoke test to verify gRPC fallback works
2. Re-run comprehensive test with lower VUs (50 instead of 100)
3. Monitor service health during tests
4. Investigate Caddy gRPC routing configuration


## Caddy gRPC Routing Configuration Issue

### Problem: Caddy Uses h2c (Cleartext) But Services Use TLS

**Caddyfile Configuration** (lines 110-113, 122-125, etc.):
```caddyfile
reverse_proxy auth-service.record-platform.svc.cluster.local:50051 {
  transport http {
    versions h2c  # HTTP/2 cleartext - NOT TLS!
  }
}
```

**Service Configuration**: Services use `grpc.ServerCredentials.createSsl()` with TLS certificates

**Mismatch**:
- Caddy tries to connect with **h2c (cleartext HTTP/2)**
- Services expect **TLS (HTTPS/2)**
- This causes connection failures

**Why Auth Works**:
- Auth service may have different configuration OR
- Port-forward bypasses Caddy entirely (direct TLS connection)

### Fix Options

1. **Change Caddy to Use TLS**: Update Caddyfile to use TLS for gRPC:
   ```caddyfile
   transport http {
     versions h2  # HTTP/2 with TLS (not h2c)
     tls  # Enable TLS
   }
   ```

2. **Use Direct Port-Forward**: Continue using port-forward for gRPC tests (most reliable)

3. **Fix Caddy gRPC Routing**: Investigate Caddy's gRPC over TLS support

### Recommendation

**For Now**: Use direct port-forward for all gRPC tests (already implemented in fallback)

**For Production**: Fix Caddy gRPC routing to use TLS (h2) instead of h2c
