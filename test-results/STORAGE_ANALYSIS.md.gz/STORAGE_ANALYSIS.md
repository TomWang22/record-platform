# Docker Storage Analysis & Cleanup Plan

**Date:** 2025-01-01  
**Purpose:** Prevent Docker Desktop disk space issues by identifying and reclaiming stale resources

## Current Storage Situation

### Overall Disk Usage
- **Total Disk:** 460GB
- **Used:** 11GB (19% used)
- **Available:** 50GB
- **Status:** ✅ Healthy (plenty of space available)

### Docker Desktop Storage
- **Docker.raw File:** 140GB
- **Docker Volumes (Active):** 120.4GB
- **Docker Images:** 7.185GB
- **Build Cache:** 4.882GB
- **Overhead/Fragmentation:** ~20GB (140GB - 120.4GB)

## Reclaimable Resources

### ✅ Safe to Remove (Total: ~10-15GB)

1. **Build Cache: 4.882GB (100% reclaimable)**
   - All build cache entries are reclaimable
   - Command: `docker builder prune -af`

2. **Dangling Images: 23 images (~3.5GB estimated)**
   - Untagged/intermediate images
   - Command: `docker image prune -f`
   - Examples:
     - fa6ff586ca27 (156MB)
     - 7d8105356aed (156MB)
     - a0904efc4aa4 (620MB)
     - ... and 20 more

3. **Unused Images: 5.004GB (69% of total images)**
   - Images not currently in use
   - Command: `docker image prune -a` (more aggressive)

4. **Duplicate Backup Files: ~6GB**
   - 6 copies of `postgres-1` backup (1.0GB each)
   - Keep only latest: `record-platform-postgres-1-all-20260101-223214.sql`
   - Can remove 5 older copies: ~5GB

5. **Test Backup Files: ~200MB**
   - `test-record-platform-postgres-auth-1-20260101-214549.sql` (36M)
   - `test-record-platform-postgres-social-1-20260101-214551.sql` (165M)

6. **Old Incomplete Backup: 13K**
   - `record-platform-postgres-analytics-1-analytics-20260101-213114.sql`

### ⚠️ Cannot Reclaim (120.4GB)

- **Active Docker Volumes:** 120.4GB
  - All 18 volumes are in use by running containers
  - Contains actual Postgres data and application data
  - **DO NOT REMOVE** - this is your production data

## Storage Breakdown

```
Docker.raw (140GB)
├── Active Volumes: 120.4GB (86%) - CANNOT RECLAIM
├── Images: 7.185GB (5%)
│   ├── Active: 2.181GB
│   └── Unused: 5.004GB - CAN RECLAIM
├── Build Cache: 4.882GB (3%) - CAN RECLAIM
└── Overhead: ~20GB (14%) - VM overhead/fragmentation
```

## Cleanup Recommendations

### Priority 1: Quick Wins (Safe, Immediate)
1. **Remove build cache:** `docker builder prune -af`
   - Reclaims: **4.882GB**
   - Risk: None (cache can be rebuilt)

2. **Remove dangling images:** `docker image prune -f`
   - Reclaims: **~3.5GB**
   - Risk: None (these are orphaned images)

3. **Clean duplicate backups:**
   - Keep: Latest backup from each container (timestamp: 20260101-223214)
   - Remove: All older duplicates and test files
   - Reclaims: **~6.2GB**

**Total Priority 1 Reclaimable: ~14.5GB**

### Priority 2: More Aggressive (Review First)
1. **Remove unused images:** `docker image prune -a`
   - Reclaims: **5.004GB**
   - Risk: Low (but may need to rebuild images later)
   - **Review which images are unused first**

## Automated Cleanup Script

A cleanup script has been created at: `scripts/cleanup-docker-storage.sh`

**Usage:**
```bash
./scripts/cleanup-docker-storage.sh
```

**What it does:**
1. Shows current storage usage
2. Removes dangling images
3. Prunes build cache (older than 7 days)
4. Removes duplicate backup files (keeps latest)
5. Removes test backup files
6. Shows updated storage usage

## Manual Cleanup Commands

If you prefer manual cleanup:

```bash
# 1. Remove build cache
docker builder prune -af

# 2. Remove dangling images
docker image prune -f

# 3. Remove duplicate backups (keep latest)
cd backups
rm -f record-platform-postgres-1-all-20260101-{213540,213632,213712,214135,214507}.sql
rm -f test-*.sql
rm -f record-platform-postgres-analytics-1-analytics-20260101-213114.sql

# 4. (Optional) Remove all unused images (more aggressive)
docker image prune -a
```

## Monitoring Recommendations

1. **Regular Cleanup:**
   - Run cleanup script weekly
   - Monitor Docker.raw size growth

2. **Backup Management:**
   - Keep only latest backup per container
   - Archive old backups to external storage if needed
   - Consider compressing backups

3. **Docker.raw Growth:**
   - Current: 140GB
   - If it grows beyond 200GB, consider:
     - Increasing Docker Desktop disk size limit
     - More aggressive cleanup
     - Moving some volumes to external storage

## Current Backup Files (Keep These)

✅ **Latest backups (timestamp: 20260101-223214):**
- `record-platform-postgres-1-all-20260101-223214.sql` (1.0G)
- `record-platform-postgres-auth-1-all-20260101-223214.sql` (36M)
- `record-platform-postgres-social-1-all-20260101-223214.sql` (165M)
- `record-platform-postgres-listings-1-all-20260101-223214.sql` (658M)
- `record-platform-postgres-shopping-1-all-20260101-223214.sql` (16M)
- `record-platform-postgres-auction-monitor-1-all-20260101-223214.sql` (65K)
- `record-platform-postgres-analytics-1-all-20260101-223214.sql` (22K)
- `record-platform-postgres-python-ai-1-all-20260101-223214.sql` (13M)

**Total latest backups: ~1.9GB**

## Summary

- **Current Status:** ✅ Healthy (50GB available)
- **Docker.raw:** 140GB (mostly active data - 120.4GB volumes)
- **Reclaimable:** ~10-15GB (build cache, dangling images, duplicate backups)
- **Risk Level:** Low (all reclaimable items are safe to remove)
- **Recommendation:** Run cleanup script to reclaim ~14.5GB immediately

## Next Steps

1. ✅ Review this analysis
2. Run cleanup script: `./scripts/cleanup-docker-storage.sh`
3. Monitor Docker.raw size after cleanup
4. Set up regular cleanup schedule (weekly/monthly)

