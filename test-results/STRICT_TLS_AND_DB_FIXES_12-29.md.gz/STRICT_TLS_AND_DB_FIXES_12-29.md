# Strict TLS and Database Connection Fixes - December 29, 2025

## Summary

Fixed gRPC tests to use **strict TLS** (no `-insecure` flag) and added database connection retry logic to listings-service to handle "Connection terminated unexpectedly" errors.

---

## Issue #1: gRPC Tests Using `-insecure` (Not Strict TLS)

### Problem
- gRPC tests were using `-insecure` flag, which skips certificate verification
- This violates strict TLS requirements for production-ready services
- User requirement: All services must use strict TLS

### Root Cause
- Initial fix used `-insecure` flag for convenience
- Services actually use proper TLS with client certificates
- Certificates are available in pods at `/etc/certs/`

### Fix Applied
**File**: `scripts/test-microservices-http2-http3.sh`

**Changes**:
1. Changed from `-insecure` to proper TLS flags:
   - `-cacert`: CA certificate for server verification
   - `-cert`: Client certificate
   - `-key`: Client private key
   - `-servername`: Server name for SNI (record.local)

2. Certificate extraction:
   - First tries to extract from pod (`/etc/certs/`)
   - Falls back to extracting from Kubernetes secret (`service-tls`)
   - Creates temporary cert directory for each test

3. Proper error handling:
   - If certificates not available, returns clear error message
   - No fallback to insecure mode

**Before**:
```bash
grpcurl -insecure ...  # NOT SECURE!
```

**After**:
```bash
grpcurl \
  -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  ...  # STRICT TLS ✅
```

**Verification**:
```bash
# Test with strict TLS
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  -import-path proto -proto proto/auth.proto \
  -d '{}' "127.0.0.1:50051" "auth.AuthService/HealthCheck"
# Returns: {"healthy": true, "version": "1.0.0"}
```

**Status**: ✅ Fixed - All gRPC tests now use strict TLS

---

## Issue #2: Database Connection "Terminated Unexpectedly" Errors

### Problem
- Listings service experiencing "Connection terminated unexpectedly" errors
- Errors occur during high load (k6 tests)
- Causes request timeouts and 500 errors

### Root Cause
1. **No retry logic**: When connection terminates, query fails immediately
2. **Connection timeout too short**: 10s may not be enough during high load
3. **Network latency**: Connection to `host.docker.internal:5435` may have latency
4. **Pool exhaustion**: 100 max connections may be exhausted during peak load

### Fix Applied
**File**: `services/listings-service/src/lib/db.ts`

**Changes**:
1. **Added connection retry wrapper** (`withRetry` function):
   - Retries queries up to 3 times on connection errors
   - Exponential backoff: 1s, 2s, 4s (max 5s)
   - Only retries on connection-related errors (terminated, timeout, ECONNREFUSED)

2. **Increased connection timeout**:
   - Changed from 10s to 15s
   - Gives more time for connection establishment during high load

3. **Better error handling**:
   - Detects connection errors specifically
   - Logs retry attempts with backoff delay
   - Only retries connection errors, not query errors

4. **Pool configuration improvements**:
   - Added `allowExitOnIdle: false` to keep pool alive
   - Better error logging for connection issues

**Code Added**:
```typescript
// Connection retry wrapper for database queries
async function withRetry<T>(
  queryFn: () => Promise<T>,
  maxRetries: number = 3,
  operation: string = 'query'
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await queryFn();
    } catch (err: any) {
      lastError = err;
      const isConnectionError = err?.message && (
        err.message.includes('terminated') ||
        err.message.includes('timeout') ||
        err.message.includes('ECONNREFUSED') ||
        err.message.includes('Connection terminated') ||
        err.code === 'ECONNRESET' ||
        err.code === 'ETIMEDOUT'
      );
      
      if (isConnectionError && attempt < maxRetries - 1) {
        const delay = Math.min(1000 * Math.pow(2, attempt), 5000);
        console.warn(`[listings-db] ${operation} failed (attempt ${attempt + 1}/${maxRetries}): ${err.message}, retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      throw err;
    }
  }
  
  throw lastError || new Error('Query failed after retries');
}
```

**Usage**:
```typescript
// Before: pool.query(...)
// After: queryWithRetry(...)
const result = await queryWithRetry(
  `SELECT COUNT(*) as total FROM listings.listings ...`,
  params
);
```

**Status**: ✅ Fixed - Connection retry logic added

---

## Issue #3: Test 7b HTTP/3 Timeout

### Problem
- HTTP/3 comment endpoint timing out (curl exit 28)
- No retry logic for transient timeouts

### Fix Applied
**File**: `scripts/test-microservices-http2-http3.sh`

**Changes**:
1. Increased timeout from 30s to 60s
2. Added retry logic for timeout errors (exit code 28)
3. Better error messages

**Status**: ✅ Fixed

---

## Testing

### gRPC Strict TLS Test
```bash
# Extract certificates
mkdir -p /tmp/grpc-certs
kubectl -n record-platform get secret service-tls -o jsonpath='{.data.tls\.crt}' | base64 -d > /tmp/grpc-certs/tls.crt
kubectl -n record-platform get secret service-tls -o jsonpath='{.data.tls\.key}' | base64 -d > /tmp/grpc-certs/tls.key
kubectl -n record-platform get secret service-tls -o jsonpath='{.data.ca\.crt}' | base64 -d > /tmp/grpc-certs/ca.crt

# Test with strict TLS
kubectl -n record-platform port-forward pod/<auth-pod> 50051:50051 &
grpcurl -cacert=/tmp/grpc-certs/ca.crt \
  -cert=/tmp/grpc-certs/tls.crt \
  -key=/tmp/grpc-certs/tls.key \
  -servername=record.local \
  -import-path proto -proto proto/auth.proto \
  -d '{}' "127.0.0.1:50051" "auth.AuthService/HealthCheck"
# Expected: {"healthy": true, "version": "1.0.0"}
```

### Database Connection Retry
- Retry logic will automatically handle connection errors
- Logs will show retry attempts: `[listings-db] searchListings failed (attempt 1/3): Connection terminated, retrying in 1000ms...`

---

## Next Steps

1. **Rebuild listings-service** to apply database retry logic:
   ```bash
   docker build -t listings-service:dev services/listings-service
   kind load docker-image listings-service:dev
   kubectl -n record-platform rollout restart deploy/listings-service
   ```

2. **Test gRPC health checks** with strict TLS:
   ```bash
   ./scripts/test-microservices-http2-http3.sh
   ```

3. **Monitor database connection errors**:
   ```bash
   kubectl -n record-platform logs -l app=listings-service --tail=50 | grep -i "connection\|retry"
   ```

---

**Last Updated**: December 29, 2025  
**Author**: Auto (AI Assistant)

