# Test Suite Erratic Behavior Analysis (January 1, 2025)

## Issues Identified

### 1. Script Stops After Smoke Test
**Problem**: Comprehensive test suite stops after smoke test completes, never runs k6 tests

**Root Cause**:
- Script uses `set -euo pipefail` (exits on any error)
- Smoke test script may exit with non-zero code due to failures
- Even though exit code is checked with `PIPESTATUS[0]`, the script may exit before reaching Step 2

**Evidence**:
- Log shows smoke test completes
- No "Step 2" or "k6" found in log file
- Results directory exists but only contains `01-smoke-test.log`
- No k6 log files generated

**Fix Needed**: Ensure script continues even if smoke test has failures (already has warning handling, but may need to wrap in `set +e` / `set -e`)

### 2. Multiple Old Test Processes
**Problem**: Old test processes from Tuesday still running (zombie processes)

**Root Cause**: Previous test runs didn't clean up properly

**Fix Applied**: ✅ Killed old processes (79447, 79445, 79443, 79441, 79440)

### 3. Social Service 502 Errors
**Problem**: Social service returning 502 "social upstream error" for many endpoints

**Evidence**:
- Test 9f, 9g, 9h, 9i, 9j, 9k, 9l all failed with 502
- Error message: `{"error":"social upstream error"}`
- Service pod shows 19 restarts (restarted 12 minutes ago)
- Pod is currently Running

**Possible Causes**:
- Service crashing and restarting
- Database connection issues
- gRPC connection failures
- Resource exhaustion

**Action Needed**: Investigate social service logs and pod status

### 4. gRPC Tests Failing
**Problem**: Most gRPC health checks failing with "routing issue"

**Evidence**:
- Auth gRPC: ✅ Works (direct port-forward)
- Records gRPC: ❌ Fails (routing issue)
- Social, Listings, Analytics, Shopping, Auction Monitor, Python AI: ❌ All fail

**Root Cause**: Caddy NodePort gRPC routing doesn't work, but drt-forward does

**Status**: Known issue - fallback to port-forward implemented but may not be triggering correctly

### 5. Listings Service Timeouts
**Problem**: Listings service create/read operations timing out

**Evidence**:
- Test 12: Create listing timed out after 180s
- Test 12b: Create listing via HTTP/3 failed with 503
- Test 13: Get my listings failed with 503

**Root Cause**: Database connection timeouts (already has retry logic, but may not be sufficient)

## Recommendations

1. **Fix Script Continuation**: Ensure script continues to Step 2 even if smoke test has failures
   - Wrap smoke test execution in `set +e` / `set -e` block
   - Or remove `set -e` and handle errors explicitly

2. **Investigate Social Service**: Check logs and pod events to understand 502 errors
   ```bash
   kubectl -n record-platform logs -l app=social-service --tail=100
   kubectl -n record-platform describe pod -l app=social-service
   ```

3. **Improve gRPC Fallback**: Make port-forward fallback more aggressive for all services

4. **Monitor During Tests**: Use `kubectl get pods -w` to watch service health during smoke test

5. **Add Better Error Handling**: Script should log why it stopped and continue anyway for comprehensive tests
