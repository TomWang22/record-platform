# Frontend-Backend Connection Guide

This guide explains how the frontend (Next.js webapp) connects to the backend (API Gateway) and how to test the connection.

## Architecture

```
Frontend (Next.js)          Backend (API Gateway)
┌─────────────────┐         ┌──────────────────┐
│  localhost:3001 │ ──────► │  localhost:8080  │
│                 │         │  (or :4000)      │
│  webapp/        │         │  api-gateway     │
└─────────────────┘         └──────────────────┘
```

## Configuration

### Frontend Configuration

The frontend uses `lib/config.ts` to determine the API gateway URL:

```typescript
gatewayUrl: process.env.NEXT_PUBLIC_GATEWAY_URL ?? 'http://localhost:8080'
```

**Environment Variables:**
- `NEXT_PUBLIC_GATEWAY_URL` - API gateway URL (default: `http://localhost:8080`)

### Backend CORS Configuration

The API gateway (`services/api-gateway/src/server.ts`) is configured to allow requests from:

- `http://localhost:3000`
- `http://localhost:3001` (frontend default)
- `http://localhost:4000`
- `http://localhost:8080`
- `https://record.local`
- `https://record-platform.local`

CORS is enabled with credentials support for authentication.

## API Client

The frontend uses a centralized API client (`lib/api-client.ts`) that:

1. **Automatically adds authentication headers** from session tokens
2. **Handles errors consistently** with `ApiError` class
3. **Uses AbortController** for bfcache-friendly navigation
4. **Connects to** `${NEXT_PUBLIC_GATEWAY_URL}${path}`

### Usage Example

```typescript
import { apiFetch } from '@/lib/api-client'

// Public endpoint (no auth)
const health = await apiFetch('/healthz')

// Authenticated endpoint
const records = await apiFetch('/records', { auth: true })

// POST request
const newRecord = await apiFetch('/records', {
  method: 'POST',
  auth: true,
  data: { artist: 'Artist', name: 'Album', format: 'LP' }
})
```

## Connected Endpoints

### Authentication
- ✅ `POST /auth/login` - User login
- ✅ `POST /auth/register` - User registration
- ✅ `GET /whoami` - Get current user info

### Records
- ✅ `GET /records` - List records (with search query `?q=...`)
- ✅ `GET /records/:id` - Get single record
- ✅ `POST /records` - Create record
- ✅ `PUT /records/:id` - Update record
- ✅ `DELETE /records/:id` - Delete record

### Dashboard
- ✅ Dashboard page fetches records to calculate stats
- ✅ Format breakdown and collection statistics

### Other Services (via API Gateway)
- Forum posts, comments, voting
- Messages and conversations
- Shopping cart, watchlist, wishlist
- Marketplace listings
- Auction monitoring
- AI insights and predictions

## Testing the Connection

### Quick Test Script

Run the comprehensive test script:

```bash
cd webapp
./test-backend.sh
```

This script tests:
1. Health endpoint (`/healthz`)
2. CORS configuration
3. Auth endpoints (`/auth/login`, `/auth/register`)
4. Records endpoint (should return 401 without auth)
5. Whoami endpoint
6. Frontend connectivity

### Manual Testing

1. **Start the backend:**
   ```bash
   # Option 1: Kubernetes
   kubectl port-forward svc/api-gateway 8080:4000 -n record-platform
   
   # Option 2: Docker Compose
   docker-compose up api-gateway
   
   # Option 3: Direct service
   cd services/api-gateway && pnpm dev
   ```

2. **Start the frontend:**
   ```bash
   cd webapp
   pnpm install
   pnpm dev
   ```

3. **Test in browser:**
   - Open `http://localhost:3001`
   - You should see the landing page
   - Click "Get Started" to go to login
   - Register a new account or login
   - Navigate to dashboard and records

### Testing with curl

```bash
# Health check
curl http://localhost:8080/healthz

# Test CORS
curl -H "Origin: http://localhost:3001" \
     -H "Access-Control-Request-Method: POST" \
     -H "Access-Control-Request-Headers: Content-Type,Authorization" \
     -X OPTIONS \
     http://localhost:8080/records

# Test login (will fail without valid credentials, but endpoint should respond)
curl -X POST http://localhost:8080/auth/login \
     -H "Content-Type: application/json" \
     -H "Origin: http://localhost:3001" \
     -d '{"email":"test@example.com","password":"test"}'
```

## Troubleshooting

### CORS Errors

**Symptom:** Browser console shows CORS errors

**Solutions:**
1. Verify API gateway CORS configuration includes your frontend origin
2. Check that `NEXT_PUBLIC_GATEWAY_URL` matches the actual gateway URL
3. Ensure API gateway is running and accessible

### 401 Unauthorized

**Symptom:** API calls return 401 errors

**Solutions:**
1. Make sure you're logged in (check localStorage for token)
2. Verify JWT token is being sent in `Authorization` header
3. Check that auth service is running
4. Try logging out and logging back in

### Connection Refused

**Symptom:** Network errors, connection refused

**Solutions:**
1. Verify API gateway is running: `curl http://localhost:8080/healthz`
2. Check the `NEXT_PUBLIC_GATEWAY_URL` environment variable
3. Ensure all backend services are running
4. Check firewall/port forwarding settings

### 404 Not Found

**Symptom:** Endpoints return 404

**Solutions:**
1. Verify the endpoint path is correct
2. Check that the API gateway route exists
3. Ensure the backend service is running and registered

## Development Workflow

1. **Start backend services first:**
   ```bash
   # Start all services
   docker-compose up -d
   # OR
   kubectl apply -k infra/k8s/overlays/dev
   ```

2. **Port forward if using Kubernetes:**
   ```bash
   kubectl port-forward svc/api-gateway 8080:4000 -n record-platform
   ```

3. **Start frontend:**
   ```bash
   cd webapp
   pnpm dev
   ```

4. **Test connection:**
   ```bash
   cd webapp
   ./test-backend.sh
   ```

5. **Open browser:**
   ```
   http://localhost:3001
   ```

## Production Deployment

In production, the frontend and backend should be:

1. **Frontend:** Served via Caddy/nginx on `https://record.local` or your domain
2. **Backend:** API Gateway accessible via the same domain at `/api/*` or separate subdomain

Update `NEXT_PUBLIC_GATEWAY_URL` to match your production API gateway URL.

## Next Steps

- ✅ Landing page created (marketing-style, not dashboard)
- ✅ CORS configured for frontend origin
- ✅ API client configured with authentication
- ✅ Test script created
- ✅ All endpoints connected and verified

The frontend is now fully connected to the backend and ready for development!

